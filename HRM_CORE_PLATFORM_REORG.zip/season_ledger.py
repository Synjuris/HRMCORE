"""
season_ledger.py — persistent props + threads for ARW Simfeld.

This is the state layer that CastMember does NOT have. CastMember tracks
relationships, affect, and shared_jokes. It does NOT track *objects* (the blue
towel, Gerald the cactus) or *runners* (Owen's package system, Theo's
classifying habit). Without this, callbacks survive only inside the ~6-beat
rolling history window — less than one episode — so cross-episode continuity is
luck, not mechanism.

The ledger fixes that:
  - MOTIFS: persistent objects / habits / systems / minted jokes, each owned by
    a resident, with a last-seen episode and a status. The producer asks the
    ledger which callbacks are *eligible* this episode and hands them to the
    renderer instead of letting it invent (and then forget) them.
  - THREADS: open runners with a heat value. Each episode cools old threads,
    today's annoyance can open a new one, and Act 3 forces the two hottest
    open threads (owned by different people) to COLLIDE — the convergence rule
    that turns parallel runners into a payoff.

The ledger persists with to_dict/from_dict, exactly like CastMember, so it is
saved alongside the cast between episodes. That persistence IS the branch.

No dependency on the kernel. Pure stdlib. Importable and unit-testable without
the API (see __main__).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Tuple


def _slug(label: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "_", label.strip().lower()).strip("_")
    return s[:48] or "motif"


# ── Motifs: persistent objects, habits, systems, jokes ────────────────────────

@dataclass
class Motif:
    id: str
    label: str                 # "the blue towel", "Owen's package custody system"
    kind: str = "object"       # object | habit | system | joke
    owner: Optional[str] = None  # cast member name, or None for shared/building
    first_episode: int = 0
    last_episode: int = 0
    mentions: int = 0
    status: str = "active"     # active | dormant | retired

    def touch(self, episode: int):
        self.mentions += 1
        self.last_episode = episode
        if self.status == "dormant":
            self.status = "active"


# ── Threads: open runners that can heat, converge, and close ──────────────────

@dataclass
class Thread:
    id: str
    label: str                 # "Owen is tracking the building temperature"
    owner: Optional[str] = None
    heat: float = 0.5          # 0..1 — how live this runner is right now
    opened_episode: int = 0
    last_episode: int = 0
    status: str = "open"       # open | converging | closed
    collisions: int = 0        # times this runner has been a convergence pair
    last_collision_episode: int = 0
    kind: str = "building"     # building | personal (a job/date/obligation)
    pull: str = ""             # for personal threads: "out" (away) | "charged" (in)

    # A runner pays off at most this many times before it is spent and closes.
    MAX_COLLISIONS = 3
    HEAT_CAP = 0.95            # never pin at 1.0 — leaves room to rank hot threads

    def heat_up(self, amount: float, episode: int):
        # Diminishing returns: a bump adds less the hotter the thread already is,
        # so re-entering + advancing + developing the same runner can no longer
        # saturate it at the ceiling. A cold runner climbs fast; a hot one
        # barely moves.
        self.heat = min(self.HEAT_CAP, self.heat + amount * (1.0 - self.heat))
        self.last_episode = episode
        # A runner closed by cooling can revive if it comes up again, but one
        # that was RETIRED (paid off MAX_COLLISIONS times) stays spent.
        if self.status == "closed" and self.collisions < self.MAX_COLLISIONS:
            self.status = "open"


class SeasonLedger:
    """Season-level continuity store. One per season, persisted between episodes."""

    def __init__(self):
        self.motifs: Dict[str, Motif] = {}
        self.threads: Dict[str, Thread] = {}

    # ── motifs ────────────────────────────────────────────────────────────────
    def register_motif(self, label: str, episode: int, kind: str = "object",
                        owner: Optional[str] = None) -> Motif:
        mid = _slug(label)
        m = self.motifs.get(mid)
        if m is None:
            m = Motif(id=mid, label=label, kind=kind, owner=owner,
                      first_episode=episode, last_episode=episode, mentions=1)
            self.motifs[mid] = m
        else:
            m.touch(episode)
            if owner and not m.owner:
                m.owner = owner
        return m

    def available_callbacks(self, episode: int, limit: int = 3) -> List[Motif]:
        """Eligible callbacks: motifs with real history, not already used THIS
        episode, favoring ones that have been quiet for an episode or two (a
        callback lands harder when it's been gone for a beat). Retired motifs
        never return."""
        pool = [
            m for m in self.motifs.values()
            if m.status != "retired"
            and m.mentions >= 1
            and m.last_episode < episode
        ]

        def score(m: Motif) -> float:
            gap = episode - m.last_episode          # episodes since last seen
            recency = 1.0 if gap == 1 else (0.7 if gap == 2 else 0.4)
            history = min(1.0, m.mentions / 4.0)    # established props score higher
            return recency + history

        pool.sort(key=score, reverse=True)
        return pool[:limit]

    # ── threads ─────────────────────────────────────────────────────────────
    def open_thread(self, label: str, episode: int, owner: Optional[str] = None,
                    heat: float = 0.55, kind: str = "building",
                    pull: str = "") -> Thread:
        tid = _slug(label)
        t = self.threads.get(tid)
        if t is None:
            t = Thread(id=tid, label=label, owner=owner, heat=heat,
                       opened_episode=episode, last_episode=episode,
                       kind=kind, pull=pull)
            self.threads[tid] = t
        else:
            t.heat_up(heat * 0.5, episode)
            if owner and not t.owner:
                t.owner = owner
            if pull:
                t.pull = pull
        return t

    def personal_threads(self) -> List[Thread]:
        return [t for t in self.open_threads() if t.kind == "personal"]

    def open_threads(self) -> List[Thread]:
        return [t for t in self.threads.values() if t.status in ("open", "converging")]

    def cool_threads(self, decay: float = 0.55, episode: int = 0):
        """Run once per episode BEFORE assembling beats. Stronger than before so
        the heat economy cannot ratchet. BUT a runner that has already paid off
        at least once (an active arc) is not euthanized by the cold floor — it
        simmers so the convergence engine can revisit it later. Only a fresh
        annoyance that never collided and went cold is closed here; retired
        runners (MAX_COLLISIONS) are closed in record_collision."""
        for t in self.threads.values():
            if t.status == "closed":
                continue
            d = decay
            if episode and t.last_collision_episode == episode - 1:
                d = min(0.80, decay + 0.15)   # softened from +0.25
            t.heat *= (1.0 - d)
            if t.status == "converging":
                t.status = "open"
            if t.kind == "personal":
                # outside-life obligations are ephemeral — a date passes, a shift
                # ends. They are always disposable, even after a collision, so
                # they don't accumulate into an immortal pile.
                if t.heat < 0.12:
                    t.status = "closed"
            elif t.collisions == 0:
                # a fresh building annoyance that fizzled before ever landing
                if t.heat < 0.12:
                    t.status = "closed"
            else:
                # a building arc that has paid off at least once: simmer so the
                # convergence engine can revisit it; fatigue ranking stops it
                # from dominating.
                t.heat = max(t.heat, 0.15)

    def close_thread(self, thread_id: str):
        t = self.threads.get(thread_id)
        if t:
            t.status = "closed"

    def record_collision(self, thread_ids: List[str], episode: int):
        """Call AFTER a convergence beat is produced. The collision is the
        payoff, so it COOLS the runners (they just had their moment) and counts
        toward retirement. After MAX_COLLISIONS a runner is spent and closes,
        freeing the season to find new friction instead of re-colliding the same
        two people forever."""
        for tid in thread_ids:
            t = self.threads.get(tid)
            if not t:
                continue
            t.collisions += 1
            t.last_collision_episode = episode
            t.heat *= 0.55          # softened from 0.40 — keeps marquee arcs alive
            if t.collisions >= Thread.MAX_COLLISIONS:
                t.status = "closed"

    def pick_convergence(self, episode: int = 0) -> Optional[Tuple[Thread, Thread]]:
        """Choose two open threads owned by DIFFERENT residents to collide,
        ranked by heat MINUS fatigue. A thread that has collided often, or that
        collided last episode, is penalized so the pairing rotates instead of
        pinning on the same doorway every week."""
        def rank(t: Thread) -> float:
            fatigue = 0.22 * t.collisions
            recent = 0.30 if (episode and t.last_collision_episode == episode - 1) else 0.0
            return t.heat - fatigue - recent

        live = sorted(self.open_threads(), key=rank, reverse=True)
        if len(live) < 2:
            return None
        a = live[0]
        partners = [t for t in live[1:] if t.owner != a.owner]
        if not partners:
            partners = live[1:]
        # Gentle cross-domain preference: a building runner colliding with a
        # personal one (a date, a shift, a deadline) is the comedy this layer
        # exists for. Prefer an opposite-kind partner if it is competitive
        # (within a small heat band of the best available partner).
        best = rank(partners[0])
        cross = [t for t in partners if t.kind != a.kind and rank(t) >= best - 0.20]
        b = cross[0] if cross else partners[0]
        a.status = b.status = "converging"
        return a, b

    # ── prompt-facing summaries ───────────────────────────────────────────────
    def callbacks_brief(self, episode: int, limit: int = 3) -> str:
        cbs = self.available_callbacks(episode, limit)
        if not cbs:
            return "AVAILABLE CALLBACKS: none yet."
        lines = [f"- {m.label} ({m.kind}" + (f", {m.owner}'s" if m.owner else "") +
                 f", last seen ep {m.last_episode})" for m in cbs]
        return "AVAILABLE CALLBACKS (reuse one if it fits; do not invent new history):\n" + "\n".join(lines)

    def threads_brief(self) -> str:
        live = sorted(self.open_threads(), key=lambda t: t.heat, reverse=True)
        if not live:
            return "OPEN RUNNERS: none."
        lines = [f"- {t.label}" + (f" [{t.owner}]" if t.owner else "") +
                 f" (heat {t.heat:.2f})" for t in live[:5]]
        return "OPEN RUNNERS (ongoing situations these people are already living):\n" + "\n".join(lines)

    # ── ingest renderer output ────────────────────────────────────────────────
    def absorb_beat(self, result: dict, episode: int):
        """Register anything the renderer surfaced. Optional fields — degrades
        gracefully if the model omits them, because the producer also seeds
        threads/motifs explicitly from the skeleton."""
        for nm in (result.get("new_motifs") or []):
            if isinstance(nm, dict) and nm.get("label"):
                self.register_motif(nm["label"], episode,
                                    kind=nm.get("kind", "object"),
                                    owner=nm.get("owner"))
            elif isinstance(nm, str):
                self.register_motif(nm, episode)
        for label in (result.get("referenced_motifs") or []):
            if isinstance(label, str):
                m = self.motifs.get(_slug(label))
                if m:
                    m.touch(episode)
        for nt in (result.get("new_threads") or []):
            if isinstance(nt, dict) and nt.get("label"):
                self.open_thread(nt["label"], episode, owner=nt.get("owner"),
                                 heat=float(nt.get("heat", 0.55)))
        for label in (result.get("advanced_threads") or []):
            t = self.threads.get(_slug(label)) if isinstance(label, str) else None
            if t:
                t.heat_up(0.15, episode)
        for label in (result.get("closed_threads") or []):
            if isinstance(label, str):
                self.close_thread(_slug(label))

    # ── persistence ───────────────────────────────────────────────────────────
    def to_dict(self) -> dict:
        return {
            "motifs": {k: asdict(v) for k, v in self.motifs.items()},
            "threads": {k: asdict(v) for k, v in self.threads.items()},
        }

    @classmethod
    def from_dict(cls, d: dict) -> "SeasonLedger":
        led = cls()
        for k, v in (d.get("motifs") or {}).items():
            led.motifs[k] = Motif(**v)
        for k, v in (d.get("threads") or {}).items():
            led.threads[k] = Thread(**v)
        return led


# ── offline smoke test (no API) ───────────────────────────────────────────────
if __name__ == "__main__":
    led = SeasonLedger()

    # Episode 1 establishes some props and runners.
    led.register_motif("the blue towel", 1, kind="object")
    led.register_motif("Gerald the cactus", 1, kind="object", owner="Gabe")
    led.open_thread("Owen reorganized the package shelf", 1, owner="Owen", heat=0.7)
    led.open_thread("Lena keeps rescuing plants", 1, owner="Lena", heat=0.5)

    # Episode 2: cool, then see what's eligible to come back / collide.
    led.cool_threads()
    print(led.callbacks_brief(2))
    print()
    print(led.threads_brief())
    print()
    conv = led.pick_convergence()
    print("CONVERGENCE:", (conv[0].label, conv[1].label) if conv else None)

    # Persistence round-trip.
    import json
    blob = json.dumps(led.to_dict())
    led2 = SeasonLedger.from_dict(json.loads(blob))
    assert led2.motifs.keys() == led.motifs.keys()
    assert led2.threads.keys() == led.threads.keys()
    print("\npersistence round-trip OK —", len(led2.motifs), "motifs,",
          len(led2.threads), "threads")
