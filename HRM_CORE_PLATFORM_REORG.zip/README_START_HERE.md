
# HRM Core Platform Reorganization

This package reorganizes HRM into a core engine plus separate apps.

## What changed

```text
hrm_core/                  # base engine / kernel
apps/hrm_studio/            # generic HRM control/demo app
apps/plague_world_map/      # Plague Inc style generic map app
apps/jackson_city_twin/     # Jackson-specific app
apps/arw/                   # Agentic Real World app
apps/simfeld/               # Simfeld app
apps/future_app_template/   # starter pattern for new apps
legacy_hrm_v4_57/source/    # original source preserved untouched
outputs/                    # generated states/reports
```

## Important rule

Do not keep stapling features onto the HRM root. New products go under `/apps` and talk to `/hrm_core`.

## First test

Double-click:

```text
RUN_HRM_STUDIO_DEMO.bat
```

It creates:

```text
outputs/hrm_studio_demo_state.json
```

## App launchers

- `RUN_HRM_STUDIO_DEMO.bat` — tests the clean core engine.
- `RUN_PLAGUE_WORLD_MAP.bat` — launches the generic map app.
- `RUN_JACKSON_CITY_TWIN.bat` — launches the Jackson app.
- `RUN_ARW_APP.bat` — launches ARW legacy episode runner.
- `RUN_SIMFELD_APP.bat` — launches Simfeld wrapper.

## Current status

This is a structural reorganization package. It preserves the old source and creates the new engine boundary. Some legacy apps may still use their old internal imports until the next migration pass. The point of this package is to stop the growth pattern and give everything a clean place to live.
