
# HRM Migration Plan

## Phase 1 — Boundary Lock
Complete in this package.
- HRM Core exists.
- Apps exist separately.
- Legacy source preserved.
- Launchers created.

## Phase 2 — Engine Extraction
Move real legacy engines from `legacy_hrm_v4_57/source` into `hrm_core` module by module:
- population
- affect / cognition
- memory
- institutions
- environment
- policy injection
- generational memory
- export/replay

## Phase 3 — App Refactor
Update each app so it imports only from `hrm_core`:
- Jackson app becomes data + map + calibration shell.
- Simfeld app becomes narrative shell.
- ARW app becomes episode/social shell.
- Plague map app becomes visual shell.

## Phase 4 — Product Layer
Build separate distributable products:
- HRM Studio
- HRM City Twin
- HRM Plague Map
- HRM Story Engine
- HRM Scenario Lab
