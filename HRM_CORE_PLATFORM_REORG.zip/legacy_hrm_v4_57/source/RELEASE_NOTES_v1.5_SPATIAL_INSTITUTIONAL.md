# HRM_UNIFIED v1.5 — Spatial & Institutional Dynamics

## Purpose

v1.5 adds geography-agnostic spatial structure and generic institutional nodes to the calibrated synthetic panel.

This version does **not** embed any personal, local, or real-city assumptions. Districts and institutions are abstract civic archetypes.

## Added

- `population/spatial.py`
  - abstract district profiles
  - abstract institution profiles
  - agent home/work district assignment
  - movement/exposure probabilities
  - spatial exposure scaling
  - district-level response summaries
  - hotspot scoring

- `run_spatial_panel.py`
  - command-line spatial/institutional response demo

- `spatial_benchmark.py`
  - deterministic v1.5 benchmark with fingerprint output

## Changed

- `CalibratedPanel` now includes:
  - generic districts
  - generic institutions
  - agent location assignments
  - spatial exposure modifiers
  - hotspot report output

- Report exports now include spatial hotspot tables when available.

## Validation

Verified commands:

```bash
python validate_engine.py --output-dir outputs/validation_v1_5_check
python run_spatial_panel.py "An employer announces layoffs affecting the industrial district and nearby households." --n 250 --ticks 20 --no-raw
python spatial_benchmark.py
```

## Scope Boundary

This version models locality-dependent propagation, not real-world prediction.
