#!/usr/bin/env python3
"""Deterministic benchmark for HRM_UNIFIED v2.2 endogenous DAS feedback."""
from __future__ import annotations

try:
    from .environment import SyntheticCivicEnvironment, EnvironmentConfig
    from .population.history import default_timeline
except ImportError:
    from environment import SyntheticCivicEnvironment, EnvironmentConfig
    from population.history import default_timeline


def run_env(feedback: bool):
    cfg = EnvironmentConfig(
        population_size=300,
        seed=222,
        das_bridge_enabled=True,
        das_feedback_enabled=feedback,
        das_bridge_inertia=0.78,
        das_feedback_strength=0.45,
    )
    env = SyntheticCivicEnvironment(config=cfg)
    paths = env.run_timeline(
        default_timeline(),
        output_dir="outputs/endogenous_benchmark_feedback" if feedback else "outputs/endogenous_benchmark_bridge_only",
        name="endogenous_feedback_on" if feedback else "bridge_only",
        build_observatory=False,
    )
    return env, paths


def main() -> int:
    bridge_only, _ = run_env(False)
    feedback_on, paths = run_env(True)
    a = bridge_only.sim.tracker.state.summary()
    b = feedback_on.sim.tracker.state.summary()
    deltas = {k: round(float(b.get(k, 0.0)) - float(a.get(k, 0.0)), 6) for k in sorted(set(a) | set(b))}
    if not any(abs(v) > 0.000001 for v in deltas.values()):
        raise AssertionError("Endogenous feedback did not change later civic baselines")
    if feedback_on.das_feedback is None:
        raise AssertionError("DAS feedback state missing")
    st = feedback_on.das_feedback.state.to_dict()
    required = ["baseline_modifiers", "active_factions", "innovation_markers", "cultural_markers", "generational_memory_index"]
    missing = [k for k in required if k not in st]
    if missing:
        raise AssertionError(f"Missing endogenous state keys: {missing}")
    print("HRM_UNIFIED v2.2 endogenous evolution benchmark: PASS")
    print(f"Feedback fingerprint: {feedback_on.das_feedback.state.fingerprint()[:16]}")
    print(f"Final deltas vs bridge-only: {deltas}")
    print(f"Manifest summary: {paths.get('summary_json')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
