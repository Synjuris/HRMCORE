# v4.35 Generational Transmission Audit

## Problem corrected
Before v4.35, children inherited blended traits with mutation noise, but parental developmental trauma did not meaningfully bias the child's starting psychological conditions. A parent with severe scarring could produce a child from the same broad initialization range as everyone else.

## Correction
v4.35 adds probabilistic psychological transmission:

- parental scar/stress/fear/trust burden is measured
- household emotional risk is measured
- protective care buffers the effect
- the child's baseline traits are shifted within bounded ranges

## Non-determinism guard
The child is not assigned the parent's trauma. The child receives a changed probability profile:

- trust_baseline may start lower under high inherited risk
- conflict_sensitivity may start higher
- avoidance_rate may start higher
- resilience/recovery_speed may start lower
- protective care can offset those pressures

This preserves emergence and prevents hardcoded fate.

## Feedback loops added

### Oral tradition
Knowledge/information-capable agents can transmit warning or resilience stories. These affect fear/trust/cooperation priors in nearby listeners.

### Care recovery
Care-family agents can target high-scar/high-stress individuals and reduce stress/scar load while restoring trust/recovery speed.

## Files changed
- `das/generational_psychology.py` added
- `das/reproduction.py` modified
- `das/run_sim.py` modified

## Output artifacts
Each run now writes:
- `generational_psychology_ledger.json`
- summary fields prefixed with `psych_transmission_`
