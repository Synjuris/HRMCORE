# v4.54 — K2-3C: observe() Infrastructure

## Summary

Adds `observe(tick, runtime)` hook to the subsystem protocol.
Called during the METRICS phase after all `step()` calls complete.
Non-mutating by convention — records metrics only, must not alter simulation state.

## What changed

**das/kernel/system_registry.py**
- `SubsystemSpec`: added optional `observe_fn` field (default `None`)
- `RegisteredSystem`: added `observe_fn` field
- `SystemRegistry.run_observers(tick, runtime)`: new method — iterates all
  registered subsystems, calls `observe_fn(tick, runtime)` on those that have
  one, skips silently otherwise. Errors are caught and printed, not fatal.
- `execution_plan()`: now includes `has_observer` boolean per entry

**das/kernel/runtime.py**
- METRICS phase: `run_observers(tick, self)` called immediately after
  `run_phase("METRICS", tick, self)`

## What did NOT change

- No simulation logic altered
- No existing runners modified
- No agent state touched
- No behavior mutation of any kind
- All subsystems without `observe_fn` behave identically to pre-patch

## Protocol

Subsystems may optionally expose:

```python
def observe(self, tick, runtime):
    pass  # non-mutating metrics hook — implement in K2-3C+
```

Register via:

```python
registry.register_spec(SubsystemSpec(
    name="my_system",
    phase="GOVERNANCE",
    fn=my_system.step,
    observe_fn=my_system.observe,   # optional
))
```

## Verification

- `SubsystemSpec` accepts `observe_fn`, defaults to `None`
- `run_observers()` calls only subsystems with `observe_fn` set
- Subsystems without `observe_fn` skipped silently — zero behavior change
- `execution_plan()` reports `has_observer` correctly
- All checks passed in isolation test

## Not in this patch

- No CognitionObserver
- No LLM calls
- No readable thoughts
- No benchmark harness

CognitionObserver is K2-3C+, separate patch, after v4.54 is verified.

## Next

K2-3C verification: run same seed/config before and after. Confirm metrics
and checkpoint state identical. Then K2-3C+ (CognitionObserver). Then K2-3D.
