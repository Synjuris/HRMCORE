#!/usr/bin/env python3
"""Run HRM_UNIFIED v2.5 institutional evolution layer."""
from __future__ import annotations

import argparse

try:
    from .population.history import HistoricalSimulator, load_timeline
    from .population.policy import load_policy_definitions, DEFAULT_POLICIES
    from .constitution import ConstitutionEngine
    from .generational_memory import GenerationalMemoryEngine, _summary_from_state
    from .institutional_evolution import InstitutionalEvolutionEngine, InstitutionalRunReport, institutional_markdown
    from .export_utils import ensure_dir
except ImportError:
    from population.history import HistoricalSimulator, load_timeline
    from population.policy import load_policy_definitions, DEFAULT_POLICIES
    from constitution import ConstitutionEngine
    from generational_memory import GenerationalMemoryEngine, _summary_from_state
    from institutional_evolution import InstitutionalEvolutionEngine, InstitutionalRunReport, institutional_markdown
    from export_utils import ensure_dir


def main() -> int:
    ap = argparse.ArgumentParser(description="Run long-run synthetic civic simulation with generational memory and institutional evolution.")
    ap.add_argument("timeline", nargs="?", help="Optional timeline JSON/YAML. Defaults to built-in generic timeline.")
    ap.add_argument("--policies", help="Optional policy definition JSON.")
    ap.add_argument("--n", type=int, default=600)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--profile", default="generic_mixed_region")
    ap.add_argument("--decay", type=float, default=0.86)
    ap.add_argument("--generations", type=int, default=5)
    ap.add_argument("--cultural-decay", type=float, default=0.72)
    ap.add_argument("--institutional-decay", type=float, default=0.88)
    ap.add_argument("--cohort-turnover", type=float, default=0.30)
    ap.add_argument("--inheritance-strength", type=float, default=0.42)
    ap.add_argument("--mutation-rate", type=float, default=0.38)
    ap.add_argument("--legitimacy-inertia", type=float, default=0.82)
    ap.add_argument("--reform-threshold", type=float, default=0.62)
    ap.add_argument("--collapse-threshold", type=float, default=0.86)
    ap.add_argument("--output-dir", default="outputs/institutional_evolution_v2_5")
    ap.add_argument("--name", default="institutional_evolution_run")
    args = ap.parse_args()

    policies = load_policy_definitions(args.policies) if args.policies else DEFAULT_POLICIES
    timeline = load_timeline(args.timeline)
    memory = GenerationalMemoryEngine(
        cultural_decay=args.cultural_decay,
        institutional_decay=args.institutional_decay,
        cohort_turnover=args.cohort_turnover,
        inheritance_strength=args.inheritance_strength,
    )
    institutions = InstitutionalEvolutionEngine(
        mutation_rate=args.mutation_rate,
        legitimacy_inertia=args.legitimacy_inertia,
        reform_threshold=args.reform_threshold,
        collapse_threshold=args.collapse_threshold,
    )

    epochs = []
    constitution_failures = 0

    for gen in range(1, max(1, args.generations) + 1):
        sim = HistoricalSimulator(n=args.n, seed=args.seed + gen - 1, profile=args.profile, decay=args.decay, policies=policies)
        memory.apply_baseline_to_simulator(sim)
        institutions.apply_to_simulator(sim)
        result = sim.run(timeline, name=f"{args.name}_generation_{gen}")
        audit = ConstitutionEngine().audit_historical_result(result)
        if not audit.passed:
            constitution_failures += 1
        summary = _summary_from_state(result.final_state)
        encoded = memory.encode_result(result, generation_label=f"generation_{gen}")
        epoch = institutions.evolve(memory.to_dict(), summary, generation=gen, label=str(timeline.get("name") or "default_timeline"))
        epoch.constitution_passed = audit.passed
        epochs.append(epoch)

    final_institutions = institutions.to_dict().get("institutions", [])
    mutation_total = sum(len(e.mutations) for e in epochs)
    collapse_max = max([float(i.get("collapse_risk", 0.0)) for i in final_institutions] or [0.0])
    legitimacy_avg = round(sum(float(i.get("legitimacy", 0.0)) for i in final_institutions) / max(1, len(final_institutions)), 6)
    benchmark = {
        "generations": len(epochs),
        "constitution_failures": constitution_failures,
        "institution_count": len(final_institutions),
        "mutation_total": mutation_total,
        "final_equilibrium": institutions.classify_equilibrium(),
        "average_legitimacy": legitimacy_avg,
        "max_collapse_risk": round(collapse_max, 6),
        "final_institution_fingerprint": institutions.to_dict().get("fingerprint"),
        "final_memory_fingerprint": memory.to_dict().get("fingerprint"),
    }
    report = InstitutionalRunReport("2.5", args.name, epochs, final_institutions, benchmark)

    out = ensure_dir(args.output_dir)
    json_path = out / "institutional_evolution_report.json"
    md_path = out / "institutional_evolution_report.md"
    json_path.write_text(report.to_json(), encoding="utf-8")
    md_path.write_text(institutional_markdown(report), encoding="utf-8")

    print("HRM_UNIFIED v2.5 INSTITUTIONAL EVOLUTION")
    print(f"Generations: {len(epochs)}")
    print(f"Mutations: {mutation_total}")
    print(f"Final equilibrium: {benchmark['final_equilibrium']}")
    print(f"Final institution fingerprint: {benchmark['final_institution_fingerprint'][:16]}")
    print("Wrote:")
    print("  json:", json_path)
    print("  markdown:", md_path)
    return 0 if constitution_failures == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())
