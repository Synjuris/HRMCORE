# HRM v4.57 — Jackson City Twin Upgrade

This package adds a rebuilt Jackson, Tennessee city-twin layer to HRM.

It does **not** merely copy the old Living Jackson app into HRM. It turns Living Jackson into an HRM-compatible data/calibration layer.

## What was integrated

- `hrm_city_twin/` — new HRM module for city-twin generation.
- Synthetic households, residents, places, routes, schedules, stress/trust/uncertainty seeds.
- Jackson anchors: neighborhoods, workplaces, school clusters, amenities, civic anchors.
- HRM export bridge:
  - `profiles/jackson_tn_city_twin_profile.json`
  - `scenarios/jackson_tn_jackson_routine_baseline.json`
  - `outputs/city_twin/jackson_tn/agent_seeds.json`
  - `outputs/city_twin/jackson_tn/snapshot.json`
  - `outputs/city_twin/jackson_tn/calibration_report.json`
- Living Jackson source preserved for audit under `hrm_city_twin/vendor_living_jackson/` with `.env` excluded.
- Real-data adapters copied into `data/city_twin/jackson/`:
  - `acs_pums_ipf.py`
  - `lodes_ingest.py`
  - `osmnx_graph.py`
  - Living Jackson calibration modules
  - `one_jackson_scenario.json`

## Run it

From the HRM folder:

```bat
RUN_CITY_TWIN_JACKSON_WINDOWS_SAFE.bat
```

For a fast smoke test:

```bat
RUN_CITY_TWIN_JACKSON_SMOKE_TEST.bat
```

## What this gives HRM

This produces a city layer HRM can consume:

1. Synthetic residents are not random blobs. They carry home, schedule, destination, mode, income band, neighborhood, stress, uncertainty, institutional trust, and trait seeds.
2. Routes are generated from home-to-destination flows and aggregated into route-load objects.
3. Calibration report summarizes age bands, mode share, destination share, neighborhood distribution, income band distribution, trust, stress, and uncertainty.
4. Scenario file gives HRM a routine daily baseline: morning departure, midday service load, return commute.

## Important limitation

The dependency-free bundled runner uses anchor geometry and synthetic residents. It is a **city-twin seed layer**, not parcel-accurate GIS.

The old Living Jackson real-data scripts are included, but real Census/LODES/OSM fetching requires internet and optional packages. The architecture is now ready for that, but this package does not pretend downloaded data exists when it does not.

## Key point

HRM v4.57 already had a generic `city_twin.py`. This upgrade leaves it intact and adds the more specific, usable Jackson layer beside it.
