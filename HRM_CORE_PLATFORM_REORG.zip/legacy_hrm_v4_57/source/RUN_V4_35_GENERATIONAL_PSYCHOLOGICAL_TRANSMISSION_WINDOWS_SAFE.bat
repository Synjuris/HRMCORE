@echo off
setlocal
cd /d "%~dp0"
set DAS_OUTPUT_ROOT=runs_v04_35
set DAS_RUNS=1
set DAS_TICKS=500
python das\run_sim.py
pause
