# HRM_UNIFIED v2.0 — Synthetic Civic Environment

v2.0 consolidates prior scenario, policy, history, and observatory tools into one persistent synthetic civic environment.

## Added

- `environment.py` persistent environment layer
- `run_environment.py` unified environment command
- `environment_benchmark.py` resume/branch smoke benchmark
- environment snapshot save/load support
- run history records
- environment fingerprints
- local observatory export per environment run
- demo timeline and environment config template

## Boundary rules

- No personal facts are embedded.
- No locality-specific baseline is embedded.
- No API keys are embedded.
- Real data remains optional through external adapters/config.
- The system remains a synthetic modeling environment, not a prediction engine.
