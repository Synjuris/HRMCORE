@echo off
setlocal ENABLEDELAYEDEXPANSION
cd /d "%~dp0"
echo ============================================================
echo HRM_UNIFIED v2.9 - World Inspection Dashboard
echo Folder: %CD%
echo ============================================================
echo.
set PYTHON_CMD=
where py >nul 2>nul
if %ERRORLEVEL%==0 set PYTHON_CMD=py -3
if "%PYTHON_CMD%"=="" (
  where python >nul 2>nul
  if !ERRORLEVEL!==0 set PYTHON_CMD=python
)
if "%PYTHON_CMD%"=="" (
  where python3 >nul 2>nul
  if !ERRORLEVEL!==0 set PYTHON_CMD=python3
)
if "%PYTHON_CMD%"=="" (
  echo ERROR: Python was not found.
  echo Install Python 3, then run this file again.
  pause
  exit /b 1
)
echo Using Python command: %PYTHON_CMD%
%PYTHON_CMD% --version
if not exist outputs mkdir outputs
if not exist outputs\human_social_dynamics_v2_8\default_world\world_state_latest.json (
  echo.
  echo No v2.8 world checkpoint found yet.
  echo Creating a small sample world first so the dashboard has something to inspect...
  %PYTHON_CMD% run_human_social_dynamics.py --cycles 1 --generations-per-cycle 1 --autosave-every 1 --world-id default_world --output-dir outputs/human_social_dynamics_v2_8
  if !ERRORLEVEL! NEQ 0 (
    echo ERROR: Could not create sample world. Dashboard will still try to open.
  )
)
echo.
echo Opening local dashboard. Press CTRL+C in this window to stop the dashboard server.
%PYTHON_CMD% run_world_dashboard.py --world-dir outputs/human_social_dynamics_v2_8/default_world --port 8765
set EXITCODE=%ERRORLEVEL%
echo.
echo Dashboard exited with code %EXITCODE%.
pause
exit /b %EXITCODE%
