@echo off
cd /d "%~dp0"
echo Starting HRM ARW Simfeld mode...
py agentic_real_world\run_episode.py
pause
