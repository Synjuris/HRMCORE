# HRM_UNIFIED v1.4 — Validation Harness

Purpose: prove deterministic directional coherence before adding dashboards, maps, or deeper emergence layers.

Added:
- `validate_engine.py`
- `validation/validation_scenarios.json`
- 10 fixed generic validation scenarios
- directional checks for valence, belief, and stress
- coherence checks for shock accumulation and decay
- deterministic fingerprint generation
- JSON, CSV, and Markdown validation reports

Run:

```bash
python validate_engine.py
```

Optional:

```bash
python validate_engine.py --n 1000 --seed 42 --ticks 45
```

Boundary:
This validates internal simulation coherence only. It does not claim real-world prediction accuracy.
No locality-specific or personal assumptions were added.
