"""Controlled HRM/DAS bridge for HRM_UNIFIED v2.1.

This module does not dump the legacy DAS agent simulation into the civic engine.
It creates a narrow, inspectable translation layer:

    HRM civic pressures -> DAS substrate pressures -> slow structural evolution

The bridge is generic and deterministic. It contains no locality-specific,
personal, or API-key values. It is intended as the first safe coupling point
between the HRM civic-state layer and DAS-style long-horizon emergence.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional
import hashlib
import json


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(x)))


def _canonical(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


@dataclass
class DASSurfacePressures:
    """Signals translated from HRM's civic layer into DAS-facing inputs."""

    economic_stress: float = 0.0
    institutional_strain: float = 0.0
    faction_volatility_pressure: float = 0.0
    cooperation_pressure: float = 0.0
    innovation_pressure: float = 0.0
    migration_pressure: float = 0.0
    cultural_drift_pressure: float = 0.0
    recovery_pressure: float = 0.0

    def to_dict(self) -> Dict[str, float]:
        return {k: round(float(v), 6) for k, v in asdict(self).items()}


@dataclass
class DASEvent:
    step_index: int
    kind: str
    severity: float
    message: str
    context: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class DASEvolutionState:
    """Slow substrate state used by the bridge.

    These values are not claims about a real society. They are traceable,
    bounded synthetic state variables designed to receive HRM pressure signals.
    """

    structural_stress: float = 0.0
    institutional_adaptation: float = 0.0
    faction_volatility: float = 0.0
    cooperation_capacity: float = 0.5
    innovation_momentum: float = 0.0
    migration_tendency: float = 0.0
    cultural_drift: float = 0.0
    resilience_memory: float = 0.0
    step_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {k: (round(float(v), 6) if isinstance(v, float) else v) for k, v in asdict(self).items()}

    def fingerprint(self) -> str:
        return hashlib.sha256(_canonical(self.to_dict()).encode("utf-8")).hexdigest()


@dataclass
class DASBridgeReport:
    pressures: DASSurfacePressures
    state_before: DASEvolutionState
    state_after: DASEvolutionState
    events: List[DASEvent]
    fingerprint: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "pressures": self.pressures.to_dict(),
            "state_before": self.state_before.to_dict(),
            "state_after": self.state_after.to_dict(),
            "events": [e.to_dict() for e in self.events],
            "fingerprint": self.fingerprint,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)


def translate_hrm_to_das(result: Any) -> DASSurfacePressures:
    """Translate a HistoricalRunResult-like object into DAS-facing pressures."""
    state = result.final_state.summary() if hasattr(result.final_state, "summary") else dict(result.final_state)

    stress = float(state.get("stress_pressure", state.get("stress", 0.0)))
    trust_loss = float(state.get("trust_loss", state.get("institutional_trust_loss", 0.0)))
    instability = float(state.get("instability_pressure", state.get("instability", 0.0)))
    withdrawal = float(state.get("withdrawal_pressure", state.get("withdrawal", 0.0)))
    recovery = float(state.get("recovery_pressure", state.get("recovery", 0.0)))
    cooperation = float(state.get("cooperation_pressure", state.get("cooperation", 0.0)))

    event_count = len(getattr(result, "events", []) or [])
    cost = float(getattr(result, "total_cost_units", 0.0) or 0.0)

    economic = _clamp(stress * 0.60 + withdrawal * 0.20)
    institutional = _clamp(trust_loss * 0.70 + instability * 0.20)
    faction = _clamp(instability * 0.55 + trust_loss * 0.25 + min(event_count / 20.0, 0.20))
    coop = _clamp(cooperation + recovery * 0.35 - stress * 0.15)
    innovation = _clamp(stress * 0.25 + recovery * 0.25 + min(cost / 100.0, 0.20))
    migration = _clamp(withdrawal * 0.45 + stress * 0.25 + institutional * 0.10)
    culture = _clamp(faction * 0.35 + recovery * 0.20 + abs(cooperation - stress) * 0.15)

    return DASSurfacePressures(
        economic_stress=economic,
        institutional_strain=institutional,
        faction_volatility_pressure=faction,
        cooperation_pressure=coop,
        innovation_pressure=innovation,
        migration_pressure=migration,
        cultural_drift_pressure=culture,
        recovery_pressure=_clamp(recovery),
    )


class DASBridge:
    """Slow, bounded DAS substrate updater."""

    def __init__(self, state: Optional[DASEvolutionState] = None, inertia: float = 0.82):
        self.state = state or DASEvolutionState()
        self.inertia = _clamp(inertia, 0.0, 0.98)
        self.events: List[DASEvent] = []

    def _blend(self, old: float, target: float) -> float:
        return _clamp(old * self.inertia + target * (1.0 - self.inertia))

    def ingest(self, result: Any) -> DASBridgeReport:
        pressures = translate_hrm_to_das(result)
        before = DASEvolutionState(**self.state.to_dict())
        p = pressures

        self.state.step_count += 1
        self.state.structural_stress = self._blend(self.state.structural_stress, p.economic_stress)
        self.state.institutional_adaptation = self._blend(
            self.state.institutional_adaptation,
            _clamp(p.institutional_strain * 0.45 + p.innovation_pressure * 0.35 + p.recovery_pressure * 0.20),
        )
        self.state.faction_volatility = self._blend(self.state.faction_volatility, p.faction_volatility_pressure)
        self.state.cooperation_capacity = self._blend(
            self.state.cooperation_capacity,
            _clamp(0.50 + p.cooperation_pressure * 0.35 + p.recovery_pressure * 0.20 - p.faction_volatility_pressure * 0.25),
        )
        self.state.innovation_momentum = self._blend(self.state.innovation_momentum, p.innovation_pressure)
        self.state.migration_tendency = self._blend(self.state.migration_tendency, p.migration_pressure)
        self.state.cultural_drift = self._blend(self.state.cultural_drift, p.cultural_drift_pressure)
        self.state.resilience_memory = self._blend(
            self.state.resilience_memory,
            _clamp(p.recovery_pressure * 0.55 + p.cooperation_pressure * 0.35 + self.state.institutional_adaptation * 0.10),
        )

        new_events = self._detect_events(before)
        self.events.extend(new_events)
        fp = hashlib.sha256(_canonical({"pressures": p.to_dict(), "state": self.state.to_dict(), "events": [e.to_dict() for e in self.events]}).encode("utf-8")).hexdigest()
        return DASBridgeReport(pressures=p, state_before=before, state_after=DASEvolutionState(**self.state.to_dict()), events=new_events, fingerprint=fp)

    def _detect_events(self, before: DASEvolutionState) -> List[DASEvent]:
        s = self.state
        i = s.step_count
        events: List[DASEvent] = []
        checks = [
            ("structural_stress_threshold", s.structural_stress, before.structural_stress, 0.55, "DAS substrate structural stress crossed threshold."),
            ("faction_volatility_threshold", s.faction_volatility, before.faction_volatility, 0.50, "DAS substrate faction volatility crossed threshold."),
            ("institutional_adaptation_threshold", s.institutional_adaptation, before.institutional_adaptation, 0.45, "DAS substrate institutional adaptation pressure crossed threshold."),
            ("innovation_momentum_threshold", s.innovation_momentum, before.innovation_momentum, 0.42, "DAS substrate innovation momentum crossed threshold."),
            ("migration_tendency_threshold", s.migration_tendency, before.migration_tendency, 0.45, "DAS substrate migration tendency crossed threshold."),
            ("resilience_memory_threshold", s.resilience_memory, before.resilience_memory, 0.45, "DAS substrate resilience memory crossed threshold."),
        ]
        for kind, value, old, threshold, message in checks:
            if value >= threshold and old < threshold:
                events.append(DASEvent(i, kind, round(value, 6), message, {"previous": round(old, 6), "threshold": threshold}))
        if s.cooperation_capacity <= 0.32 and before.cooperation_capacity > 0.32:
            events.append(DASEvent(i, "cooperation_capacity_low", round(1.0 - s.cooperation_capacity, 6), "DAS substrate cooperation capacity fell below stability band.", {"previous": round(before.cooperation_capacity, 6), "threshold": 0.32}))
        return events

    def to_dict(self) -> Dict[str, Any]:
        return {"state": self.state.to_dict(), "events": [e.to_dict() for e in self.events], "inertia": self.inertia}

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "DASBridge":
        bridge = cls(state=DASEvolutionState(**payload.get("state", {})), inertia=float(payload.get("inertia", 0.82)))
        bridge.events = [DASEvent(**e) for e in payload.get("events", [])]
        return bridge


def bridge_markdown(report: DASBridgeReport) -> str:
    lines = [
        "# HRM/DAS Bridge Report",
        "",
        "This report shows the controlled translation from HRM civic pressures into DAS substrate state. It is not a prediction of a real society.",
        "",
        "## Surface Pressures",
        "",
        "| Pressure | Value |",
        "|---|---:|",
    ]
    for k, v in report.pressures.to_dict().items():
        lines.append(f"| {k} | {v:.4f} |")
    lines += ["", "## DAS State After Update", "", "| State | Value |", "|---|---:|"]
    for k, v in report.state_after.to_dict().items():
        lines.append(f"| {k} | {v} |")
    lines += ["", "## Bridge Events", ""]
    if not report.events:
        lines.append("No DAS substrate thresholds crossed in this update.")
    else:
        lines += ["| Step | Kind | Severity | Message |", "|---:|---|---:|---|"]
        for e in report.events:
            lines.append(f"| {e.step_index} | {e.kind} | {e.severity:.4f} | {e.message} |")
    lines += ["", f"Fingerprint: `{report.fingerprint}`"]
    return "\n".join(lines)
