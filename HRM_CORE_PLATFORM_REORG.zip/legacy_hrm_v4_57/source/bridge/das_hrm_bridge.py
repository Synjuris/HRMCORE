"""bridge/das_hrm_bridge.py — HRM v4.57 Real DAS↔HRM Bridge.

This is the actual bidirectional coupling between the DAS individual-agent layer
and the HRM civic-pressure layer. It replaces the stub bridge that smoothed
fake data with inertia parameters.

The thesis this implements:
    Individual psychology aggregates into collective civic dynamics.
    Collective civic shocks feed back into individual conditions.

Two directions:

    UPWARD  (DAS agents → HRM CivicState)
        Runs every UPWARD_INTERVAL ticks during a DAS run.
        Aggregates real agent state — trust baselines, stress, faction
        hostility, conflict/cooperation ratios, resilience, subjective
        belief valence — into HRM-compatible pressure deltas.

    DOWNWARD (HRM CivicState → DAS phase environment)
        Runs when HRM produces a CivicState update (scenario step,
        policy injection, threshold event).
        Translates civic pressure signals into DAS phase parameter
        adjustments that affect every agent's next tick.

Neither direction overwrites — both use bounded additive deltas so the
simulation is not destabilized by a single bridge call.

Design rules:
    - No locality-specific values, no hardcoded city names
    - Every translation function is documented with the causal claim it encodes
    - All outputs are clamped and bounded
    - Falls back gracefully if either side is absent
    - Read-only on observation; writes only through documented mutation points
"""
from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple


# ── Constants ─────────────────────────────────────────────────────────────────

UPWARD_INTERVAL   = 25    # DAS ticks between upward aggregation calls
DOWNWARD_STRENGTH = 0.18  # max fractional shift per downward call (bounded)
UPWARD_STRENGTH   = 0.22  # max pressure contribution per upward call
TRUST_LOW         = 0.40  # below this, trust_baseline is "low trust"
HOSTILITY_HIGH    = 0.35  # above this, inter-faction hostility is "high"


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(x)))


def _r4(x: float) -> float:
    return round(float(x), 4)


# ── Upward translation: DAS agents → HRM pressures ───────────────────────────

@dataclass
class UpwardSignal:
    """Aggregated signal from DAS population → HRM civic pressure layer."""

    # Population counts
    n_living: int = 0
    n_sampled: int = 0

    # Aggregated psychological state
    mean_trust_baseline: float = 0.50
    mean_stress: float = 0.20
    mean_resilience: float = 0.50
    mean_valence: float = 0.00
    mean_fear: float = 0.20

    # Social structure
    faction_hostility_mean: float = 0.15   # mean cross-faction hostility
    conflict_ratio: float = 0.20           # conflicts / total interactions (recent)
    negative_belief_fraction: float = 0.0  # fraction of formed beliefs with valence < -0.3

    # Derived pressure deltas for HRM (computed by aggregate_das_to_hrm)
    stress_pressure_delta: float = 0.0
    trust_pressure_delta: float = 0.0
    volatility_pressure_delta: float = 0.0
    cooperation_pressure_delta: float = 0.0
    withdrawal_pressure_delta: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {k: _r4(v) if isinstance(v, float) else v for k, v in asdict(self).items()}


def aggregate_das_to_hrm(runtime: Any) -> UpwardSignal:
    """
    Aggregate DAS agent population into HRM civic pressure signals.

    Translation claims encoded here:
    - Low mean trust_baseline → high trust_pressure
      A population that has learned not to trust produces institutional
      distrust at the civic scale. This is the generational transmission
      thesis: childhood trauma that lowers trust_baseline aggregates into
      community-wide institutional skepticism.

    - High mean stress → high stress_pressure
      Individual stress is the microscopic substrate of collective unrest.

    - High faction hostility → high volatility_pressure
      Inter-group resentment at the individual level is what political
      volatility looks like from the outside.

    - High conflict_ratio → high withdrawal_pressure
      Populations where most interactions are conflictual withdraw from
      civic participation.

    - High negative_belief_fraction → amplifies trust_pressure
      When many agents have formed conclusions like perceived_humiliator
      or perceived_unreliable_under_pressure, collective social trust has
      already degraded. This is the subjective memory layer paying off.

    - High resilience → dampens all pressures
      Resilient populations absorb shocks. This is what the developmental
      bonding literature shows: early-secure populations recover faster.
    """
    sig = UpwardSignal()

    agents = [a for a in getattr(runtime, "agents", []) if getattr(a, "alive", False)]
    if not agents:
        return sig

    sig.n_living = len(agents)
    sig.n_sampled = len(agents)

    # ── Psychological aggregation ─────────────────────────────────────────────
    trust_vals, stress_vals, resil_vals, valence_vals, fear_vals = [], [], [], [], []
    neg_beliefs, total_beliefs = 0, 0

    for a in agents:
        traits = getattr(a, "traits", None)
        state  = getattr(a, "state", None)
        if traits:
            trust_vals.append(getattr(traits, "trust_baseline", 0.50))
            resil_vals.append(getattr(traits, "resilience", 0.50))
        if state:
            stress_vals.append(getattr(state, "stress", 0.20))
            valence_vals.append(getattr(state, "valence", 0.00))
            fear_vals.append(getattr(state, "fear", 0.20))

        # Subjective belief valence — formed social conclusions
        sm = getattr(a, "subjective_memory", None)
        if sm is not None:
            beliefs = getattr(sm, "subjective_beliefs", {})
            for b in beliefs.values():
                total_beliefs += 1
                v = getattr(b, "valence", 0.0) if hasattr(b, "valence") else b.get("valence", 0.0)
                if float(v) < -0.30:
                    neg_beliefs += 1

    def _mean(lst: list, default: float = 0.0) -> float:
        return sum(lst) / len(lst) if lst else default

    sig.mean_trust_baseline    = _mean(trust_vals,  0.50)
    sig.mean_stress            = _mean(stress_vals, 0.20)
    sig.mean_resilience        = _mean(resil_vals,  0.50)
    sig.mean_valence           = _mean(valence_vals, 0.00)
    sig.mean_fear              = _mean(fear_vals,   0.20)
    sig.negative_belief_fraction = (neg_beliefs / total_beliefs) if total_beliefs > 0 else 0.0

    # ── Faction hostility aggregation ─────────────────────────────────────────
    fr = getattr(runtime, "faction_registry", None)
    if fr is not None:
        hostility_vals = []
        factions = getattr(fr, "factions", {})
        for fid, faction in factions.items():
            for other_id, h in getattr(faction, "hostility", {}).items():
                hostility_vals.append(float(h))
        sig.faction_hostility_mean = _mean(hostility_vals, 0.15)

    # ── Conflict ratio from recent event bus ─────────────────────────────────
    bus = getattr(runtime, "bus", None)
    if bus is not None:
        recent = list(getattr(bus, "event_log", []) or [])[-200:]
        interactions = [e for e in recent if e.get("event_type") == "interaction"]
        if interactions:
            conflicts = sum(1 for e in interactions if e.get("outcome") == "conflict")
            sig.conflict_ratio = conflicts / len(interactions)

    # ── Compute HRM pressure deltas ───────────────────────────────────────────
    # Resilience dampens everything — a resilient population absorbs shocks
    resilience_damper = _clamp(sig.mean_resilience * 0.60 + 0.40)

    # Trust pressure: low trust_baseline → high trust_pressure
    # Amplified by negative subjective beliefs (formed social conclusions)
    trust_deficit = _clamp(TRUST_LOW - sig.mean_trust_baseline, 0.0, TRUST_LOW)
    trust_raw = (trust_deficit / TRUST_LOW) * 0.55 + sig.negative_belief_fraction * 0.45
    sig.trust_pressure_delta = _r4(_clamp(trust_raw * UPWARD_STRENGTH / resilience_damper))

    # Stress pressure: direct from mean agent stress
    stress_raw = sig.mean_stress * 0.70 + sig.mean_fear * 0.30
    sig.stress_pressure_delta = _r4(_clamp(stress_raw * UPWARD_STRENGTH / resilience_damper))

    # Volatility pressure: faction hostility + conflict ratio
    volatility_raw = sig.faction_hostility_mean * 0.55 + sig.conflict_ratio * 0.45
    sig.volatility_pressure_delta = _r4(_clamp(volatility_raw * UPWARD_STRENGTH / resilience_damper))

    # Withdrawal pressure: negative valence + fear
    withdrawal_raw = _clamp(-sig.mean_valence * 0.60 + sig.mean_fear * 0.40)
    sig.withdrawal_pressure_delta = _r4(_clamp(withdrawal_raw * UPWARD_STRENGTH / resilience_damper))

    # Cooperation pressure: positive valence + high trust (recovery signal)
    coop_raw = _clamp(sig.mean_valence * 0.50 + (sig.mean_trust_baseline - 0.40) * 0.50)
    sig.cooperation_pressure_delta = _r4(_clamp(coop_raw * UPWARD_STRENGTH))

    return sig


def apply_upward_signal(signal: UpwardSignal, civic_state: Any) -> None:
    """
    Apply aggregated DAS signal to HRM CivicState pressures.
    Additive, bounded. Does not overwrite — accumulates like a normal
    CivicDynamicsTracker ingest call.
    """
    if signal.n_living == 0:
        return

    s = civic_state
    s.stress_pressure    = _clamp(getattr(s, "stress_pressure",    0.0) + signal.stress_pressure_delta)
    s.trust_pressure     = _clamp(getattr(s, "trust_pressure",     0.0) + signal.trust_pressure_delta)
    s.volatility_pressure= _clamp(getattr(s, "volatility_pressure",0.0) + signal.volatility_pressure_delta)
    s.cooperation_pressure=_clamp(getattr(s, "cooperation_pressure",0.0) + signal.cooperation_pressure_delta)
    s.withdrawal_pressure= _clamp(getattr(s, "withdrawal_pressure", 0.0) + signal.withdrawal_pressure_delta)


# ── Downward translation: HRM CivicState → DAS phase environment ──────────────

@dataclass
class DownwardSignal:
    """Translated civic pressure → DAS phase parameter adjustments."""

    # Phase parameter deltas (applied to all phases proportionally)
    conflict_pressure_delta: float = 0.0  # + = more conflict
    stress_load_delta: float = 0.0        # + = more stress
    social_density_delta: float = 0.0     # + = more interaction
    rest_quality_delta: float = 0.0       # + = more recovery
    scarcity_delta: float = 0.0           # + = more resource pressure

    # Agent trait deltas (slow, bounded — applied to trust_baseline and avoidance_rate)
    trust_baseline_delta: float = 0.0     # negative = erosion
    avoidance_rate_delta: float = 0.0     # positive = more avoidance

    source_tick: int = 0
    source_event: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {k: _r4(v) if isinstance(v, float) else v for k, v in asdict(self).items()}


def translate_hrm_to_das(civic_state: Any, tick: int = 0,
                          event: str = "") -> DownwardSignal:
    """
    Translate HRM CivicState into DAS phase parameter adjustments.

    Translation claims encoded here:
    - High stress_pressure → raise conflict_pressure and stress_load
      A city under economic or political stress is a harder environment
      to live in at the individual level.

    - High trust_pressure → slowly erode trust_baseline on agents
      Institutional distrust at the civic scale writes back into individual
      psychology over time. This is slow and bounded — it takes sustained
      civic failure to damage individual trust baselines.

    - High cooperation_pressure → raise social_density and rest_quality
      Civic recovery signals — successful policy, community organizing —
      make the environment more cooperative at the individual level.

    - High withdrawal_pressure → lower social_density and raise avoidance_rate
      When the population is withdrawing from civic life, individuals
      interact less and avoid more.

    - High volatility_pressure → raise conflict_pressure and scarcity
      Political volatility translates into resource uncertainty and
      heightened conflict readiness.
    """
    sig = DownwardSignal(source_tick=tick, source_event=event)

    sp  = float(getattr(civic_state, "stress_pressure",     0.0))
    tp  = float(getattr(civic_state, "trust_pressure",      0.0))
    vp  = float(getattr(civic_state, "volatility_pressure", 0.0))
    cp  = float(getattr(civic_state, "cooperation_pressure",0.0))
    wp  = float(getattr(civic_state, "withdrawal_pressure", 0.0))

    s = DOWNWARD_STRENGTH

    # Conflict pressure: stress + volatility drive conflict
    sig.conflict_pressure_delta = _r4(_clamp(
        (sp * 0.55 + vp * 0.45) * s, -s, s
    ))

    # Stress load: direct from civic stress
    sig.stress_load_delta = _r4(_clamp(sp * s * 0.70, -s, s))

    # Social density: cooperation increases it, withdrawal decreases it
    sig.social_density_delta = _r4(_clamp(
        (cp * 0.50 - wp * 0.50) * s, -s, s
    ))

    # Rest quality: cooperation/recovery improves rest, stress degrades it
    sig.rest_quality_delta = _r4(_clamp(
        (cp * 0.40 - sp * 0.40) * s * 0.50, -s * 0.50, s * 0.50
    ))

    # Scarcity: volatility and stress increase perceived resource scarcity
    sig.scarcity_delta = _r4(_clamp(
        (vp * 0.45 + sp * 0.35) * s * 0.60, -s * 0.60, s * 0.60
    ))

    # Trust baseline erosion: slow, only fires above threshold
    # This is the most consequential channel — institutional failure
    # eventually rewrites individual trust. Bounded tightly.
    if tp > 0.25:
        sig.trust_baseline_delta = _r4(-_clamp(
            (tp - 0.25) * s * 0.08, 0.0, 0.012  # max 0.012 per call
        ))

    # Avoidance rate: withdrawal pressure raises avoidance
    if wp > 0.20:
        sig.avoidance_rate_delta = _r4(_clamp(
            (wp - 0.20) * s * 0.06, 0.0, 0.008  # max 0.008 per call
        ))

    return sig


def apply_downward_signal(signal: DownwardSignal, runtime: Any) -> int:
    """
    Apply HRM civic signal to DAS phase parameters and agent traits.

    Phase parameters are adjusted on the EnvironmentCycle phases.
    Agent trait deltas (trust_baseline, avoidance_rate) are applied
    to all living agents — slowly and within hard bounds.

    Returns count of agents affected.
    """
    affected = 0

    # ── Phase parameter adjustments ───────────────────────────────────────────
    env_cycle = getattr(runtime, "env_cycle", None)
    if env_cycle is not None:
        for phase in getattr(env_cycle, "phases", []):
            phase.conflict_pressure = _clamp(
                phase.conflict_pressure + signal.conflict_pressure_delta, 0.0, 0.95
            )
            phase.stress_load = _clamp(
                phase.stress_load + signal.stress_load_delta, 0.0, 0.95
            )
            phase.social_density = _clamp(
                phase.social_density + signal.social_density_delta, 0.05, 0.98
            )
            phase.rest_quality = _clamp(
                phase.rest_quality + signal.rest_quality_delta, 0.0, 1.0
            )
            phase.scarcity = _clamp(
                phase.scarcity + signal.scarcity_delta, 0.0, 0.95
            )

    # ── Agent trait adjustments (slow, bounded) ───────────────────────────────
    if signal.trust_baseline_delta != 0.0 or signal.avoidance_rate_delta != 0.0:
        agents = [a for a in getattr(runtime, "agents", []) if getattr(a, "alive", False)]
        for a in agents:
            traits = getattr(a, "traits", None)
            if traits is None:
                continue
            if signal.trust_baseline_delta != 0.0:
                old = getattr(traits, "trust_baseline", 0.50)
                # Only erode unconsolidated traits or very slowly after consolidation
                consolidated = getattr(a, "traits_consolidated", False)
                rate = 0.08 if consolidated else 1.0
                new = _clamp(old + signal.trust_baseline_delta * rate, 0.05, 0.95)
                traits.trust_baseline = new
            if signal.avoidance_rate_delta != 0.0:
                old = getattr(traits, "avoidance_rate", 0.05)
                traits.avoidance_rate = _clamp(old + signal.avoidance_rate_delta, 0.01, 0.35)
            affected += 1

    return affected


# ── Bridge coordinator ────────────────────────────────────────────────────────

@dataclass
class BridgeRecord:
    tick: int
    direction: str  # "upward" or "downward"
    signal: Dict[str, Any]
    agents_affected: int = 0
    fingerprint: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class DASHRMBridge:
    """
    Coordinator for the bidirectional DAS↔HRM bridge.

    Usage in DAS kernel (add to experiment_setup.py):

        from bridge.das_hrm_bridge import DASHRMBridge
        bridge = DASHRMBridge()
        bridge.attach_to_runtime(rt)   # registers upward subsystem

    Usage from HRM environment (call after each CivicState update):

        bridge.push_downward(civic_state, das_runtime, tick=tick)

    The bridge can also be driven manually for testing:

        signal = aggregate_das_to_hrm(runtime)
        apply_upward_signal(signal, civic_state)
    """

    def __init__(self,
                 upward_interval: int = UPWARD_INTERVAL,
                 downward_strength: float = DOWNWARD_STRENGTH):
        self.upward_interval  = upward_interval
        self.downward_strength = downward_strength
        self.records: List[BridgeRecord] = []
        self._das_runtime: Any = None
        self._hrm_civic_state: Any = None
        self._last_upward_tick: int = -1

    def attach_to_runtime(self, das_runtime: Any) -> None:
        """Register the upward aggregation subsystem with the DAS kernel."""
        self._das_runtime = das_runtime
        try:
            from das.kernel.system_registry import SubsystemSpec
        except ImportError:
            try:
                from kernel.system_registry import SubsystemSpec
            except ImportError:
                return  # kernel not available, manual mode only

        bridge_ref = self

        def _upward_step(tick: int, runtime: Any) -> None:
            if tick - bridge_ref._last_upward_tick < bridge_ref.upward_interval:
                return
            if bridge_ref._hrm_civic_state is None:
                return
            signal = aggregate_das_to_hrm(runtime)
            apply_upward_signal(signal, bridge_ref._hrm_civic_state)
            bridge_ref._last_upward_tick = tick
            rec = BridgeRecord(
                tick=tick,
                direction="upward",
                signal=signal.to_dict(),
                agents_affected=signal.n_living,
                fingerprint=_fp(signal.to_dict()),
            )
            bridge_ref.records.append(rec)

        das_runtime.registry.register_spec(SubsystemSpec(
            name="das_hrm_bridge_upward",
            phase="METRICS",
            fn=_upward_step,
            depends_on=("viability",),
        ))

    def set_civic_state(self, civic_state: Any) -> None:
        """Point the bridge at the HRM CivicState to write into."""
        self._hrm_civic_state = civic_state

    def push_downward(self, civic_state: Any, das_runtime: Any,
                      tick: int = 0, event: str = "") -> DownwardSignal:
        """
        Called from HRM after a civic state update.
        Translates the current CivicState into DAS phase adjustments.
        """
        signal = translate_hrm_to_das(civic_state, tick=tick, event=event)
        affected = apply_downward_signal(signal, das_runtime)
        rec = BridgeRecord(
            tick=tick,
            direction="downward",
            signal=signal.to_dict(),
            agents_affected=affected,
            fingerprint=_fp(signal.to_dict()),
        )
        self.records.append(rec)
        return signal

    def pull_upward(self, das_runtime: Any,
                    civic_state: Any, tick: int = 0) -> UpwardSignal:
        """
        Manual upward call — aggregate DAS into HRM without waiting for
        the kernel subsystem schedule.
        """
        signal = aggregate_das_to_hrm(das_runtime)
        apply_upward_signal(signal, civic_state)
        self._last_upward_tick = tick
        rec = BridgeRecord(
            tick=tick,
            direction="upward",
            signal=signal.to_dict(),
            agents_affected=signal.n_living,
            fingerprint=_fp(signal.to_dict()),
        )
        self.records.append(rec)
        return signal

    def summary(self) -> Dict[str, Any]:
        ups   = [r for r in self.records if r.direction == "upward"]
        downs = [r for r in self.records if r.direction == "downward"]
        return {
            "upward_calls":   len(ups),
            "downward_calls": len(downs),
            "last_upward":    ups[-1].to_dict()  if ups   else None,
            "last_downward":  downs[-1].to_dict() if downs else None,
        }

    def to_dict(self) -> Dict[str, Any]:
        return {
            "upward_interval":   self.upward_interval,
            "downward_strength": self.downward_strength,
            "records":           [r.to_dict() for r in self.records[-50:]],
        }


def _fp(obj: Any) -> str:
    raw = json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]
