"""Endogenous DAS feedback layer for HRM_UNIFIED v2.2.

This module keeps the HRM/DAS coupling narrow and inspectable. The bridge
translates HRM civic pressure into slow DAS substrate variables; this layer then
feeds selected bounded DAS substrate effects back into the persistent civic
baseline so later HRM responses change.

It contains no locality-specific, personal, or API-key values.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional
import hashlib
import json

try:
    from .das_bridge import DASBridgeReport, DASEvolutionState
except ImportError:
    from bridge.das_bridge import DASBridgeReport, DASEvolutionState  # type: ignore


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(x)))


def _canonical(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


@dataclass
class EndogenousEvent:
    step_index: int
    kind: str
    severity: float
    message: str
    context: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class EndogenousFeedbackState:
    """Persistent endogenous substrate outputs.

    These are synthetic, bounded state markers. They are not claims about a real
    location or population.
    """

    active_factions: List[Dict[str, Any]] = field(default_factory=list)
    institutional_adaptations: Dict[str, float] = field(default_factory=dict)
    institutional_degradations: Dict[str, float] = field(default_factory=dict)
    innovation_markers: List[Dict[str, Any]] = field(default_factory=list)
    cultural_markers: List[Dict[str, Any]] = field(default_factory=list)
    generational_memory_index: float = 0.0
    baseline_modifiers: Dict[str, float] = field(default_factory=dict)
    step_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["generational_memory_index"] = round(float(self.generational_memory_index), 6)
        data["baseline_modifiers"] = {k: round(float(v), 6) for k, v in self.baseline_modifiers.items()}
        data["institutional_adaptations"] = {k: round(float(v), 6) for k, v in self.institutional_adaptations.items()}
        data["institutional_degradations"] = {k: round(float(v), 6) for k, v in self.institutional_degradations.items()}
        return data

    def fingerprint(self) -> str:
        return hashlib.sha256(_canonical(self.to_dict()).encode("utf-8")).hexdigest()


@dataclass
class EndogenousFeedbackReport:
    state_before: EndogenousFeedbackState
    state_after: EndogenousFeedbackState
    applied_modifiers: Dict[str, float]
    events: List[EndogenousEvent]
    fingerprint: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "state_before": self.state_before.to_dict(),
            "state_after": self.state_after.to_dict(),
            "applied_modifiers": {k: round(float(v), 6) for k, v in self.applied_modifiers.items()},
            "events": [e.to_dict() for e in self.events],
            "fingerprint": self.fingerprint,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)


class DASEndogenousEvolution:
    """Feeds slow DAS substrate change back into the civic baseline."""

    def __init__(self, state: Optional[EndogenousFeedbackState] = None, strength: float = 0.35):
        self.state = state or EndogenousFeedbackState()
        self.strength = _clamp(strength, 0.0, 1.0)
        self.events: List[EndogenousEvent] = []

    def _copy_state(self) -> EndogenousFeedbackState:
        return EndogenousFeedbackState(**json.loads(json.dumps(self.state.to_dict())))

    def apply(self, bridge_report: DASBridgeReport, civic_state: Any) -> EndogenousFeedbackReport:
        before = self._copy_state()
        self.state.step_count += 1
        das_state: DASEvolutionState = bridge_report.state_after
        s = das_state

        # Bounded baseline modifiers. Positive stress/trust/volatility/withdrawal
        # values add pressure; negative values relieve pressure. Cooperation is
        # separately signed because higher cooperation is stabilizing in this model.
        modifiers = {
            "stress_pressure": (s.structural_stress * 0.18 + s.migration_tendency * 0.08 - s.resilience_memory * 0.10 - s.innovation_momentum * 0.04) * self.strength,
            "trust_pressure": (s.faction_volatility * 0.12 + s.structural_stress * 0.06 - s.institutional_adaptation * 0.12 - s.resilience_memory * 0.06) * self.strength,
            "volatility_pressure": (s.faction_volatility * 0.20 + s.cultural_drift * 0.08 - s.cooperation_capacity * 0.07) * self.strength,
            "withdrawal_pressure": (s.migration_tendency * 0.16 + s.structural_stress * 0.05 - s.resilience_memory * 0.08) * self.strength,
            "cooperation_pressure": ((s.cooperation_capacity - 0.50) * 0.18 + s.resilience_memory * 0.10 + s.institutional_adaptation * 0.06 - s.faction_volatility * 0.08) * self.strength,
        }

        # Apply modifiers directly to persistent civic state so future runs start
        # from an evolved baseline instead of an amnesic reset.
        for key, delta in modifiers.items():
            old = float(getattr(civic_state, key, 0.0))
            setattr(civic_state, key, _clamp(old + float(delta), 0.0, 1.0))
        self.state.baseline_modifiers = {k: self.state.baseline_modifiers.get(k, 0.0) * 0.75 + v for k, v in modifiers.items()}
        self.state.generational_memory_index = _clamp(self.state.generational_memory_index * 0.88 + s.resilience_memory * 0.08 + s.cultural_drift * 0.04)

        new_events = self._detect_and_update_markers(s)
        self.events.extend(new_events)
        fp = hashlib.sha256(_canonical({"state": self.state.to_dict(), "events": [e.to_dict() for e in self.events], "modifiers": modifiers}).encode("utf-8")).hexdigest()
        return EndogenousFeedbackReport(state_before=before, state_after=self._copy_state(), applied_modifiers=modifiers, events=new_events, fingerprint=fp)

    def _detect_and_update_markers(self, s: DASEvolutionState) -> List[EndogenousEvent]:
        i = self.state.step_count
        out: List[EndogenousEvent] = []

        if s.faction_volatility >= 0.28 and s.structural_stress >= 0.12:
            faction_id = f"faction_cluster_{len(self.state.active_factions) + 1}"
            if not any(f.get("id") == faction_id for f in self.state.active_factions) and len(self.state.active_factions) < 12:
                marker = {"id": faction_id, "formed_at_step": i, "basis": "sustained_pressure", "intensity": round(s.faction_volatility, 6)}
                self.state.active_factions.append(marker)
                out.append(EndogenousEvent(i, "faction_emergence", s.faction_volatility, "Synthetic faction cluster emerged from sustained pressure.", marker))

        if s.institutional_adaptation >= 0.22:
            key = f"adaptation_cycle_{i}"
            self.state.institutional_adaptations[key] = s.institutional_adaptation
            out.append(EndogenousEvent(i, "institutional_adaptation", s.institutional_adaptation, "Institutional adaptation marker recorded.", {"marker": key}))

        if s.structural_stress >= 0.35 and s.institutional_adaptation < 0.18:
            key = f"degradation_cycle_{i}"
            self.state.institutional_degradations[key] = s.structural_stress
            out.append(EndogenousEvent(i, "institutional_degradation", s.structural_stress, "Institutional degradation marker recorded under sustained stress.", {"marker": key}))

        if s.innovation_momentum >= 0.18 and (s.structural_stress >= 0.10 or s.resilience_memory >= 0.05):
            marker = {"id": f"innovation_marker_{len(self.state.innovation_markers) + 1}", "step": i, "intensity": round(s.innovation_momentum, 6)}
            if len(self.state.innovation_markers) < 20:
                self.state.innovation_markers.append(marker)
                out.append(EndogenousEvent(i, "innovation_recombination", s.innovation_momentum, "Innovation/recombination marker recorded.", marker))

        if s.cultural_drift >= 0.20:
            marker = {"id": f"cultural_drift_{len(self.state.cultural_markers) + 1}", "step": i, "intensity": round(s.cultural_drift, 6)}
            if len(self.state.cultural_markers) < 20:
                self.state.cultural_markers.append(marker)
                out.append(EndogenousEvent(i, "cultural_drift_marker", s.cultural_drift, "Cultural drift marker recorded.", marker))

        if self.state.generational_memory_index >= 0.12 and i >= 2:
            out.append(EndogenousEvent(i, "generational_memory_placeholder", self.state.generational_memory_index, "Generational memory placeholder updated for future inheritance modeling.", {"index": round(self.state.generational_memory_index, 6)}))

        return out

    def to_dict(self) -> Dict[str, Any]:
        return {"state": self.state.to_dict(), "events": [e.to_dict() for e in self.events], "strength": self.strength}

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "DASEndogenousEvolution":
        obj = cls(state=EndogenousFeedbackState(**payload.get("state", {})), strength=float(payload.get("strength", 0.35)))
        obj.events = [EndogenousEvent(**e) for e in payload.get("events", [])]
        return obj


def endogenous_markdown(report: EndogenousFeedbackReport) -> str:
    lines = [
        "# HRM/DAS Endogenous Feedback Report",
        "",
        "This report shows bounded DAS substrate effects fed back into the persistent civic baseline. It is not a prediction of a real society.",
        "",
        "## Applied Baseline Modifiers",
        "",
        "| Civic signal | Modifier |",
        "|---|---:|",
    ]
    for k, v in report.applied_modifiers.items():
        lines.append(f"| {k} | {float(v):+.6f} |")
    lines += ["", "## Endogenous Markers", ""]
    after = report.state_after
    lines += [
        f"- Active faction clusters: {len(after.active_factions)}",
        f"- Institutional adaptations: {len(after.institutional_adaptations)}",
        f"- Institutional degradations: {len(after.institutional_degradations)}",
        f"- Innovation markers: {len(after.innovation_markers)}",
        f"- Cultural markers: {len(after.cultural_markers)}",
        f"- Generational memory index: {after.generational_memory_index:.6f}",
        "",
        "## New Events",
        "",
    ]
    if not report.events:
        lines.append("No endogenous event thresholds crossed on this update.")
    else:
        lines += ["| Step | Kind | Severity | Message |", "|---:|---|---:|---|"]
        for e in report.events:
            lines.append(f"| {e.step_index} | {e.kind} | {e.severity:.4f} | {e.message} |")
    lines += ["", f"Fingerprint: `{report.fingerprint}`"]
    return "\n".join(lines)
