#!/usr/bin/env python3
"""Small v3.0 scalability benchmark for preset modes."""
from __future__ import annotations

import json
import time
from pathlib import Path

try:
    from .scalable_architecture import MODE_PRESETS, make_fidelity_plan
except ImportError:
    from scalable_architecture import MODE_PRESETS, make_fidelity_plan


def main() -> int:
    rows = []
    for mode in ("toy", "desktop", "large"):
        requested = int(MODE_PRESETS[mode]["max_agents"] * 1.4)
        t0 = time.time()
        plan = make_fidelity_plan(mode, requested)
        rows.append({"mode": mode, "elapsed_ms": round((time.time() - t0) * 1000, 3), **plan.to_dict()})
    out = Path("outputs/scalable_world_v3_0/benchmark")
    out.mkdir(parents=True, exist_ok=True)
    (out / "scalable_benchmark.json").write_text(json.dumps({"rows": rows}, indent=2, sort_keys=True), encoding="utf-8")
    print("HRM_UNIFIED v3.0 SCALABILITY BENCHMARK")
    for r in rows:
        print(f"{r['mode']}: requested={r['requested_agents']} simulated={r['simulated_agents']} tiers={r['active_agents']}/{r['regional_agents']}/{r['statistical_agents']} compression={r['compression_ratio']}")
    print("Wrote:", out / "scalable_benchmark.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
