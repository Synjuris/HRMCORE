# HRM Unified v4.39 — Civilization Coupling Balance

Recovery-grade runtime balancing pass built from the full v4.38 package.

## Fixed
- Proto-institution formation no longer waits for unrealistically mature high-trust societies.
- Small institutions persist through founder attrition instead of dissolving immediately when only one member survives.
- Logistics storage deposits now occur in primitive surplus conditions instead of staying at 0.0.
- Domesticated herd wealth no longer converges to the same hard cap across runs; herd capacity now responds to grazing conditions, drought, plant growth, tolerance, disease and crowding.
- Information fidelity metrics now fall back to all extant inbox state when survivors have no messages, avoiding misleading 0.000 readings after active information exchange.
- Logistics terrain generation now uses the run seed instead of a fixed seed.

## Validation target
A successful run should show nonzero negotiation, recovery, domestication, information flow, some local storage, and more frequent institution persistence without requiring every run to become institutionalized.
