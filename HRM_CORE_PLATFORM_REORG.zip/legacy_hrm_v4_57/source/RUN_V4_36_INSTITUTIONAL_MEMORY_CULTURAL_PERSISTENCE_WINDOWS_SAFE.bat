@echo off
setlocal
cd /d "%~dp0"
if not exist runs_v04_36 mkdir runs_v04_36
set DAS_OUTPUT_ROOT=runs_v04_36
set DAS_RUNS=1
set DAS_TICKS=120
python das\run_sim.py
pause
