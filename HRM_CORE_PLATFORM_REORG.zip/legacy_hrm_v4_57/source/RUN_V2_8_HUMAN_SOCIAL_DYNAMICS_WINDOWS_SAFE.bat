@echo off
setlocal ENABLEDELAYEDEXPANSION
cd /d "%~dp0"
echo ============================================================
echo HRM_UNIFIED v2.8 - Human Social Dynamics + DAS Deep Integration
echo Folder: %CD%
echo ============================================================
echo.
set PYTHON_CMD=
where py >nul 2>nul
if %ERRORLEVEL%==0 set PYTHON_CMD=py -3
if "%PYTHON_CMD%"=="" (
  where python >nul 2>nul
  if !ERRORLEVEL!==0 set PYTHON_CMD=python
)
if "%PYTHON_CMD%"=="" (
  where python3 >nul 2>nul
  if !ERRORLEVEL!==0 set PYTHON_CMD=python3
)
if "%PYTHON_CMD%"=="" (
  echo ERROR: Python was not found.
  echo Install Python 3, then run this file again.
  pause
  exit /b 1
)
echo Using Python command: %PYTHON_CMD%
%PYTHON_CMD% --version
if not exist outputs mkdir outputs
%PYTHON_CMD% run_human_social_dynamics.py --cycles 3 --generations-per-cycle 2 --autosave-every 1 --world-id default_world --output-dir outputs/human_social_dynamics_v2_8
set EXITCODE=%ERRORLEVEL%
echo.
if %EXITCODE%==0 (
  echo Done. Open:
  echo outputs\human_social_dynamics_v2_8\default_world\reports\human_social_dynamics_report.md
  echo outputs\human_social_dynamics_v2_8\default_world\reports\since_last_viewed_report.md
  echo outputs\human_social_dynamics_v2_8\default_world\world_state_latest.json
  echo outputs\human_social_dynamics_v2_8\default_world\evolution_timeline.json
) else (
  echo Run finished with error code %EXITCODE%.
)
pause
exit /b %EXITCODE%
