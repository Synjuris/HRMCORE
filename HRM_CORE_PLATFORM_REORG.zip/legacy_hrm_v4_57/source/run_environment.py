#!/usr/bin/env python3
"""Run the persistent HRM_UNIFIED v2.2 synthetic civic environment."""
from __future__ import annotations

import argparse
from pathlib import Path

try:
    from .environment import SyntheticCivicEnvironment, load_environment_config
    from .population.history import load_timeline
    from .population.policy import load_policy_definitions, DEFAULT_POLICIES
except ImportError:
    from environment import SyntheticCivicEnvironment, load_environment_config
    from population.history import load_timeline
    from population.policy import load_policy_definitions, DEFAULT_POLICIES


def main() -> int:
    ap = argparse.ArgumentParser(description="Run or resume a persistent synthetic civic environment.")
    ap.add_argument("timeline", nargs="?", help="Optional timeline JSON/YAML. Defaults to generic built-in timeline.")
    ap.add_argument("--config", help="Optional environment config JSON.")
    ap.add_argument("--load-env", help="Resume from prior environment_snapshot.json.")
    ap.add_argument("--save-env", help="Path to write final environment snapshot. Defaults inside output run folder.")
    ap.add_argument("--branch", help="Create a named branch from the loaded environment before running.")
    ap.add_argument("--policies", help="Optional policy definition JSON.")
    ap.add_argument("--name", help="Override timeline/run name.")
    ap.add_argument("--n", type=int, help="Population size override for new environments.")
    ap.add_argument("--seed", type=int, help="Seed override for new environments.")
    ap.add_argument("--profile", help="Profile override for new environments.")
    ap.add_argument("--decay", type=float, help="Decay override for new environments.")
    ap.add_argument("--output-dir", default="outputs/environment_v2_1")
    ap.add_argument("--no-observatory", action="store_true", help="Skip local HTML observatory export.")
    ap.add_argument("--enable-das-bridge", action="store_true", help="Enable controlled HRM/DAS bridge substrate update for this environment.")
    ap.add_argument("--enable-das-feedback", action="store_true", help="Enable DAS endogenous feedback into future civic baselines. Implies --enable-das-bridge.")
    ap.add_argument("--das-bridge-inertia", type=float, default=None, help="Bridge inertia for slow DAS substrate state, default 0.82.")
    ap.add_argument("--das-feedback-strength", type=float, default=None, help="Strength of endogenous DAS feedback, default 0.35.")
    args = ap.parse_args()

    policies = load_policy_definitions(args.policies) if args.policies else DEFAULT_POLICIES
    if args.load_env:
        env = SyntheticCivicEnvironment.load(args.load_env, policies=policies)
        if args.branch:
            env = env.branch(args.branch)
    else:
        config = load_environment_config(args.config)
        if args.n is not None:
            config.population_size = args.n
        if args.seed is not None:
            config.seed = args.seed
        if args.profile is not None:
            config.profile = args.profile
        if args.decay is not None:
            config.decay = args.decay
        if args.enable_das_bridge or args.enable_das_feedback:
            config.das_bridge_enabled = True
        if args.enable_das_feedback:
            config.das_feedback_enabled = True
        if args.das_bridge_inertia is not None:
            config.das_bridge_inertia = args.das_bridge_inertia
        if args.das_feedback_strength is not None:
            config.das_feedback_strength = args.das_feedback_strength
        env = SyntheticCivicEnvironment(config=config, policies=policies)

    timeline = load_timeline(args.timeline)
    name = args.name or str(timeline.get("name") or (Path(args.timeline).stem if args.timeline else "generic_environment_run"))
    paths = env.run_timeline(
        timeline,
        output_dir=args.output_dir,
        name=name,
        save_snapshot=True,
        build_observatory=not args.no_observatory,
    )
    if args.save_env:
        env.save(args.save_env)
        paths["saved_environment"] = args.save_env

    print("HRM_UNIFIED v2.2 SYNTHETIC CIVIC ENVIRONMENT")
    print(f"Environment: {env.config.name}")
    print(f"Run index: {env.config.run_index}")
    print(f"Timeline: {name}")
    print(f"Environment fingerprint: {env.environment_fingerprint()[:16]}")
    print("Wrote:")
    for k, v in paths.items():
        print(f"  {k}: {v}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
