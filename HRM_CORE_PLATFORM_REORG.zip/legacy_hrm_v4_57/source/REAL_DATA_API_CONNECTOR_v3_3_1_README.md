# HRM_UNIFIED v3.3.1 — Real Data API Connector

This rebuild fixes the v3.3 connector path. It does not require hardcoded secrets.

## Run

Double-click:

`RUN_V3_3_1_REAL_DATA_API_CONNECTOR_WINDOWS_SAFE.bat`

## Key loading

The connector checks, in order:

1. `DATASET_API_KEY`
2. `CENSUS_API_KEY`
3. `ACS_API_KEY`
4. `.env`
5. `.env.user`

Use `.env.user` for local secrets:

```text
DATASET_API_KEY=your_key_here
```

Do not put your real key in a zip you plan to share.

## What it does

The default launcher attempts a live ACS calibration for:

- Tennessee state FIPS: `47`
- Madison County FIPS: `113`

It also uses the bundled sample as a safe fallback so the pipeline still proves itself when offline, blocked, or missing a key.

Outputs:

- `outputs/real_data_api_connector_v3_3_1/api_health_report.json`
- `outputs/real_data_api_connector_v3_3_1/real_dataset_calibration_report.md`
- `outputs/real_data_api_connector_v3_3_1/real_dataset_calibration_bundle.json`
