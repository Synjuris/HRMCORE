# HRM_UNIFIED v1.2 REAL DATA ADAPTER

## Added

- Optional U.S. Census ACS real-data adapter.
- `.env.user` support for local API key loading.
- `.env.example` and `.gitignore` guardrails.
- `fetch_real_profile.py` for real calibration profile generation.
- `run_real_panel.py` for real-calibrated panel runs.
- `REAL_DATA_README.md` usage guide.

## Preserved

- No personal context in engine code.
- No locality-specific hardcoding.
- Core engine still runs offline without external data.
- Real data is converted into generic priors; it does not become model truth.

## Tested

- Python compile check passed for new modules.
- Existing self-test still runs.
- Standard panel run still works.
- Calibration normalization unit check passed.
