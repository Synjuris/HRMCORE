"""Persistent synthetic civic environment for HRM_UNIFIED v2.2.

This layer consolidates timeline replay, policy injection, civic state persistence,
and observatory export into one continuous environment runner. It remains generic:
no personal, locality-specific, or API-key values are embedded.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional
import copy
import hashlib
import json
import time

try:
    from .population.history import HistoricalSimulator, HistoricalRunResult, load_timeline, fingerprint
    from .population.policy import DEFAULT_POLICIES, load_policy_definitions, PolicyDefinition
    from .observatory import write_observatory
    from .export_utils import ensure_dir, safe_slug
    from .bridge.das_bridge import DASBridge, bridge_markdown
    from .bridge.endogenous import DASEndogenousEvolution, endogenous_markdown
    from .bridge.das_hrm_bridge import DASHRMBridge, translate_hrm_to_das, apply_downward_signal
except ImportError:
    from population.history import HistoricalSimulator, HistoricalRunResult, load_timeline, fingerprint
    from population.policy import DEFAULT_POLICIES, load_policy_definitions, PolicyDefinition
    from observatory import write_observatory
    from export_utils import ensure_dir, safe_slug
    from bridge.das_bridge import DASBridge, bridge_markdown
    from bridge.endogenous import DASEndogenousEvolution, endogenous_markdown
    from bridge.das_hrm_bridge import DASHRMBridge, translate_hrm_to_das, apply_downward_signal


ENGINE_VERSION = "2.2"


def _utc_stamp() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _canonical(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


@dataclass
class EnvironmentConfig:
    name: str = "generic_synthetic_civic_environment"
    population_size: int = 1000
    seed: int = 42
    profile: str = "generic_mixed_region"
    decay: float = 0.86
    run_index: int = 0
    das_bridge_enabled: bool = False
    das_feedback_enabled: bool = False
    das_bridge_inertia: float = 0.82
    das_feedback_strength: float = 0.35
    created_at: str = field(default_factory=_utc_stamp)
    updated_at: str = field(default_factory=_utc_stamp)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class EnvironmentRunRecord:
    run_index: int
    name: str
    started_at: str
    completed_at: str
    timeline_name: str
    result_fingerprint: str
    snapshot_path: str
    observatory_html: str
    summary_json: str
    total_policy_cost_units: float
    event_count: int
    final_state: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class EnvironmentSnapshot:
    version: str
    config: Dict[str, Any]
    simulator_state: Dict[str, Any]
    run_history: List[Dict[str, Any]]
    environment_fingerprint: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class SyntheticCivicEnvironment:
    """One persistent environment containing simulator state and run history."""

    def __init__(self, config: Optional[EnvironmentConfig] = None, policies: Optional[Dict[str, PolicyDefinition]] = None):
        self.config = config or EnvironmentConfig()
        self.policies = policies or DEFAULT_POLICIES
        self.sim = HistoricalSimulator(
            n=self.config.population_size,
            seed=self.config.seed,
            profile=self.config.profile,
            decay=self.config.decay,
            policies=self.policies,
        )
        self.run_history: List[EnvironmentRunRecord] = []
        self.das_bridge = DASBridge(inertia=self.config.das_bridge_inertia) if self.config.das_bridge_enabled else None
        self.das_feedback = DASEndogenousEvolution(strength=self.config.das_feedback_strength) if self.config.das_feedback_enabled else None
        self._das_hrm_bridge: DASHRMBridge = DASHRMBridge()
        self._das_runtime = None

    def attach_das_runtime(self, das_runtime) -> None:
        """Connect a live DAS HRMRuntime for bidirectional bridge operation."""
        self._das_runtime = das_runtime
        self._das_hrm_bridge.set_civic_state(self.sim.tracker.state)
        existing = getattr(das_runtime, "_das_hrm_bridge", None)
        if existing is not None:
            existing.set_civic_state(self.sim.tracker.state)
            self._das_hrm_bridge = existing

    @property
    def state(self) -> Dict[str, Any]:
        return self.sim.tracker.state.to_dict()

    def environment_fingerprint(self) -> str:
        payload = {
            "version": ENGINE_VERSION,
            "config": self.config.to_dict(),
            "state": self.sim.tracker.state.to_dict(),
            "events": [e.to_dict() for e in self.sim.tracker.events],
            "steps": [s.to_dict() for s in self.sim.steps],
            "run_history": [r.to_dict() for r in self.run_history],
            "das_bridge": self.das_bridge.to_dict() if self.das_bridge else None,
            "das_feedback": self.das_feedback.to_dict() if self.das_feedback else None,
        }
        return hashlib.sha256(_canonical(payload).encode("utf-8")).hexdigest()

    def snapshot_payload(self) -> EnvironmentSnapshot:
        sim_state = {
            "civic_state": self.sim.tracker.state.to_dict(),
            "events": [e.to_dict() for e in self.sim.tracker.events],
            "steps": [s.to_dict() for s in self.sim.steps],
            "snapshots": [s.to_dict() for s in self.sim.snapshots],
            "total_cost_units": self.sim.total_cost,
            "das_bridge": self.das_bridge.to_dict() if self.das_bridge else None,
            "das_feedback": self.das_feedback.to_dict() if self.das_feedback else None,
        }
        return EnvironmentSnapshot(
            version=ENGINE_VERSION,
            config=self.config.to_dict(),
            simulator_state=sim_state,
            run_history=[r.to_dict() for r in self.run_history],
            environment_fingerprint=self.environment_fingerprint(),
        )

    def save(self, path: str | Path) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.config.updated_at = _utc_stamp()
        path.write_text(json.dumps(self.snapshot_payload().to_dict(), indent=2), encoding="utf-8")
        return path

    @classmethod
    def load(cls, path: str | Path, policies: Optional[Dict[str, PolicyDefinition]] = None) -> "SyntheticCivicEnvironment":
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        cfg_data = dict(payload.get("config", {}))
        config = EnvironmentConfig(**{k: v for k, v in cfg_data.items() if k in EnvironmentConfig.__dataclass_fields__})
        env = cls(config=config, policies=policies)
        sim_state = payload.get("simulator_state", {})
        try:
            from .population.history import HistoricalStep as HStep, HistoricalSnapshot as HSnap
            from .population.civic_dynamics import CivicState as CState, CivicEvent as CEvent
        except Exception:
            from population.history import HistoricalStep as HStep, HistoricalSnapshot as HSnap  # type: ignore
            from population.civic_dynamics import CivicState as CState, CivicEvent as CEvent  # type: ignore
        env.sim.tracker.state = CState(**sim_state.get("civic_state", {}))
        env.sim.tracker.events = [CEvent(**e) for e in sim_state.get("events", [])]
        env.sim.steps = [HStep(**s) for s in sim_state.get("steps", [])]
        env.sim.snapshots = [HSnap(**s) for s in sim_state.get("snapshots", [])]
        env.sim.total_cost = float(sim_state.get("total_cost_units", 0.0))
        bridge_payload = sim_state.get("das_bridge") or payload.get("das_bridge")
        if config.das_bridge_enabled and bridge_payload:
            env.das_bridge = DASBridge.from_dict(bridge_payload)
        elif config.das_bridge_enabled and env.das_bridge is None:
            env.das_bridge = DASBridge(inertia=config.das_bridge_inertia)
        feedback_payload = sim_state.get("das_feedback") or payload.get("das_feedback")
        if config.das_feedback_enabled and feedback_payload:
            env.das_feedback = DASEndogenousEvolution.from_dict(feedback_payload)
        elif config.das_feedback_enabled and env.das_feedback is None:
            env.das_feedback = DASEndogenousEvolution(strength=config.das_feedback_strength)
        env.run_history = [EnvironmentRunRecord(**r) for r in payload.get("run_history", [])]
        return env

    def branch(self, name_suffix: str = "branch") -> "SyntheticCivicEnvironment":
        clone = copy.deepcopy(self)
        clone.config.name = safe_slug(f"{self.config.name}_{name_suffix}")
        clone.config.updated_at = _utc_stamp()
        return clone

    def run_timeline(self, timeline: Dict[str, Any], output_dir: str | Path = "outputs/environment_v2_1", name: Optional[str] = None,
                     save_snapshot: bool = True, build_observatory: bool = True) -> Dict[str, str]:
        out = ensure_dir(output_dir)
        self.config.run_index += 1
        run_index = self.config.run_index
        started = _utc_stamp()
        timeline_name = name or str(timeline.get("name") or f"environment_run_{run_index}")
        run_slug = safe_slug(f"run_{run_index:03d}_{timeline_name}")

        # Continue from current simulator state. HistoricalSimulator.run appends steps/events/snapshots.
        result: HistoricalRunResult = self.sim.run(timeline, name=timeline_name)

        run_dir = ensure_dir(out / run_slug)
        summary_json = run_dir / "environment_run_summary.json"
        summary_md = run_dir / "environment_run_summary.md"
        summary_json.write_text(result.to_json(), encoding="utf-8")
        summary_md.write_text(environment_markdown(result, env_name=self.config.name, run_index=run_index), encoding="utf-8")

        obs_paths: Dict[str, str] = {}
        if build_observatory:
            obs_paths = write_observatory(result, output_dir=run_dir / "observatory", prefix="environment_observatory")

        # v04.57: push downward civic signal into live DAS runtime if attached
        if self._das_runtime is not None:
            self._das_hrm_bridge.push_downward(
                self.sim.tracker.state,
                self._das_runtime,
                tick=len(self.run_history),
                event=timeline_name,
            )

        bridge_paths: Dict[str, str] = {}
        if self.das_bridge is not None:
            bridge_report = self.das_bridge.ingest(result)
            bridge_json = run_dir / "das_bridge_report.json"
            bridge_md = run_dir / "das_bridge_report.md"
            bridge_json.write_text(bridge_report.to_json(), encoding="utf-8")
            bridge_md.write_text(bridge_markdown(bridge_report), encoding="utf-8")
            bridge_paths = {"das_bridge_json": str(bridge_json), "das_bridge_md": str(bridge_md)}
            if self.das_feedback is not None:
                feedback_report = self.das_feedback.apply(bridge_report, self.sim.tracker.state)
                feedback_json = run_dir / "das_endogenous_feedback_report.json"
                feedback_md = run_dir / "das_endogenous_feedback_report.md"
                feedback_json.write_text(feedback_report.to_json(), encoding="utf-8")
                feedback_md.write_text(endogenous_markdown(feedback_report), encoding="utf-8")
                bridge_paths.update({"das_feedback_json": str(feedback_json), "das_feedback_md": str(feedback_md)})

        snapshot_path = run_dir / "environment_snapshot.json"
        if save_snapshot:
            self.save(snapshot_path)

        record = EnvironmentRunRecord(
            run_index=run_index,
            name=timeline_name,
            started_at=started,
            completed_at=_utc_stamp(),
            timeline_name=timeline_name,
            result_fingerprint=result.fingerprint(),
            snapshot_path=str(snapshot_path),
            observatory_html=obs_paths.get("html", ""),
            summary_json=str(summary_json),
            total_policy_cost_units=result.total_cost_units,
            event_count=len(result.events),
            final_state=result.final_state.to_dict(),
        )
        self.run_history.append(record)
        # Resave so run_history includes this record.
        if save_snapshot:
            self.save(snapshot_path)

        manifest = {
            "environment": self.config.name,
            "version": ENGINE_VERSION,
            "run_index": run_index,
            "timeline": timeline_name,
            "fingerprint": result.fingerprint(),
            "environment_fingerprint": self.environment_fingerprint(),
            "summary_json": str(summary_json),
            "summary_md": str(summary_md),
            "snapshot": str(snapshot_path),
            **{f"observatory_{k}": v for k, v in obs_paths.items()},
            **bridge_paths,
        }
        manifest_path = run_dir / "manifest.json"
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        return {k: str(v) for k, v in manifest.items()}


def environment_markdown(result: HistoricalRunResult, env_name: str, run_index: int) -> str:
    lines = [
        "# HRM_UNIFIED v2.2 Synthetic Civic Environment Run",
        "",
        f"**Environment:** {env_name}",
        f"**Run index:** {run_index}",
        f"**Timeline:** {result.name}",
        f"**Profile:** {result.profile_name}",
        f"**Population:** {result.population_size}",
        f"**Seed:** {result.seed}",
        f"**Fingerprint:** `{result.fingerprint()}`",
        "",
        "## Final Civic State",
        "",
        "| Signal | Value |",
        "|---|---:|",
    ]
    for k, v in result.final_state.summary().items():
        lines.append(f"| {k} | {v:+.4f} |")
    lines += ["", "## Run Record", "", f"- Steps recorded: {len(result.steps)}", f"- Snapshots recorded: {len(result.snapshots)}", f"- Emergent events recorded: {len(result.events)}", f"- Policy cost units: {result.total_cost_units:.2f}", "", "## Latest Events", ""]
    if not result.events:
        lines.append("No emergent events crossed thresholds.")
    else:
        lines += ["| Tick | Kind | Scope | Severity | Message |", "|---:|---|---|---:|---|"]
        for e in result.events[-25:]:
            lines.append(f"| {e.tick} | {e.kind} | {e.scope} | {e.severity:.4f} | {e.message} |")
    return "\n".join(lines)


def load_environment_config(path: Optional[str]) -> EnvironmentConfig:
    if not path:
        return EnvironmentConfig()
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return EnvironmentConfig(**{k: v for k, v in data.items() if k in EnvironmentConfig.__dataclass_fields__})
