from __future__ import annotations

import argparse
import json
from pathlib import Path
from inject import SyntheticPanel
from export_utils import write_panel_result, safe_slug, ensure_dir


def read_text_arg(value: str) -> str:
    p = Path(value)
    return p.read_text(encoding="utf-8").strip() if p.exists() else value


def main() -> None:
    parser = argparse.ArgumentParser(description="A/B compare two stimuli against the same deterministic panel baseline.")
    parser.add_argument("stimulus_a", help="Stimulus A text or path to text file.")
    parser.add_argument("stimulus_b", help="Stimulus B text or path to text file.")
    parser.add_argument("--n", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--ticks", type=int, default=30)
    parser.add_argument("--output-dir", default="outputs/compare")
    args = parser.parse_args()

    a = read_text_arg(args.stimulus_a)
    b = read_text_arg(args.stimulus_b)
    panel = SyntheticPanel(n=args.n, seed=args.seed)
    results = panel.compare(a, b, run_ticks=args.ticks)

    out = ensure_dir(args.output_dir)
    for label, result in results.items():
        print(f"\n=== Stimulus {label} ===")
        print(result.summary())
        write_panel_result(result, out, prefix=f"{label.lower()}_{safe_slug(result.stimulus_text)}")

    diff = {k: round(results["B"].delta.get(k, 0) - results["A"].delta.get(k, 0), 4) for k in results["A"].delta}
    (out / "ab_delta_difference.json").write_text(json.dumps({"B_minus_A": diff}, indent=2), encoding="utf-8")
    print("\nB minus A delta difference:")
    print(json.dumps(diff, indent=2))


if __name__ == "__main__":
    main()
