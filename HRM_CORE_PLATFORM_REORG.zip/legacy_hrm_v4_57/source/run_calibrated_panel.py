#!/usr/bin/env python3
"""Run a v1.3 calibrated HRM synthetic panel."""
from __future__ import annotations

import argparse
from pathlib import Path

try:
    from .population.calibrated_panel import CalibratedPanel
    from .export_utils import write_panel_result, safe_slug
except ImportError:
    from population.calibrated_panel import CalibratedPanel
    from export_utils import write_panel_result, safe_slug


def main() -> int:
    ap = argparse.ArgumentParser(description="Run calibrated synthetic population response panel.")
    ap.add_argument("stimulus", nargs="+", help="Stimulus text to inject.")
    ap.add_argument("--n", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--ticks", type=int, default=45)
    ap.add_argument("--profile", default="generic_mixed_region", help="Profile name or path to JSON profile.")
    ap.add_argument("--output-dir", default="outputs")
    ap.add_argument("--no-raw", action="store_true")
    args = ap.parse_args()

    text = " ".join(args.stimulus)
    panel = CalibratedPanel(n=args.n, seed=args.seed, profile=args.profile)
    result = panel.inject(text, run_ticks=args.ticks)
    print(result.summary())
    paths = write_panel_result(result, args.output_dir, prefix=safe_slug("calibrated_" + text), include_raw=not args.no_raw)
    print("\nWrote:")
    for k, v in paths.items():
        print(f"  {k}: {v}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
