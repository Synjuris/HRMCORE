@echo off
setlocal ENABLEDELAYEDEXPANSION
cd /d "%~dp0"
set PYTHON_CMD=
where py >nul 2>nul
if %ERRORLEVEL%==0 set PYTHON_CMD=py -3
if "%PYTHON_CMD%"=="" (
  where python >nul 2>nul
  if !ERRORLEVEL!==0 set PYTHON_CMD=python
)
if "%PYTHON_CMD%"=="" (
  where python3 >nul 2>nul
  if !ERRORLEVEL!==0 set PYTHON_CMD=python3
)
if "%PYTHON_CMD%"=="" (
  echo ERROR: Python was not found.
  pause
  exit /b 1
)
%PYTHON_CMD% run_world_dashboard.py --world-dir outputs/human_social_dynamics_v2_8/default_world --port 8765 --no-browser
pause
