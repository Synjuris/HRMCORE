#!/usr/bin/env python3
"""Run HRM_UNIFIED v3.2 disease ecology / public health layer."""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

try:
    from .reality_baseline import ERA_PRESETS, make_reality_baseline, write_seed_files
    from .disease_ecology import ENGINE_VERSION, DISEASE_PRESETS, profile_from_key, simulate_disease_ecology, disease_report_markdown, read_json, write_json
except ImportError:
    from reality_baseline import ERA_PRESETS, make_reality_baseline, write_seed_files
    from disease_ecology import ENGINE_VERSION, DISEASE_PRESETS, profile_from_key, simulate_disease_ecology, disease_report_markdown, read_json, write_json


def main() -> int:
    ap = argparse.ArgumentParser(description="Seed an era/current world and run disease as a civilization pressure system.")
    ap.add_argument("--era", choices=sorted(list(ERA_PRESETS.keys()) + ["now"]), default="modern")
    ap.add_argument("--start-year", type=int, default=None)
    ap.add_argument("--location", default="generic")
    ap.add_argument("--profile", default="generic_mixed_region")
    ap.add_argument("--disease", choices=sorted(list(DISEASE_PRESETS.keys()) + ["auto"]), default="auto")
    ap.add_argument("--cycles", type=int, default=12)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--run-world", action="store_true", help="Also run the scalable world after writing disease reports.")
    ap.add_argument("--mode", choices=["toy", "desktop", "large"], default="toy")
    ap.add_argument("--n", type=int, default=250)
    ap.add_argument("--world-id", default="disease_seeded_world_v3_2")
    ap.add_argument("--output-dir", default="outputs/disease_ecology_v3_2")
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    baseline = make_reality_baseline(args.era, args.start_year, args.location, args.profile)
    baseline_dict = baseline.to_dict()
    disease_profile = profile_from_key(args.disease, baseline_dict)
    world_dir = Path(args.output_dir) / args.world_id
    seed_dir = world_dir / "seeds"
    seed_files = write_seed_files(seed_dir, baseline)

    report = simulate_disease_ecology(baseline_dict, disease_profile, cycles=args.cycles, seed=args.seed)
    reports_dir = world_dir / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    write_json(reports_dir / "disease_ecology_report.json", report)
    (reports_dir / "disease_ecology_report.md").write_text(disease_report_markdown(report), encoding="utf-8")

    # Also write a pressure event sequence compatible with existing timeline runners.
    pressure_events = []
    for step in report["timeline"]:
        pressure_events.append({
            "t": int(step["cycle"]),
            "label": f"disease_{step['phase']}",
            "type": "public_health",
            "intensity": float(step["outbreak_risk"]),
            "prevalence": float(step["prevalence"]),
            "institutional_stress": float(step["institutional_stress"]),
        })
    disease_timeline = {
        "name": f"v3_2_disease_{baseline.era}_{baseline.start_year}_{baseline.location}".replace(" ", "_"),
        "description": "Disease ecology pressure timeline generated from era baseline.",
        "events": pressure_events,
    }
    disease_timeline_path = seed_dir / "disease_pressure_timeline.json"
    write_json(disease_timeline_path, disease_timeline)

    run_code = 0
    if args.run_world:
        cmd = [
            sys.executable,
            str(Path(__file__).with_name("run_scalable_world.py")),
            str(disease_timeline_path),
            "--mode", args.mode,
            "--n", str(args.n),
            "--cycles", "1",
            "--generations-per-cycle", "1",
            "--seed", str(args.seed),
            "--profile", args.profile,
            "--world-id", args.world_id,
            "--output-dir", args.output_dir,
        ]
        if args.force:
            cmd.append("--force")
        completed = subprocess.run(cmd, cwd=Path(__file__).resolve().parent)
        run_code = completed.returncode

    print(f"HRM_UNIFIED v{ENGINE_VERSION} DISEASE ECOLOGY / PUBLIC HEALTH")
    print(f"Era: {baseline.era} | Start year: {baseline.start_year} | Location: {baseline.location}")
    print(f"Disease profile: {disease_profile.label}")
    print("Wrote baseline seed:", seed_files.get("baseline"))
    print("Wrote disease timeline:", disease_timeline_path)
    print("Wrote disease report:", reports_dir / "disease_ecology_report.md")
    return 0 if run_code in (0, 2) else run_code


if __name__ == "__main__":
    raise SystemExit(main())
