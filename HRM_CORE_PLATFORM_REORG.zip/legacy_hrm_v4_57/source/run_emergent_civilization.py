#!/usr/bin/env python3
"""Run HRM_UNIFIED v2.6 emergent civilization layer."""
from __future__ import annotations

import argparse

try:
    from .population.history import HistoricalSimulator, load_timeline
    from .population.policy import load_policy_definitions, DEFAULT_POLICIES
    from .constitution import ConstitutionEngine
    from .generational_memory import GenerationalMemoryEngine, _summary_from_state
    from .institutional_evolution import InstitutionalEvolutionEngine
    from .emergent_civilization import EmergentCivilizationEngine, CivilizationRunReport, civilization_markdown, load_novelty_definitions
    from .export_utils import ensure_dir
except ImportError:
    from population.history import HistoricalSimulator, load_timeline
    from population.policy import load_policy_definitions, DEFAULT_POLICIES
    from constitution import ConstitutionEngine
    from generational_memory import GenerationalMemoryEngine, _summary_from_state
    from institutional_evolution import InstitutionalEvolutionEngine
    from emergent_civilization import EmergentCivilizationEngine, CivilizationRunReport, civilization_markdown, load_novelty_definitions
    from export_utils import ensure_dir


def main() -> int:
    ap = argparse.ArgumentParser(description="Run synthetic civic simulation with emergent civilization novelty layer.")
    ap.add_argument("timeline", nargs="?", help="Optional timeline JSON/YAML. Defaults to built-in generic timeline.")
    ap.add_argument("--policies", help="Optional policy definition JSON.")
    ap.add_argument("--novelties", help="Optional novelty/product/idea/discovery JSON.")
    ap.add_argument("--n", type=int, default=600)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--profile", default="generic_mixed_region")
    ap.add_argument("--decay", type=float, default=0.86)
    ap.add_argument("--generations", type=int, default=6)
    ap.add_argument("--cultural-decay", type=float, default=0.72)
    ap.add_argument("--institutional-decay", type=float, default=0.88)
    ap.add_argument("--cohort-turnover", type=float, default=0.30)
    ap.add_argument("--inheritance-strength", type=float, default=0.42)
    ap.add_argument("--mutation-rate", type=float, default=0.38)
    ap.add_argument("--invention-rate", type=float, default=0.24)
    ap.add_argument("--output-dir", default="outputs/emergent_civilization_v2_6")
    ap.add_argument("--name", default="emergent_civilization_run")
    args = ap.parse_args()

    policies = load_policy_definitions(args.policies) if args.policies else DEFAULT_POLICIES
    timeline = load_timeline(args.timeline)
    novelties = load_novelty_definitions(args.novelties)

    memory = GenerationalMemoryEngine(
        cultural_decay=args.cultural_decay,
        institutional_decay=args.institutional_decay,
        cohort_turnover=args.cohort_turnover,
        inheritance_strength=args.inheritance_strength,
    )
    institutions = InstitutionalEvolutionEngine(mutation_rate=args.mutation_rate)
    civilization = EmergentCivilizationEngine(novelties=novelties, seed=args.seed, invention_rate=args.invention_rate)

    epochs = []
    constitution_failures = 0

    for gen in range(1, max(1, args.generations) + 1):
        sim = HistoricalSimulator(n=args.n, seed=args.seed + gen - 1, profile=args.profile, decay=args.decay, policies=policies)
        memory.apply_baseline_to_simulator(sim)
        institutions.apply_to_simulator(sim)
        result = sim.run(timeline, name=f"{args.name}_generation_{gen}")
        audit = ConstitutionEngine().audit_historical_result(result)
        if not audit.passed:
            constitution_failures += 1
        summary = _summary_from_state(result.final_state)
        memory.encode_result(result, generation_label=f"generation_{gen}")
        institutions.evolve(memory.to_dict(), summary, generation=gen, label=str(timeline.get("name") or "default_timeline"))
        epoch = civilization.step(gen, summary, memory.to_dict(), institutions, label=str(timeline.get("name") or "default_timeline"))
        epochs.append(epoch)

    civ_state = civilization.to_dict()
    inst_state = institutions.to_dict()
    final_metrics = epochs[-1].civilization_metrics if epochs else {}
    benchmark = {
        "generations": len(epochs),
        "constitution_failures": constitution_failures,
        "novelty_count": int(final_metrics.get("novelty_count", 0.0)),
        "generated_novelty_count": int(final_metrics.get("generated_novelty_count", 0.0)),
        "final_shift": epochs[-1].dominant_shift if epochs else "none",
        "average_adoption": final_metrics.get("average_adoption", 0.0),
        "average_normalization": final_metrics.get("average_normalization", 0.0),
        "civilization_shift_score": final_metrics.get("civilization_shift_score", 0.0),
        "civilization_fingerprint": civ_state.get("fingerprint"),
        "institution_fingerprint": inst_state.get("fingerprint"),
        "memory_fingerprint": memory.to_dict().get("fingerprint"),
    }
    report = CivilizationRunReport("2.6", args.name, epochs, civ_state.get("novelties", []), inst_state.get("institutions", []), benchmark)

    out = ensure_dir(args.output_dir)
    json_path = out / "emergent_civilization_report.json"
    md_path = out / "emergent_civilization_report.md"
    json_path.write_text(report.to_json(), encoding="utf-8")
    md_path.write_text(civilization_markdown(report), encoding="utf-8")

    print("HRM_UNIFIED v2.6 EMERGENT CIVILIZATION ENGINE")
    print(f"Generations: {len(epochs)}")
    print(f"Novelties: {benchmark['novelty_count']} total, {benchmark['generated_novelty_count']} generated")
    print(f"Final shift: {benchmark['final_shift']}")
    print(f"Civilization fingerprint: {str(benchmark['civilization_fingerprint'])[:16]}")
    print("Wrote:")
    print("  json:", json_path)
    print("  markdown:", md_path)
    return 0 if constitution_failures == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())
