#!/usr/bin/env python3
"""Run a v1.5 spatial/institutional HRM synthetic panel."""
from __future__ import annotations

import argparse

try:
    from .population.calibrated_panel import CalibratedPanel
    from .export_utils import write_panel_result, safe_slug
except ImportError:
    from population.calibrated_panel import CalibratedPanel
    from export_utils import write_panel_result, safe_slug


def main() -> int:
    ap = argparse.ArgumentParser(description="Run spatial/institutional synthetic population response panel.")
    ap.add_argument("stimulus", nargs="+", help="Stimulus text to inject.")
    ap.add_argument("--n", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--ticks", type=int, default=45)
    ap.add_argument("--profile", default="generic_mixed_region", help="Profile name or path to JSON profile.")
    ap.add_argument("--output-dir", default="outputs/spatial_v1_5")
    ap.add_argument("--no-raw", action="store_true")
    args = ap.parse_args()

    text = " ".join(args.stimulus)
    panel = CalibratedPanel(n=args.n, seed=args.seed, profile=args.profile)
    result = panel.inject(text, run_ticks=args.ticks)
    print(result.summary())
    print("\nSPATIAL HOTSPOTS:")
    for h in result.hotspot_report:
        print(f"  {h['district_id']} ({h['district_kind']}): stress {h['stress_delta']:+.4f}, valence {h['valence_delta']:+.4f}, score {h['hotspot_score']:+.4f}")
    print("\nINSTITUTIONS:")
    for inst in result.spatial_summary.get("institutions", [])[:8]:
        print(f"  {inst['id']} {inst['kind']} in {inst['district_id']} | trust={inst['trust']:.2f} reach={inst['reach']:.2f}")
    paths = write_panel_result(result, args.output_dir, prefix=safe_slug("spatial_" + text), include_raw=not args.no_raw)
    print("\nWrote:")
    for k, v in paths.items():
        print(f"  {k}: {v}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
