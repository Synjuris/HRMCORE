from __future__ import annotations

import argparse
import json
from pathlib import Path
from adapters.census_acs import get_calibration_profile


def main() -> None:
    parser = argparse.ArgumentParser(description="Fetch a real ACS calibration profile for a generic HRM panel.")
    parser.add_argument("--state", required=True, help="Two-digit Census state FIPS, e.g. 06, 17, 36.")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--county", help="Three-digit Census county FIPS.")
    group.add_argument("--place", help="Five-digit Census place FIPS.")
    parser.add_argument("--output", default=None, help="Output JSON path. Defaults to outputs/profile_<geo>.json")
    parser.add_argument("--no-cache", action="store_true", help="Force live API fetch even if cached snapshot exists.")
    parser.add_argument("--api-key", default=None, help="Optional override. Prefer .env.user or CENSUS_API_KEY.")
    args = parser.parse_args()

    profile = get_calibration_profile(
        state=args.state,
        county=args.county,
        place=args.place,
        api_key=args.api_key,
        use_cache=not args.no_cache,
    )
    out = Path(args.output or f"outputs/profile_{profile.geography_type}_{args.state}_{args.county or args.place}.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(profile.to_dict(), indent=2, sort_keys=True), encoding="utf-8")
    print(f"Fetched: {profile.geography_name}")
    print(f"Wrote: {out}")
    print(json.dumps(profile.normalized, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
