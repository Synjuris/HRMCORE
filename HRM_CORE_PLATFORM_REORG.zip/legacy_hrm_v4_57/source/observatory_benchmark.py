#!/usr/bin/env python3
"""Smoke benchmark for HRM_UNIFIED v1.9 observatory output."""
from __future__ import annotations
from pathlib import Path

try:
    from .population.history import HistoricalSimulator, default_timeline
    from .observatory import build_observatory_payload, write_observatory
except ImportError:
    from population.history import HistoricalSimulator, default_timeline
    from observatory import build_observatory_payload, write_observatory


def main() -> int:
    sim = HistoricalSimulator(n=250, seed=919, profile="generic_mixed_region")
    result = sim.run(default_timeline(), name="observatory_benchmark")
    payload = build_observatory_payload(result)
    required = ["snapshots", "steps", "events", "final_state", "fingerprint"]
    missing = [k for k in required if k not in payload]
    if missing:
        raise SystemExit(f"Missing observatory payload keys: {missing}")
    if len(payload["snapshots"]) < 2 or len(payload["steps"]) < 1:
        raise SystemExit("Observatory payload is too sparse.")
    paths = write_observatory(result, output_dir="outputs/observatory_benchmark_v1_9", prefix="observatory_benchmark")
    html = Path(paths["html"])
    if not html.exists() or "HRM_UNIFIED Observatory" not in html.read_text(encoding="utf-8"):
        raise SystemExit("Observatory HTML was not written correctly.")
    print("HRM_UNIFIED v1.9 observatory benchmark: PASS")
    print(f"Fingerprint: {payload['fingerprint'][:16]}")
    print(f"HTML: {html}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
