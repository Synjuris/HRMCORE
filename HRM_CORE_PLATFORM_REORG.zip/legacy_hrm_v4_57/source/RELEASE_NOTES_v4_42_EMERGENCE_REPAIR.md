# HRM_UNIFIED v4.42 — Emergence Repair

Three bugs were preventing the civilization layer from functioning. All three fixed.

## Bugs Fixed

### 1. Story transmission never fired (generational_psychology.py)
The fallback storykeeper path required `linguistic_complexity > 0.42 AND age > 120`.
With 10 agents at 120 ticks, typically one agent qualified — and even then the 28%
fire probability across 6 eligible windows gave ~1.7 expected fires, frequently zero.
The primary path (role_family == "knowledge") never fired because no agents held
knowledge roles in default scenario seeding.

**Fix:** Lowered LC threshold to 0.28. Removed age gate. Added scars > 0.15 as
an alternative qualifier — a scarred young adult can be a storykeeper.

**Result:** stories: 0 → 1–2 per 120-tick run.

### 2. Innovation diffusion read cleared aux_events (innovation.py, run_sim.py)
`diffuse_practices()` looked for cooperation events in `agent.aux_events`, but
`aux_events` was cleared at line 621 of run_sim.py while innovation tick was called
at line 767. The list was always empty by the time diffusion ran.

**Fix:** Collect cooperation events from `event_log` immediately after aux_events
processing. Pass them explicitly to `apply_innovation_tick()` and into
`diffuse_practices()`. Added `cooperation_events` parameter to both functions.

**Result:** diffusions: 0 → 7–11 per 120-tick run.

### 3. Innovation noise always positive — failures impossible (innovation.py)
`noise = rng.uniform(0.0, cfg.utility_noise)` floored at zero. Combined with
`base_aptitude=0.30` and positive fidelity/aptitude contributions, utility almost
always exceeded the 0.38 success threshold. 100% success rate across all runs.

**Fix:** `noise = rng.uniform(-cfg.utility_noise * 0.6, cfg.utility_noise)` —
noise can now push utility below threshold.

**Result:** success rate: 1.0 → ~0.85–0.96, varying by run conditions.

## Also Fixed

### 4. Meme strength flat across all seed memes (culture.py)
Seed memes defaulted to strength=0.0 (Meme dataclass default). `decay()` ran
every tick but `try_spread()` never incremented strength on successful spread.
All memes decayed toward the same near-zero floor, making competition impossible.

**Fix:** Gave seed memes differentiated initial strengths (0.20–0.35). Added
`meme.strength += 0.008` on successful spread.

**Result:** Meme strengths now diverge based on actual spread success.

## What This Means

The civilization layer now functions as designed:
- Knowledge moves between agents (diffusion)
- Oral tradition carries psychological weight between generations (story transmission)
- Innovations can fail, creating genuine selection pressure
- Memes compete rather than flatten

The substrate was always real. The emergence is now real too.
