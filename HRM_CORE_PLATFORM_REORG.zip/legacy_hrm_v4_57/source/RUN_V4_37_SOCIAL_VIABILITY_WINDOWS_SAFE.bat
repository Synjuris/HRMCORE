@echo off
setlocal
cd /d "%~dp0"
echo Running HRM Unified v4.37 Social Viability + Population Stability...
py -3 das\run_sim.py
pause
