from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from inject import SyntheticPanel
from export_utils import write_panel_result, safe_slug, ensure_dir


def load_stimuli(path: Path) -> list[str]:
    if path.suffix.lower() == ".csv":
        with path.open(newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            if "stimulus" not in reader.fieldnames:
                raise SystemExit("CSV must contain a 'stimulus' column.")
            return [row["stimulus"].strip() for row in reader if row.get("stimulus", "").strip()]
    return [line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def main() -> None:
    parser = argparse.ArgumentParser(description="Run many stimuli through the HRM synthetic panel.")
    parser.add_argument("input", help="CSV with stimulus column or plain text file with one stimulus per line.")
    parser.add_argument("--n", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--ticks", type=int, default=30)
    parser.add_argument("--output-dir", default="outputs/batch")
    args = parser.parse_args()

    stimuli = load_stimuli(Path(args.input))
    if not stimuli:
        raise SystemExit("No stimuli found.")

    out = ensure_dir(args.output_dir)
    aggregate = []
    for idx, text in enumerate(stimuli, start=1):
        panel = SyntheticPanel(n=args.n, seed=args.seed)
        result = panel.inject(text, run_ticks=args.ticks)
        prefix = f"{idx:03d}_{safe_slug(text)}"
        write_panel_result(result, out, prefix=prefix, include_raw=False)
        aggregate.append({"index": idx, "stimulus": text, "delta": result.delta, "baseline": result.baseline, "post_injection": result.post_injection})
        print(f"[{idx}/{len(stimuli)}] {text[:70]}")
        print(result.summary())

    (out / "batch_summary.json").write_text(json.dumps(aggregate, indent=2), encoding="utf-8")
    with (out / "batch_deltas.csv").open("w", newline="", encoding="utf-8") as f:
        fieldnames = ["index", "stimulus", "valence", "arousal", "dominance", "belief", "stress", "resources"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in aggregate:
            writer.writerow({"index": row["index"], "stimulus": row["stimulus"], **row["delta"]})
    print(f"\nBatch outputs written to {out}")


if __name__ == "__main__":
    main()
