# HRM_UNIFIED v2.6 — Emergent Civilization Engine

## Purpose

v2.6 expands the experiment layer beyond policies and events. It adds a generic novelty layer for products, ideas, discoveries, technologies, doctrines, media systems, market instruments, infrastructure concepts, and social movements.

## Core loop

```text
environmental pressure
→ civic adaptation
→ novelty / invention / discovery
→ institutional reaction
→ cultural spread or resistance
→ generational normalization
→ civilization shift
```

## Added files

- `emergent_civilization.py`
- `run_emergent_civilization.py`
- `RELEASE_NOTES_v2.6_EMERGENT_CIVILIZATION_ENGINE.md`
- `RUN_V2_6_EMERGENT_CIVILIZATION_ENGINE_WINDOWS_SAFE.bat`

## Outputs

- `outputs/emergent_civilization_v2_6/emergent_civilization_report.json`
- `outputs/emergent_civilization_v2_6/emergent_civilization_report.md`

## Safety note

The layer is generic and synthetic. It does not encode real local facts, personal facts, protected traits, or predetermined historical outcomes.
