@echo off
setlocal ENABLEDELAYEDEXPANSION
cd /d "%~dp0"
set PYTHON_CMD=
where py >nul 2>nul
if %ERRORLEVEL%==0 set PYTHON_CMD=py -3
if "%PYTHON_CMD%"=="" (
  where python >nul 2>nul
  if !ERRORLEVEL!==0 set PYTHON_CMD=python
)
if "%PYTHON_CMD%"=="" (
  where python3 >nul 2>nul
  if !ERRORLEVEL!==0 set PYTHON_CMD=python3
)
if "%PYTHON_CMD%"=="" (
  echo ERROR: Python was not found.
  pause
  exit /b 1
)
%PYTHON_CMD% run_human_social_dynamics.py --report-only --world-id default_world --output-dir outputs/human_social_dynamics_v2_8
pause
