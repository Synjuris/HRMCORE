# HRM_UNIFIED v4.50 — Kernel Phase K2: Experiment Migration

## Summary
Old run scripts converted to thin wrappers or deprecated.
Kernel is now the only runtime path.
Bugs get fixed once.

## Changes

### New: das/kernel/experiment_setup.py
Shared setup functions used by all kernel runners:
- register_standard_subsystems(rt) — 9 subsystem registrations
- make_agent(...) — agent construction + full init
- seed_group_culture(agents, gcfg, culture_pool) — meme seeding
- setup_groups(rt) — builds and registers all groups from rt.cfg

### New: das/configs/
JSON experiment configs replacing scattered module-level constants:
- exp_E.json       — seed=23, staggered founding, group memes
- exp_E_1k.json    — same as E, 1000 ticks
- exp_A.json       — seed=17, mixed memes (distrust intact)
- exp_B.json       — seed=17, prosocial memes only
- single_band.json — seed=42, 30 agents, 20×20 world

### Updated: das/run_kernel_exp_E.py
66 lines (was 534). Now a thin wrapper:
    cfg = KernelConfig.from_json("configs/exp_E.json")
    rt = HRMRuntime(cfg)
    register_standard_subsystems(rt)
    setup_groups(rt)
    rt.run()

### New: das/kernel/tests/test_kernel_parity.py
Compatibility test suite. Runs kernel exp E and asserts:
- alive count 20–200
- death count 5–150
- homicide % 30–90%
- max generation 1–15
- innovation successes 10–5000
- practice registry 5–300
- active memes 5–12 (after tick 700)
- conflict rate 0.05–0.60

All 9 assertions pass on 700-tick, 2-run test.

### Deprecated (with headers): all old run scripts
- run_exp_A.py, run_exp_B.py, run_exp_C.py, run_exp_C2.py
- run_exp_D.py, run_exp_E.py, run_exp_E_1k.py
- run_four_groups.py, run_four_groups_resume.py
- run_single_band.py, run_three_groups.py, run_civilization.py

All marked: "DEPRECATED — use run_kernel_exp_E.py"
Preserved for reference. Not deleted until SRK-2 proves kernel stability.

### New: das/kernel/kernel_migration_audit.md
Full audit of what the kernel owns, what lives in old scripts,
K2 migration plan, bug fix table, validation results.

## K2 complete. Next: SRK-2 (belief-mediated perception).
