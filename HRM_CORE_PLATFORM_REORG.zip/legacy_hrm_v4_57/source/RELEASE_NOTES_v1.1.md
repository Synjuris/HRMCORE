# HRM_UNIFIED v1.1 Stable Panel

## What changed

This release stabilizes the HRM synthetic panel as the working product interface.

### Fixed

- Repaired broken validation imports that referenced a nonexistent `backend` package.
- Added root-level `run_self_test.py`.
- Added durable output directory creation.
- Made `stimulus/interface.py` importable in the unified package context.
- Disabled default demo events inside `SyntheticPanel` so panel runs measure the provided stimulus rather than background canned events.
- Changed panel deltas to treatment-vs-no-stimulus-control instead of raw drift from baseline.

### Added

- `run_panel.py` — run one stimulus.
- `compare_stimuli.py` — A/B compare two stimuli against the same deterministic baseline.
- `batch_stimuli.py` — run CSV/plain-text batches.
- `benchmark_panel.py` — five deterministic benchmark stimuli plus SHA256 fingerprint.
- `export_utils.py` — JSON, Markdown, CSV, JSONL export helpers.
- `examples/stimuli.csv` — starter benchmark batch.

## Stable commands

```bash
python run_self_test.py
python validation/generate_validation_run.py
python run_panel.py "Factory closures announced across Madison County."
python compare_stimuli.py "Major layoffs announced." "Volunteers launch food relief."
python batch_stimuli.py examples/stimuli.csv
python benchmark_panel.py
```

## Known limits

- HRM panel is stable enough for deterministic demonstrations, not real-world prediction.
- DAS is included as an experimental emergence layer and is not yet the default product interface.
- Stimulus parsing is lexical and lightweight; it is not a validated semantic model.
- Current response effects are intentionally conservative after counterfactual drift control.

## Verification from this build

Self-test:

```text
Self-test records: 45000
Self-test SHA256: 036de277239a0a0bc69a7b3045d247a8dc28162df2831df85f4a5b7be37c86ab
```

Panel benchmark:

```text
Benchmark scenarios: 5
Benchmark SHA256: 5681be3e650a9715e40c1067c639a86467fbfad87b52c841ab83c81dc9445767
```
