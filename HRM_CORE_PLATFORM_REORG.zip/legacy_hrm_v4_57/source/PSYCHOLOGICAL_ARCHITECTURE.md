# HRM_UNIFIED — Psychological Architecture

*This document covers the agent psychological depth layer introduced in v04.30–v04.31.*

---

## Overview

Agents in HRM_UNIFIED are not statistical units. Each one carries a layered psychological architecture that accumulates across their lifetime: affect state, experiential memory, relational history, identity, and — critically — a developmental record that determines how much any given experience can reshape who they are.

The architecture is split across four modules:

| Module | Responsibility |
|---|---|
| `psychology.py` | Valence state, grief, identity consolidation, cognitive dissonance |
| `development.py` | Life stage tracking, trait plasticity, developmental imprinting |
| `experiential.py` | Episodic memory, grudges, bonds, scars, symbolic artifacts, rituals |
| `beliefs.py` | Learned threat/safety assessments per agent and per phase |

These are not decorative. They feed directly into interaction decisions every tick.

---

## The trait layer vs. the state layer

This distinction is fundamental to understanding how the psychology works.

**State variables** (`AgentState`) are dynamic, tick-by-tick values: `stress`, `fear`, `curiosity`, `social_openness`, `valence`. They respond to events and recover between them. An adult who experiences a bad conflict will have elevated stress for some ticks, then recover.

**Trait variables** (`DevelopmentalTraits`) are stable personality parameters: `trust_baseline`, `attachment_rate`, `conflict_sensitivity`, `resilience`, `risk_tolerance`. Under normal circumstances they do not change. They represent who the agent *is*, not what the agent is *feeling*.

The developmental layer is the mechanism that makes traits writable — but only during sensitive periods, and only at rates that decline with age. After adolescence, traits are largely consolidated. This is intentional. It models the empirical reality that personality formed in childhood is far more resistant to revision than mood formed on a Tuesday.

---

## Life stages and plasticity

```
INFANT       age   0–19     plasticity 1.00
CHILD        age  20–59     plasticity 0.80
ADOLESCENT   age  60–119    plasticity 0.45
ADULT        age 120–399    plasticity 0.08
ELDER        age 400+       plasticity 0.05
```

Plasticity is a multiplier on how much a traumatic or bonding event writes to the trait layer versus absorbing only into state. A severe conflict at age 10 (child stage) rewrites `trust_baseline`, `attachment_rate`, `avoidance_rate`, and `conflict_sensitivity` permanently. The same conflict at age 200 (adult) leaves elevated stress and scars — significant — but does not change who the agent fundamentally is.

---

## Developmental trauma

When a high-intensity negative event (conflict, grief, detected deception) occurs during a pre-consolidation stage, `development.imprint_trauma()` fires. The effects depend on stage:

**Infant/Child**
- `trust_baseline` decreases (difficulty trusting others persists into adulthood)
- `attachment_rate` decreases (lower capacity to form bonds)
- `avoidance_rate` increases (pull away from potential threat)
- `conflict_sensitivity` increases (heightened alertness to danger signals)
- `resilience` decreases (the floor from which they recover is lower)

**Adolescent** — same as above, plus:
- `ideology_sensitivity` spikes (trauma crystallises worldview before it has stabilised, producing rigid ideological attachment)
- `risk_tolerance` diverges by dominance: high-dominance adolescents become reckless; low-dominance adolescents become avoidant

A single severe childhood trauma shifts `trust_baseline` by at most −0.18 and `attachment_rate` by at most −0.12. These are large but not total — agents are marked, not broken. Repeated trauma compounds.

---

## Developmental bonding

Positive cooperative experience during sensitive periods has the inverse effect. Strong bonds formed in infancy and childhood raise `trust_baseline`, lower `conflict_sensitivity`, increase `resilience`, and reduce `avoidance_rate`. These are the agents who enter adulthood with a buffer — not immune to stress, but harder to destabilise.

Early bonding does not guarantee later prosocial behavior. It raises the floor. An early-secure agent who experiences sustained faction hostility in adulthood will still accumulate resentment and scars. The difference is their recovery curve: they return to baseline faster, and their baseline is higher.

---

## Attractor lock (trait consolidation)

At the adolescent/adult boundary (age 120), a `traits_consolidated` flag is set on the agent. This never unsets. After consolidation:

- Trauma still hits the trait layer, but at 8% of the developmental rate
- Bonding recovery is similarly reduced
- Full recovery from a childhood wound requires ~80 consecutive cooperative ticks post-consolidation

This models the asymmetry clinical psychology consistently documents: it is much easier to wound a personality in childhood than to heal it in adulthood. Healing is possible — it just takes sustained positive experience over time, not a single event.

When consolidation fires, the agent's trait profile is inspected and permanent identity tags are stamped:

| Tag | Condition |
|---|---|
| `early-wounded` | `trust_baseline` < 0.35 at consolidation |
| `early-secure` | `trust_baseline` > 0.65 at consolidation |
| `hypervigilant` | `conflict_sensitivity` > 0.70 at consolidation |
| `hardened` | `resilience` > 0.68 at consolidation |

These tags persist for life and appear in agent snapshots and chronicle episodes.

---

## Valence state

`state.valence` is a unified affect scalar from −1.0 (deeply distressed) to +1.0 (flourishing). It integrates:

- Stress (negative weight)
- Fear (negative weight)
- Scar load (negative weight)
- Goal satisfaction (positive weight)
- Mean bond strength (positive weight)

Valence is computed each tick and contributes a small positive pull to `cooperation_pull` when positive (max +0.04). Negative valence contributes nothing directly — `stress` and `fear` already do that work. The purpose of valence is readability: it gives a single number that summarises an agent's overall psychological condition for logging, visualisation, and threshold-based narrative triggers.

---

## Grief

When an agent dies, `psychology.notify_death_to_population()` fires immediately. Every living agent that held a bond above the threshold (0.18) with the deceased receives a grief impulse scaled to bond strength:

- `stress` spike (max +0.08, scaled by bond strength and inverse resilience)
- `fear` spike (max +0.04)
- `social_openness` suppression (max −0.06)
- Permanent scar contribution (+0.055 × intensity)
- Bond entry removed (the person is gone)
- Episodic memory trace added: "loss of [name]"
- `bond` goal priority elevated (compensatory drive)

Grief resolves via natural stress recovery, ritual participation, or renewed bonding. It does not resolve instantly. An agent who loses their highest bond in adulthood may carry elevated stress and reduced social openness for 50–100 ticks.

Grief events appear in the event log with `event_type: "grief"` and salience proportional to bond strength.

---

## Identity

`experience.identity_tags` is a list of narrative labels that describe who an agent is. Tags are populated from multiple sources:

| Source | Tag examples |
|---|---|
| Role crystallization (age ≥ 100) | `"the planner"`, `"the defender"` |
| Scar threshold (≥ 0.35) | `"the scarred"` |
| Top grudge (≥ 0.40) | `"the aggrieved"` |
| Top bond (≥ 0.45) | `"the bonded"` |
| Faction membership | `"member of [faction]"` |
| High grief state | `"grieving"` (transient) |
| Developmental consolidation | `"early-wounded"`, `"early-secure"`, `"hypervigilant"`, `"hardened"` |
| Artifact spread | Artifact labels (e.g. `"the bitter mark"`) |

Tags are not behavior scalars. They do not directly gate decisions. Their function is narrative annotation — they make agent snapshots and chronicle episodes legible as character histories rather than numerical outputs.

---

## Cognitive dissonance

When `ideology_alignment` (what the agent's faction says to do) diverges from `cultural_alignment` (what the agent actually does) by more than 0.28, dissonance friction accumulates:

- Small stress load per tick (+0.006)
- `ideology_alignment` drifts toward `cultural_alignment` (actual behavior wins long-term)
- Chronic dissonance slowly erodes `ideology_sensitivity` (disengagement/cynicism)

This is deliberate friction, not a forced outcome. Agents do not automatically exit factions or change behavior. The pressure builds slowly and may resolve through cultural drift, faction split, or gradual cynicism. It is weakest of the four psychological mechanisms by design — ideology is persistent.

---

## Reading agent snapshots

The `psychology` and `development` sections in every agent snapshot provide a complete psychological profile:

```json
"psychology": {
  "valence": -0.31,
  "identity_tags": ["the scarred", "early-wounded", "the aggrieved", "the defender"],
  "scars": 0.44,
  "top_grudge": ["agent_0042", 0.67],
  "top_bond": ["agent_0018", 0.51]
},
"development": {
  "stage": "adult",
  "traits_consolidated": true,
  "plasticity": 0.08,
  "trust_baseline": 0.21,
  "attachment_rate": 0.024,
  "avoidance_rate": 0.71,
  "conflict_sensitivity": 0.84,
  "resilience": 0.31,
  "risk_tolerance": 0.38,
  "ideology_sensitivity": 0.63,
  "identity_tags": ["the scarred", "early-wounded", "the aggrieved", "the defender"]
}
```

This agent is an adult with consolidated traits. Their `trust_baseline` of 0.21 is far below the birth-range floor of 0.35 — they experienced severe trauma during a sensitive period. Their `conflict_sensitivity` of 0.84 and `avoidance_rate` of 0.71 confirm a hypervigilant profile. They carry a strong grudge against agent_0042, have not broken their bond with agent_0018, and their valence of −0.31 reflects chronic distress. The `"early-wounded"` tag tells you this is not a recent bad run — it is who they became.

---

## Chronicle episodes

Developmental events appear in the `TextureChronicle` alongside grudge-hardenings, artifacts, and rituals:

- `developmental_trauma` — trait layer written during sensitive period
- `developmental_bonding` — positive trait write during sensitive period
- `grief` — survivor response to bonded agent's death

These are narrative waypoints. A full chronicle can be read as the psychological history of a population — not just what happened, but what it did to the people it happened to.
