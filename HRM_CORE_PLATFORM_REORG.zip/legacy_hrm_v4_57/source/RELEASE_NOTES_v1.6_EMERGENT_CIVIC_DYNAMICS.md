# HRM_UNIFIED v1.6 — Emergent Civic Dynamics

Purpose: convert repeated synthetic population responses into accumulated civic pressure states and threshold-crossing emergent events.

## Added

- `population/civic_dynamics.py`
  - `CivicDynamicsTracker`
  - `CivicState`
  - `CivicEvent`
  - `run_civic_sequence()`
- `run_civic_dynamics.py`
  - runs a multi-step generic civic sequence
  - writes JSON, Markdown, CSV, and JSONL state trace outputs
- `civic_benchmark.py`
  - deterministic benchmark and fingerprint output
- `scenarios/generic_civic_sequence.json`
  - non-local, non-personal generic scenario sequence

## What v1.6 proves

The system now supports:

```text
stimulus → heterogeneous response → spatial/institutional pressure → accumulation/decay → emergent civic event
```

This is not predictive sociology. It is a traceable synthetic response model with explicit thresholds.

## Event types

- `system_stress_threshold`
- `volatility_threshold`
- `withdrawal_threshold`
- `cooperation_recovery_wave`
- `localized_hotspot`
- `localized_withdrawal`
- `institutional_strain`

## Run commands

```bash
python run_civic_dynamics.py
python run_civic_dynamics.py --scenario scenarios/generic_civic_sequence.json --n 1000 --seed 42
python civic_benchmark.py
```

## Boundary conditions

- No personal assumptions are embedded.
- No locality-specific defaults are embedded.
- No API keys are embedded.
- Institution strain and civic events are synthetic threshold signals, not real-world claims.
