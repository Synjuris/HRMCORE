# HRM Unified v4.38 — Runtime Coupling Fixes

This build is a repair pass over v4.37 based on the user's real Windows run output.

## Defects addressed

1. **Negotiation showed as permanently zero**
   - Root cause: negotiation/deception were emitted as `agent.aux_events`, but aux events were not recorded into the benchmark rolling counters.
   - Fix: aux events now write to `_counters` and JSONL stream before retention filtering.
   - Result: negotiation is visible in benchmark summaries.

2. **Births occurred while final average libido reported 0.000**
   - Root cause: founder age/energy dynamics and final exhaustion made mature survivors report zero libido, while reproduction still occurred through broader pair-bond/energy gates.
   - Fixes:
     - founders are mature-age adults, while newborns are explicitly reset to age 0;
     - reproduction chance now includes libido factor and minimum libido gates;
     - libido floor added for mature, non-collapsed adults;
     - food/resource systems convert small amounts of food into energy so survivors do not end with solved hunger but zero energy.

3. **Recovery systems were dormant**
   - Root cause: formal `care` roles were rarely seeded and the targeted recovery threshold was too strict.
   - Fixes:
     - founder roles now include care/knowledge/craft/logistics families;
     - if no formal care specialist exists, high-cooperation/high-openness agents can provide primitive recovery;
     - recovery threshold/frequency adjusted.

4. **Domestication/herd logic was dormant or unstable**
   - Root cause: attempt probability was too low, then herd growth could explode without caps once activated.
   - Fixes:
     - proto-domestication attempts now occur at low-but-real rates;
     - herd wealth is capped by species carrying scale;
     - herd reproduction is bounded.

5. **Institution/settlement systems remained too weak in small founder bands**
   - Fixes:
     - proto-institution formation threshold supports dyads;
     - required trust threshold reduced for founder-scale societies;
     - institution strength initialized lower but earlier.

## Validation performed

Executed:

```bash
python3 das/run_sim.py
```

The full 10-run x 500-tick benchmark completed and wrote:

```text
benchmark_v04_38.json
runs_v04_38/
```

Observed aggregate results:

- births: 18
- interactions: 8,923
- conflicts: 413
- negotiations: 2,387
- negotiation successes: 825
- deception events: 30
- institution-prevented conflicts: 64
- care events: 537
- targeted psychological recoveries active across runs
- domestication events active across runs
- final avg libido mean: 0.0646

## Compatibility

This package keeps every file from the v4.37 base package and adds v4.38 outputs/release notes/inventory.
