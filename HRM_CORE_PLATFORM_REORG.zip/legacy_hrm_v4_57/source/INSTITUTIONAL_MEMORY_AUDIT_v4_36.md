# v4.36 Institutional Memory Audit

Base: HRM_UNIFIED_v4_35_GENERATIONAL_PSYCHOLOGICAL_TRANSMISSION_FULL_WINDOWS_SAFE.zip

## What was changed
- Added das/institutional_memory.py as an operational closed-loop memory layer.
- Updated das/run_sim.py to instantiate InstitutionalMemoryLedger, run it every tick, include metrics, and write institutional_memory_ledger.json.
- Added RUN_V4_36_INSTITUTIONAL_MEMORY_CULTURAL_PERSISTENCE_WINDOWS_SAFE.bat.
- Added RELEASE_NOTES_v4_36_INSTITUTIONAL_MEMORY_CULTURAL_PERSISTENCE.md.

## What the new layer does
- Converts repeated events into cultural memory anchors.
- Maintains faction/local cultural profiles: trust prior, threat prior, scarcity prior, care norm, knowledge preservation, authority tolerance, divergence index.
- Lets knowledge/information/care/governance carriers and elders transmit cultural memory back into agents.
- Stabilizes proto-institutions from repeated functional needs, not from era labels.
- Allows knowledge preservation, distortion, and loss.

## Anti-hardcoding check
- No date-based profession switching was added.
- No 10000 BC / modern role templates were added.
- Institution functions derive from observed memory domains and local role-family capacity.
- Effects are probabilistic pressure shifts, not deterministic scripts.
