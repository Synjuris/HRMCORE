#!/usr/bin/env python3
"""Run HRM_UNIFIED v3.1 era seeding / reality baseline layer."""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

try:
    from .reality_baseline import ENGINE_VERSION, ERA_PRESETS, make_reality_baseline, write_seed_files, compute_divergence_report, divergence_markdown
except ImportError:
    from reality_baseline import ENGINE_VERSION, ERA_PRESETS, make_reality_baseline, write_seed_files, compute_divergence_report, divergence_markdown

try:
    from .scalable_architecture import _read_json, _write_json
except ImportError:
    from scalable_architecture import _read_json, _write_json


def main() -> int:
    ap = argparse.ArgumentParser(description="Seed HRM from an era/current-reality baseline, run scalable world, and report divergence.")
    ap.add_argument("--era", choices=sorted(list(ERA_PRESETS.keys()) + ["now"]), default="modern")
    ap.add_argument("--start-year", type=int, default=None)
    ap.add_argument("--location", default="generic")
    ap.add_argument("--profile", default="generic_mixed_region")
    ap.add_argument("--custom-baseline", help="Optional JSON file overriding preset baseline fields.")
    ap.add_argument("--mode", choices=["toy", "desktop", "large"], default="toy")
    ap.add_argument("--n", type=int, default=250)
    ap.add_argument("--cycles", type=int, default=1)
    ap.add_argument("--generations-per-cycle", type=int, default=1)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--world-id", default="reality_seeded_world_v3_1")
    ap.add_argument("--output-dir", default="outputs/era_seeded_world_v3_1")
    ap.add_argument("--sleep", type=float, default=0.0)
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--mark-viewed", action="store_true")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--seed-only", action="store_true", help="Write seed files but do not run the simulator.")
    args = ap.parse_args()

    custom = _read_json(args.custom_baseline, {}) if args.custom_baseline else None
    baseline = make_reality_baseline(args.era, args.start_year, args.location, args.profile, custom=custom)
    world_dir = Path(args.output_dir) / args.world_id
    seed_dir = world_dir / "seeds"
    seed_files = write_seed_files(seed_dir, baseline)

    if not args.seed_only:
        cmd = [
            sys.executable,
            str(Path(__file__).with_name("run_scalable_world.py")),
            seed_files["timeline"],
            "--mode", args.mode,
            "--n", str(args.n),
            "--cycles", str(args.cycles),
            "--generations-per-cycle", str(args.generations_per_cycle),
            "--seed", str(args.seed),
            "--profile", args.profile,
            "--world-id", args.world_id,
            "--output-dir", args.output_dir,
            "--sleep", str(args.sleep),
        ]
        if args.resume:
            cmd.append("--resume")
        if args.force:
            cmd.append("--force")
        if args.mark_viewed:
            cmd.append("--mark-viewed")
        completed = subprocess.run(cmd, cwd=Path(__file__).resolve().parent)
        run_code = completed.returncode
    else:
        run_code = 0

    latest = _read_json(world_dir / "world_state_latest.json", {})
    report = compute_divergence_report(baseline, latest)
    reports_dir = world_dir / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    _write_json(reports_dir / "reality_divergence_report.json", report)
    (reports_dir / "reality_divergence_report.md").write_text(divergence_markdown(report), encoding="utf-8")

    print(f"HRM_UNIFIED v{ENGINE_VERSION} ERA SEEDING / REALITY BASELINE")
    print(f"Era: {baseline.era}")
    print(f"Start year: {baseline.start_year}")
    print(f"Location: {baseline.location}")
    print("Wrote seed files:")
    for k, v in seed_files.items():
        print(f"  {k}: {v}")
    print("Wrote divergence report:", reports_dir / "reality_divergence_report.md")
    return 0 if run_code in (0, 2) else run_code


if __name__ == "__main__":
    raise SystemExit(main())
