# HRM_UNIFIED v2.5 — Institutional Evolution Layer

Purpose:

> Institutions should not just remember history — they should change structure because of it.

## Added

- `institutional_evolution.py`
- `run_institutional_evolution.py`
- `institutional_evolution_benchmark.py`
- `RUN_V2_5_INSTITUTIONAL_EVOLUTION_WINDOWS.bat`

## Capabilities

- Institution types
- Legitimacy drift
- Policy/behavior mutation proxy through institutional doctrine changes
- Enforcement style evolution
- Civic doctrine formation
- Reform vs collapse thresholds
- Institutional path dependency
- Institution benchmark report

## Core loop

```text
generational memory
→ institutional legitimacy shift
→ institutional behavior mutation
→ public adaptation
→ new civic equilibrium or breakdown
```

## Outputs

Default runner writes:

- `outputs/institutional_evolution_v2_5/institutional_evolution_report.json`
- `outputs/institutional_evolution_v2_5/institutional_evolution_report.md`

## Notes

This layer is generic and synthetic. It does not encode real local claims, personal facts, or hidden scenario assumptions.
