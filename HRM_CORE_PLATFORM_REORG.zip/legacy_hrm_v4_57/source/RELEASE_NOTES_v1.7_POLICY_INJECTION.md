# HRM_UNIFIED v1.7 — Policy Injection Layer

This release adds synthetic intervention testing on top of the v1.6 civic dynamics layer.

## Added

- `population/policy.py`
- `run_policy.py`
- `policy_benchmark.py`
- generic policy definitions
- generic policy intervention scenario
- before/after civic pressure comparison
- policy cost-unit proxy
- markdown, JSON, CSV reports

## Design constraints

- No personal hardcoding.
- No locality-specific hardcoding.
- No API key embedded.
- Policies are synthetic model interventions, not real-world recommendations.
- Outputs are scenario-comparison artifacts, not predictions.

## Commands

```bash
python run_policy.py
python run_policy.py --scenario scenarios/policy_intervention_sequence.json --policies scenarios/policies_generic.json
python policy_benchmark.py
```
