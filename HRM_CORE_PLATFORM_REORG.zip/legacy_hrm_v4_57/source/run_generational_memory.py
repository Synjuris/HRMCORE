#!/usr/bin/env python3
"""Run HRM_UNIFIED v2.4 generational memory layer."""
from __future__ import annotations

import argparse
from pathlib import Path

try:
    from .population.history import HistoricalSimulator, load_timeline
    from .population.policy import load_policy_definitions, DEFAULT_POLICIES
    from .constitution import ConstitutionEngine
    from .generational_memory import GenerationalMemoryEngine, GenerationReport, GenerationalRunReport, generational_markdown, _summary_from_state
    from .export_utils import ensure_dir
except ImportError:
    from population.history import HistoricalSimulator, load_timeline
    from population.policy import load_policy_definitions, DEFAULT_POLICIES
    from constitution import ConstitutionEngine
    from generational_memory import GenerationalMemoryEngine, GenerationReport, GenerationalRunReport, generational_markdown, _summary_from_state
    from export_utils import ensure_dir


def main() -> int:
    ap = argparse.ArgumentParser(description="Run a long-run synthetic civic simulation with generational memory inheritance.")
    ap.add_argument("timeline", nargs="?", help="Optional timeline JSON/YAML. Defaults to built-in generic timeline.")
    ap.add_argument("--policies", help="Optional policy definition JSON.")
    ap.add_argument("--n", type=int, default=600)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--profile", default="generic_mixed_region")
    ap.add_argument("--decay", type=float, default=0.86)
    ap.add_argument("--generations", type=int, default=4)
    ap.add_argument("--cultural-decay", type=float, default=0.72)
    ap.add_argument("--institutional-decay", type=float, default=0.88)
    ap.add_argument("--cohort-turnover", type=float, default=0.30)
    ap.add_argument("--inheritance-strength", type=float, default=0.42)
    ap.add_argument("--output-dir", default="outputs/generational_memory_v2_4")
    ap.add_argument("--name", default="generational_memory_run")
    args = ap.parse_args()

    policies = load_policy_definitions(args.policies) if args.policies else DEFAULT_POLICIES
    timeline = load_timeline(args.timeline)
    memory = GenerationalMemoryEngine(
        cultural_decay=args.cultural_decay,
        institutional_decay=args.institutional_decay,
        cohort_turnover=args.cohort_turnover,
        inheritance_strength=args.inheritance_strength,
    )
    reports = []
    first_after = None
    previous_after = None
    constitution_failures = 0

    for gen in range(1, max(1, args.generations) + 1):
        sim = HistoricalSimulator(n=args.n, seed=args.seed + gen - 1, profile=args.profile, decay=args.decay, policies=policies)
        inherited_shift = memory.apply_baseline_to_simulator(sim)
        before = _summary_from_state(sim.tracker.state)
        result = sim.run(timeline, name=f"{args.name}_generation_{gen}")
        audit = ConstitutionEngine().audit_historical_result(result)
        if not audit.passed:
            constitution_failures += 1
        after = _summary_from_state(result.final_state)
        encoded = memory.encode_result(result, generation_label=f"generation_{gen}")
        if first_after is None:
            first_after = dict(after)
        previous_after = dict(after)
        reports.append(GenerationReport(
            generation=gen,
            label=str(timeline.get("name") or "default_timeline"),
            before_state=before,
            after_state=after,
            encoded_memory=encoded,
            inherited_baseline_shift=inherited_shift,
            cohort_summary=[c.to_dict() for c in memory.state.cohorts],
            constitution_passed=audit.passed,
        ))

    final_memory = memory.to_dict()
    first_after = first_after or {k: 0.0 for k in ["stress_pressure","trust_pressure","volatility_pressure","cooperation_pressure","withdrawal_pressure"]}
    previous_after = previous_after or dict(first_after)
    benchmark = {
        "generations": len(reports),
        "constitution_failures": constitution_failures,
        "cohort_count": len(final_memory.get("cohorts", [])),
        "final_memory_fingerprint": final_memory.get("fingerprint"),
        "stress_delta_final_minus_generation_1": round(previous_after.get("stress_pressure", 0.0) - first_after.get("stress_pressure", 0.0), 6),
        "trust_delta_final_minus_generation_1": round(previous_after.get("trust_pressure", 0.0) - first_after.get("trust_pressure", 0.0), 6),
        "resilience_inheritance": final_memory.get("resilience_inheritance", 0.0),
        "max_historical_scar": round(max(final_memory.get("historical_scars", {"none": 0}).values() or [0.0]), 6),
    }
    report = GenerationalRunReport("2.4", args.name, reports, final_memory, benchmark)

    out = ensure_dir(args.output_dir)
    json_path = out / "generational_memory_report.json"
    md_path = out / "generational_memory_report.md"
    json_path.write_text(report.to_json(), encoding="utf-8")
    md_path.write_text(generational_markdown(report), encoding="utf-8")

    print("HRM_UNIFIED v2.4 GENERATIONAL MEMORY")
    print(f"Generations: {len(reports)}")
    print(f"Final memory fingerprint: {benchmark['final_memory_fingerprint'][:16]}")
    print("Wrote:")
    print("  json:", json_path)
    print("  markdown:", md_path)
    return 0 if constitution_failures == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())
