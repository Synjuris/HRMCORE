# HRM_UNIFIED v3.3 — Real Dataset Ingestion + Calibration Layer

Purpose: convert public/local datasets into inspectable HRM calibration priors.

This layer does **not** pretend one CSV/API call makes the simulation true. It creates a calibration bundle with:

- raw recognized metrics
- normalized model drivers
- HRM config patch
- disease/public-health patch
- era/reality baseline patch
- scale architecture patch
- calibration score
- missing-data warnings
- source hashes for local files

## Fast Windows test

Double-click:

`RUN_V3_3_REAL_DATASET_CALIBRATION_WINDOWS_SAFE.bat`

With no custom input, it uses:

`datasets/sample_real_dataset.csv`

and writes:

`outputs/real_dataset_calibration_v3_3/real_dataset_calibration_report.md`

## Use your own CSV or JSON

```bat
py -3 run_real_dataset_calibration.py --input path\to\your_file.csv --geography "Your Target Region"
```

Accepted columns include any of these names:

- `population_total`, `population`, `total_population`, `pop`
- `median_household_income`, `median_income`, `income`
- `poverty_pct`, `poverty_rate`
- `unemployment_pct`, `unemployment_rate`
- `under_18_pct`, `children_pct`, `youth_pct`
- `age_65_plus_pct`, `senior_pct`, `elderly_pct`
- `bachelors_or_higher_pct`, `education_ba_pct`, `college_pct`
- `renter_occupied_pct`, `renters_pct`
- `manufacturing_employment_pct`, `manufacturing_pct`
- `density_per_sq_mile`, `density`, `population_density`
- `hospital_beds_per_1000`, `beds_per_1000`, `healthcare_capacity`
- `violent_crime_rate`, `crime_rate`, `violence_rate`
- `commute_minutes`, `mean_commute_minutes`

## Optional ACS fetch

The older Census ACS adapter is still supported:

```bat
py -3 run_real_dataset_calibration.py --state 47 --county 113 --geography "Madison County, TN"
```

If no internet/API access is available, the run does not crash. It writes a warning and continues with whatever local data exists.

## Output files

- `real_dataset_calibration_bundle.json`
- `real_dataset_calibration_report.md`
- `hrm_config_patch.json`
- `disease_patch.json`
- `era_patch.json`
- `scale_patch.json`

## Design rule

This is calibration, not prophecy. The engine is still synthetic. Real data shifts priors, constraints, baselines, and warnings; it does not magically make outcomes certain.
