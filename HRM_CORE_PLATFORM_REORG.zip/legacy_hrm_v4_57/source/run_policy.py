#!/usr/bin/env python3
"""Run HRM_UNIFIED v1.7 policy injection scenarios."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

try:
    from .population.policy import (
        run_policy_sequence,
        default_policy_scenario,
        DEFAULT_POLICIES,
        load_policy_definitions,
        load_policy_sequence,
    )
    from .export_utils import ensure_dir, safe_slug
except ImportError:
    from population.policy import (
        run_policy_sequence,
        default_policy_scenario,
        DEFAULT_POLICIES,
        load_policy_definitions,
        load_policy_sequence,
    )
    from export_utils import ensure_dir, safe_slug


def write_policy_outputs(result, output_dir: str, prefix: str = "policy_injection"):
    out = ensure_dir(output_dir)
    summary_json = out / f"{prefix}_summary.json"
    summary_md = out / f"{prefix}_summary.md"
    steps_csv = out / f"{prefix}_steps.csv"
    events_csv = out / f"{prefix}_events.csv"

    summary_json.write_text(result.to_json(), encoding="utf-8")

    lines = [
        "# HRM_UNIFIED v1.7 Policy Injection Report",
        "",
        f"**Scenario:** {result.scenario_name}",
        f"**Profile:** {result.profile_name}",
        f"**Population:** {result.population_size}",
        f"**Total policy cost units:** {result.total_cost_units:.2f}",
        "",
        "## Final Civic Pressures",
        "",
        "| Pressure | Value |",
        "|---|---:|",
    ]
    for k, v in result.final_state.summary().items():
        lines.append(f"| {k} | {v:+.4f} |")

    cb = result.cost_benefit()
    lines += ["", "## Cost/Benefit Proxy", "", "| Metric | Value |", "|---|---:|"]
    for k, v in cb.items():
        lines.append(f"| {k} | {v:+.4f} |")

    lines += ["", "## Scenario and Policy Steps", "", "| Tick | Type | Label | Stress Before | Stress After | Volatility Before | Volatility After | Cost |", "|---:|---|---|---:|---:|---:|---:|---:|"]
    for s in result.steps:
        before = s.state_before or {}
        after = s.state_after or {}
        lines.append(
            f"| {s.tick} | {s.kind} | {s.label} | "
            f"{float(before.get('stress_pressure', 0.0)):+.4f} | {float(after.get('stress_pressure', 0.0)):+.4f} | "
            f"{float(before.get('volatility_pressure', 0.0)):+.4f} | {float(after.get('volatility_pressure', 0.0)):+.4f} | "
            f"{s.cost_units:.2f} |"
        )

    lines += ["", "## Policies Used", "", "| Policy | Cost Units | Direct Effects |", "|---|---:|---|"]
    if result.policies:
        for p in result.policies:
            effects = ", ".join(f"{k}:{v:+.3f}" for k, v in p.effects.items())
            lines.append(f"| {p.name} | {p.cost_units:.2f} | {effects} |")
    else:
        lines.append("| none | 0.00 | — |")

    lines += ["", "## Emergent Events", "", "| Tick | Kind | Scope | Severity | Message |", "|---:|---|---|---:|---|"]
    if result.events:
        for e in result.events:
            lines.append(f"| {e.tick} | {e.kind} | {e.scope} | {e.severity:.4f} | {e.message} |")
    else:
        lines.append("| — | none | — | 0.0000 | No thresholds crossed. |")

    summary_md.write_text("\n".join(lines), encoding="utf-8")

    with steps_csv.open("w", encoding="utf-8") as f:
        f.write("tick,kind,label,policy_id,cost_units,stress_before,stress_after,volatility_before,volatility_after,trust_before,trust_after\n")
        for s in result.steps:
            before = s.state_before or {}
            after = s.state_after or {}
            f.write(
                f'{s.tick},{s.kind},"{s.label.replace(chr(34), chr(34)*2)}",{s.policy_id or ""},{s.cost_units},'
                f'{float(before.get("stress_pressure", 0.0))},{float(after.get("stress_pressure", 0.0))},'
                f'{float(before.get("volatility_pressure", 0.0))},{float(after.get("volatility_pressure", 0.0))},'
                f'{float(before.get("trust_pressure", 0.0))},{float(after.get("trust_pressure", 0.0))}\n'
            )

    with events_csv.open("w", encoding="utf-8") as f:
        f.write("tick,kind,scope,severity,message\n")
        for e in result.events:
            msg = e.message.replace('"', '""')
            f.write(f'{e.tick},{e.kind},{e.scope},{e.severity},"{msg}"\n')

    return {
        "summary_json": str(summary_json),
        "summary_md": str(summary_md),
        "steps_csv": str(steps_csv),
        "events_csv": str(events_csv),
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Run a synthetic policy intervention scenario.")
    ap.add_argument("--scenario", help="Optional JSON scenario sequence with policy steps.")
    ap.add_argument("--policies", help="Optional JSON policy definition file.")
    ap.add_argument("--n", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--profile", default="generic_mixed_region")
    ap.add_argument("--decay", type=float, default=0.86)
    ap.add_argument("--name", default="default_policy_sequence")
    ap.add_argument("--output-dir", default="outputs/policy_v1_7")
    args = ap.parse_args()

    sequence = load_policy_sequence(args.scenario) if args.scenario else default_policy_scenario()
    policies = load_policy_definitions(args.policies) if args.policies else DEFAULT_POLICIES

    result = run_policy_sequence(
        sequence=sequence,
        policies=policies,
        n=args.n,
        seed=args.seed,
        profile=args.profile,
        decay=args.decay,
        scenario_name=args.name,
    )

    print(result.summary())
    paths = write_policy_outputs(result, args.output_dir, prefix=safe_slug("policy_" + args.name))
    print("\nWrote:")
    for k, v in paths.items():
        print(f"  {k}: {v}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
