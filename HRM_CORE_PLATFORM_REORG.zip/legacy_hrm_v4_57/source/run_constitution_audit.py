"""Run HRM_UNIFIED v2.3 constitution/invariant audit."""
from __future__ import annotations

import argparse
from pathlib import Path

try:
    from .population.history import HistoricalSimulator, load_timeline
    from .population.policy import load_policy_definitions, DEFAULT_POLICIES
    from .constitution import ConstitutionEngine, constitution_markdown
    from .export_utils import ensure_dir
except ImportError:
    from population.history import HistoricalSimulator, load_timeline
    from population.policy import load_policy_definitions, DEFAULT_POLICIES
    from constitution import ConstitutionEngine, constitution_markdown
    from export_utils import ensure_dir


def main() -> int:
    ap = argparse.ArgumentParser(description="Run constitution/invariant audit over a generic synthetic civic timeline.")
    ap.add_argument("timeline", nargs="?", help="Optional timeline JSON/YAML. Defaults to built-in generic timeline.")
    ap.add_argument("--policies", help="Optional policy definition JSON.")
    ap.add_argument("--n", type=int, default=600)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--profile", default="generic_mixed_region")
    ap.add_argument("--decay", type=float, default=0.86)
    ap.add_argument("--output-dir", default="outputs/constitution_v2_3")
    args = ap.parse_args()

    policies = load_policy_definitions(args.policies) if args.policies else DEFAULT_POLICIES
    timeline = load_timeline(args.timeline)
    sim = HistoricalSimulator(n=args.n, seed=args.seed, profile=args.profile, decay=args.decay, policies=policies)
    result = sim.run(timeline, name=str(timeline.get("name") or "constitution_audit_timeline"))
    report = ConstitutionEngine().audit_historical_result(result)

    out = ensure_dir(args.output_dir)
    json_path = out / "constitution_audit.json"
    md_path = out / "constitution_audit.md"
    json_path.write_text(report.to_json(), encoding="utf-8")
    md_path.write_text(constitution_markdown(report), encoding="utf-8")

    print("HRM_UNIFIED v2.3 constitution audit:", "PASS" if report.passed else "FAIL")
    print("Wrote:")
    print("  json:", json_path)
    print("  markdown:", md_path)
    return 0 if report.passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
