# HRM Unified v4.40 — Settlement Persistence + Demographic Stability

Recovery-grade build from v4.39. This version addresses the live bottleneck seen in v4.39: civilization systems were present, but populations still ended near terminal survivor counts and occupied cells often collapsed too tightly.

## Added

- `das/settlements.py`
  - persistent settlement records by cell
  - home-cell assignment
  - settlement continuity
  - settlement support/care buffering
  - infrastructure memory
  - storage memory
  - controlled secondary-site budding
  - settlement metrics and `settlements.json` output

## Changed

- Reproduction thresholds rebalanced for small founder populations.
- Newborns receive viable early-life state initialization instead of inheriting fragile defaults.
- Small-population sex-balance guard prevents immediate one-sex demographic dead ends.
- Child and low-population mortality buffering extended so second/third-generation dynamics can actually express.
- Event/metric JSON writes are compacted to keep runtime feasible as event volume grows.
- Default output root moved to `runs_v04_40`.
- Benchmark file moved to `benchmark_v04_40.json`.

## Validation Performed

- Python compile check passed.
- 10 runs × 300 ticks completed successfully in this environment.
- The 500-tick default remains in code, but the 10 × 500 validation run exceeded the sandbox execution time limit before completion. It completed through multiple runs and showed the intended direction, but is not claimed here as a completed validation.

## Observed Validation Signals from 10 × 300

- births total: 31
- household count final total: 28
- interaction events: 10,684
- negotiation events: 2,443
- institution-prevented conflicts: 100
- information created: 10,635
- information relayed: 12,588
- settlement active mean: 29.4
- living home-cell mean: 3.4
- occupied-cell mean: 2.4
- settlement continuity mean: 0.2388

## Known Remaining Issues

- Long-run 10 × 500 validation needs local execution outside the sandbox timeout.
- Population still experiences high founder death; the important improvement is that child generations survive and carry continuity forward.
- Conflict rates dropped in the 300-tick validation, likely because settlement buffering strongly stabilizes the population. Later tuning may need to restore more conflict variance without returning to collapse.
