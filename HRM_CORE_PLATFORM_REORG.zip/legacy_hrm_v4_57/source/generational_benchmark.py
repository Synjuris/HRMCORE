#!/usr/bin/env python3
"""Small v2.4 benchmark entrypoint."""
from __future__ import annotations

try:
    from .run_generational_memory import main
except ImportError:
    from run_generational_memory import main

if __name__ == "__main__":
    raise SystemExit(main())
