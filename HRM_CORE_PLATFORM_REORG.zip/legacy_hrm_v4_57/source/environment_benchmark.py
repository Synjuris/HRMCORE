#!/usr/bin/env python3
"""Deterministic benchmark for HRM_UNIFIED v2.1 environment layer."""
from __future__ import annotations

from pathlib import Path

try:
    from .environment import SyntheticCivicEnvironment
    from .population.history import default_timeline
except ImportError:
    from environment import SyntheticCivicEnvironment
    from population.history import default_timeline


def main() -> int:
    out = Path("outputs/environment_benchmark_v2_2")
    env = SyntheticCivicEnvironment()
    paths1 = env.run_timeline(default_timeline(), output_dir=out, name="benchmark_primary", build_observatory=False)
    snap = paths1["snapshot"]
    branch = SyntheticCivicEnvironment.load(snap).branch("continued")
    paths2 = branch.run_timeline(default_timeline(), output_dir=out, name="benchmark_continued", build_observatory=False)
    print("HRM_UNIFIED v2.2 environment benchmark: PASS")
    print(f"primary_snapshot: {snap}")
    print(f"continued_snapshot: {paths2['snapshot']}")
    print(f"primary_fingerprint: {paths1['environment_fingerprint'][:16]}")
    print(f"continued_fingerprint: {paths2['environment_fingerprint'][:16]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
