@echo off
setlocal
cd /d "%~dp0"
echo Running HRM_UNIFIED v4.41 validation harness...
py -3 validate_build.py --profile smoke --runs 2 --ticks 80 --population 10 --timeout 180
pause
