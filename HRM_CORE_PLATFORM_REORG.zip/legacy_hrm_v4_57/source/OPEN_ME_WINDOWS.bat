@echo off
setlocal
cd /d "%~dp0"
echo HRM_UNIFIED v2.3 Constitution Layer
echo.
echo Checking Python...
py -3 --version >nul 2>&1
if errorlevel 1 (
  echo Python launcher py -3 was not found.
  echo Install Python 3 from python.org and check "Add Python to PATH".
  pause
  exit /b 1
)
echo Running constitution audit...
py -3 run_constitution_audit.py
pause
