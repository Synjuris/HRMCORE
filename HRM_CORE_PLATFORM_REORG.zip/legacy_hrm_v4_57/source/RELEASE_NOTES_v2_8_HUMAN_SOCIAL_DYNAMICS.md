# HRM_UNIFIED v2.8 — Human Social Dynamics + DAS Deep Integration

Purpose: make DAS social mechanics part of the persistent HRM world state instead of leaving them as a separate attached subsystem.

Adds:
- human lifecycle pressure
- reproduction and mortality pressure
- pair-bond stability
- family continuity and lineage records
- kinship density
- identity expression dynamics
- sexuality expression dynamics
- norm tolerance
- factionalism and belief rigidity
- role specialization and labor stratification
- migration pressure and territorial attachment
- language and information density
- DAS integration manifest
- persistent social state checkpointing
- social dynamics report
- Windows-safe launcher

Gender and sexuality are represented structurally, not as stereotypes or scripted morality. They interact with bonding, reproduction, cultural norms, institutional legitimacy, identity expression, and demographic continuity.

Run:

```bat
RUN_V2_8_HUMAN_SOCIAL_DYNAMICS_WINDOWS_SAFE.bat
```

Outputs:
- `outputs/human_social_dynamics_v2_8/default_world/reports/human_social_dynamics_report.md`
- `outputs/human_social_dynamics_v2_8/default_world/reports/since_last_viewed_report.md`
- `outputs/human_social_dynamics_v2_8/default_world/world_state_latest.json`
- `outputs/human_social_dynamics_v2_8/default_world/evolution_timeline.json`
