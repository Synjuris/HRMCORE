# HRM Unified v4.37 — Social Viability + Population Stability Pass

This build repairs the v4.36 runtime failure where simulations compiled but collapsed before civilization systems could activate.

## Fixes
- Fixed benchmark crash from missing `episodes` / `turning_points` summary fields.
- Added founder-band seeding: clustered starting positions, balanced founding sexes, initial trust runway, viable energy/resources.
- Added per-tick social viability substrate: rendezvous movement, cooperative food sharing, early mortality buffering, pair-bond runway.
- Lowered reproduction thresholds enough for generational systems to activate without forcing births.
- Reduced exhaustion/starvation runaway in constraints and subsistence.
- Added metrics for living count, sex balance, social drive, and viable reproductive pairs.

## Intent
This is not a scripted success condition. It repairs ecological/social viability so existing systems—relationships, reproduction, culture, institutions, inheritance, and memory—can actually express themselves during normal runs.
