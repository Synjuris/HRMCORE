# v4.37 Validation Report

## Checks run
- Python compile check across full package: passed.
- Full default simulation: `10` runs × `500` ticks completed.
- Benchmark write: `benchmark_v04_37.json` produced.
- Omission diff against v4.36 base: `0` missing files.

## Runtime outcome summary
```json
{
  "runs": 10,
  "ticks": 500,
  "total_births": 20,
  "total_interactions": 10315,
  "total_conflicts": 1070,
  "recovered_runs": 3,
  "omitted_files": 0
}
```

## Runtime defect fixed
The v4.36 runtime failure had two layers:

1. `build_benchmark()` assumed summary keys `episodes` and `turning_points`; those are now read with safe defaults.
2. The recovered `RelationshipBook` lacked methods already expected by active systems (`update_after_interaction`, `cool_resentments`). `safe_agent_tick()` was silently marking agents dead on first interaction. v4.37 restores those methods and adds viability metrics.

## Social viability changes
- Founder band seeding with clustered encounter topology.
- Balanced founding biological sex distribution.
- Initial familiarity/trust runway.
- Cooperative food sharing.
- Low-population rendezvous behavior.
- Pair-bond runway.
- Gentler exhaustion and starvation curves.
- Reproduction thresholds retuned so generational systems can activate without forcing deterministic growth.
