
from __future__ import annotations
from typing import Dict, Tuple
import re

TOPIC_LEX = {
    "economy":  ["layoff","layoffs","closure","closures","closed","shutdown","inflation","recession","wage","factory","jobs","market","rent","prices","eviction","loss","losses","slowdown","downturn"],
    "crime":    ["crime","shooting","violent","assault","theft","robbery","gang","homicide","riot","carjacking","threat","unsafe","danger","safety"],
    "health":   ["pandemic","virus","hospital","overdose","opioid","disease","mental","suicide","obesity"],
    "govern":   ["policy","ban","law","regulation","tax","court","election","governor","congress","sanction"],
    "community":["protest","volunteer","charity","festival","church","neighborhood","community","solidarity"],
    "education":["school","teacher","student","curriculum","campus","college","tuition","literacy"],
    "environment":["climate","wildfire","flood","drought","pollution","heatwave","storm"],
    "tech":     ["ai","automation","hack","breach","surveillance","app","startup","robot"],
    "terror":   ["terror","bomb","attack","explosion","hostage","hijack"],
}

POS_WORDS = {"growth","aid","funding","support","win","peace","recovery","improve","drop","decline_prices","relief","invest"}
NEG_WORDS = {"crisis","fear","panic","anger","shortage","spike","collapse","closure","closures","closed","shutdown","layoff","layoffs","strike","controversy","corruption","anxiety","attack","dead","deaths","tragedy","loss","losses","slowdown","downturn","threat","unsafe","danger"}

SEVERITY_WORDS = {
    "minor": 0.7, "small": 0.8, "isolated": 0.8, "limited": 0.85, "contained": 0.9,
    "major": 1.4, "severe": 1.8, "massive": 2.0, "catastrophic": 2.5, "disaster": 2.3,
    "terror": 2.5, "terrorist": 2.6, "attack": 2.0, "explosion": 2.0, "war": 2.8, "genocide": 3.0
}

SCOPE_WORDS = {
    "neighborhood": 0.10, "block": 0.08, "local": 0.15, "city": 0.25, "metropolitan": 0.30,
    "statewide": 0.40, "regional": 0.50, "nationwide": 0.80, "national": 0.75, "country": 0.75,
    "global": 1.00, "worldwide": 1.00, "international": 0.85
}

LOCALITY_HINTS = {"in ", "at ", "near ", "downtown", "city", "county", "neighborhood", "airport", "mall", "school"}

RESONANCE_HOOKS = {
    "economy":  [0],
    "crime":    [1],
    "health":   [2],
    "govern":   [3],
    "community":[4],
    "environment":[5],
    "education":[0,4],
    "tech":     [0,3],
    "terror":   [1,3],
}

def _sentiment(text: str) -> float:
    t = text.lower()
    score = 0
    for w in POS_WORDS:
        if w in t: score += 1
    for w in NEG_WORDS:
        if w in t: score -= 1
    score += t.count("!") * 0.2
    return max(-1.0, min(1.0, score / 4.0))

def _severity_and_scope(text: str) -> Tuple[float, float]:
    t = text.lower()
    sev = 1.0
    for w, mult in SEVERITY_WORDS.items():
        if w in t: sev *= mult
    sev = max(0.5, min(3.0, sev))
    scope = 0.15
    for w, val in SCOPE_WORDS.items():
        if w in t:
            scope = max(scope, val)
    return sev, max(0.05, min(1.0, scope))

def _locality_bias(text: str) -> float:
    t = text.lower()
    hits = sum(1 for h in LOCALITY_HINTS if h in t)
    if hits >= 2: return 0.08
    if hits == 1: return 0.05
    return 0.03

def parse_event_text(text: str) -> Dict[str, float]:
    t = re.sub(r"[^a-zA-Z0-9\s]", " ", text.lower())
    tokens = t.split()
    hits = {k: 0 for k in TOPIC_LEX}
    for tok in tokens:
        for topic, vocab in TOPIC_LEX.items():
            if any(tok.startswith(v) or v in tok for v in vocab):
                hits[topic] += 1
    total = sum(hits.values()) or 1
    val = _sentiment(text)
    sev, scope = _severity_and_scope(text)
    local_hint = _locality_bias(text)
    local_scope = min(scope, max(0.01, local_hint))
    national_scope = max(scope, 0.6 if scope >= 0.5 else scope)

    tags: Dict[str,float] = {}
    for topic, c in hits.items():
        if c == 0: continue
        mag = (c / total)
        tags[topic] = float(val * mag)
    tags["valence"] = float(val)
    tags["severity"] = float(sev)
    tags["scope"] = float(scope)
    tags["local_scope"] = float(local_scope)
    tags["national_scope"] = float(national_scope)
    return tags

def map_tags_to_effects(tags: Dict[str,float], scale: float = 1.0, scope_override: float | None = None) -> Dict[str, float]:
    val = tags.get("valence", 0.0)
    severity = tags.get("severity", 1.0)
    scope = float(scope_override) if scope_override is not None else tags.get("scope", 1.0)
    base_scale = severity * scope * scale

    affect_d  = 0.25 * val * base_scale
    satis_d   = 0.30 * val * base_scale
    stress_d  = -0.20 * val * base_scale
    income_d  = 0.00
    ideology_d= 0.00
    rboost: Dict[int, float] = {}
    for topic, mag in tags.items():
        if topic in ("valence","severity","scope","local_scope","national_scope"): continue
        s = mag * base_scale
        if topic == "economy":
            income_d += -0.25 * abs(s) * (1 if s < 0 else -0.5)
            stress_d +=  0.15 * (-1 if s > 0 else 1) * abs(s)
        if topic == "crime" or topic == "terror":
            stress_d += 0.25 * abs(s) * (1 if s < 0 else -0.4)
            ideology_d += -0.12 * s
        if topic == "health":
            satis_d  += -0.15 * abs(s) * (1 if s < 0 else -0.2)
        if topic == "govern":
            ideology_d += 0.12 * s
        if topic == "community":
            satis_d  += 0.12 * s
            stress_d += -0.08 * s
        if topic == "environment":
            stress_d += 0.10 * abs(s) * (1 if s < 0 else -0.3)
        if topic == "education":
            satis_d  += 0.06 * s
        if topic == "tech":
            satis_d  += 0.05 * s
        for idx in RESONANCE_HOOKS.get(topic, []):
            rboost[idx] = rboost.get(idx, 0.0) + 0.20 * s
    if val < 0: stress_d = abs(stress_d)
    else:       stress_d = -abs(stress_d)
    return {
        "affect_d": affect_d,
        "satis_d": satis_d,
        "stress_d": stress_d,
        "income_d": income_d,
        "ideology_d": ideology_d,
        "resonance_boost": rboost,
    }


# ── Public API wrappers for inject.py ─────────────────────────────────────────

def parse_stimulus(text: str) -> Dict[str, float]:
    """
    Parse a text stimulus into a signal dict.
    Returns tags + effects ready for apply_stimulus().
    """
    tags = parse_event_text(text)
    effects = map_tags_to_effects(tags)
    return {"tags": tags, "effects": effects}


def apply_stimulus(sim, signal: Dict) -> None:
    """
    Apply a parsed stimulus signal to an HRMCore simulation instance.
    Modulates agent stress, belief, and valence based on signal effects.
    """
    effects = signal.get("effects", {})
    stress_d = effects.get("stress_d", 0.0)
    satis_d = effects.get("satis_d", 0.0)
    affect_d = effects.get("affect_d", 0.0)

    for agent in sim.agents:
        s = agent.state
        tr = agent.traits
        # Scale by social sensitivity — more sensitive agents react more
        sensitivity = getattr(tr, "social_sensitivity", 0.5)
        scale = 0.5 + sensitivity
        s.stress = max(0.0, min(1.0, s.stress + stress_d * scale))
        s.valence = max(-1.0, min(1.0, s.valence + affect_d * scale))
        s.belief = max(0.0, min(1.0, s.belief + satis_d * 0.5 * scale))
