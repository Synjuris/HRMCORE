from typing import Dict
import re

_SPACY_OK = False
_TRANSFORMERS_OK = False
nlp = None
pipe = None

try:
    import spacy
    try:
        nlp = spacy.load("en_core_web_sm")
    except Exception:
        nlp = None
    _SPACY_OK = nlp is not None
except Exception:
    pass

try:
    from transformers import pipeline
    pipe = pipeline("sentiment-analysis")
    _TRANSFORMERS_OK = True
except Exception:
    pass

KEYWORDS = {
    "joy": ["love", "win", "success", "happy", "fun", "good"],
    "fear": ["fear", "risk", "threat", "danger", "unsafe", "worry"],
    "anger": ["angry", "mad", "hate", "injustice", "cheat", "lie"],
}

def _keyword_scores(text: str) -> Dict[str, float]:
    t = text.lower()
    scores = {"joy": 0.0, "fear": 0.0, "anger": 0.0}
    for k, words in KEYWORDS.items():
        for w in words:
            if re.search(rf"\b{re.escape(w)}\b", t):
                scores[k] += 1.0
    m = max(scores.values()) if scores else 0.0
    if m > 0:
        for k in scores:
            scores[k] /= m
    return scores

def text_to_emotion_semantic(text: str) -> Dict[str, float]:
    if pipe is not None:
        try:
            out = pipe(text, truncation=True)[0]
            if out["label"].upper().startswith("POS"):
                return {"joy": min(1.0, out["score"]), "fear": 0.0, "anger": 1.0 - out["score"]}
            else:
                sc = min(1.0, out["score"])
                return {"joy": 0.0, "fear": sc*0.5, "anger": sc*0.8}
        except Exception:
            pass
    if nlp is not None:
        doc = nlp(text)
        pos = sum(t.is_alpha and not t.is_stop for t in doc) or 1
        return {"joy": 0.5, "fear": 0.25, "anger": 0.25}
    return _keyword_scores(text)
