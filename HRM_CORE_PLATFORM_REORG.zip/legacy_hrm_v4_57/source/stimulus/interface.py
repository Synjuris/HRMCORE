
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Tuple, List
import random
import json

try:
    import torch
except ImportError:  # torch is optional for map builders; required only for run()
    torch = None

try:
    from ..core.state import SimParams
    from ..core.determinism import initialize_determinism
except ImportError:  # direct project-root usage
    from core.state import SimParams
    from core.determinism import initialize_determinism


def load_region_data(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_timeline(path: str) -> list:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data if isinstance(data, list) else data.get("events", [])


@dataclass
class RunRequest:
    n: int = 800
    ticks: int = 150
    seed: int = 42
    params: Dict[str, Any] = field(default_factory=dict)
    timeline_path: Optional[str] = None
    region: Optional[str] = None
    region_data_path: Optional[str] = None


def _build_params(req: RunRequest) -> SimParams:
    base = SimParams(n=int(req.n), ticks=int(req.ticks))
    merged: Dict[str, Any] = {**base.__dict__, **(req.params or {})}

    if req.region is not None:
        merged["region"] = req.region
        if req.region_data_path:
            merged["region_data"] = load_region_data(req.region_data_path)

    if req.timeline_path:
        merged["timeline_events"] = load_timeline(req.timeline_path)

    return SimParams(**merged)


def _rand_in_box(box: Tuple[float, float, float, float]) -> Tuple[float, float]:
    lat_min, lat_max, lon_min, lon_max = box
    return (
        random.uniform(lat_min, lat_max),
        random.uniform(lon_min, lon_max),
    )


# ---------- MAP MODE 1: GENERIC ABSTRACT CITY ----------

def build_map_frames_generic_city(n: int, ticks: int, seed: int) -> Dict[str, Any]:
    """Abstract city-level view with simple commuting patterns.

    Coordinates are normalized x/y-like values, not a real place.
    """
    random.seed(seed)

    RES_BOX = (0.10, 0.45, 0.10, 0.45)
    WORK_BOX = (0.45, 0.80, 0.35, 0.70)
    SCHOOL_BOX = (0.25, 0.65, 0.55, 0.90)

    agents: List[Dict[str, Any]] = []
    for i in range(n):
        role = random.choices(
            ["worker", "student", "other"],
            weights=[0.5, 0.25, 0.25],
            k=1,
        )[0]
        home = _rand_in_box(RES_BOX)
        if role == "worker":
            dest = _rand_in_box(WORK_BOX)
        elif role == "student":
            dest = _rand_in_box(SCHOOL_BOX)
        else:
            dest = home
        agents.append({"id": i, "role": role, "home": home, "dest": dest})

    frames: List[Dict[str, Any]] = []
    for t in range(ticks + 1):
        hour = t % 24
        nodes = []
        for a in agents:
            r = a["role"]
            if r == "worker":
                loc = a["dest"] if 8 <= hour < 17 else a["home"]
            elif r == "student":
                loc = a["dest"] if 8 <= hour < 15 else a["home"]
            else:
                loc = a["home"]

            base_trust = 0.6
            if 7 <= hour <= 9 or 16 <= hour <= 18:
                base_trust -= 0.1
            trust = max(0.1, min(0.99, base_trust + random.uniform(-0.05, 0.05)))

            nodes.append(
                {
                    "id": a["id"],
                    "x": loc[0],
                    "y": loc[1],
                    "trust": trust,
                    "role": r,
                }
            )
        frames.append({"t": t, "nodes": nodes})

    return {"mode": "generic_city", "frames": frames}


def build_map_frames_jackson(n: int, ticks: int, seed: int) -> Dict[str, Any]:
    """Backward-compatible alias for older callers. Use build_map_frames_generic_city."""
    return build_map_frames_generic_city(n=n, ticks=ticks, seed=seed)


# ---------- MAP MODE 2: DEMO CITY (NEUTRAL) ----------

def build_map_frames_demo(n: int, ticks: int, seed: int) -> Dict[str, Any]:
    """Neutral synthetic city for portable demos."""
    random.seed(seed + 1337)

    RES_BOX = (37.76, 37.78, -122.44, -122.40)
    WORK_BOX = (37.77, 37.775, -122.42, -122.405)
    SCHOOL_BOX = (37.765, 37.775, -122.435, -122.415)

    agents: List[Dict[str, Any]] = []
    for i in range(n):
        role = random.choices(
            ["worker", "student", "other"],
            weights=[0.55, 0.20, 0.25],
            k=1,
        )[0]
        home = _rand_in_box(RES_BOX)
        if role == "worker":
            dest = _rand_in_box(WORK_BOX)
        elif role == "student":
            dest = _rand_in_box(SCHOOL_BOX)
        else:
            dest = home
        agents.append({"id": i, "role": role, "home": home, "dest": dest})

    frames: List[Dict[str, Any]] = []
    for t in range(ticks + 1):
        hour = t % 24
        nodes = []
        for a in agents:
            r = a["role"]
            if r == "worker":
                loc = a["dest"] if 9 <= hour < 17 else a["home"]
            elif r == "student":
                loc = a["dest"] if 8 <= hour < 15 else a["home"]
            else:
                loc = a["home"]

            base_trust = 0.65
            if 12 <= hour <= 13:
                base_trust += 0.05
            trust = max(0.1, min(0.99, base_trust + random.uniform(-0.05, 0.05)))

            nodes.append(
                {
                    "id": a["id"],
                    "lat": loc[0],
                    "lon": loc[1],
                    "trust": trust,
                    "role": r,
                }
            )
        frames.append({"t": t, "nodes": nodes})

    return {"center": [37.77, -122.42], "frames": frames}


# ---------- MAP MODE 3: BUILDING LAYOUT (MICRO) ----------

def build_map_frames_building(n: int, ticks: int, seed: int) -> Dict[str, Any]:
    """Micro-level facility view: entrance/offices/cafeteria/floor."""
    random.seed(seed + 4242)

    zones = {
        "entrance": (0.05, 0.30, 0.10, 0.25),
        "office": (0.55, 0.95, 0.08, 0.40),
        "floor": (0.10, 0.90, 0.45, 0.92),
        "cafeteria": (0.12, 0.40, 0.18, 0.40),
    }

    def rand_in_zone(name: str) -> Tuple[float, float]:
        x1, x2, y1, y2 = zones[name]
        return (random.uniform(x1, x2), random.uniform(y1, y2))

    agents: List[Dict[str, Any]] = []
    for i in range(n):
        role = random.choices(
            ["staff", "line", "visitor"],
            weights=[0.3, 0.6, 0.1],
            k=1,
        )[0]
        home_zone = "office" if role == "staff" else "floor"
        home = rand_in_zone(home_zone)
        work = rand_in_zone("floor") if role != "visitor" else rand_in_zone("entrance")
        agents.append({"id": i, "role": role, "home": home, "work": work})

    frames: List[Dict[str, Any]] = []
    for t in range(ticks + 1):
        hour = t % 24
        nodes = []
        for a in agents:
            r = a["role"]
            if r == "staff":
                if 8 <= hour < 10:
                    x, y = a["home"]; zone = "office"
                elif 10 <= hour < 15:
                    x, y = a["work"]; zone = "floor"
                else:
                    x, y = a["home"]; zone = "office"
            elif r == "line":
                x, y = a["work"]; zone = "floor"
            else:  # visitor
                if 11 <= hour < 14:
                    x, y = rand_in_zone("cafeteria"); zone = "cafeteria"
                else:
                    x, y = rand_in_zone("entrance"); zone = "entrance"

            base_trust = 0.7
            if zone == "floor" and (10 <= hour < 15):
                base_trust -= 0.15
            trust = max(0.1, min(0.99, base_trust + random.uniform(-0.05, 0.05)))

            nodes.append(
                {
                    "id": a["id"],
                    "x": x,
                    "y": y,
                    "trust": trust,
                    "role": r,
                    "zone": zone,
                }
            )
        frames.append({"t": t, "nodes": nodes})

    return {"frames": frames, "size": [1.0, 1.0]}


def build_maps(n: int, ticks: int, seed: int) -> Dict[str, Any]:
    return {
        "jackson": build_map_frames_jackson(n, ticks, seed),
        "demo": build_map_frames_demo(n, ticks, seed),
        "building": build_map_frames_building(n, ticks, seed),
    }


def run(req: RunRequest) -> Dict[str, Any]:
    seed = int(req.seed)
    initialize_determinism(seed)
    if torch is None:
        raise RuntimeError("stimulus.interface.run() requires torch. Install requirements or use run_panel.py for the stable panel interface.")
    gen = torch.Generator().manual_seed(seed)
    params = _build_params(req)

    try:
        from ..core.core_functions import simulate
    except ImportError:
        from core.core_functions import simulate

    result = simulate(params, gen=gen)
    metrics = result.get("metrics", {})

    summary = {
        "seed": seed,
        "n": int(req.n),
        "ticks": int(req.ticks),
        "keys": sorted(list(result.keys())),
    }

    maps = build_maps(req.n, req.ticks, seed)

    return {
        "summary": summary,
        "metrics": metrics,
        "maps": maps,
        "raw": {k: v for k, v in result.items() if k not in ("metrics",)},
    }
