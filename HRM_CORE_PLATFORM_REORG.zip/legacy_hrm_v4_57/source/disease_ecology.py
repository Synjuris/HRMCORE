"""HRM_UNIFIED v3.2 disease ecology and public health layer.

Disease is modeled as a civilization pressure system seeded from the v3.1
reality/era baseline. This is intentionally transparent and lightweight: it
tracks risk, outbreak phases, public-health capacity, compliance, productivity,
mortality/fertility pressure, trust effects, and long-run scarring without
requiring full epidemiological microsimulation.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Dict, List, Optional
import json
import math
import os
import random

ENGINE_VERSION = "3.2"


def clamp(v: float, lo: float = 0.0, hi: float = 1.0) -> float:
    try:
        return max(lo, min(hi, float(v)))
    except Exception:
        return lo


def read_json(path: str | Path, default: Any) -> Any:
    p = Path(path)
    if not p.exists():
        return default
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path: str | Path, payload: Any) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    os.replace(tmp, p)


DISEASE_PRESETS: Dict[str, Dict[str, Any]] = {
    "low_chronic": {
        "label": "Low chronic disease burden",
        "transmissibility": 0.10,
        "severity": 0.16,
        "chronicity": 0.62,
        "mortality": 0.05,
        "fertility_drag": 0.08,
        "productivity_drag": 0.20,
        "mutation_rate": 0.08,
        "visibility": 0.28,
    },
    "seasonal_respiratory": {
        "label": "Seasonal respiratory pressure",
        "transmissibility": 0.48,
        "severity": 0.22,
        "chronicity": 0.16,
        "mortality": 0.04,
        "fertility_drag": 0.03,
        "productivity_drag": 0.24,
        "mutation_rate": 0.32,
        "visibility": 0.45,
    },
    "high_epidemic": {
        "label": "High epidemic pressure",
        "transmissibility": 0.74,
        "severity": 0.64,
        "chronicity": 0.18,
        "mortality": 0.36,
        "fertility_drag": 0.28,
        "productivity_drag": 0.58,
        "mutation_rate": 0.28,
        "visibility": 0.82,
    },
    "novel_pathogen": {
        "label": "Novel pathogen",
        "transmissibility": 0.68,
        "severity": 0.48,
        "chronicity": 0.34,
        "mortality": 0.22,
        "fertility_drag": 0.18,
        "productivity_drag": 0.52,
        "mutation_rate": 0.46,
        "visibility": 0.70,
    },
}


@dataclass
class DiseaseProfile:
    key: str
    label: str
    transmissibility: float
    severity: float
    chronicity: float
    mortality: float
    fertility_drag: float
    productivity_drag: float
    mutation_rate: float
    visibility: float
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class PublicHealthState:
    healthcare_capacity: float
    sanitation: float
    institutional_trust: float
    misinformation: float
    compliance: float
    vaccine_medicine_capacity: float
    surveillance_capacity: float
    quarantine_capacity: float

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class DiseaseStep:
    cycle: int
    outbreak_risk: float
    prevalence: float
    mortality_pressure: float
    fertility_pressure: float
    productivity_pressure: float
    institutional_stress: float
    trust_delta: float
    public_health_response: float
    scar_delta: float
    phase: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def profile_from_key(key: str, baseline: Optional[Dict[str, Any]] = None) -> DiseaseProfile:
    if key == "auto":
        burden = clamp((baseline or {}).get("disease_burden", 0.35))
        if burden > 0.58:
            key = "high_epidemic"
        elif burden > 0.34:
            key = "seasonal_respiratory"
        else:
            key = "low_chronic"
    if key not in DISEASE_PRESETS:
        raise ValueError(f"Unknown disease profile {key!r}. Use one of: auto, {', '.join(sorted(DISEASE_PRESETS))}")
    raw = dict(DISEASE_PRESETS[key])
    return DiseaseProfile(
        key=key,
        label=str(raw["label"]),
        transmissibility=clamp(raw["transmissibility"]),
        severity=clamp(raw["severity"]),
        chronicity=clamp(raw["chronicity"]),
        mortality=clamp(raw["mortality"]),
        fertility_drag=clamp(raw["fertility_drag"]),
        productivity_drag=clamp(raw["productivity_drag"]),
        mutation_rate=clamp(raw["mutation_rate"]),
        visibility=clamp(raw["visibility"]),
        notes=list(raw.get("notes", []) or []),
    )


def public_health_from_baseline(baseline: Dict[str, Any]) -> PublicHealthState:
    healthcare = clamp(baseline.get("healthcare_capacity", 0.5))
    trust = clamp(baseline.get("baseline_trust", 0.5))
    literacy = clamp(baseline.get("literacy", 0.5))
    media = clamp(baseline.get("media_density", 0.5))
    urban = clamp(baseline.get("urbanization", 0.5))
    tech = clamp(baseline.get("technology_level", 0.5))
    institutional = clamp(baseline.get("institutional_complexity", 0.5))
    misinformation = clamp(media * (1.0 - trust) * (1.0 - 0.45 * literacy))
    compliance = clamp((trust * 0.52) + (literacy * 0.23) + (institutional * 0.25) - misinformation * 0.30)
    sanitation = clamp((healthcare * 0.40) + (tech * 0.24) + (institutional * 0.20) + ((1.0 - urban) * 0.16))
    return PublicHealthState(
        healthcare_capacity=healthcare,
        sanitation=sanitation,
        institutional_trust=trust,
        misinformation=misinformation,
        compliance=compliance,
        vaccine_medicine_capacity=clamp((healthcare + tech + literacy) / 3.0),
        surveillance_capacity=clamp((institutional + tech + media) / 3.0),
        quarantine_capacity=clamp((institutional + compliance + trust) / 3.0),
    )


def simulate_disease_ecology(
    baseline: Dict[str, Any],
    profile: DiseaseProfile,
    cycles: int = 12,
    seed: int = 42,
) -> Dict[str, Any]:
    rng = random.Random(seed)
    ph = public_health_from_baseline(baseline)
    mobility = clamp(baseline.get("mobility", 0.5))
    urban = clamp(baseline.get("urbanization", 0.5))
    disease_burden = clamp(baseline.get("disease_burden", 0.35))
    trust = ph.institutional_trust
    scar = disease_burden * 0.25
    prevalence = clamp(disease_burden * 0.35 + profile.transmissibility * 0.12)
    steps: List[DiseaseStep] = []

    for cycle in range(1, max(1, int(cycles)) + 1):
        contact = clamp((urban * 0.45) + (mobility * 0.35) + (1.0 - ph.sanitation) * 0.20)
        response = clamp((ph.healthcare_capacity * 0.28) + (ph.sanitation * 0.18) + (ph.compliance * 0.20) + (ph.vaccine_medicine_capacity * 0.22) + (ph.surveillance_capacity * 0.12))
        mutation_shock = rng.random() * profile.mutation_rate * 0.08
        outbreak_risk = clamp((profile.transmissibility * contact * (1.0 + mutation_shock)) + disease_burden * 0.25 - response * 0.32)
        prevalence = clamp(prevalence + outbreak_risk * 0.18 - response * 0.11 + mutation_shock - (scar * 0.02))
        mortality_pressure = clamp(prevalence * profile.severity * profile.mortality * (1.25 - ph.healthcare_capacity))
        fertility_pressure = clamp(prevalence * profile.fertility_drag * (0.65 + profile.chronicity * 0.35))
        productivity_pressure = clamp(prevalence * profile.productivity_drag * (0.55 + profile.chronicity * 0.45))
        institutional_stress = clamp((outbreak_risk * 0.35) + (mortality_pressure * 0.30) + (ph.misinformation * 0.20) + ((1.0 - ph.compliance) * 0.15))
        if response >= outbreak_risk:
            trust_delta = clamp((response - outbreak_risk) * 0.06, -1, 1)
            phase = "contained" if prevalence < 0.22 else "managed"
        else:
            trust_delta = -clamp((outbreak_risk - response + ph.misinformation * 0.3) * 0.08, 0, 1)
            phase = "outbreak" if prevalence < 0.55 else "systemic_health_crisis"
        trust = clamp(trust + trust_delta)
        ph.institutional_trust = trust
        ph.compliance = clamp(ph.compliance + trust_delta * 0.8 - ph.misinformation * 0.01)
        scar_delta = clamp((mortality_pressure + productivity_pressure + institutional_stress) / 3.0 * 0.15)
        scar = clamp(scar + scar_delta - response * 0.015)
        steps.append(DiseaseStep(
            cycle=cycle,
            outbreak_risk=round(outbreak_risk, 4),
            prevalence=round(prevalence, 4),
            mortality_pressure=round(mortality_pressure, 4),
            fertility_pressure=round(fertility_pressure, 4),
            productivity_pressure=round(productivity_pressure, 4),
            institutional_stress=round(institutional_stress, 4),
            trust_delta=round(trust_delta, 4),
            public_health_response=round(response, 4),
            scar_delta=round(scar_delta, 4),
            phase=phase,
        ))

    final = steps[-1]
    summary = {
        "engine_version": ENGINE_VERSION,
        "baseline": baseline,
        "disease_profile": profile.to_dict(),
        "public_health_initial": public_health_from_baseline(baseline).to_dict(),
        "public_health_final": ph.to_dict(),
        "cycles": len(steps),
        "final_phase": final.phase,
        "final_prevalence": final.prevalence,
        "final_outbreak_risk": final.outbreak_risk,
        "final_mortality_pressure": final.mortality_pressure,
        "final_fertility_pressure": final.fertility_pressure,
        "final_productivity_pressure": final.productivity_pressure,
        "final_institutional_stress": final.institutional_stress,
        "historical_scar": round(scar, 4),
        "cumulative_mortality_pressure": round(sum(s.mortality_pressure for s in steps), 4),
        "cumulative_productivity_pressure": round(sum(s.productivity_pressure for s in steps), 4),
        "cumulative_fertility_pressure": round(sum(s.fertility_pressure for s in steps), 4),
        "mean_public_health_response": round(sum(s.public_health_response for s in steps) / len(steps), 4),
        "mean_outbreak_risk": round(sum(s.outbreak_risk for s in steps) / len(steps), 4),
        "timeline": [s.to_dict() for s in steps],
    }
    return summary


def disease_report_markdown(report: Dict[str, Any]) -> str:
    b = report.get("baseline", {})
    p = report.get("disease_profile", {})
    lines = [
        "# HRM_UNIFIED v3.2 Disease Ecology Report",
        "",
        f"Era/location: **{b.get('era', 'unknown')} / {b.get('location', 'generic')}**",
        f"Disease profile: **{p.get('label', p.get('key', 'unknown'))}**",
        "",
        "## Final State",
        f"- Final phase: `{report.get('final_phase')}`",
        f"- Final prevalence pressure: `{report.get('final_prevalence')}`",
        f"- Final outbreak risk: `{report.get('final_outbreak_risk')}`",
        f"- Mortality pressure: `{report.get('final_mortality_pressure')}`",
        f"- Fertility pressure: `{report.get('final_fertility_pressure')}`",
        f"- Productivity pressure: `{report.get('final_productivity_pressure')}`",
        f"- Institutional stress: `{report.get('final_institutional_stress')}`",
        f"- Historical disease scar: `{report.get('historical_scar')}`",
        "",
        "## Interpretation",
        "Disease is represented here as a structural civilization pressure, not as a medical diagnosis engine.",
        "The numbers are normalized pressures intended for simulation dynamics, benchmarking, and future calibration.",
        "",
        "## Timeline",
        "| Cycle | Phase | Risk | Prevalence | Response | Mortality | Productivity | Trust Δ |",
        "|---:|---|---:|---:|---:|---:|---:|---:|",
    ]
    for s in report.get("timeline", []):
        lines.append(f"| {s['cycle']} | {s['phase']} | {s['outbreak_risk']} | {s['prevalence']} | {s['public_health_response']} | {s['mortality_pressure']} | {s['productivity_pressure']} | {s['trust_delta']} |")
    lines.append("")
    return "\n".join(lines)
