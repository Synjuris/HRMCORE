# Calibrated Population Layer

v1.3 adds differentiated synthetic populations.

The panel now models structural variance across:
- age band
- economic stability band
- education band
- social connectivity band
- institutional trust
- peer trust
- media trust
- local trust
- authority trust
- risk tolerance
- media exposure
- mobility

These are calibration variables, not claims about real individuals.

## Run a calibrated panel
```bash
python run_calibrated_panel.py "News report describes a controversial policy change affecting household costs."
```

## Compare profile response
```bash
python compare_profiles.py "Community volunteers organize broad relief support after a storm."
```

## Use real aggregate data
Put your Census key in `.env.user`:
```text
CENSUS_API_KEY=your_key_here
```

Then run:
```bash
python run_real_panel.py "Public health officials announce a contained hospital capacity warning." --state 06 --county 001
```

The real data adapter uses public aggregate ACS data to derive broad structural parameters. It does not hardcode any place into the engine.
