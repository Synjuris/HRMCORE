@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo ============================================================
echo HRM_UNIFIED v3.3 - Real Dataset Ingestion + Calibration
echo Folder: %CD%
echo ============================================================
echo.

set PYTHON_CMD=
where py >nul 2>nul
if %ERRORLEVEL%==0 (
    set PYTHON_CMD=py -3
) else (
    where python >nul 2>nul
    if %ERRORLEVEL%==0 (
        set PYTHON_CMD=python
    ) else (
        where python3 >nul 2>nul
        if %ERRORLEVEL%==0 (
            set PYTHON_CMD=python3
        )
    )
)

if "%PYTHON_CMD%"=="" (
    echo ERROR: Python was not found.
    echo Install Python 3 from https://www.python.org/downloads/ and check "Add Python to PATH".
    pause
    exit /b 1
)

echo Using Python command: %PYTHON_CMD%
%PYTHON_CMD% --version

echo.
echo Running bundled sample calibration. Replace this command with --input YOUR_FILE.csv when ready.
%PYTHON_CMD% run_real_dataset_calibration.py --use-sample --geography "sample_generic_region"
set EXITCODE=%ERRORLEVEL%

echo.
if not "%EXITCODE%"=="0" (
    echo ERROR: Real dataset calibration failed with code %EXITCODE%.
    pause
    exit /b %EXITCODE%
)

echo Done.
echo Report: outputs\real_dataset_calibration_v3_3\real_dataset_calibration_report.md
echo Bundle: outputs\real_dataset_calibration_v3_3\real_dataset_calibration_bundle.json
echo.
pause
