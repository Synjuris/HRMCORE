#!/usr/bin/env python3
"""city_twin.py — HRM v4.57 City Skin

Resolves a county name → FIPS → Census ACS 5-year data → HRM profile + scenario files.
Drop this file in the project root alongside run_environment.py.

Usage
-----
    python city_twin.py "Madison County, TN"
    python city_twin.py "Cook County, IL" --scenario economic_shock
    python city_twin.py "Orleans Parish, LA" --api-key YOUR_KEY --output-dir my_outputs
    python city_twin.py --list-counties TN
    python city_twin.py --fips 47113          # direct FIPS (Madison County TN)

Outputs (written to profiles/ and scenarios/ by default)
---------
    profiles/<slug>_twin.json         — HRM population profile
    scenarios/<slug>_<scenario>.json  — scenario timeline
    outputs/<slug>_twin/acs_raw.json  — raw ACS metrics (audit trail)

Requirements
------------
    Standard library only. No extra packages needed.
    Census ACS API key optional but recommended (free at api.census.gov/data/key_signup.html).
    Key can also be set in .env.user as CENSUS_API_KEY=your_key
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import math
import os
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


# ── CONFIG ────────────────────────────────────────────────────────────────────

ACS_YEAR = "2023"
ACS_DATASET = "acs/acs5/profile"
ACS_BASE = f"https://api.census.gov/data/{ACS_YEAR}/{ACS_DATASET}"

ACS_VARS: Dict[str, str] = {
    "DP05_0001E":  "population_total",
    "DP05_0018PE": "under_18_pct",
    "DP05_0024PE": "age_65_plus_pct",
    "DP03_0062E":  "median_household_income",
    "DP03_0128PE": "poverty_pct",
    "DP03_0009PE": "unemployment_pct",
    "DP03_0033PE": "manufacturing_employment_pct",
    "DP02_0067PE": "bachelors_or_higher_pct",
    "DP04_0046PE": "renter_occupied_pct",
}

FIPS_CSV_URL = (
    "https://raw.githubusercontent.com/kjhealy/fips-codes/master/"
    "state_and_county_fips_master.csv"
)

KEY_ENV_NAMES = ("CENSUS_API_KEY", "ACS_API_KEY", "DATASET_API_KEY")
ENV_FILES = (".env.user", ".env")

SCENARIO_TEMPLATES: Dict[str, List[Dict[str, Any]]] = {
    "economic_shock": [
        {"label": "major employer layoffs",      "kind": "scenario", "ticks": 30,
         "stimulus": "A major employer in {geo} announces significant layoffs affecting thousands of residents."},
        {"label": "emergency aid distribution",  "kind": "policy",   "ticks": 18, "policy_id": "emergency_aid",
         "stimulus": "{geo} opens emergency assistance intake with clear eligibility information."},
        {"label": "service confusion wave",      "kind": "scenario", "ticks": 24,
         "stimulus": "Residents report confusion about available resources and timelines across {geo}."},
        {"label": "small business relief",       "kind": "policy",   "ticks": 20, "policy_id": "small_business_relief",
         "stimulus": "A temporary relief program opens for {geo} businesses with fast processing and transparent reporting."},
    ],
    "infrastructure_failure": [
        {"label": "utility outage",                  "kind": "scenario", "ticks": 28,
         "stimulus": "A major utility failure cuts power and water to large portions of {geo}."},
        {"label": "targeted service restore",        "kind": "policy",   "ticks": 20, "policy_id": "targeted_service_restore",
         "stimulus": "{geo} service restoration crews prioritize affected districts and publish progress updates."},
        {"label": "community mutual aid emergence",  "kind": "scenario", "ticks": 22,
         "stimulus": "Residents organize informal supply sharing and check-in networks across {geo}."},
        {"label": "institutional messaging",         "kind": "policy",   "ticks": 18, "policy_id": "institutional_messaging",
         "stimulus": "Coordinated guidance issued through employers, schools, and community organizations in {geo}."},
    ],
    "political_crisis": [
        {"label": "leadership scandal breaks",   "kind": "scenario", "ticks": 35,
         "stimulus": "A major scandal involving {geo} officials is reported across local and national media."},
        {"label": "protest mobilization",        "kind": "scenario", "ticks": 28,
         "stimulus": "Residents organize protests following institutional trust collapse in {geo}."},
        {"label": "clear public notice",         "kind": "policy",   "ticks": 18, "policy_id": "clear_public_notice",
         "stimulus": "{geo} institutions publish a coordinated update with timelines and next steps."},
        {"label": "institutional messaging",     "kind": "policy",   "ticks": 20, "policy_id": "institutional_messaging",
         "stimulus": "Trusted community organizations in {geo} coordinate repair messaging."},
    ],
    "public_health": [
        {"label": "outbreak cluster reported",       "kind": "scenario", "ticks": 30,
         "stimulus": "Health authorities report an illness cluster in {geo}, triggering concern and behavioral change."},
        {"label": "institutional messaging campaign","kind": "policy",   "ticks": 20, "policy_id": "institutional_messaging",
         "stimulus": "Trusted institutions in {geo} coordinate health guidance through employers, schools, and community orgs."},
        {"label": "compliance variance",             "kind": "scenario", "ticks": 28,
         "stimulus": "Significant variation in protective behavior is observed across different {geo} districts."},
        {"label": "emergency aid distribution",      "kind": "policy",   "ticks": 18, "policy_id": "emergency_aid",
         "stimulus": "{geo} opens community health support resources with clear access guidance."},
    ],
    "displacement": [
        {"label": "development acceleration",    "kind": "scenario", "ticks": 40,
         "stimulus": "Major development projects in {geo} accelerate displacement of long-term residents in lower-income areas."},
        {"label": "affordability crisis peak",   "kind": "scenario", "ticks": 35,
         "stimulus": "{geo} rental prices reach record highs; eviction clusters reported in multiple neighborhoods."},
        {"label": "tenant coalition organizing", "kind": "scenario", "ticks": 30,
         "stimulus": "Community coalitions escalate pressure on {geo} city council over housing policy."},
        {"label": "institutional messaging",     "kind": "policy",   "ticks": 18, "policy_id": "institutional_messaging",
         "stimulus": "Local government in {geo} issues a public response to housing affordability concerns."},
    ],
}


# ── HELPERS ───────────────────────────────────────────────────────────────────

def clamp(v: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, v))


def r4(v: float) -> float:
    return round(v, 4)


def safe_float(val: Any) -> Optional[float]:
    if val in (None, "", "null", "-666666666", "-999999999"):
        return None
    try:
        f = float(str(val).replace(",", "").strip())
        return None if math.isnan(f) else f
    except (ValueError, TypeError):
        return None


def slug(text: str) -> str:
    return "".join(c if c.isalnum() else "_" for c in text.lower()).strip("_")


def load_api_key(explicit: Optional[str] = None, base_dir: Optional[Path] = None) -> Optional[str]:
    if explicit and "PASTE_" not in explicit:
        return explicit.strip()
    root = base_dir or Path.cwd()
    for fname in ENV_FILES:
        p = root / fname
        if not p.exists():
            continue
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            if k.strip() in KEY_ENV_NAMES:
                v = v.strip().strip('"').strip("'")
                if v and "PASTE_" not in v:
                    return v
    for name in KEY_ENV_NAMES:
        val = os.getenv(name)
        if val and "PASTE_" not in val:
            return val.strip()
    return None


def http_get(url: str, timeout: int = 30) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "HRM_UNIFIED/city_twin/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


# ── FIPS LOOKUP ───────────────────────────────────────────────────────────────

@dataclass
class CountyRecord:
    name: str
    state: str
    state_fips: str
    county_fips: str

    @property
    def full_fips(self) -> str:
        return self.state_fips + self.county_fips

    def __str__(self) -> str:
        return f"{self.name}, {self.state}  (FIPS {self.full_fips})"


def load_fips_table(cache_path: Optional[Path] = None) -> List[CountyRecord]:
    """Download (or load cached) county FIPS table."""
    COUNTY_WORDS = ("County", "Parish", "Borough", "Municipality", "Census Area", "city and borough")

    if cache_path and cache_path.exists():
        raw = cache_path.read_text(encoding="utf-8")
    else:
        print("  Fetching FIPS table…", end=" ", flush=True)
        raw = http_get(FIPS_CSV_URL).decode("utf-8")
        print("done")
        if cache_path:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            cache_path.write_text(raw, encoding="utf-8")

    reader = csv.DictReader(io.StringIO(raw))
    records: List[CountyRecord] = []
    for row in reader:
        if row["state"] == "NA" or row["fips"] == "0":
            continue
        if not any(w in row["name"] for w in COUNTY_WORDS):
            continue
        fips = row["fips"].zfill(5)
        records.append(CountyRecord(
            name=row["name"],
            state=row["state"],
            state_fips=fips[:2],
            county_fips=fips[2:],
        ))
    return records


def search_counties(table: List[CountyRecord], query: str) -> List[CountyRecord]:
    q = query.lower().strip()
    exact, partial = [], []
    for r in table:
        full = f"{r.name}, {r.state}".lower()
        name_lower = r.name.lower()
        if full == q or name_lower == q:
            exact.append(r)
        elif q in full or q in name_lower:
            partial.append(r)
    return exact + partial


def resolve_fips(fips_str: str, table: List[CountyRecord]) -> Optional[CountyRecord]:
    fips = fips_str.strip().zfill(5)
    for r in table:
        if r.full_fips == fips:
            return r
    return None


# ── CENSUS ACS FETCH ──────────────────────────────────────────────────────────

def fetch_acs(county: CountyRecord, api_key: Optional[str] = None) -> Dict[str, Any]:
    var_list = ",".join(["NAME"] + list(ACS_VARS.keys()))
    key_param = f"&key={api_key}" if api_key else ""
    url = (
        f"{ACS_BASE}?get={var_list}"
        f"&for=county:{county.county_fips}"
        f"&in=state:{county.state_fips}"
        f"{key_param}"
    )
    try:
        raw = http_get(url)
    except urllib.error.HTTPError as exc:
        if exc.code == 403 and not api_key:
            raise RuntimeError(
                f"Census API returned 403. You need a free API key.\n"
                f"Get one at: https://api.census.gov/data/key_signup.html\n"
                f"Then pass --api-key YOUR_KEY or set CENSUS_API_KEY in .env.user"
            ) from exc
        raise RuntimeError(f"Census API HTTP {exc.code}: {exc.reason}") from exc

    data = json.loads(raw)
    if not isinstance(data, list) or len(data) < 2:
        raise RuntimeError(f"Unexpected Census API response shape: {type(data)}")

    headers, row = data[0], data[1]
    record = dict(zip(headers, row))

    result: Dict[str, Any] = {"_geography_name": record.get("NAME", str(county))}
    for var_code, label in ACS_VARS.items():
        result[label] = safe_float(record.get(var_code))

    return result


# ── CALIBRATION PIPELINE (from real_dataset_calibration.py + census_acs.py) ──

def normalize_metrics(raw: Dict[str, Any]) -> Dict[str, float]:
    """Port of normalize_metrics() from real_dataset_calibration.py."""
    population    = raw.get("population_total") or 0.0
    income        = raw.get("median_household_income") or 0.0
    poverty       = raw.get("poverty_pct") or 0.0
    unemployment  = raw.get("unemployment_pct") or 0.0
    manufacturing = raw.get("manufacturing_employment_pct") or 0.0
    education     = raw.get("bachelors_or_higher_pct") or 0.0
    renters       = raw.get("renter_occupied_pct") or 0.0
    under18       = raw.get("under_18_pct") or 0.0
    senior        = raw.get("age_65_plus_pct") or 0.0

    economic_pressure   = clamp((poverty / 30.0) * 0.45 + (unemployment / 15.0) * 0.35 + (renters / 70.0) * 0.20)
    resource_baseline   = clamp(0.35 + (income / 120000.0) * 0.50 - economic_pressure * 0.20, 0.15, 0.90)
    volatility_pressure = clamp(economic_pressure * 0.55 + (manufacturing / 35.0) * 0.25 + (under18 / 35.0) * 0.10 + (senior / 30.0) * 0.10, 0.05, 0.95)
    social_complexity   = clamp((education / 60.0) * 0.35 + (population / 1_000_000.0) * 0.35 + (renters / 70.0) * 0.30, 0.05, 0.95)
    education_signal    = clamp(education / 60.0)
    manufacturing_dep   = clamp(manufacturing / 35.0)
    demographic_youth   = clamp(under18 / 34.0)
    demographic_aging   = clamp(senior / 32.0)
    institutional_load  = clamp(economic_pressure * 0.40 + volatility_pressure * 0.28 + social_complexity * 0.16 + manufacturing_dep * 0.16)

    return {
        "population_scale":        r4(clamp(population / 1_000_000.0)),
        "economic_pressure":       r4(economic_pressure),
        "resource_baseline":       r4(resource_baseline),
        "volatility_pressure":     r4(volatility_pressure),
        "social_complexity":       r4(social_complexity),
        "education_signal":        r4(education_signal),
        "manufacturing_dependency":r4(manufacturing_dep),
        "demographic_youth":       r4(demographic_youth),
        "demographic_aging":       r4(demographic_aging),
        "institutional_load":      r4(institutional_load),
    }


def build_profile(county: CountyRecord, raw: Dict[str, Any], n: Dict[str, float]) -> Dict[str, Any]:
    """Build HRM-compatible population profile from normalized metrics.
    Schema matches generic_mixed_region.json exactly."""
    econ     = n["economic_pressure"]
    res      = n["resource_baseline"]
    complex_ = n["social_complexity"]
    edu      = n["education_signal"]
    inst     = n["institutional_load"]
    youth    = n["demographic_youth"]
    aging    = n["demographic_aging"]

    # ── Age structure ─────────────────────────────────────────────────────────
    under_25 = clamp(youth * 0.9 + 0.10, 0.12, 0.55)
    age_65p  = clamp(aging * 0.80, 0.06, 0.32)
    age_25_44 = clamp(0.34 + (1 - youth) * 0.06 - aging * 0.04, 0.22, 0.48)
    age_45_64 = clamp(1.0 - under_25 - age_25_44 - age_65p, 0.14, 0.36)
    age_sum   = under_25 + age_25_44 + age_45_64 + age_65p
    age_struct = {
        "under_25": r4(under_25 / age_sum),
        "25_44":    r4(age_25_44 / age_sum),
        "45_64":    r4(age_45_64 / age_sum),
        "65_plus":  r4(age_65p / age_sum),
    }

    # ── Economic stability ────────────────────────────────────────────────────
    low  = clamp(econ * 1.10, 0.12, 0.65)
    high = clamp(res * 0.50 - econ * 0.10, 0.05, 0.44)
    mid  = clamp(1.0 - low - high, 0.20, 0.68)
    econ_sum = low + mid + high
    econ_struct = {
        "low_stability":  r4(low / econ_sum),
        "mid_stability":  r4(mid / econ_sum),
        "high_stability": r4(high / econ_sum),
    }

    # ── Education ─────────────────────────────────────────────────────────────
    higher = clamp(edu * 0.80, 0.06, 0.58)
    lower  = clamp(0.55 - edu * 0.65, 0.12, 0.62)
    middle = clamp(1.0 - higher - lower, 0.18, 0.62)
    edu_sum = higher + middle + lower
    edu_struct = {
        "lower":  r4(lower / edu_sum),
        "middle": r4(middle / edu_sum),
        "higher": r4(higher / edu_sum),
    }

    # ── Connectivity ──────────────────────────────────────────────────────────
    isolated = clamp(0.28 - complex_ * 0.20, 0.05, 0.42)
    hub      = clamp(complex_ * 0.28, 0.02, 0.32)
    typical  = clamp(1.0 - isolated - hub, 0.48, 0.80)
    conn_sum = isolated + typical + hub
    conn_struct = {
        "isolated": r4(isolated / conn_sum),
        "typical":  r4(typical / conn_sum),
        "hub":      r4(hub / conn_sum),
    }

    # ── Baseline factors ──────────────────────────────────────────────────────
    baseline_factors = {
        "institutional_trust": r4(clamp(0.64 - inst * 0.34 + res * 0.10)),
        "peer_trust":          r4(clamp(0.55 + (res - 0.5) * 0.20 - econ * 0.12)),
        "media_trust":         r4(clamp(0.44 - complex_ * 0.08 + edu * 0.06)),
        "local_trust":         r4(clamp(0.60 + (1 - complex_) * 0.10 - econ * 0.12)),
        "authority_trust":     r4(clamp(0.49 - inst * 0.22 + res * 0.08)),
        "risk_tolerance":      r4(clamp(0.40 + (1 - econ) * 0.18 + edu * 0.10)),
        "media_exposure":      r4(clamp(0.45 + complex_ * 0.30)),
        "mobility":            r4(clamp(0.35 + complex_ * 0.25 - n["manufacturing_dependency"] * 0.10)),
    }

    geo_name = raw.get("_geography_name", str(county))
    profile_slug = slug(geo_name.split(",")[0])

    return {
        "name":        f"{profile_slug}_twin",
        "description": f"Digital twin profile for {geo_name}. Source: US Census ACS {ACS_YEAR} 5-year.",
        "_meta": {
            "geography":   geo_name,
            "fips":        county.full_fips,
            "acs_year":    ACS_YEAR,
            "generated":   time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "hrm_version": "v4.57",
            "note":        "Calibration from real public data. Not a prediction model.",
        },
        "population_structure": {
            "age":          age_struct,
            "economic":     econ_struct,
            "education":    edu_struct,
            "connectivity": conn_struct,
        },
        "baseline_factors": baseline_factors,
    }


def build_hrm_config_patch(n: Dict[str, float], raw: Dict[str, Any]) -> Dict[str, Any]:
    """Port of build_patches() hrm_config_patch from real_dataset_calibration.py."""
    econ    = n["economic_pressure"]
    res     = n["resource_baseline"]
    complex_= n["social_complexity"]
    vol     = n["volatility_pressure"]
    inst    = n["institutional_load"]
    edu     = n["education_signal"]
    return {
        "traits": {
            "resource_level_mean":            r4(res),
            "resource_level_var":             r4(0.12 + econ * 0.18),
            "anxiety_reactivity_mean":        r4(0.30 + econ * 0.35 + vol * 0.10),
            "social_sensitivity_mean":        r4(0.45 + complex_ * 0.25),
            "openness_mean":                  r4(0.38 + edu * 0.22),
            "neuroticism_mean":               r4(0.32 + econ * 0.24),
            "institutional_trust_baseline":   r4(clamp(0.64 - inst * 0.34 + res * 0.10)),
            "civic_stress_baseline":          r4(clamp(0.20 + econ * 0.32 + vol * 0.20)),
        },
        "environment": {
            "economic_pressure":   n["economic_pressure"],
            "institutional_load":  n["institutional_load"],
            "volatility_pressure": n["volatility_pressure"],
            "social_complexity":   n["social_complexity"],
        },
        "scale": {
            "recommended_mode": (
                "toy"     if n["population_scale"] < 0.08 else
                "desktop" if n["population_scale"] < 0.75 else
                "large"
            ),
            "active_fraction":   r4(clamp(0.18 - n["population_scale"] * 0.10, 0.03, 0.18)),
            "regional_fraction": r4(clamp(0.42 + n["population_scale"] * 0.20, 0.42, 0.72)),
        },
        "metadata": {
            "calibration_source": f"US Census ACS {ACS_YEAR} 5-Year Data Profile",
            "calibration_note":   "Real public data converted into HRM trait priors. Not a prediction model.",
        },
    }


def build_scenario(geo_name: str, scenario_key: str) -> Dict[str, Any]:
    steps = SCENARIO_TEMPLATES.get(scenario_key, SCENARIO_TEMPLATES["economic_shock"])
    periods = []
    for i, step in enumerate(steps):
        s = dict(step)
        s["stimulus"] = s["stimulus"].replace("{geo}", geo_name)
        s["tick"] = i * 2
        periods.append({"label": s["label"], "steps": [s]})

    geo_slug = slug(geo_name.split(",")[0])
    return {
        "name": f"{geo_slug}_{scenario_key}",
        "_meta": {
            "geography": geo_name,
            "scenario":  scenario_key,
            "generated": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        },
        "periods": periods,
    }


# ── OUTPUT WRITERS ────────────────────────────────────────────────────────────

def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=False), encoding="utf-8")
    print(f"  wrote  {path}")


def print_summary(raw: Dict[str, Any], n: Dict[str, float]) -> None:
    geo = raw.get("_geography_name", "—")
    print(f"\n{'─'*56}")
    print(f"  {geo}")
    print(f"{'─'*56}")
    print(f"  Population      {raw.get('population_total', '—'):>12,.0f}" if raw.get('population_total') else f"  Population           —")
    print(f"  Median income   ${raw.get('median_household_income', 0):>11,.0f}" if raw.get('median_household_income') else f"  Median income        —")
    print(f"  Poverty         {raw.get('poverty_pct', 0):>11.1f}%" if raw.get('poverty_pct') is not None else f"  Poverty              —")
    print(f"  Unemployment    {raw.get('unemployment_pct', 0):>11.1f}%" if raw.get('unemployment_pct') is not None else f"  Unemployment         —")
    print(f"  Bachelor's+     {raw.get('bachelors_or_higher_pct', 0):>11.1f}%" if raw.get('bachelors_or_higher_pct') is not None else f"  Bachelor's+          —")
    print(f"\n  Normalized drivers:")
    for k, v in n.items():
        bar = "█" * int(v * 20) + "░" * (20 - int(v * 20))
        flag = "  ▲ HIGH" if v > 0.65 else ("  ▼ low" if v < 0.30 else "")
        print(f"    {k:<28} {v:.3f}  {bar}{flag}")
    print()


# ── CLI ───────────────────────────────────────────────────────────────────────

def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(
        description="HRM v4.57 City Skin — fetch real Census ACS data and write HRM profile + scenario files.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    ap.add_argument("county", nargs="?",
                    help='County name, e.g. "Madison County, TN" or "Cook County, IL"')
    ap.add_argument("--fips", metavar="NNNNN",
                    help="5-digit FIPS code instead of name lookup, e.g. 47113")
    ap.add_argument("--scenario", default="economic_shock",
                    choices=list(SCENARIO_TEMPLATES.keys()),
                    help="Scenario template (default: economic_shock)")
    ap.add_argument("--api-key", default=None,
                    help="Census API key (or set CENSUS_API_KEY in .env.user)")
    ap.add_argument("--profiles-dir", default="profiles",
                    help="Where to write profile JSON (default: profiles/)")
    ap.add_argument("--scenarios-dir", default="scenarios",
                    help="Where to write scenario JSON (default: scenarios/)")
    ap.add_argument("--output-dir", default=None,
                    help="Where to write acs_raw + hrm_config_patch (default: outputs/<slug>_twin/)")
    ap.add_argument("--list-counties", metavar="STATE",
                    help="List all counties for a state abbreviation, e.g. TN")
    ap.add_argument("--no-cache", action="store_true",
                    help="Force re-download of FIPS table")
    args = ap.parse_args(argv)

    root = Path(__file__).resolve().parent
    fips_cache = root / "datasets" / "cache" / "fips_counties.csv"
    if args.no_cache and fips_cache.exists():
        fips_cache.unlink()

    # ── List counties mode ────────────────────────────────────────────────────
    if args.list_counties:
        print(f"\nLoading FIPS table…")
        table = load_fips_table(fips_cache)
        state = args.list_counties.upper()
        matches = [r for r in table if r.state == state]
        if not matches:
            print(f"No counties found for state '{state}'.")
            return 1
        print(f"\n{len(matches)} counties in {state}:")
        for r in sorted(matches, key=lambda x: x.name):
            print(f"  {r.full_fips}  {r.name}")
        return 0

    if not args.county and not args.fips:
        ap.print_help()
        return 1

    # ── FIPS resolution ───────────────────────────────────────────────────────
    print(f"\nLoading FIPS table…")
    table = load_fips_table(fips_cache)

    if args.fips:
        county = resolve_fips(args.fips, table)
        if not county:
            print(f"ERROR: FIPS {args.fips} not found in table.")
            return 1
    else:
        matches = search_counties(table, args.county)
        if not matches:
            print(f"ERROR: No county found matching '{args.county}'.")
            print("Try --list-counties <STATE> to browse, or use --fips NNNNN directly.")
            return 1
        if len(matches) > 1:
            print(f"\nMultiple matches for '{args.county}':")
            for i, r in enumerate(matches[:10]):
                print(f"  [{i}] {r}")
            print(f"\nBe more specific, e.g. 'Madison County, TN', or use --fips.")
            return 1
        county = matches[0]

    print(f"  Resolved: {county}")

    # ── API key ───────────────────────────────────────────────────────────────
    api_key = load_api_key(args.api_key, root)
    if api_key:
        print(f"  API key: {api_key[:4]}…{api_key[-4:]}")
    else:
        print("  API key: none (anonymous — 500 req/day limit)")

    # ── Fetch ACS ─────────────────────────────────────────────────────────────
    print(f"\nFetching Census ACS {ACS_YEAR} data…")
    try:
        raw = fetch_acs(county, api_key)
    except RuntimeError as e:
        print(f"\nERROR: {e}")
        return 1

    # ── Calibrate ─────────────────────────────────────────────────────────────
    n = normalize_metrics(raw)
    geo_name = raw["_geography_name"]
    geo_slug = slug(geo_name.split(",")[0])

    print_summary(raw, n)

    profile     = build_profile(county, raw, n)
    patch       = build_hrm_config_patch(n, raw)
    scenario    = build_scenario(geo_name, args.scenario)

    # ── Write files ───────────────────────────────────────────────────────────
    profiles_dir  = root / args.profiles_dir
    scenarios_dir = root / args.scenarios_dir
    out_dir       = root / (args.output_dir or f"outputs/{geo_slug}_twin")

    print("Writing output files:")
    profile_path  = profiles_dir  / f"{geo_slug}_twin.json"
    scenario_path = scenarios_dir / f"{geo_slug}_{args.scenario}.json"
    raw_path      = out_dir / "acs_raw.json"
    patch_path    = out_dir / "hrm_config_patch.json"

    write_json(profile_path,  profile)
    write_json(scenario_path, scenario)
    write_json(raw_path,      raw)
    write_json(patch_path,    patch)

    # ── Run instructions ──────────────────────────────────────────────────────
    print(f"\n{'─'*56}")
    print("  Run command:")
    print(f"    python run_environment.py {scenarios_dir.name}/{geo_slug}_{args.scenario}.json \\")
    print(f"      --profile {geo_slug}_twin")
    print()
    print("  Or with explicit patch:")
    print(f"    python run_real_dataset_calibration.py \\")
    print(f"      --input {profile_path} \\")
    print(f"      --geography \"{geo_name}\"")
    print(f"{'─'*56}\n")

    return 0


if __name__ == "__main__":
    sys.exit(main())
