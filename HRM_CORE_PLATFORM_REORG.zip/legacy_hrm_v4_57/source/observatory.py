"""Observatory export layer for HRM_UNIFIED v1.9.

This module converts replayable history outputs into a self-contained, static
HTML observatory. It uses only generic synthetic fields already produced by the
engine. It does not embed real locality, personal data, API keys, or external
network dependencies.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional
import html
import json

PRESSURE_KEYS = [
    "stress_pressure",
    "trust_pressure",
    "volatility_pressure",
    "cooperation_pressure",
    "withdrawal_pressure",
]


def _state_series(result: Any) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for snap in getattr(result, "snapshots", []):
        st = dict(getattr(snap, "state", {}) or {})
        row = {
            "period": getattr(snap, "period", 0),
            "tick": getattr(snap, "tick", 0),
            "label": getattr(snap, "label", "snapshot"),
            "events_seen": getattr(snap, "events_seen", 0),
            "fingerprint": getattr(snap, "fingerprint", ""),
        }
        for key in PRESSURE_KEYS:
            row[key] = round(float(st.get(key, 0.0)), 4)
        rows.append(row)
    return rows


def _step_rows(result: Any) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for s in getattr(result, "steps", []):
        before = getattr(s, "state_before", {}) or {}
        after = getattr(s, "state_after", {}) or {}
        rows.append({
            "period": getattr(s, "period", 0),
            "tick": getattr(s, "tick", 0),
            "kind": getattr(s, "kind", "scenario"),
            "label": getattr(s, "label", ""),
            "policy_id": getattr(s, "policy_id", None),
            "cost_units": round(float(getattr(s, "cost_units", 0.0)), 4),
            "stress_before": round(float(before.get("stress_pressure", 0.0)), 4),
            "stress_after": round(float(after.get("stress_pressure", 0.0)), 4),
            "trust_before": round(float(before.get("trust_pressure", 0.0)), 4),
            "trust_after": round(float(after.get("trust_pressure", 0.0)), 4),
            "volatility_before": round(float(before.get("volatility_pressure", 0.0)), 4),
            "volatility_after": round(float(after.get("volatility_pressure", 0.0)), 4),
            "cooperation_before": round(float(before.get("cooperation_pressure", 0.0)), 4),
            "cooperation_after": round(float(after.get("cooperation_pressure", 0.0)), 4),
        })
    return rows


def _event_rows(result: Any) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for e in getattr(result, "events", []):
        rows.append({
            "tick": getattr(e, "tick", 0),
            "kind": getattr(e, "kind", "event"),
            "scope": getattr(e, "scope", "system"),
            "severity": round(float(getattr(e, "severity", 0.0)), 4),
            "message": getattr(e, "message", ""),
        })
    return rows


def build_observatory_payload(result: Any, comparison: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    final_state = getattr(result, "final_state", None)
    final_summary = final_state.summary() if hasattr(final_state, "summary") else {}
    return {
        "version": "HRM_UNIFIED_v1.9_OBSERVATORY_LAYER",
        "name": getattr(result, "name", "history"),
        "profile_name": getattr(result, "profile_name", "unknown"),
        "population_size": getattr(result, "population_size", 0),
        "seed": getattr(result, "seed", 0),
        "decay": getattr(result, "decay", 0.0),
        "fingerprint": result.fingerprint() if hasattr(result, "fingerprint") else "",
        "total_cost_units": round(float(getattr(result, "total_cost_units", 0.0)), 4),
        "final_state": {k: round(float(v), 4) for k, v in final_summary.items()},
        "snapshots": _state_series(result),
        "steps": _step_rows(result),
        "events": _event_rows(result),
        "comparison": comparison or {},
    }


HTML_TEMPLATE = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>HRM_UNIFIED Observatory</title>
<style>
:root { font-family: system-ui, -apple-system, Segoe UI, sans-serif; color: #171717; background: #f7f7f4; }
body { margin: 0; }
header { padding: 28px 32px; background: #101014; color: #f5f5f0; }
main { padding: 24px 32px 48px; max-width: 1280px; margin: 0 auto; }
h1 { margin: 0 0 8px; font-size: 28px; }
.sub { opacity: .82; }
.grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 14px; margin: 20px 0; }
.card { background: white; border: 1px solid #ddd; border-radius: 14px; padding: 16px; box-shadow: 0 1px 4px rgba(0,0,0,.05); }
.card h2 { margin: 0 0 10px; font-size: 17px; }
.metric { font-size: 30px; font-weight: 700; margin-top: 4px; }
.small { font-size: 12px; color: #666; }
table { width: 100%; border-collapse: collapse; background: white; border-radius: 14px; overflow: hidden; margin: 14px 0 26px; }
th, td { padding: 9px 10px; border-bottom: 1px solid #e7e7e2; text-align: left; font-size: 13px; vertical-align: top; }
th { background: #ecece7; font-size: 12px; text-transform: uppercase; letter-spacing: .04em; }
.barbox { background: #e9e9e3; height: 10px; border-radius: 999px; overflow: hidden; }
.bar { height: 10px; background: #555; width: 0%; }
.neg { color: #7a1b1b; } .pos { color: #125a31; }
.timeline { display: flex; gap: 8px; align-items: stretch; overflow-x: auto; padding: 8px 0 18px; }
.tick { min-width: 132px; border-radius: 12px; border: 1px solid #ddd; background: #fff; padding: 10px; }
.tick strong { display: block; font-size: 12px; }
pre { white-space: pre-wrap; background: #fff; padding: 14px; border-radius: 14px; border: 1px solid #ddd; overflow:auto; }
</style>
</head>
<body>
<header>
  <h1>HRM_UNIFIED Observatory</h1>
  <div class="sub" id="subtitle"></div>
</header>
<main>
  <section class="grid" id="summary"></section>
  <section class="card"><h2>Replay Timeline</h2><div class="timeline" id="timeline"></div></section>
  <section><h2>Pressure Trajectory</h2><table id="snapshots"></table></section>
  <section><h2>Timeline Steps</h2><table id="steps"></table></section>
  <section><h2>Emergent Events</h2><table id="events"></table></section>
  <section><h2>Raw Observatory Payload</h2><pre id="raw"></pre></section>
</main>
<script id="payload" type="application/json">__PAYLOAD__</script>
<script>
const data = JSON.parse(document.getElementById('payload').textContent);
const fmt = v => (typeof v === 'number' ? (v >= 0 ? '+' : '') + v.toFixed(4) : v);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
document.getElementById('subtitle').textContent = `${data.name} | profile ${data.profile_name} | population ${data.population_size} | seed ${data.seed} | fingerprint ${data.fingerprint.slice(0,16)}`;
const summary = document.getElementById('summary');
const cards = [
  ['Snapshots', data.snapshots.length], ['Steps', data.steps.length], ['Events', data.events.length], ['Policy cost', data.total_cost_units]
];
for (const [k,v] of cards) summary.innerHTML += `<div class="card"><h2>${esc(k)}</h2><div class="metric">${esc(v)}</div></div>`;
for (const [k,v] of Object.entries(data.final_state)) summary.innerHTML += `<div class="card"><h2>${esc(k)}</h2><div class="metric ${v<0?'neg':'pos'}">${fmt(v)}</div><div class="small">final civic pressure</div></div>`;
const tl = document.getElementById('timeline');
for (const s of data.snapshots) {
  const stress = Math.min(100, Math.abs(s.stress_pressure || 0) * 100);
  tl.innerHTML += `<div class="tick"><strong>P${s.period} T${s.tick}</strong><div>${esc(s.label)}</div><div class="small">events ${s.events_seen}</div><div class="barbox"><div class="bar" style="width:${stress}%"></div></div></div>`;
}
function table(id, rows, cols) {
  const el = document.getElementById(id);
  if (!rows.length) { el.innerHTML = '<tr><td>No rows.</td></tr>'; return; }
  el.innerHTML = '<thead><tr>' + cols.map(c=>`<th>${esc(c)}</th>`).join('') + '</tr></thead><tbody>' + rows.map(r => '<tr>' + cols.map(c => `<td>${esc(fmt(r[c]))}</td>`).join('') + '</tr>').join('') + '</tbody>';
}
table('snapshots', data.snapshots, ['period','tick','label','stress_pressure','trust_pressure','volatility_pressure','cooperation_pressure','withdrawal_pressure','events_seen']);
table('steps', data.steps, ['period','tick','kind','label','policy_id','cost_units','stress_before','stress_after','trust_before','trust_after','volatility_before','volatility_after']);
table('events', data.events, ['tick','kind','scope','severity','message']);
document.getElementById('raw').textContent = JSON.stringify(data, null, 2);
</script>
</body>
</html>
'''


def write_observatory(result: Any, output_dir: str | Path = "outputs/observatory_v1_9", prefix: str = "observatory", comparison: Optional[Dict[str, Any]] = None) -> Dict[str, str]:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    payload = build_observatory_payload(result, comparison=comparison)
    data_path = out / f"{prefix}_payload.json"
    html_path = out / f"{prefix}.html"
    md_path = out / f"{prefix}_observatory.md"
    data_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    embedded = json.dumps(payload).replace("</", "<\\/")
    html_path.write_text(HTML_TEMPLATE.replace("__PAYLOAD__", embedded), encoding="utf-8")
    md_lines = [
        "# HRM_UNIFIED v1.9 Observatory Report", "",
        f"**Timeline:** {payload['name']}",
        f"**Profile:** {payload['profile_name']}",
        f"**Population:** {payload['population_size']}",
        f"**Fingerprint:** `{payload['fingerprint']}`", "",
        "## Final State", "", "| Pressure | Value |", "|---|---:|",
    ]
    for k, v in payload["final_state"].items():
        md_lines.append(f"| {k} | {v:+.4f} |")
    md_lines += ["", "## Files", "", f"- HTML: `{html_path.name}`", f"- Payload: `{data_path.name}`"]
    md_path.write_text("\n".join(md_lines), encoding="utf-8")
    return {"html": str(html_path), "payload_json": str(data_path), "markdown": str(md_path)}
