@echo off
setlocal
cd /d "%~dp0"
echo Running HRM_UNIFIED v4.41 configurable sim...
py -3 das/run_sim.py --runs 10 --ticks 500 --population 10 --output-root runs_v04_41 --benchmark-file benchmark_v04_41.json
pause
