# HRM_UNIFIED v2.9 — World Inspection Dashboard

This release adds a local-only inspection dashboard for the persistent HRM/DAS world state.

## Added

- `world_dashboard.py`
- `run_world_dashboard.py`
- `RUN_V2_9_WORLD_INSPECTION_DASHBOARD_WINDOWS_SAFE.bat`
- `RUN_V2_9_DASHBOARD_NO_BROWSER_WINDOWS_SAFE.bat`

## Dashboard panels

- world summary
- benchmark metrics
- replay/evolution events
- ideas/products/discoveries
- institutions
- human social dynamics
- kinship/lineage/faction raw inspectors
- since-last-viewed report viewer

## Windows-safe behavior

The launcher does not rely on Python file associations. It searches for:

1. `py -3`
2. `python`
3. `python3`

If no world checkpoint exists yet, the launcher creates a small sample v2.8 world first, then opens the dashboard.
