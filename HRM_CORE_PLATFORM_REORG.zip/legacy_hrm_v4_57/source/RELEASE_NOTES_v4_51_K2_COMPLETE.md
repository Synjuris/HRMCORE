# HRM_UNIFIED v4.51 — Kernel Phase K2-2: Complete Runtime Absorption

## Summary
All experiments now route through the kernel.
Old run scripts are legacy reference only — not the execution path.
Bugs get fixed once, in one place.

## What Changed

### New: das/configs/ (8 configs total)
- exp_A.json  — seed=17, 4 groups simultaneous, no seed memes (organic emergence)
- exp_B.json  — seed=17, 4 groups simultaneous, prosocial memes all groups
- exp_C.json  — seed=17, 4 groups simultaneous, prosocial memes (resource_transfer emphasis)
- exp_D.json  — seed=17, 4 groups simultaneous, no seed memes (epoch/attractor analytics)
- exp_E.json  — seed=23, staggered arrival, group-differentiated memes (pre-existing)
- exp_E_1k.json — exp_E, 1000 ticks (pre-existing)
- single_band.json — seed=42, 30 agents, 20×20 world, no groups
- civilization.json — seed=13, 20 agents, 18×18 world, no groups

### New: das/run_kernel_*.py (7 thin wrappers, ~60 lines each)
- run_kernel_exp_A.py
- run_kernel_exp_B.py
- run_kernel_exp_C.py
- run_kernel_exp_D.py
- run_kernel_single_band.py
- run_kernel_civilization.py
- run_kernel_exp_E_resume.py  [K2-PARTIAL — see below]

### New: das/kernel/KERNEL_MIGRATION_AUDIT_K2.md
Full migration map. Script status. Remaining K2-3 items.

## Deprecated (legacy, not deleted)
- run_exp_A/B/C/C2/D/E/E_1k.py — superseded by kernel wrappers
- run_four_groups.py — identical to exp_A, mapped to configs/exp_A.json
- run_exp_E_resume.py — superseded by run_kernel_exp_E_resume.py
- run_single_band.py, run_civilization.py — superseded by kernel wrappers

## Not Migrated
- run_sim.py — multi-run benchmark harness, deferred to K2-3

## K2-PARTIAL: Resume
run_kernel_exp_E_resume.py routes tick loop through the kernel.
Full agent state restoration (beliefs, memory, relationships) from
checkpoint is not yet kernel-native. Deferred to K2-3.

## Remaining for K2-3
1. Kernel checkpoint load/restore API (true resume)
2. run_sim.py → kernel benchmark harness
3. SYSTEM_PHASES constant in runtime.py
4. SubsystemSpec dependency declarations
5. observe(tick, state) hook in kernel METRICS phase

## After K2 Complete: SRK-2
Belief-mediated perception through kernel-managed hooks.
