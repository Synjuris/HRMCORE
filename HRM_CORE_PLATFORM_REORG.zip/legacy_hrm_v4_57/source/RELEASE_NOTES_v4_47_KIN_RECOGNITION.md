# HRM_UNIFIED v4.47 — Kin Recognition

Follow-up to v4.46 relational layer. The attraction gate on pair bonds raised
a correct concern: family relationships need to be treated differently from
romantic relationships, not gated by the same attraction mechanics.

## Added

### Kin recognition (generational.py)
is_kin(a, b) helper checks parent_ids for direct kin relationships:
- Parent-child: b.id in a.parent_ids or a.id in b.parent_ids
- Siblings: a.parent_ids ∩ b.parent_ids is non-empty

### Incest prevention
Kin gate added to pair bond formation. is_kin() called before attraction check.
Close kin cannot form romantic pair bonds regardless of trust/attachment levels.

### Kin bond reinforcement
Each caretaking tick, when a capable adult cares for a dependent kin member,
both agents receive a trust and attachment boost to their mutual relationship:
- Caretaker → dependent: trust +0.004, attachment +0.006 per tick
- Dependent → caretaker: trust +0.005, attachment +0.008 per tick

This produces meaningfully different relationship profiles between kin vs strangers.
After 500 ticks, parent-child relationships show trust 0.53–1.0 and attachment
0.02–1.0 depending on co-location and caretaking frequency. Non-kin strangers
start at relationship defaults and build through normal interaction only.
