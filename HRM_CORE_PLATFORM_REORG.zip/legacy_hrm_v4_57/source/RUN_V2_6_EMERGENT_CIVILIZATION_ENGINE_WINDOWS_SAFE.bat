@echo off
setlocal ENABLEDELAYEDEXPANSION
cd /d "%~dp0"
echo HRM_UNIFIED v2.6 - Emergent Civilization Engine
echo.
echo Checking for Python...
set "PYTHON_CMD="
where py >nul 2>nul
if not errorlevel 1 set "PYTHON_CMD=py -3"
if "%PYTHON_CMD%"=="" (
  where python >nul 2>nul
  if not errorlevel 1 set "PYTHON_CMD=python"
)
if "%PYTHON_CMD%"=="" (
  where python3 >nul 2>nul
  if not errorlevel 1 set "PYTHON_CMD=python3"
)
if "%PYTHON_CMD%"=="" (
  echo ERROR: Python was not found on PATH.
  echo Install Python 3.10+ from python.org and check "Add Python to PATH" during install.
  echo.
  pause
  exit /b 1
)
echo Using: %PYTHON_CMD%
%PYTHON_CMD% --version
echo.
%PYTHON_CMD% run_emergent_civilization.py --generations 6 --n 600 --seed 42 --output-dir outputs\emergent_civilization_v2_6
set "EXITCODE=%ERRORLEVEL%"
echo.
if "%EXITCODE%"=="0" (
  echo Run complete. See outputs\emergent_civilization_v2_6.
) else (
  echo Run completed with warnings/audit failures or an error. Exit code: %EXITCODE%
  echo See outputs\emergent_civilization_v2_6 if reports were produced.
)
echo.
pause
exit /b %EXITCODE%
