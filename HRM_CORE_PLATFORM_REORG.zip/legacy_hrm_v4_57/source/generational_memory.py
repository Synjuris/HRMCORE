"""Generational memory layer for HRM_UNIFIED v2.4.

This module makes historical consequences persist across simulated generations.
It is intentionally generic: it does not encode personal facts, real local claims,
or hidden scenario assumptions. It converts simulated historical pressure into
cohort-level inheritance, institutional memory, cultural decay, scars, resilience,
and shifted future baselines.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List, Optional
import copy
import hashlib
import json
import math
import time

ENGINE_VERSION = "2.4"

CORE_SIGNALS = [
    "stress_pressure",
    "trust_pressure",
    "volatility_pressure",
    "cooperation_pressure",
    "withdrawal_pressure",
]


def _utc_stamp() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _canonical(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def fingerprint(obj: Any) -> str:
    return hashlib.sha256(_canonical(obj).encode("utf-8")).hexdigest()


def _clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, float(value)))


def _as_float(obj: Any, default: float = 0.0) -> float:
    try:
        if obj is None:
            return default
        if isinstance(obj, float) and math.isnan(obj):
            return default
        return float(obj)
    except Exception:
        return default


def _summary_from_state(state: Any) -> Dict[str, float]:
    if hasattr(state, "summary"):
        return {k: _as_float(v) for k, v in state.summary().items()}
    if hasattr(state, "to_dict"):
        state = state.to_dict()
    if isinstance(state, dict):
        return {k: _as_float(state.get(k, 0.0)) for k in CORE_SIGNALS}
    return {k: 0.0 for k in CORE_SIGNALS}


@dataclass
class CohortMemory:
    cohort_id: str
    generation: int
    population_share: float
    inherited_trust_baseline: float = 0.0
    inherited_stress_baseline: float = 0.0
    inherited_resilience: float = 0.0
    inherited_withdrawal: float = 0.0
    formative_scar: float = 0.0
    formative_legitimacy: float = 0.0
    encoded_at: str = field(default_factory=_utc_stamp)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class GenerationalMemoryState:
    generation_index: int = 0
    cohorts: List[CohortMemory] = field(default_factory=list)
    institutional_memory: Dict[str, float] = field(default_factory=dict)
    cultural_memory: Dict[str, float] = field(default_factory=dict)
    historical_scars: Dict[str, float] = field(default_factory=dict)
    resilience_inheritance: float = 0.0
    baseline_shift: Dict[str, float] = field(default_factory=dict)
    encoded_events: List[Dict[str, Any]] = field(default_factory=list)
    created_at: str = field(default_factory=_utc_stamp)
    updated_at: str = field(default_factory=_utc_stamp)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "generation_index": self.generation_index,
            "cohorts": [c.to_dict() for c in self.cohorts],
            "institutional_memory": dict(self.institutional_memory),
            "cultural_memory": dict(self.cultural_memory),
            "historical_scars": dict(self.historical_scars),
            "resilience_inheritance": round(self.resilience_inheritance, 6),
            "baseline_shift": dict(self.baseline_shift),
            "encoded_events": list(self.encoded_events),
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "fingerprint": self.fingerprint(),
        }

    def fingerprint(self) -> str:
        payload = asdict(self)
        return fingerprint(payload)


@dataclass
class GenerationReport:
    generation: int
    label: str
    before_state: Dict[str, float]
    after_state: Dict[str, float]
    encoded_memory: Dict[str, Any]
    inherited_baseline_shift: Dict[str, float]
    cohort_summary: List[Dict[str, Any]]
    constitution_passed: Optional[bool] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class GenerationalRunReport:
    version: str
    name: str
    generations: List[GenerationReport]
    final_memory_state: Dict[str, Any]
    long_run_benchmark: Dict[str, Any]
    created_at: str = field(default_factory=_utc_stamp)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "version": self.version,
            "name": self.name,
            "generations": [g.to_dict() for g in self.generations],
            "final_memory_state": self.final_memory_state,
            "long_run_benchmark": self.long_run_benchmark,
            "created_at": self.created_at,
            "fingerprint": fingerprint({
                "version": self.version,
                "name": self.name,
                "generations": [g.to_dict() for g in self.generations],
                "final_memory_state": self.final_memory_state,
                "long_run_benchmark": self.long_run_benchmark,
            }),
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)


class GenerationalMemoryEngine:
    """Encodes simulated historical consequences into future cohort baselines."""

    def __init__(self, cultural_decay: float = 0.72, institutional_decay: float = 0.88, cohort_turnover: float = 0.30, inheritance_strength: float = 0.42):
        self.cultural_decay = _clamp(cultural_decay, 0.0, 0.99)
        self.institutional_decay = _clamp(institutional_decay, 0.0, 0.99)
        self.cohort_turnover = _clamp(cohort_turnover, 0.01, 0.95)
        self.inheritance_strength = _clamp(inheritance_strength, 0.0, 1.0)
        self.state = GenerationalMemoryState(
            cohorts=[CohortMemory("founding_cohort", 0, 1.0)],
            institutional_memory={"legitimacy": 0.0, "strain_memory": 0.0, "response_reliability": 0.0},
            cultural_memory={"cooperation_norm": 0.0, "withdrawal_norm": 0.0, "uncertainty_norm": 0.0},
            historical_scars={"stress_scar": 0.0, "trust_scar": 0.0, "volatility_scar": 0.0},
            baseline_shift={k: 0.0 for k in CORE_SIGNALS},
        )

    def _decay_memory(self) -> None:
        for k in list(self.state.cultural_memory):
            self.state.cultural_memory[k] = round(self.state.cultural_memory[k] * self.cultural_decay, 6)
        for k in list(self.state.institutional_memory):
            self.state.institutional_memory[k] = round(self.state.institutional_memory[k] * self.institutional_decay, 6)
        for k in list(self.state.historical_scars):
            # Scars decay slower than ordinary culture but are not permanent constants.
            self.state.historical_scars[k] = round(self.state.historical_scars[k] * max(self.cultural_decay, self.institutional_decay), 6)

    def encode_result(self, result: Any, generation_label: str = "generation") -> Dict[str, Any]:
        summary = _summary_from_state(getattr(result, "final_state", {}))
        stress = summary.get("stress_pressure", 0.0)
        trust = summary.get("trust_pressure", 0.0)
        volatility = summary.get("volatility_pressure", 0.0)
        cooperation = summary.get("cooperation_pressure", 0.0)
        withdrawal = summary.get("withdrawal_pressure", 0.0)
        events = getattr(result, "events", []) or []
        event_pressure = min(1.0, len(events) / 20.0)

        self._decay_memory()
        self.state.generation_index += 1

        legitimacy_delta = 0.35 * trust + 0.25 * cooperation - 0.30 * stress - 0.20 * volatility - 0.15 * withdrawal
        strain_delta = 0.45 * stress + 0.35 * volatility + 0.20 * withdrawal
        reliability_delta = 0.30 * cooperation + 0.20 * trust - 0.25 * volatility

        self.state.institutional_memory["legitimacy"] = round(_clamp(self.state.institutional_memory.get("legitimacy", 0.0) + legitimacy_delta, -2.0, 2.0), 6)
        self.state.institutional_memory["strain_memory"] = round(_clamp(self.state.institutional_memory.get("strain_memory", 0.0) + strain_delta, 0.0, 2.0), 6)
        self.state.institutional_memory["response_reliability"] = round(_clamp(self.state.institutional_memory.get("response_reliability", 0.0) + reliability_delta, -2.0, 2.0), 6)

        self.state.cultural_memory["cooperation_norm"] = round(_clamp(self.state.cultural_memory.get("cooperation_norm", 0.0) + 0.45 * cooperation + 0.15 * trust, -2.0, 2.0), 6)
        self.state.cultural_memory["withdrawal_norm"] = round(_clamp(self.state.cultural_memory.get("withdrawal_norm", 0.0) + 0.50 * withdrawal + 0.20 * stress, 0.0, 2.0), 6)
        self.state.cultural_memory["uncertainty_norm"] = round(_clamp(self.state.cultural_memory.get("uncertainty_norm", 0.0) + 0.45 * volatility + 0.15 * event_pressure, 0.0, 2.0), 6)

        self.state.historical_scars["stress_scar"] = round(_clamp(self.state.historical_scars.get("stress_scar", 0.0) + max(0.0, stress) * 0.55 + event_pressure * 0.10, 0.0, 2.0), 6)
        self.state.historical_scars["trust_scar"] = round(_clamp(self.state.historical_scars.get("trust_scar", 0.0) + max(0.0, -trust) * 0.45 + max(0.0, volatility) * 0.10, 0.0, 2.0), 6)
        self.state.historical_scars["volatility_scar"] = round(_clamp(self.state.historical_scars.get("volatility_scar", 0.0) + max(0.0, volatility) * 0.50, 0.0, 2.0), 6)

        resilience_delta = 0.35 * max(0.0, cooperation) + 0.25 * max(0.0, trust) - 0.20 * max(0.0, withdrawal) - 0.15 * max(0.0, volatility)
        self.state.resilience_inheritance = round(_clamp(self.state.resilience_inheritance * self.institutional_decay + resilience_delta, -1.5, 1.5), 6)

        self.state.baseline_shift = self.compute_baseline_shift()
        self._turnover_cohorts(summary)
        encoded = {
            "generation": self.state.generation_index,
            "label": generation_label,
            "source_result_fingerprint": result.fingerprint() if hasattr(result, "fingerprint") else "",
            "final_pressures": {k: round(v, 6) for k, v in summary.items()},
            "event_pressure": round(event_pressure, 6),
            "institutional_memory": dict(self.state.institutional_memory),
            "cultural_memory": dict(self.state.cultural_memory),
            "historical_scars": dict(self.state.historical_scars),
            "baseline_shift": dict(self.state.baseline_shift),
        }
        self.state.encoded_events.append(encoded)
        self.state.updated_at = _utc_stamp()
        return encoded

    def compute_baseline_shift(self) -> Dict[str, float]:
        inst = self.state.institutional_memory
        cult = self.state.cultural_memory
        scars = self.state.historical_scars
        resilience = self.state.resilience_inheritance
        shift = {
            "stress_pressure": 0.18 * scars.get("stress_scar", 0.0) + 0.12 * inst.get("strain_memory", 0.0) - 0.10 * resilience,
            "trust_pressure": 0.16 * inst.get("legitimacy", 0.0) + 0.10 * inst.get("response_reliability", 0.0) - 0.18 * scars.get("trust_scar", 0.0),
            "volatility_pressure": 0.16 * scars.get("volatility_scar", 0.0) + 0.12 * cult.get("uncertainty_norm", 0.0) - 0.08 * resilience,
            "cooperation_pressure": 0.18 * cult.get("cooperation_norm", 0.0) + 0.08 * resilience - 0.10 * cult.get("withdrawal_norm", 0.0),
            "withdrawal_pressure": 0.16 * cult.get("withdrawal_norm", 0.0) + 0.10 * scars.get("stress_scar", 0.0) - 0.07 * resilience,
        }
        return {k: round(_clamp(v * self.inheritance_strength, -0.85, 0.85), 6) for k, v in shift.items()}

    def _turnover_cohorts(self, summary: Dict[str, float]) -> None:
        surviving: List[CohortMemory] = []
        for c in self.state.cohorts:
            share = round(c.population_share * (1.0 - self.cohort_turnover), 6)
            if share >= 0.01:
                c.population_share = share
                surviving.append(c)
        new_share = round(1.0 - sum(c.population_share for c in surviving), 6)
        shift = self.state.baseline_shift
        cohort = CohortMemory(
            cohort_id=f"generation_{self.state.generation_index}_cohort",
            generation=self.state.generation_index,
            population_share=max(0.0, new_share),
            inherited_trust_baseline=shift.get("trust_pressure", 0.0),
            inherited_stress_baseline=shift.get("stress_pressure", 0.0),
            inherited_resilience=self.state.resilience_inheritance,
            inherited_withdrawal=shift.get("withdrawal_pressure", 0.0),
            formative_scar=max(self.state.historical_scars.values() or [0.0]),
            formative_legitimacy=self.state.institutional_memory.get("legitimacy", 0.0),
        )
        self.state.cohorts = surviving + [cohort]

    def apply_baseline_to_simulator(self, simulator: Any) -> Dict[str, float]:
        """Apply inherited baseline shift to a HistoricalSimulator-like object."""
        shift = self.compute_baseline_shift()
        state = simulator.tracker.state
        for key, delta in shift.items():
            if hasattr(state, key):
                setattr(state, key, round(_clamp(_as_float(getattr(state, key)) + delta, -2.0, 2.0), 6))
        self.state.baseline_shift = shift
        return shift

    def to_dict(self) -> Dict[str, Any]:
        return self.state.to_dict()


def generational_markdown(report: GenerationalRunReport) -> str:
    d = report.to_dict()
    lines = [
        "# HRM_UNIFIED v2.4 Generational Memory Report",
        "",
        f"**Run:** {report.name}",
        f"**Version:** {report.version}",
        f"**Fingerprint:** `{d['fingerprint']}`",
        "",
        "## Core Loop",
        "",
        "event pressure -> civic adaptation -> memory encoding -> cohort inheritance -> future baseline shift -> different future response",
        "",
        "## Generation Before/After Summary",
        "",
        "| Generation | Label | Stress Before | Stress After | Trust Before | Trust After | Constitution |",
        "|---:|---|---:|---:|---:|---:|---|",
    ]
    for g in report.generations:
        before = g.before_state
        after = g.after_state
        cp = "n/a" if g.constitution_passed is None else ("PASS" if g.constitution_passed else "FAIL")
        lines.append(f"| {g.generation} | {g.label} | {before.get('stress_pressure',0):+.4f} | {after.get('stress_pressure',0):+.4f} | {before.get('trust_pressure',0):+.4f} | {after.get('trust_pressure',0):+.4f} | {cp} |")
    lines += ["", "## Final Inherited Baseline Shift", "", "| Signal | Shift |", "|---|---:|"]
    for k, v in report.final_memory_state.get("baseline_shift", {}).items():
        lines.append(f"| {k} | {v:+.4f} |")
    lines += ["", "## Long-Run Benchmark", ""]
    for k, v in report.long_run_benchmark.items():
        lines.append(f"- **{k}:** {v}")
    lines += ["", "## Cohorts", "", "| Cohort | Generation | Share | Trust Base | Stress Base | Resilience | Scar |", "|---|---:|---:|---:|---:|---:|---:|"]
    for c in report.final_memory_state.get("cohorts", []):
        lines.append(f"| {c.get('cohort_id')} | {c.get('generation')} | {float(c.get('population_share',0)):.3f} | {float(c.get('inherited_trust_baseline',0)):+.4f} | {float(c.get('inherited_stress_baseline',0)):+.4f} | {float(c.get('inherited_resilience',0)):+.4f} | {float(c.get('formative_scar',0)):+.4f} |")
    return "\n".join(lines)
