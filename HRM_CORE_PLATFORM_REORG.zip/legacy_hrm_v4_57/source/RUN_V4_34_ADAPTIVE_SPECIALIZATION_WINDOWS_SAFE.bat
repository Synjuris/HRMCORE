@echo off
cd /d "%~dp0\das"
set DAS_OUTPUT_ROOT=runs_v04_34
python run_sim.py
pause
