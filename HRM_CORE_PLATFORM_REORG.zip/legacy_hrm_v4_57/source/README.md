# HRM_UNIFIED v2.3 — Constitution Layer

HRM_UNIFIED is a local Python simulation package for running synthetic civic scenarios over time. It combines a synthetic population response engine, calibrated population profiles, abstract spatial districts, institutional influence, civic pressure accumulation, policy/intervention testing, replayable history, static local observatory export, and an invariant/audit constitution layer.

The package is intentionally generic. It does **not** contain personal context, hardcoded real-city defaults, embedded API keys, or prediction claims about actual populations.

---

## What this package does

At a high level, HRM_UNIFIED runs this loop:

```text
initialize synthetic civic environment
→ apply timeline events and/or policies
→ update synthetic population response
→ accumulate district and institutional pressure
→ detect synthetic civic state changes
→ save environment state
→ export reports and local observatory files
```

It is best understood as a **synthetic society sandbox** for testing internal causal coherence, not as a validated forecasting system.

---

## Main capabilities

- Synthetic population stimulus-response panel
- Generic calibrated population profiles
- Segment-level heterogeneous responses
- Trust-channel weighting
- Clustered social topology
- Abstract districts and institutions
- Movement/exposure pathways
- Civic pressure accumulation and decay
- Emergent civic event detection
- Policy/intervention injection
- Replayable timeline simulation
- Save/load/resume/branch environment state
- Static local observatory HTML export
- Validation and benchmark scripts
- Optional Census ACS adapter for aggregate calibration inputs
- Experimental DAS emergence modules included separately
- Constitution/invariant audit layer for internal coherence checks

---

## Install

From inside the extracted `hrm_unified/` folder:

```bash
python -m pip install -r requirements.txt
```

Most core scripts use the Python standard library plus this package code. Some experimental or optional modules may require packages listed in `requirements.txt`.

---

## Quick start

Run the default persistent environment:

```bash
python run_environment.py
```

Run the packaged demo timeline:

```bash
python run_environment.py scenarios/environment_demo_timeline.json
```

Run the environment benchmark:

```bash
python environment_benchmark.py
```

Run the v2.3 constitution audit:

```bash
python run_constitution_audit.py
```

On Windows, you can also double-click:

```text
OPEN_ME_WINDOWS.bat
```

Typical output is written under:

```text
outputs/environment_v2_1/
```

Each run writes a local summary, snapshot, fingerprint, and observatory export.

---

## Primary entrypoints

### Persistent environment

```bash
python run_environment.py
```

Runs the full v2.2 environment loop with persistent state.

### Resume from a saved snapshot

```bash
python run_environment.py scenarios/environment_demo_timeline.json --load-env outputs/environment_v2_1/run_001_generic_recovery_history/environment_snapshot.json
```

### Branch from a saved snapshot

```bash
python run_environment.py scenarios/environment_demo_timeline.json --load-env path/to/environment_snapshot.json --branch alternate_policy_path
```

### Build observatory output

```bash
python build_observatory.py
```

Exports a static local HTML replay/summary view.

### Validate core behavior

```bash
python validate_engine.py
```

Runs deterministic coherence checks against fixed generic scenarios.

---

## Common scripts

| Script | Purpose |
|---|---|
| `run_environment.py` | Main v2.2 persistent synthetic civic environment runner |
| `environment_benchmark.py` | Deterministic v2.2 environment benchmark |
| `run_panel.py` | Single synthetic population stimulus-response run |
| `compare_stimuli.py` | Compare two text stimuli |
| `batch_stimuli.py` | Run multiple stimuli from CSV |
| `run_calibrated_panel.py` | Run calibrated population profiles |
| `run_spatial_panel.py` | Run abstract spatial/institutional response |
| `run_civic_dynamics.py` | Run accumulated civic pressure sequence |
| `run_policy.py` | Run synthetic policy/intervention sequence |
| `replay_history.py` | Run replayable timeline simulation |
| `compare_histories.py` | Compare two timeline branches |
| `build_observatory.py` | Build static local observatory files |
| `validate_engine.py` | Run coherence validation harness |
| `fetch_real_profile.py` | Optional Census ACS profile fetch |
| `run_real_panel.py` | Optional aggregate real-data calibrated panel |

---

## Output files

Depending on the script, outputs may include:

- `*.json` structured run summaries
- `*.md` human-readable reports
- `*.csv` tabular summaries
- `*.jsonl` synthetic agent samples
- `environment_snapshot.json` persistent saved state
- fingerprint hashes for deterministic comparison
- static local HTML observatory exports

The primary v2.2 environment output folder is:

```text
outputs/environment_v2_1/
```

---

## Optional real-data calibration

The real-data path is optional and uses aggregate public data as calibration input. It is not required for the engine to run.

API keys are loaded from environment variables or a local `.env.user` file. They are not embedded in Python source.

Example:

```bash
python fetch_real_profile.py --state 06 --county 001
python run_real_panel.py "A major employer announces layoffs." --state 06 --county 001
```

See:

```text
REAL_DATA_README.md
```

Important: real aggregate data can help parameterize synthetic profiles, but it does not make the system predictive or validated against real populations.

---

## Design boundaries

This package is designed to stay:

- generic
- local-first
- reproducible
- configurable
- non-personalized by default
- free of embedded secrets
- free of hardcoded local/geographic assumptions

The engine should not contain autobiographical context, legal/custody context, hidden ideology, or real-city defaults. Any specific calibration dataset should live outside the core engine as external configuration or runtime input.

---

## Current status

Stable enough to inspect and run as a v2.0 synthetic civic environment prototype.

Not yet:

- a validated social science model
- a real-world prediction system
- a GIS-accurate city model
- a live data platform
- a polished application UI

The most defensible description is:

> A local synthetic civic simulation sandbox for exploring how abstract populations, institutions, policies, and events interact over replayable timelines.

---

## Development lineage

Earlier release notes are preserved for traceability:

- `RELEASE_NOTES_v1.1.md`
- `RELEASE_NOTES_v1.2_REAL_DATA.md`
- `RELEASE_NOTES_v1.3_CALIBRATED_POPULATION.md`
- `RELEASE_NOTES_v1.4_VALIDATION.md`
- `RELEASE_NOTES_v1.5_SPATIAL_INSTITUTIONAL.md`
- `RELEASE_NOTES_v1.6_EMERGENT_CIVIC_DYNAMICS.md`
- `RELEASE_NOTES_v1.7_POLICY_INJECTION.md`

v1.8 and v1.9 functionality is represented by the history and observatory scripts in this package. v2.0 consolidates those layers into the persistent environment runner.

## v2.2 HRM/DAS Bridge Layer

The v2.2 bridge is an optional controlled coupling between the HRM civic environment and DAS-style long-horizon emergence. It does **not** dump the full legacy DAS simulation into the environment. Instead, it translates final HRM civic pressures into bounded DAS substrate variables.

Run:

```bash
python run_das_bridge.py
```

Or enable it in the environment runner:

```bash
python run_environment.py --enable-das-bridge
```

Bridge outputs include:

- `das_bridge_report.json`
- `das_bridge_report.md`
- bridge state inside `environment_snapshot.json` when enabled

Tracked substrate variables:

- structural stress
- institutional adaptation
- faction volatility
- cooperation capacity
- innovation momentum
- migration tendency
- cultural drift
- resilience memory

The bridge remains generic: no personal context, locality-specific defaults, or API keys are embedded.



## v2.2 Endogenous Evolution Layer

Version 2.2 adds controlled DAS feedback into the persistent civic baseline. The HRM/DAS bridge still translates civic pressures into a bounded DAS substrate, but v2.2 can now feed selected substrate effects back into later civic state so repeated runs are no longer only reactive.

New commands:

```bash
python run_endogenous_evolution.py
python run_environment.py --enable-das-feedback
python endogenous_benchmark.py
```

New outputs include:

- `das_endogenous_feedback_report.json`
- `das_endogenous_feedback_report.md`
- persistent endogenous markers in `environment_snapshot.json`

The feedback layer records generic synthetic markers only:

- faction emergence
- institutional adaptation/degradation
- innovation/recombination
- cultural drift
- generational memory placeholder
- baseline modifiers for later civic runs

This layer remains generic. It contains no personal, locality-specific, or embedded API-key values.

## v2.4 Generational Memory Layer

The v2.4 layer makes historical consequences persist across simulated generations rather than ending at one run boundary. It adds cohort turnover, inherited trust/stress baselines, institutional memory, cultural memory decay, historical scar formation, resilience inheritance, long-run benchmark output, and a before/after generation report.

Run:

```bash
python -m hrm_unified.run_generational_memory --generations 4 --n 600
```

Windows launcher:

```text
RUN_V2_4_GENERATIONAL_MEMORY_WINDOWS.bat
```

Outputs:

```text
outputs/generational_memory_v2_4/generational_memory_report.json
outputs/generational_memory_v2_4/generational_memory_report.md
```

## v2.5 Institutional Evolution Layer

v2.5 adds institutional evolution on top of v2.4 generational memory.
Institutions now mutate structure in response to inherited civic memory, legitimacy drift, strain, scars, resilience, and public adaptation.

Run:

```bash
python run_institutional_evolution.py --generations 5
```

Windows:

```bat
RUN_V2_5_INSTITUTIONAL_EVOLUTION_WINDOWS.bat
```

Outputs:

- `outputs/institutional_evolution_v2_5/institutional_evolution_report.json`
- `outputs/institutional_evolution_v2_5/institutional_evolution_report.md`

Core loop:

```text
generational memory -> institutional legitimacy shift -> institutional behavior mutation -> public adaptation -> new civic equilibrium or breakdown
```


## v2.8 — Human Social Dynamics + DAS Deep Integration

v2.8 integrates DAS-derived lifecycle and social mechanics into the persistent HRM world loop.

Run on Windows:

```bat
RUN_V2_8_HUMAN_SOCIAL_DYNAMICS_WINDOWS_SAFE.bat
```

This layer adds persistent social state for reproduction pressure, mortality pressure, pair bonding, family continuity, kinship, identity/sexuality expression, norm tolerance, factions, beliefs, territory, specialization, migration, language, and information density.

Reports are written to:

```text
outputs/human_social_dynamics_v2_8/default_world/reports/human_social_dynamics_report.md
outputs/human_social_dynamics_v2_8/default_world/reports/since_last_viewed_report.md
```


## v2.9 World Inspection Dashboard

Run on Windows:

```bat
RUN_V2_9_WORLD_INSPECTION_DASHBOARD_WINDOWS_SAFE.bat
```

This starts a local dashboard at `http://127.0.0.1:8765/` and reads the persistent world output from:

```text
outputs/human_social_dynamics_v2_8/default_world
```

If no world checkpoint exists, the launcher creates a small sample world first.

---

# HRM_UNIFIED v3.0 — Scalable World Architecture

v3.0 is a scale-control release. It does not add more civilization mechanics. It adds the architecture needed to keep the existing mechanics practical as the world grows.

## Main runner

Windows:

```bat
RUN_V3_0_SCALABLE_WORLD_ARCHITECTURE_WINDOWS_SAFE.bat
```

Python:

```bash
python run_scalable_world.py --mode desktop --n 1200 --cycles 2 --generations-per-cycle 2
```

## Modes

- `toy`: small fast inspection mode
- `desktop`: practical local-machine default
- `large`: compressed large-world mode

## Added files

- `scalable_architecture.py`
- `run_scalable_world.py`
- `scalable_benchmark.py`
- `RUN_V3_0_SCALABLE_WORLD_ARCHITECTURE_WINDOWS_SAFE.bat`
- `RUN_V3_0_SCALABILITY_BENCHMARK_WINDOWS_SAFE.bat`

## What v3.0 changes

- Adds fidelity tiers: active / regional / statistical
- Adds max-agent guardrails by mode
- Adds replay log compaction
- Adds checkpoint pruning
- Adds dashboard-safe summaries
- Adds scale health reports
- Adds a small scalability benchmark

The rule is: not every agent, memory, relationship, and tick stays full-detail forever.

---

## v3.1 — Era Seeding + Reality Baseline

Start the simulation from a chosen baseline instead of an unanchored emergent world.

Windows:

```bat
RUN_V3_1_ERA_SEEDING_REALITY_BASELINE_WINDOWS_SAFE.bat
```

Manual:

```bash
python run_era_seeding.py --era modern --start-year 2026 --location generic --mode toy --n 150 --cycles 1 --generations-per-cycle 1
```

Available eras:

- ancient
- medieval
- industrial
- modern
- near_future
- now

Outputs:

- `outputs/era_seeded_world_v3_1/<world_id>/seeds/reality_baseline.json`
- `outputs/era_seeded_world_v3_1/<world_id>/seeds/timeline_seed.json`
- `outputs/era_seeded_world_v3_1/<world_id>/reports/reality_divergence_report.md`

---

## v3.2 — Disease Ecology + Public Health Layer

Purpose: model disease as a civilization pressure system seeded from the v3.1 era/reality baseline.

Added files:

- `disease_ecology.py`
- `run_disease_ecology.py`
- `RUN_V3_2_DISEASE_ECOLOGY_PUBLIC_HEALTH_WINDOWS_SAFE.bat`

What it adds:

- disease profiles: low chronic, seasonal respiratory, high epidemic, novel pathogen, auto
- public-health state derived from era baseline
- healthcare, sanitation, compliance, misinformation, surveillance, vaccine/medicine capacity
- mortality, fertility, productivity, institutional stress, trust deltas
- historical disease scar formation
- disease pressure timeline compatible with existing scalable world runner
- Markdown and JSON disease reports

Windows use:

1. Unzip the package.
2. Open the `hrm_unified` folder.
3. Double-click:

```bat
RUN_V3_2_DISEASE_ECOLOGY_PUBLIC_HEALTH_WINDOWS_SAFE.bat
```

Manual examples:

```bash
python run_disease_ecology.py --era now --disease auto --cycles 12 --run-world --mode toy --n 250 --force
python run_disease_ecology.py --era medieval --disease high_epidemic --cycles 24
python run_disease_ecology.py --era modern --disease novel_pathogen --cycles 18 --run-world --mode desktop --n 1000
```

Outputs:

- `outputs/disease_ecology_v3_2/<world_id>/reports/disease_ecology_report.md`
- `outputs/disease_ecology_v3_2/<world_id>/reports/disease_ecology_report.json`
- `outputs/disease_ecology_v3_2/<world_id>/seeds/disease_pressure_timeline.json`

Important boundary: v3.2 is not a medical prediction system. It produces normalized simulation pressures for civilization dynamics and future calibration.

---

# v3.3 — Real Dataset Ingestion + Calibration Layer

Added files:

- `real_dataset_calibration.py`
- `run_real_dataset_calibration.py`
- `REAL_DATASET_CALIBRATION_v3_3_README.md`
- `datasets/sample_real_dataset.csv`
- `RUN_V3_3_REAL_DATASET_CALIBRATION_WINDOWS_SAFE.bat`

Purpose: ingest public/local CSV/JSON/ACS data into inspectable calibration priors used by HRM, disease ecology, era seeding, and scalable architecture.

Run:

`RUN_V3_3_REAL_DATASET_CALIBRATION_WINDOWS_SAFE.bat`

Outputs:

- `outputs/real_dataset_calibration_v3_3/real_dataset_calibration_bundle.json`
- `outputs/real_dataset_calibration_v3_3/real_dataset_calibration_report.md`
- patch JSON files for HRM / disease / era / scale layers

This layer is offline-safe. Missing APIs create warnings instead of breaking the package.
