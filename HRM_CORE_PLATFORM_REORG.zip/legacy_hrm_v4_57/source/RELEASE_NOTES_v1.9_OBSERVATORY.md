# HRM_UNIFIED v1.9 — Observatory Layer

## Purpose

v1.9 makes replayable synthetic histories observable. It adds a static, local-only observatory export that turns timeline runs into human-readable HTML, JSON, and Markdown reports.

This is still a synthetic simulation environment, not a prediction engine.

## Added

- `observatory.py`
  - converts historical run results into observatory payloads
  - exports self-contained HTML reports
  - exports JSON payloads and Markdown summaries
- `build_observatory.py`
  - command-line observatory builder
- `observatory_benchmark.py`
  - deterministic smoke benchmark for observatory generation

## Observable outputs

The generated observatory displays:

- replay timeline
- pressure trajectory
- timeline steps
- emergent events
- final civic pressure state
- raw machine-readable payload

## Privacy / locality rules

- No API keys embedded.
- No personal references embedded.
- No fixed locality embedded.
- No external JS/CDN/network dependency.
- The HTML observatory is static and local.

## Example

```bash
python build_observatory.py
```

Optional custom timeline:

```bash
python build_observatory.py scenarios/generic_history_timeline.json --n 1000 --seed 42
```

Output defaults to:

```text
outputs/observatory_v1_9/
```

## Verification

Smoke-tested commands:

```bash
python run_self_test.py
python validate_engine.py
python history_benchmark.py
python observatory_benchmark.py
python build_observatory.py --n 300 --seed 42
```
