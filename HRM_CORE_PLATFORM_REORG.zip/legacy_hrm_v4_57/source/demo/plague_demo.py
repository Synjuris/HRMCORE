import time
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt

GRID_SIZE = 20

def init_state():
    st.session_state.tick = 0
    st.session_state.stress = np.random.uniform(0.1, 0.3, size=(GRID_SIZE, GRID_SIZE))
    st.session_state.trust = np.random.uniform(0.5, 0.9, size=(GRID_SIZE, GRID_SIZE))
    st.session_state.panic = np.zeros((GRID_SIZE, GRID_SIZE), dtype=float)
    # Seed an "incident" in the center, Plague Inc style
    cx = cy = GRID_SIZE // 2
    st.session_state.stress[cx, cy] = 0.95
    st.session_state.panic[cx, cy] = 0.9
    st.session_state.trust[cx, cy] = 0.2
    st.session_state.running = False
    st.session_state.speed = 1.0
    st.session_state.history = []

def contagion_step():
    stress = st.session_state.stress
    trust = st.session_state.trust
    panic = st.session_state.panic

    new_stress = stress.copy()
    new_trust = trust.copy()
    new_panic = panic.copy()

    kernel = np.array([[0.05, 0.1, 0.05],
                       [0.1 , 0.0, 0.1 ],
                       [0.05, 0.1, 0.05]])

    from scipy.signal import convolve2d

    stress_neighbor = convolve2d(stress, kernel, mode="same", boundary="symm")
    panic_neighbor = convolve2d(panic, kernel, mode="same", boundary="symm")

    base_stress = 0.02 + 0.4 * panic_neighbor
    trust_erosion = 0.01 + 0.3 * panic_neighbor
    panic_growth = 0.05 + 0.6 * stress_neighbor

    new_stress = np.clip(stress + base_stress - 0.1 * trust, 0.0, 1.0)
    new_trust = np.clip(trust - trust_erosion + 0.02, 0.0, 1.0)
    new_panic = np.clip(panic + panic_growth - 0.15 * trust, 0.0, 1.0)

    st.session_state.stress = new_stress
    st.session_state.trust = new_trust
    st.session_state.panic = new_panic
    st.session_state.tick += 1

    avg_stress = float(new_stress.mean())
    avg_trust = float(new_trust.mean())
    avg_panic = float(new_panic.mean())
    st.session_state.history.append(
        {"tick": st.session_state.tick,
         "stress": avg_stress,
         "trust": avg_trust,
         "panic": avg_panic}
    )

def plot_heatmap(data, title):
    fig, ax = plt.subplots()
    im = ax.imshow(data, vmin=0, vcap=1)
    ax.set_title(title)
    ax.set_xticks([])
    ax.set_yticks([])
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    st.pyplot(fig)
    plt.close(fig)

def main():
    st.set_page_config(page_title="HRM Plague-Style Demo", layout="wide")

    if "stress" not in st.session_state:
        init_state()

    st.title("Hugh Mann Resonance — Crisis Spread Demo (Plague Inc style)")

    col1, col2, col3, col4 = st.columns(4)
    avg_stress = float(st.session_state.stress.mean())
    avg_trust = float(st.session_state.trust.mean())
    avg_panic = float(st.session_state.panic.mean())

    col1.metric("Tick", st.session_state.tick)
    col2.metric("Avg Stress", f"{avg_stress:.3f}")
    col3.metric("Avg Trust", f"{avg_trust:.3f}")
    col4.metric("Avg Panic", f"{avg_panic:.3f}")

    with st.sidebar:
        st.header("Controls")
        if st.button("Reset Simulation"):
            init_state()
            st.experimental_rerun()

        run_label = "Pause" if st.session_state.running else "Start"
        if st.button(run_label):
            st.session_state.running = not st.session_state.running

        st.session_state.speed = st.slider(
            "Speed (steps per second)", min_value=0.2, max_value=3.0, value=1.0, step=0.2
        )

        if st.button("Step Once"):
            contagion_step()

        st.markdown("---")
        st.caption("This is a simplified HRM crisis-spread toy model — not the full engine.")

    left, right = st.columns([2, 1])

    with left:
        st.subheader("City Grid — Panic Heatmap")
        plot_heatmap(st.session_state.panic, "Panic Level")

    with right:
        st.subheader("Macro Trend")
        if st.session_state.history:
            df = pd.DataFrame(st.session_state.history)
            st.line_chart(df.set_index("tick")[["stress", "trust", "panic"]])
        else:
            st.info("Press 'Start' or 'Step Once' to begin the simulation.")

    if st.session_state.running:
        time.sleep(1.0 / st.session_state.speed)
        contagion_step()
        st.experimental_rerun()

if __name__ == "__main__":
    main()