#!/usr/bin/env python3
"""
demo/mushroom_demo.py — psychoactive mushroom patch, end-to-end against the
real HRM engine classes (AgentState + the MushroomPatch add-on).

Run:
    python demo/mushroom_demo.py
    python demo/mushroom_demo.py --agents 40 --ticks 80 --drop 6 6

It builds a small population of real AgentState-backed agents on a grid, lets
them wander, drops ONE mushroom patch (the "shock"), and prints how affect/
behaviour state shifts for agents that pass through it — then decays after they
leave. No torch, no external data; this is a self-contained integration proof.
"""
from __future__ import annotations
import argparse
import random
import sys
from pathlib import Path

# allow running from repo root or demo/
ROOT = Path(__file__).resolve().parent.parent
for p in (ROOT, ROOT / "das"):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))

from schemas import AgentState           # real engine state
from mushrooms import MushroomPatch       # the add-on


class Position:
    __slots__ = ("x", "y")
    def __init__(self, x, y): self.x, self.y = x, y


class Agent:
    """Minimal agent wrapper holding the real AgentState and a grid position."""
    def __init__(self, idx, x, y):
        self.id = f"agent_{idx}"
        self.position = Position(x, y)
        self.state = AgentState()


def main() -> int:
    ap = argparse.ArgumentParser(description="HRM psychoactive mushroom patch demo.")
    ap.add_argument("--agents", type=int, default=24)
    ap.add_argument("--ticks", type=int, default=60)
    ap.add_argument("--grid", type=int, default=14)
    ap.add_argument("--drop", type=float, nargs=2, metavar=("X", "Y"), default=[7, 7])
    ap.add_argument("--drop-at", type=int, default=5, help="Tick at which the patch is dropped.")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    rng = random.Random(args.seed)
    agents = [Agent(i, rng.uniform(0, args.grid), rng.uniform(0, args.grid))
              for i in range(args.agents)]
    patch = MushroomPatch(seed=args.seed)

    print(f"HRM · Psychoactive Mushroom Patch demo")
    print(f"{args.agents} agents on a {args.grid}x{args.grid} grid, {args.ticks} ticks.\n")

    def avg(field):
        return sum(getattr(a.state, field) for a in agents) / len(agents)

    base = {f: avg(f) for f in ("curiosity", "social_openness", "dominance", "stability")}

    for t in range(args.ticks):
        # simple random wander
        for a in agents:
            a.position.x = min(args.grid, max(0, a.position.x + rng.uniform(-0.8, 0.8)))
            a.position.y = min(args.grid, max(0, a.position.y + rng.uniform(-0.8, 0.8)))

        if t == args.drop_at:
            patch.drop(args.drop[0], args.drop[1])
            print(f"tick {t:>3}: *** mushrooms dropped at ({args.drop[0]}, {args.drop[1]}) ***")

        events = patch.tick(agents, t)
        if events:
            for e in events:
                print(f"tick {t:>3}: {e.actor_id} began tripping (dose {e.context['dose']})")
        if t % 10 == 0 or events:
            print(f"tick {t:>3}: tripping={patch.tripping_count():>2}  "
                  f"mean curiosity={avg('curiosity'):.3f}  "
                  f"mean openness={avg('social_openness'):.3f}  "
                  f"patch stock={patch.stock:.2f}")

    print("\n— population averages (start → end) —")
    for f in ("curiosity", "social_openness", "dominance", "stability"):
        print(f"  {f:<16} {base[f]:.3f} → {avg(f):.3f}")
    print(f"\nfinal patch: {patch.snapshot()}")
    print("done.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
