#!/usr/bin/env python3
"""Run HRM_UNIFIED v1.6 emergent civic dynamics."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

try:
    from .population.civic_dynamics import run_civic_sequence, default_civic_sequence
    from .export_utils import ensure_dir, safe_slug
except ImportError:
    from population.civic_dynamics import run_civic_sequence, default_civic_sequence
    from export_utils import ensure_dir, safe_slug


def load_sequence(path: str | None):
    if not path:
        return default_civic_sequence()
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if isinstance(data, dict):
        data = data.get("sequence", [])
    if not isinstance(data, list):
        raise ValueError("Scenario file must be a JSON list or an object with a 'sequence' list.")
    return data


def write_civic_outputs(result, output_dir: str, prefix: str = "civic_dynamics"):
    out = ensure_dir(output_dir)
    summary_json = out / f"{prefix}_summary.json"
    summary_md = out / f"{prefix}_summary.md"
    events_csv = out / f"{prefix}_events.csv"
    trace_jsonl = out / f"{prefix}_state_trace.jsonl"

    summary_json.write_text(result.to_json(), encoding="utf-8")

    lines = [
        "# HRM_UNIFIED v1.6 Civic Dynamics Report",
        "",
        f"**Profile:** {result.profile_name}",
        f"**Population:** {result.population_size}",
        "",
        "## Final Civic Pressures",
        "",
        "| Pressure | Value |",
        "|---|---:|",
    ]
    for k, v in result.final_state.summary().items():
        lines.append(f"| {k} | {v:+.4f} |")
    lines += ["", "## Emergent Events", "", "| Tick | Kind | Scope | Severity | Message |", "|---:|---|---|---:|---|"]
    if result.events:
        for e in result.events:
            lines.append(f"| {e.tick} | {e.kind} | {e.scope} | {e.severity:.4f} | {e.message} |")
    else:
        lines.append("| — | none | — | 0.0000 | No thresholds crossed. |")
    lines += ["", "## Scenario Steps", "", "| Tick | Stimulus | Stress Δ | Valence Δ | Belief Δ |", "|---:|---|---:|---:|---:|"]
    for step in result.steps:
        d = step.get("delta", {})
        lines.append(f"| {step.get('tick')} | {step.get('stimulus')} | {float(d.get('stress',0)):+.4f} | {float(d.get('valence',0)):+.4f} | {float(d.get('belief',0)):+.4f} |")
    summary_md.write_text("\n".join(lines), encoding="utf-8")

    with events_csv.open("w", encoding="utf-8") as f:
        f.write("tick,kind,scope,severity,message\n")
        for e in result.events:
            msg = e.message.replace('"', '""')
            f.write(f'{e.tick},{e.kind},{e.scope},{e.severity},"{msg}"\n')

    with trace_jsonl.open("w", encoding="utf-8") as f:
        for rec in result.state_trace:
            f.write(json.dumps(rec) + "\n")

    return {
        "summary_json": str(summary_json),
        "summary_md": str(summary_md),
        "events_csv": str(events_csv),
        "state_trace_jsonl": str(trace_jsonl),
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Run emergent civic dynamics from a sequence of generic stimuli.")
    ap.add_argument("--scenario", help="Optional JSON scenario sequence file.")
    ap.add_argument("--n", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--profile", default="generic_mixed_region")
    ap.add_argument("--decay", type=float, default=0.86)
    ap.add_argument("--output-dir", default="outputs/civic_v1_6")
    args = ap.parse_args()

    sequence = load_sequence(args.scenario)
    result = run_civic_sequence(sequence=sequence, n=args.n, seed=args.seed, profile=args.profile, decay=args.decay)
    print(result.summary())
    paths = write_civic_outputs(result, args.output_dir, prefix=safe_slug("civic_dynamics_" + args.profile))
    print("\nWrote:")
    for k, v in paths.items():
        print(f"  {k}: {v}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
