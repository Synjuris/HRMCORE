#!/usr/bin/env python3
"""Convenience benchmark entry point for HRM_UNIFIED v2.5."""
from run_institutional_evolution import main

if __name__ == "__main__":
    raise SystemExit(main())
