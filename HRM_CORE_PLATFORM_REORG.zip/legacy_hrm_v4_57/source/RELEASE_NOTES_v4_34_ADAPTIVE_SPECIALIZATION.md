# HRM Unified v4.34 — Adaptive Specialization / Anti-Hardcoding Repair

This is a complete package build based on v4.33. No v4.33 base files were intentionally omitted.

## Core change

v4.34 replaces fixed historical role assumptions with an adaptive capability-family ontology.

Roles are now treated as functional domains that shift with society needs and capability maturity:

- generalist
- subsistence
- protection
- coordination
- diplomacy
- craft
- care
- knowledge
- logistics
- governance
- information

Display labels are generated from emergent context rather than fixed era templates. For example, a subsistence specialist may appear as a forager in a low-complexity context and as an agricultural/resource-system worker only after storage, infrastructure, language, and innovation capacity justify it.

## Files changed or added

- Added `das/adaptive_roles.py`
- Replaced `das/specialization.py` with adaptive capability logic
- Updated `das/agent.py` initial role seeding
- Updated `das/schemas.py` role comment/schema intent
- Updated `das/governance.py` to use role families
- Updated `das/information.py` to use role families
- Updated `das/innovation.py` to use capability-family aptitude
- Updated `das/persistence.py` to avoid gatherer-only assumptions
- Updated `das/subsistence.py` to use subsistence/protection role families
- Updated `das/continuity.py` to classify historical memory by role family
- Updated `das/run_sim.py` output defaults to v04.34

## Validation performed

- Python compile check across the full package
- DAS smoke run with v04.34 output root
- Zip integrity check
- Omission check against v4.33 base file list
