@echo off
setlocal ENABLEDELAYEDEXPANSION
cd /d "%~dp0"
set PYTHON_CMD=
where py >nul 2>nul
if %ERRORLEVEL%==0 set PYTHON_CMD=py -3
if "%PYTHON_CMD%"=="" (
  where python >nul 2>nul
  if !ERRORLEVEL!==0 set PYTHON_CMD=python
)
if "%PYTHON_CMD%"=="" (
  where python3 >nul 2>nul
  if !ERRORLEVEL!==0 set PYTHON_CMD=python3
)
if "%PYTHON_CMD%"=="" (
  echo ERROR: Python was not found.
  pause
  exit /b 1
)
%PYTHON_CMD% run_persistent_continuous_world.py --report-only --world-id default_world --output-dir outputs/persistent_world_v2_7
pause
