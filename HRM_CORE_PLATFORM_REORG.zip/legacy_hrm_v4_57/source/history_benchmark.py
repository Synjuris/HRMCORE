#!/usr/bin/env python3
"""Deterministic benchmark for HRM_UNIFIED v1.8 history replay."""
from __future__ import annotations

try:
    from .population.history import HistoricalSimulator, default_timeline
except ImportError:
    from population.history import HistoricalSimulator, default_timeline


def main() -> int:
    sim = HistoricalSimulator(n=500, seed=184, profile="generic_mixed_region", decay=0.86)
    result = sim.run(default_timeline(), name="v1_8_history_benchmark")
    assert len(result.steps) >= 6, "history benchmark should include multiple steps"
    assert len(result.snapshots) >= 2, "history benchmark should create snapshots"
    fp = result.fingerprint()
    print("HRM_UNIFIED v1.8 history benchmark: PASS")
    print(f"fingerprint={fp}")
    print(f"events={len(result.events)} snapshots={len(result.snapshots)} steps={len(result.steps)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
