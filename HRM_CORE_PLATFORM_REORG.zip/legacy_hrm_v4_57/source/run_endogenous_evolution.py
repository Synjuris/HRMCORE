#!/usr/bin/env python3
"""Run the v2.2 environment with HRM/DAS bridge and endogenous feedback enabled."""
from __future__ import annotations

import argparse
from pathlib import Path

try:
    from .environment import SyntheticCivicEnvironment, EnvironmentConfig
    from .population.history import load_timeline
except ImportError:
    from environment import SyntheticCivicEnvironment, EnvironmentConfig
    from population.history import load_timeline


def main() -> int:
    ap = argparse.ArgumentParser(description="Run synthetic civic environment with DAS endogenous feedback enabled.")
    ap.add_argument("timeline", nargs="?", help="Optional timeline JSON/YAML. Defaults to built-in generic timeline.")
    ap.add_argument("--n", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--profile", default="generic_mixed_region")
    ap.add_argument("--decay", type=float, default=0.86)
    ap.add_argument("--bridge-inertia", type=float, default=0.82)
    ap.add_argument("--feedback-strength", type=float, default=0.35)
    ap.add_argument("--output-dir", default="outputs/endogenous_evolution")
    ap.add_argument("--name", default=None)
    args = ap.parse_args()

    cfg = EnvironmentConfig(
        population_size=args.n,
        seed=args.seed,
        profile=args.profile,
        decay=args.decay,
        das_bridge_enabled=True,
        das_feedback_enabled=True,
        das_bridge_inertia=args.bridge_inertia,
        das_feedback_strength=args.feedback_strength,
    )
    env = SyntheticCivicEnvironment(config=cfg)
    timeline = load_timeline(args.timeline)
    name = args.name or str(timeline.get("name") or (Path(args.timeline).stem if args.timeline else "endogenous_evolution_run"))
    paths = env.run_timeline(timeline, output_dir=args.output_dir, name=name, build_observatory=True)
    print("HRM_UNIFIED v2.2 ENDOGENOUS EVOLUTION")
    print(f"Environment fingerprint: {env.environment_fingerprint()[:16]}")
    if env.das_feedback is not None:
        print(f"Endogenous fingerprint: {env.das_feedback.state.fingerprint()[:16]}")
        print(f"Endogenous events: {len(env.das_feedback.events)}")
    print("Wrote:")
    for k, v in paths.items():
        print(f"  {k}: {v}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
