# HRM_UNIFIED v4.41 — Validation Harness + Runtime Configurability

This build does not add new civilization mechanics. It adds engineering control over the mechanics that already exist.

## Added

- `validate_build.py` validation harness
- CLI runtime configuration for `das/run_sim.py`
- configurable run count, tick count, population, scenario, output root, benchmark file, retention mode, and checkpoint interval
- Windows launchers for validation and configurable simulation
- benchmark schema validation
- summary invariant checks
- system liveness checks for interactions, information, settlements, institutions, governance, storage, and negotiation
- validation output files:
  - `VALIDATION_REPORT_v4_41.json`
  - `validation_smoke_stdout.txt`
  - `validation_smoke_stderr.txt`
  - `benchmark_validation_smoke.json`
  - `validation_runs_smoke/`

## Example commands

```bash
py -3 validate_build.py --profile smoke --runs 2 --ticks 80 --population 10
py -3 das/run_sim.py --runs 10 --ticks 500 --population 10 --output-root runs_v04_41 --benchmark-file benchmark_v04_41.json
py -3 das/run_sim.py --runs 3 --ticks 1000 --population 20 --output-root long_history_test --benchmark-file benchmark_long_history.json
```

## Purpose

Future builds can now be tested with targeted, reproducible validation instead of relying only on one large monolithic simulation run.
