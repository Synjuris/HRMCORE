# HRM_UNIFIED v4.43 — Role Diversity + Chronicle

Two bugs identified in the v4.41 assessment, deferred from v4.42.

## Bugs Fixed

### 1. Role collapse to diplomacy (adaptive_roles.py, specialization.py)
All agents drifted to "diplomacy" within ~50 ticks in peaceful runs. Root cause:
diplomacy formula used `cooperation * 0.32 + social_openness * 0.24` — both
near 0.5 in cooperative sims — giving a floor of ~0.56 before bonuses. The
cooperation outcome bonus added 0.12 on every cooperation event (98% of
interactions). Knowledge/care/information scores topped out at 0.35-0.45.
The drift threshold (0.16 gap) was crossed constantly.

Three-part fix:
- Diplomacy weights reduced: cooperation 0.32→0.20, social_openness 0.24→0.18,
  cooperation outcome bonus 0.12→0.04
- Knowledge boosted: language_aptitude weight 0.18→0.26, added 0.04 base floor
- Care boosted: attachment_rate (stable trait) now weighted at 2.5x
- Information base floor added (0.03)
- Continuity bonus scaled with depth: 0.06 flat → 0.10 + depth*0.18, so
  established roles actively resist washout
- Drift threshold in specialization.py scales with depth: 0.16 + depth*0.30

**Result:** Survivors now include care, subsistence, protection across runs.
Knowledge/information roles survive when seeded. No single role dominates.

### 2. Civilization chronicle was four sentences (continuity.py)
The _chronicle() function had access to records, lineage, death memory, and the
full culture timeline but ignored all of it. Wrote population count, generation
list, one lineage fact, death class dict, and a disclaimer.

**Fix:** Chronicle now reads from all available data and writes structured
narrative sections: Population (with lineage), Deaths (causes + memory class),
History (apprenticeship, innovation count and tick range, artifacts, first death,
grief count, oral tradition), Culture (top 3 memes by strength with tone and
carrier count), Social Texture (interaction count and conflict rate).

**Result:** Chronicle is a readable account of what actually happened.

## Side effects
- Innovation attempts increased (more role diversity = more eligible
  recombination pairs), success rate now ~50-88% depending on run conditions
- Recovery events increased (more care-role agents = more targeted repair)
- Deception detection increased in run 2 (information-role agents carry
  higher information fidelity, flagging deception more accurately)
