#!/usr/bin/env python3
"""Compare one stimulus across multiple abstract population profiles."""
from __future__ import annotations

import argparse
import csv
from pathlib import Path

try:
    from .population.calibrated_panel import CalibratedPanel
except ImportError:
    from population.calibrated_panel import CalibratedPanel


def main() -> int:
    ap = argparse.ArgumentParser(description="Compare calibrated response across profiles.")
    ap.add_argument("stimulus", nargs="+", help="Stimulus text.")
    ap.add_argument("--profiles", nargs="+", default=["generic_mixed_region", "industrial_transition_region", "high_mobility_growth_region"])
    ap.add_argument("--n", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--ticks", type=int, default=45)
    ap.add_argument("--output", default="outputs/profile_comparison.csv")
    args = ap.parse_args()

    text = " ".join(args.stimulus)
    rows = []
    for profile in args.profiles:
        panel = CalibratedPanel(n=args.n, seed=args.seed, profile=profile)
        result = panel.inject(text, run_ticks=args.ticks)
        row = {"profile": result.profile_name, "source_channel": result.source_channel, **result.delta}
        rows.append(row)
        print(f"\n=== {result.profile_name} ===")
        print(result.summary())

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted(set().union(*(r.keys() for r in rows)))
    with out.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    print(f"\nWrote comparison: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
