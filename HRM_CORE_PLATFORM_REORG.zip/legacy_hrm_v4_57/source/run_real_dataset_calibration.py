#!/usr/bin/env python3
"""Run HRM_UNIFIED v3.3 real dataset ingestion + calibration."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

try:
    from .real_dataset_calibration import (
        ENGINE_VERSION,
        DatasetSource,
        build_calibration_bundle,
        calibration_report_markdown,
        load_dataset_file,
        write_json,
    )
except ImportError:
    from real_dataset_calibration import (
        ENGINE_VERSION,
        DatasetSource,
        build_calibration_bundle,
        calibration_report_markdown,
        load_dataset_file,
        write_json,
    )


def try_fetch_acs(state: str, county: str | None, place: str | None, api_key: str | None, no_cache: bool):
    try:
        try:
            from .real_data_api_connector import get_dataset_api_key
        except ImportError:
            from real_data_api_connector import get_dataset_api_key
        api_key = get_dataset_api_key(api_key, Path(__file__).resolve().parent)
    except Exception:
        pass
    try:
        try:
            from .adapters.census_acs import get_calibration_profile
        except ImportError:
            from adapters.census_acs import get_calibration_profile
        profile = get_calibration_profile(state=state, county=county, place=place, api_key=api_key, use_cache=not no_cache)
        source = DatasetSource(
            name=f"ACS {profile.dataset} {profile.geography_name}",
            source_type="acs_profile",
            path="US Census Bureau API/cache",
            records=1,
            sha256=None,
            notes=["Fetched through optional ACS adapter or cache."],
        )
        return source, [profile.to_dict()]
    except Exception as exc:
        source = DatasetSource(
            name="ACS fetch failed",
            source_type="acs_profile",
            path="US Census Bureau API/cache",
            records=0,
            sha256=None,
            notes=[f"acs_fetch_failed: {exc}"],
        )
        return source, []


def main() -> int:
    ap = argparse.ArgumentParser(description="Ingest real/public/local datasets and write HRM calibration patches.")
    ap.add_argument("--input", action="append", default=[], help="CSV or JSON dataset file. Can be used multiple times.")
    ap.add_argument("--geography", default="generic_baseline", help="Human-readable target geography/baseline label.")
    ap.add_argument("--output-dir", default="outputs/real_dataset_calibration_v3_3")
    ap.add_argument("--use-sample", action="store_true", help="Use bundled sample dataset if no --input is supplied.")
    ap.add_argument("--state", help="Optional Census state FIPS for ACS fetch, e.g. 47.")
    acs_group = ap.add_mutually_exclusive_group()
    acs_group.add_argument("--county", help="Optional Census county FIPS for ACS fetch, e.g. 113.")
    acs_group.add_argument("--place", help="Optional Census place FIPS for ACS fetch.")
    ap.add_argument("--api-key", default=None, help="Optional Census API key override. Prefer DATASET_API_KEY/CENSUS_API_KEY or .env/.env.user.")
    ap.add_argument("--api-health", action="store_true", help="Write a connector health report before calibration.")
    ap.add_argument("--no-cache", action="store_true", help="Force ACS live fetch instead of cache.")
    ap.add_argument("--fail-on-weak", action="store_true", help="Exit nonzero if calibration score is too weak.")
    args = ap.parse_args()

    here = Path(__file__).resolve().parent
    input_paths = [Path(p) for p in args.input]
    if args.use_sample and not input_paths:
        input_paths = [here / "datasets" / "sample_real_dataset.csv"]

    sources = []
    records = []
    for idx, path in enumerate(input_paths, 1):
        src, recs = load_dataset_file(path, name=f"input_{idx}:{path.name}")
        sources.append(src)
        records.extend(recs)

    if args.api_health:
        try:
            try:
                from .real_data_api_connector import census_health_check, write_health_report
            except ImportError:
                from real_data_api_connector import census_health_check, write_health_report
            health = census_health_check(args.api_key)
            Path(args.output_dir).mkdir(parents=True, exist_ok=True)
            write_health_report(Path(args.output_dir) / "api_health_report.json", health)
            print(f"API health: {health.status}; key={health.key_preview}")
        except Exception as exc:
            print(f"API health check failed safely: {exc}")

    if args.state and (args.county or args.place):
        src, recs = try_fetch_acs(args.state, args.county, args.place, args.api_key, args.no_cache)
        sources.append(src)
        records.extend(recs)

    if not sources:
        sample_path = here / "datasets" / "sample_real_dataset.csv"
        src, recs = load_dataset_file(sample_path, name="bundled_sample_no_inputs_given")
        src.notes.append("No --input supplied; used bundled sample to prove the pipeline works.")
        sources.append(src)
        records.extend(recs)

    bundle = build_calibration_bundle(records, sources, args.geography)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    bundle_path = out_dir / "real_dataset_calibration_bundle.json"
    report_path = out_dir / "real_dataset_calibration_report.md"
    write_json(bundle_path, bundle.to_dict())
    report_path.write_text(calibration_report_markdown(bundle), encoding="utf-8")

    # Write individual patch files for downstream layers.
    write_json(out_dir / "hrm_config_patch.json", bundle.hrm_config_patch)
    write_json(out_dir / "disease_patch.json", bundle.disease_patch)
    write_json(out_dir / "era_patch.json", bundle.era_patch)
    write_json(out_dir / "scale_patch.json", bundle.scale_patch)

    print("HRM_UNIFIED v3.3.1 REAL DATA API CONNECTOR + CALIBRATION")
    print(f"Geography: {bundle.geography_label}")
    print(f"Calibration score: {bundle.validation['calibration_score_0_100']} / 100")
    print(f"Ready for experiment: {bundle.validation['ready_for_experiment']}")
    print(f"Wrote bundle: {bundle_path}")
    print(f"Wrote report: {report_path}")
    if bundle.warnings:
        print("Warnings:")
        for warning in bundle.warnings:
            print(f" - {warning}")
    if args.fail_on_weak and not bundle.validation["ready_for_experiment"]:
        return 3
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
