from __future__ import annotations

import argparse
import json
from pathlib import Path

try:
    from .adapters.census_acs import get_calibration_profile
    from .export_utils import write_panel_result, safe_slug
    from .population.calibrated_panel import CalibratedPanel
    from .population.calibration import derive_profile_from_real_snapshot
except ImportError:
    from adapters.census_acs import get_calibration_profile
    from export_utils import write_panel_result, safe_slug
    from population.calibrated_panel import CalibratedPanel
    from population.calibration import derive_profile_from_real_snapshot


def main() -> None:
    parser = argparse.ArgumentParser(description="Run v1.3 calibrated HRM panel using real ACS-derived aggregate profile.")
    parser.add_argument("stimulus", help="Stimulus text to inject.")
    parser.add_argument("--state", required=True, help="Two-digit Census state FIPS.")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--county", help="Three-digit Census county FIPS.")
    group.add_argument("--place", help="Five-digit Census place FIPS.")
    parser.add_argument("--n", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--warmup", type=int, default=20)
    parser.add_argument("--ticks", type=int, default=45)
    parser.add_argument("--output-dir", default="outputs")
    parser.add_argument("--no-raw", action="store_true")
    parser.add_argument("--no-cache", action="store_true")
    parser.add_argument("--api-key", default=None, help="Optional override. Prefer .env.user or CENSUS_API_KEY.")
    args = parser.parse_args()

    source_profile = get_calibration_profile(
        state=args.state,
        county=args.county,
        place=args.place,
        api_key=args.api_key,
        use_cache=not args.no_cache,
    )
    aggregate_snapshot = {"facts": {**source_profile.raw_metrics, **source_profile.normalized}}
    calibrated_profile = derive_profile_from_real_snapshot(aggregate_snapshot)
    calibrated_profile["name"] = f"external_aggregate_{source_profile.geography_type}"
    calibrated_profile["source_metadata"] = {
        "source": source_profile.source,
        "dataset": source_profile.dataset,
        "geography_type": source_profile.geography_type,
        "geography_name": source_profile.geography_name,
        "note": "Used as aggregate calibration input only; no locality is hardcoded into the engine.",
    }

    panel = CalibratedPanel(n=args.n, seed=args.seed, warmup_ticks=args.warmup, profile=calibrated_profile)
    result = panel.inject(args.stimulus, run_ticks=args.ticks)

    print(f"REAL AGGREGATE PROFILE: {source_profile.geography_name}")
    print(json.dumps(calibrated_profile, indent=2, sort_keys=True))
    print()
    print(result.summary())

    prefix = safe_slug(f"real_calibrated_{source_profile.geography_type}_{source_profile.state}_{source_profile.county or source_profile.place}_{args.stimulus}")
    paths = write_panel_result(result, args.output_dir, prefix=prefix, include_raw=not args.no_raw)
    profile_path = Path(args.output_dir) / f"{prefix}_calibration_profile.json"
    profile_path.write_text(json.dumps({"source": source_profile.to_dict(), "calibrated_profile": calibrated_profile}, indent=2, sort_keys=True), encoding="utf-8")
    paths["calibration_profile"] = str(profile_path)
    print("\nOutputs:")
    for label, path in paths.items():
        print(f"  {label}: {path}")


if __name__ == "__main__":
    main()
