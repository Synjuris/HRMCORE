# HRM v4.57 — Simfeld ARW Integrated Package

This package contains the full HRM v4.57 folder with `agentic_real_world` replaced by the cleaned Simfeld apartment-life build.

## What changed

- Original ARW sealed-house cast was removed.
- Old ARW run data was removed.
- Default ARW mode is now Simfeld: NYC apartment life.
- Cast uses hidden Seinfeld-style personality trait bundles, not named/emulated TV characters.
- Outputs write to:

```text
agentic_real_world\seasons\season_01_simfeld\
```

## Run

From inside the `hrm_v4_57` folder, double-click:

```bat
RUN_SIMFELD_WINDOWS_SAFE.bat
```

To reset season output first, double-click:

```bat
RUN_SIMFELD_RESET_WINDOWS_SAFE.bat
```

Or run manually:

```bat
py agentic_real_world\run_episode.py
```

## API key

The runner checks these locations:

```text
.env.user
.env
anthropic_key.txt
ANTHROPIC_API_KEY.txt
agentic_real_world\.env.user
agentic_real_world\.env
agentic_real_world\anthropic_key.txt
agentic_real_world\ANTHROPIC_API_KEY.txt
```

Format:

```text
ANTHROPIC_API_KEY=sk-ant-...
```

or just:

```text
sk-ant-...
```
