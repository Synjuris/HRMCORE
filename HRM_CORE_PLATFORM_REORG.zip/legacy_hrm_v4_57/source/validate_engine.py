#!/usr/bin/env python3
"""HRM_UNIFIED validation harness.

Runs fixed generic scenarios and produces deterministic coherence reports.
This harness validates directional behavior; it does not claim real-world prediction.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
from typing import Any, Dict, List, Tuple

try:
    from population.calibrated_panel import CalibratedPanel
except ImportError:
    from .population.calibrated_panel import CalibratedPanel


METRICS = ["valence", "arousal", "dominance", "belief", "stress", "resources"]


def _root() -> Path:
    return Path(__file__).resolve().parent


def load_scenarios(path: str | None = None) -> Dict[str, Any]:
    p = Path(path) if path else _root() / "validation" / "validation_scenarios.json"
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)


def sign_ok(value: float, expected: str, tolerance: float) -> bool:
    if expected == "positive":
        return value > tolerance
    if expected == "negative":
        return value < -tolerance
    if expected == "near_zero":
        return abs(value) <= tolerance
    raise ValueError(f"Unsupported expectation: {expected}")


def directional_checks(delta: Dict[str, float], expect: Dict[str, Any], tolerance: float) -> Tuple[bool, List[Dict[str, Any]]]:
    checks: List[Dict[str, Any]] = []
    ok_all = True

    mag = expect.get("magnitude_max")
    if mag is not None:
        max_abs = max(abs(float(delta.get(k, 0.0))) for k in METRICS)
        ok = max_abs <= float(mag)
        checks.append({"check": "magnitude_max", "expected": mag, "actual": round(max_abs, 4), "passed": ok})
        ok_all = ok_all and ok

    for metric, expected in expect.items():
        if metric == "magnitude_max":
            continue
        actual = float(delta.get(metric, 0.0))
        ok = sign_ok(actual, str(expected), tolerance)
        checks.append({"check": f"{metric}_{expected}", "metric": metric, "expected": expected, "actual": round(actual, 4), "passed": ok})
        ok_all = ok_all and ok

    return ok_all, checks


def run_scenario(s: Dict[str, Any], profile: str, n: int, seed: int, ticks: int, tolerance: float) -> Dict[str, Any]:
    panel = CalibratedPanel(n=n, seed=seed, profile=profile)
    result = panel.inject(s["text"], run_ticks=ticks)
    passed, checks = directional_checks(result.delta, s.get("expect", {}), tolerance)
    return {
        "id": s["id"],
        "text": s["text"],
        "passed": passed,
        "delta": result.delta,
        "source_channel": result.source_channel,
        "topology_summary": result.topology_summary,
        "checks": checks,
    }


def shock_accumulation_check(profile: str, n: int, seed: int, tolerance: float) -> Dict[str, Any]:
    one = CalibratedPanel(n=n, seed=seed, profile=profile).inject(
        "A major regional factory closure and layoffs create economic uncertainty and wage loss.",
        run_ticks=25,
        half_life_ticks=10,
    )
    repeated = CalibratedPanel(n=n, seed=seed, profile=profile).inject(
        "A major regional factory closure and layoffs create economic uncertainty, wage loss, closure, layoffs, crisis, shortage, and panic.",
        run_ticks=25,
        half_life_ticks=10,
    )
    eps = max(tolerance, 0.001)
    stress_ok = repeated.delta.get("stress", 0.0) >= one.delta.get("stress", 0.0) - eps
    eps = max(tolerance, 0.001)
    belief_ok = repeated.delta.get("belief", 0.0) <= one.delta.get("belief", 0.0) + eps
    return {
        "id": "shock_accumulation",
        "passed": bool(stress_ok and belief_ok),
        "single_delta": one.delta,
        "repeated_delta": repeated.delta,
        "checks": [
            {"check": "repeated_stress_not_lower", "passed": bool(stress_ok), "single": one.delta.get("stress"), "repeated": repeated.delta.get("stress")},
            {"check": "repeated_belief_not_higher", "passed": bool(belief_ok), "single": one.delta.get("belief"), "repeated": repeated.delta.get("belief")},
        ],
    }


def decay_check(profile: str, n: int, seed: int) -> Dict[str, Any]:
    result = CalibratedPanel(n=n, seed=seed, profile=profile).inject(
        "A severe local crisis creates fear, panic, danger, and service disruption.",
        run_ticks=40,
        half_life_ticks=8,
    )
    trace = result.persistence_trace
    intensities = [x["intensity"] for x in trace]
    monotonic = all(a >= b for a, b in zip(intensities, intensities[1:]))
    lower_end = bool(intensities and intensities[-1] < intensities[0])
    return {
        "id": "decay_reduces_intensity",
        "passed": bool(monotonic and lower_end),
        "first_intensity": intensities[0] if intensities else None,
        "last_intensity": intensities[-1] if intensities else None,
        "trace_length": len(trace),
        "checks": [
            {"check": "monotonic_nonincreasing", "passed": bool(monotonic)},
            {"check": "last_below_first", "passed": bool(lower_end)},
        ],
    }


def fingerprint(payload: Dict[str, Any]) -> str:
    stable = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(stable.encode("utf-8")).hexdigest()


def write_reports(report: Dict[str, Any], output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)

    with (output_dir / "validation_report.json").open("w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    with (output_dir / "validation_results.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["id", "passed", *METRICS])
        writer.writeheader()
        for r in report["scenario_results"]:
            row = {"id": r["id"], "passed": r["passed"]}
            row.update({k: r["delta"].get(k, 0.0) for k in METRICS})
            writer.writerow(row)

    lines = [
        "# HRM_UNIFIED v1.4 Validation Report",
        "",
        f"Overall: **{'PASS' if report['passed'] else 'FAIL'}**",
        f"Fingerprint: `{report['fingerprint']}`",
        "",
        "This validates deterministic directional coherence only. It is not a real-world prediction claim.",
        "",
        "## Scenario Results",
        "",
        "| Scenario | Pass | Valence | Belief | Stress |",
        "|---|---:|---:|---:|---:|",
    ]
    for r in report["scenario_results"]:
        d = r["delta"]
        lines.append(f"| {r['id']} | {'✅' if r['passed'] else '❌'} | {d.get('valence',0):+.4f} | {d.get('belief',0):+.4f} | {d.get('stress',0):+.4f} |")
    lines.extend(["", "## Coherence Checks", ""])
    for c in report["coherence_results"]:
        lines.append(f"- {'✅' if c['passed'] else '❌'} `{c['id']}`")
    lines.append("")
    with (output_dir / "validation_report.md").open("w", encoding="utf-8") as f:
        f.write("\n".join(lines))


def main() -> int:
    parser = argparse.ArgumentParser(description="Run HRM_UNIFIED validation harness.")
    parser.add_argument("--scenarios", default=None, help="Path to validation_scenarios.json.")
    parser.add_argument("--profile", default=None, help="Profile JSON path. Defaults to scenario config profile.")
    parser.add_argument("--n", type=int, default=None, help="Population size.")
    parser.add_argument("--seed", type=int, default=None, help="Deterministic seed.")
    parser.add_argument("--ticks", type=int, default=None, help="Run ticks per scenario.")
    parser.add_argument("--tolerance", type=float, default=0.0001, help="Directional tolerance.")
    parser.add_argument("--output-dir", default="outputs/validation_v1_4", help="Report output directory.")
    args = parser.parse_args()

    spec = load_scenarios(args.scenarios)
    root = _root()

    profile = args.profile or spec.get("profile", "profiles/generic_mixed_region.json")
    profile_path = Path(profile)
    if not profile_path.is_absolute():
        profile_path = root / profile_path

    n = int(args.n or spec.get("population_size", 400))
    seed = int(args.seed or spec.get("seed", 42))
    ticks = int(args.ticks or spec.get("run_ticks", 35))

    scenario_results = [
        run_scenario(s, str(profile_path), n, seed, ticks, args.tolerance)
        for s in spec["scenarios"]
    ]
    coherence_results = [
        shock_accumulation_check(str(profile_path), n, seed, args.tolerance),
        decay_check(str(profile_path), n, seed),
    ]

    pre_fingerprint_payload = {
        "version": "1.4",
        "profile": str(profile_path.name),
        "n": n,
        "seed": seed,
        "ticks": ticks,
        "scenario_results": scenario_results,
        "coherence_results": coherence_results,
    }
    fp = fingerprint(pre_fingerprint_payload)

    passed = all(r["passed"] for r in scenario_results) and all(c["passed"] for c in coherence_results)

    report = {
        "version": "1.4",
        "name": "HRM_UNIFIED Validation Harness",
        "passed": bool(passed),
        "fingerprint": fp,
        "profile": str(profile_path),
        "population_size": n,
        "seed": seed,
        "run_ticks": ticks,
        "scenario_results": scenario_results,
        "coherence_results": coherence_results,
    }

    output_dir = Path(args.output_dir)
    if not output_dir.is_absolute():
        output_dir = root / output_dir
    write_reports(report, output_dir)

    print(f"HRM_UNIFIED v1.4 validation: {'PASS' if passed else 'FAIL'}")
    print(f"Fingerprint: {fp}")
    print(f"Reports written to: {output_dir}")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
