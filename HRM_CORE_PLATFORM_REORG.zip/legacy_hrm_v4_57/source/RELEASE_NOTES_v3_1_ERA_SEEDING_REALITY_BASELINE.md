# HRM_UNIFIED v3.1 — Era Seeding + Reality Baseline

Purpose: let the world start from a chosen historical/current baseline instead of always growing from an unanchored sandbox.

Adds:
- era presets: ancient, medieval, industrial, modern, near_future
- `now` alias for modern/current baseline
- start year override
- location/profile metadata
- baseline-derived timeline seed
- baseline-derived novelty seed
- divergence report comparing observed run behavior against seeded expectations
- Windows-safe launcher that does not depend on `.py` file association

Main launcher:

`RUN_V3_1_ERA_SEEDING_REALITY_BASELINE_WINDOWS_SAFE.bat`

Seed-only launcher:

`RUN_V3_1_ERA_SEEDING_SEED_ONLY_WINDOWS_SAFE.bat`

This is not full real-data calibration. It is the layer that defines *what era/date/reality profile* the later calibration layer should target.
