#!/usr/bin/env python3
"""
validate_build.py — v4.41 validation harness for HRM_UNIFIED.

This is intentionally separate from das/run_sim.py. It runs fast, targeted,
repeatable checks that catch broken summaries, schema drift, dead systems,
and packaging regressions without requiring a full long-history simulation.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import py_compile
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
DAS = ROOT / "das"

REQUIRED_SUMMARY_KEYS = [
    "run_id", "alive", "dead", "births", "interaction_events",
    "conflict_events", "cooperation_events", "negotiation_events",
    "factions", "institutions", "information_total_created",
    "information_avg_fidelity", "logistics_storage_total",
    "logistics_infrastructure_total", "settlement_active",
    "settlement_avg_continuity", "subsistence_herd_wealth",
    "subsistence_domestication_events", "governance_avg_legitimacy",
    "care_events", "pair_bond_events", "final_attractor",
]

REQUIRED_BENCHMARK_KEYS = ["version", "runs", "ticks", "totals", "means", "runs_detail", "avg_time_series"]


def fail(msg: str) -> None:
    raise AssertionError(msg)


def load_json(path: Path) -> Any:
    if not path.exists():
        fail(f"Missing expected JSON file: {path}")
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def numeric_ok(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, bool):
        return True
    if isinstance(value, (int, float)):
        return not (math.isnan(value) or math.isinf(value))
    if isinstance(value, list):
        return all(numeric_ok(v) for v in value)
    if isinstance(value, dict):
        return all(numeric_ok(v) for v in value.values())
    return True


def compile_check() -> list[str]:
    errors: list[str] = []
    for path in sorted(ROOT.rglob("*.py")):
        if "__pycache__" in path.parts:
            continue
        try:
            py_compile.compile(str(path), doraise=True)
        except Exception as exc:
            errors.append(f"{path.relative_to(ROOT)} :: {exc}")
    if errors:
        fail("Compile failures:\n" + "\n".join(errors[:20]))
    return ["compile_check: PASS"]


def run_sim_profile(profile: str, runs: int, ticks: int, population: int, timeout: int) -> tuple[Path, Path, list[str]]:
    out_root = ROOT / f"validation_runs_{profile}"
    bench = ROOT / f"benchmark_validation_{profile}.json"
    shutil.rmtree(out_root, ignore_errors=True)
    if bench.exists():
        bench.unlink()
    cmd = [
        sys.executable, "das/run_sim.py",
        "--runs", str(runs),
        "--ticks", str(ticks),
        "--population", str(population),
        "--output-root", str(out_root),
        "--benchmark-file", str(bench),
    ]
    proc = subprocess.run(cmd, cwd=ROOT, text=True, capture_output=True, timeout=timeout)
    (ROOT / f"validation_{profile}_stdout.txt").write_text(proc.stdout, encoding="utf-8")
    (ROOT / f"validation_{profile}_stderr.txt").write_text(proc.stderr, encoding="utf-8")
    if proc.returncode != 0:
        fail(f"Simulation profile {profile} failed with code {proc.returncode}. See validation_{profile}_stderr.txt")
    return out_root, bench, [f"sim_profile_{profile}: PASS ({runs} x {ticks}, population={population})"]


def validate_outputs(out_root: Path, bench_path: Path, expected_runs: int, expected_ticks: int) -> list[str]:
    benchmark = load_json(bench_path)
    for key in REQUIRED_BENCHMARK_KEYS:
        if key not in benchmark:
            fail(f"Benchmark missing required key: {key}")
    if benchmark.get("runs") != expected_runs:
        fail(f"Benchmark runs mismatch: expected {expected_runs}, got {benchmark.get('runs')}")
    if benchmark.get("ticks") != expected_ticks:
        fail(f"Benchmark ticks mismatch: expected {expected_ticks}, got {benchmark.get('ticks')}")
    if not numeric_ok(benchmark):
        fail("Benchmark contains NaN/Inf numeric values")
    details = benchmark.get("runs_detail", [])
    if len(details) != expected_runs:
        fail(f"Benchmark runs_detail length mismatch: expected {expected_runs}, got {len(details)}")

    alive_system_counts = {
        "interactions": 0,
        "births": 0,
        "negotiation": 0,
        "information": 0,
        "settlements": 0,
        "storage": 0,
        "institutions": 0,
        "governance": 0,
    }

    for run_idx in range(1, expected_runs + 1):
        run_dir = out_root / f"run_{run_idx}"
        summary = load_json(run_dir / "summary.json")
        metrics = load_json(run_dir / "metrics.json")
        if not isinstance(metrics, list) or not metrics:
            fail(f"Run {run_idx} metrics.json is empty or invalid")
        for key in REQUIRED_SUMMARY_KEYS:
            if key not in summary:
                fail(f"Run {run_idx} summary missing key: {key}")
        if not numeric_ok(summary):
            fail(f"Run {run_idx} summary contains NaN/Inf")
        if summary.get("births", 0) < 0 or summary.get("dead", 0) < 0:
            fail(f"Run {run_idx} has negative births/deaths")
        if summary.get("interaction_events", 0) < summary.get("conflict_events", 0):
            fail(f"Run {run_idx} has more conflicts than total interactions")
        if summary.get("survivor_count", len(summary.get("survivors", []))) < 0:
            fail(f"Run {run_idx} has negative survivor count")

        alive_system_counts["interactions"] += int(summary.get("interaction_events", 0) > 0)
        alive_system_counts["births"] += int(summary.get("births", 0) > 0)
        alive_system_counts["negotiation"] += int(summary.get("negotiation_events", 0) > 0)
        alive_system_counts["information"] += int(summary.get("information_total_created", 0) > 0)
        alive_system_counts["settlements"] += int(summary.get("settlement_active", 0) > 0)
        alive_system_counts["storage"] += int(summary.get("logistics_storage_total", 0) >= 0)
        alive_system_counts["institutions"] += int(summary.get("institutions", 0) >= 0)
        alive_system_counts["governance"] += int(summary.get("governance_avg_legitimacy", 0) >= 0)

    # These are liveness checks, not claims about historical realism.
    required_live = ["interactions", "negotiation", "information", "settlements", "storage", "institutions", "governance"]
    for system in required_live:
        if alive_system_counts[system] <= 0:
            fail(f"System liveness check failed: {system}")
    return ["output_schema: PASS", "invariant_checks: PASS", "system_liveness: PASS"]


def write_report(lines: list[str]) -> None:
    report = ROOT / "VALIDATION_REPORT_v4_41.json"
    report.write_text(json.dumps({"version": "v4.41", "checks": lines}, indent=2), encoding="utf-8")
    print("\n".join(lines))
    print(f"WROTE {report.name}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Validate HRM_UNIFIED build without relying on one monolithic long run.")
    parser.add_argument("--profile", choices=["smoke", "demographics", "settlements"], default="smoke")
    parser.add_argument("--runs", type=int, default=2)
    parser.add_argument("--ticks", type=int, default=80)
    parser.add_argument("--population", type=int, default=10)
    parser.add_argument("--timeout", type=int, default=120)
    args = parser.parse_args()

    lines: list[str] = []
    lines.extend(compile_check())
    out_root, bench, sim_lines = run_sim_profile(args.profile, args.runs, args.ticks, args.population, args.timeout)
    lines.extend(sim_lines)
    lines.extend(validate_outputs(out_root, bench, args.runs, args.ticks))
    write_report(lines)


if __name__ == "__main__":
    main()
