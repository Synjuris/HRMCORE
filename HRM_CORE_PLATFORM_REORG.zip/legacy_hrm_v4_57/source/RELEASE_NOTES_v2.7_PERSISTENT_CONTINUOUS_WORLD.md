# HRM_UNIFIED v2.7 — Persistent Continuous World Layer

Purpose: allow worlds to continue across sessions with crash-safe checkpoints, replay logs, and reports that show what evolved while the user was away.

## Added

- `world_persistence.py`
- `run_persistent_continuous_world.py`
- `RUN_V2_7_PERSISTENT_CONTINUOUS_WORLD_WINDOWS_SAFE.bat`
- `RUN_V2_7_REPORT_ONLY_WINDOWS_SAFE.bat`

## Capabilities

- save/load latest world checkpoint
- atomic checkpoint writes
- replay/event log
- evolution timeline cache
- since-last-viewed report
- resume counters from previous checkpoint with `--resume`
- unattended cycle mode with autosave
- crash-safe recovery from latest checkpoint file

## Core loop

```text
load/resume world
→ run generation cycle
→ update memory/institutions/novelty
→ save checkpoint
→ append replay events
→ repeat
→ compare latest checkpoint to last viewed checkpoint
→ generate since-last-viewed report
```

## Windows use

Run:

```text
RUN_V2_7_PERSISTENT_CONTINUOUS_WORLD_WINDOWS_SAFE.bat
```

Then open:

```text
outputs/persistent_world_v2_7/default_world/reports/since_last_viewed_report.md
outputs/persistent_world_v2_7/default_world/world_state_latest.json
outputs/persistent_world_v2_7/default_world/evolution_timeline.json
```

## Notes

This is not a fake background service. It runs while the command window is open. That is deliberate for v2.7 because it keeps execution visible and recoverable. A true tray/service wrapper can be added later once the runtime behavior is stable.
