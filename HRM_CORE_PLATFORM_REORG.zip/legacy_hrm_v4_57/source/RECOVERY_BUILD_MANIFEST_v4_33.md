# Recovery / Full Package Manifest — v4.33

Base package: `HRM_UNIFIED_v4_32_CONTINUITY_ENGINE_PATCHED_FULL.zip`

Build rule used: full-tree copy forward. No source tree pruning was performed.

File count in new package: 395 files.

Primary v4.33 additions:
- `das/subsistence.py`
- `RELEASE_NOTES_v4_33_WORLD_PRESSURE_SUBSISTENCE.md`
- `RUN_V4_33_WORLD_PRESSURE_SUBSISTENCE_WINDOWS_SAFE.bat`
- `FILE_INVENTORY_v4_33.txt`
- `OMISSION_CHECK_v4_33.txt`

Primary v4.33 modified file:
- `das/run_sim.py`

Validation:
- `python3 -m py_compile *.py` from `hrm_unified/das` passed.
- DAS smoke run passed with `DAS_RUNS=1 DAS_TICKS=30` and wrote `benchmark_v04_33.json`.

Omission check against v4.32 patched full base:
```text
base_files=387
new_files=394
missing_from_v4_32=0
added_in_v4_33=7

MISSING:


ADDED:
FILE_INVENTORY_v4_33.txt
RECOVERY_BUILD_MANIFEST_v4_33.md
RELEASE_NOTES_v4_33_WORLD_PRESSURE_SUBSISTENCE.md
RUN_V4_33_WORLD_PRESSURE_SUBSISTENCE_WINDOWS_SAFE.bat
das/__pycache__/subsistence.cpython-313.pyc
das/benchmark_v04_33.json
das/subsistence.py
```
