# HRM_UNIFIED v2.3 — Constitution Layer

This release adds an invariant/audit layer for the synthetic civic environment.

## Added

- `constitution.py`
- `run_constitution_audit.py`
- `constitution_benchmark.py`
- bounded pressure checks
- single-step rate limit checks
- memory decay floor checks
- institutional inertia checks
- causal transition checks
- JSON and Markdown audit reports
- Windows helper launcher: `OPEN_ME_WINDOWS.bat`

## Boundary

The constitution layer validates internal simulation coherence. It does not validate real-world predictive accuracy.

## Run

```bash
py -3 run_constitution_audit.py
```

or on Windows, double-click:

```text
OPEN_ME_WINDOWS.bat
```
