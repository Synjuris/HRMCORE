"""Institutional evolution layer for HRM_UNIFIED v2.5.

This layer sits after v2.4 generational memory. Institutions no longer only
store memory; their structure mutates under accumulated legitimacy, strain,
scar, resilience, and public adaptation pressure.

It is intentionally generic. It does not encode real local facts, personal facts,
or hidden scenario assumptions.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List, Optional
import hashlib
import json
import math
import time

ENGINE_VERSION = "2.5"

CORE_SIGNALS = [
    "stress_pressure",
    "trust_pressure",
    "volatility_pressure",
    "cooperation_pressure",
    "withdrawal_pressure",
]

INSTITUTION_TYPES = [
    "governance",
    "justice",
    "welfare",
    "infrastructure",
    "civic_information",
]


def _stamp() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _canonical(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def fingerprint(obj: Any) -> str:
    return hashlib.sha256(_canonical(obj).encode("utf-8")).hexdigest()


def _clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, float(value)))


def _as_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        if isinstance(value, float) and math.isnan(value):
            return default
        return float(value)
    except Exception:
        return default


def _summary_from_state(state: Any) -> Dict[str, float]:
    if hasattr(state, "summary"):
        return {k: _as_float(v) for k, v in state.summary().items()}
    if hasattr(state, "to_dict"):
        state = state.to_dict()
    if isinstance(state, dict):
        return {k: _as_float(state.get(k, 0.0)) for k in CORE_SIGNALS}
    return {k: 0.0 for k in CORE_SIGNALS}


@dataclass
class InstitutionState:
    institution_id: str
    institution_type: str
    legitimacy: float = 0.0
    capacity: float = 0.35
    enforcement_style: float = 0.0  # -1.0 adaptive/service oriented, +1.0 punitive/control oriented
    reform_pressure: float = 0.0
    collapse_risk: float = 0.0
    doctrine: str = "procedural_stability"
    path_dependency: float = 0.0
    mutation_count: int = 0
    last_mutation: str = "initialized"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class InstitutionalEpochReport:
    generation: int
    label: str
    inherited_memory: Dict[str, Any]
    before_institutions: List[Dict[str, Any]]
    after_institutions: List[Dict[str, Any]]
    mutations: List[Dict[str, Any]]
    civic_baseline_effect: Dict[str, float]
    equilibrium: str
    constitution_passed: Optional[bool] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class InstitutionalRunReport:
    version: str
    name: str
    epochs: List[InstitutionalEpochReport]
    final_institutions: List[Dict[str, Any]]
    institution_benchmark: Dict[str, Any]
    created_at: str = field(default_factory=_stamp)

    def to_dict(self) -> Dict[str, Any]:
        payload = {
            "version": self.version,
            "name": self.name,
            "epochs": [e.to_dict() for e in self.epochs],
            "final_institutions": self.final_institutions,
            "institution_benchmark": self.institution_benchmark,
            "created_at": self.created_at,
        }
        payload["fingerprint"] = fingerprint(payload)
        return payload

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)


class InstitutionalEvolutionEngine:
    """Mutates institutional structure under long-run memory pressure."""

    def __init__(self, mutation_rate: float = 0.38, legitimacy_inertia: float = 0.82, reform_threshold: float = 0.62, collapse_threshold: float = 0.86):
        self.mutation_rate = _clamp(mutation_rate, 0.0, 1.0)
        self.legitimacy_inertia = _clamp(legitimacy_inertia, 0.0, 0.99)
        self.reform_threshold = _clamp(reform_threshold, 0.0, 2.0)
        self.collapse_threshold = _clamp(collapse_threshold, 0.0, 2.0)
        self.institutions = [
            InstitutionState("civic_governance", "governance", capacity=0.42, doctrine="procedural_stability"),
            InstitutionState("dispute_resolution", "justice", capacity=0.36, doctrine="case_by_case_order"),
            InstitutionState("public_support", "welfare", capacity=0.33, doctrine="need_triage"),
            InstitutionState("systems_maintenance", "infrastructure", capacity=0.40, doctrine="continuity_first"),
            InstitutionState("civic_signal", "civic_information", capacity=0.31, doctrine="broadcast_consensus"),
        ]
        self.mutation_log: List[Dict[str, Any]] = []

    def _pressure_from_memory(self, memory_state: Dict[str, Any], civic_summary: Dict[str, float]) -> Dict[str, float]:
        inst_mem = memory_state.get("institutional_memory", {}) or {}
        cult_mem = memory_state.get("cultural_memory", {}) or {}
        scars = memory_state.get("historical_scars", {}) or {}
        resilience = _as_float(memory_state.get("resilience_inheritance", 0.0))
        strain = _as_float(inst_mem.get("strain_memory", 0.0))
        legitimacy_memory = _as_float(inst_mem.get("legitimacy", 0.0))
        reliability = _as_float(inst_mem.get("response_reliability", 0.0))
        withdrawal_norm = _as_float(cult_mem.get("withdrawal_norm", 0.0))
        cooperation_norm = _as_float(cult_mem.get("cooperation_norm", 0.0))
        uncertainty_norm = _as_float(cult_mem.get("uncertainty_norm", 0.0))
        scar_load = max([_as_float(v) for v in scars.values()] or [0.0])
        return {
            "strain": _clamp(strain + civic_summary.get("stress_pressure", 0.0) * 0.45 + civic_summary.get("volatility_pressure", 0.0) * 0.35, 0.0, 3.0),
            "legitimacy_memory": _clamp(legitimacy_memory + reliability * 0.35 + civic_summary.get("trust_pressure", 0.0) * 0.35, -3.0, 3.0),
            "public_withdrawal": _clamp(withdrawal_norm + civic_summary.get("withdrawal_pressure", 0.0) * 0.50, 0.0, 3.0),
            "cooperation_base": _clamp(cooperation_norm + civic_summary.get("cooperation_pressure", 0.0) * 0.50 + resilience * 0.30, -2.0, 3.0),
            "uncertainty": _clamp(uncertainty_norm + civic_summary.get("volatility_pressure", 0.0) * 0.60, 0.0, 3.0),
            "scar_load": _clamp(scar_load, 0.0, 3.0),
            "resilience": _clamp(resilience, -2.0, 2.0),
        }

    def evolve(self, memory_state: Dict[str, Any], civic_summary: Dict[str, float], generation: int, label: str = "epoch") -> InstitutionalEpochReport:
        before = [i.to_dict() for i in self.institutions]
        pressure = self._pressure_from_memory(memory_state, civic_summary)
        mutations: List[Dict[str, Any]] = []

        for inst in self.institutions:
            type_bias = self._type_bias(inst.institution_type)
            legitimacy_delta = (
                0.32 * pressure["legitimacy_memory"]
                + 0.18 * pressure["cooperation_base"]
                - 0.28 * pressure["strain"]
                - 0.22 * pressure["public_withdrawal"]
                - 0.18 * pressure["scar_load"]
                + type_bias.get("legitimacy", 0.0)
            )
            inst.legitimacy = round(_clamp(inst.legitimacy * self.legitimacy_inertia + legitimacy_delta * (1.0 - self.legitimacy_inertia), -1.5, 1.5), 6)

            reform_delta = 0.30 * pressure["strain"] + 0.24 * pressure["public_withdrawal"] + 0.18 * pressure["uncertainty"] - 0.20 * pressure["cooperation_base"] - 0.14 * inst.legitimacy
            inst.reform_pressure = round(_clamp(inst.reform_pressure * 0.72 + reform_delta, 0.0, 2.0), 6)

            collapse_delta = 0.34 * pressure["strain"] + 0.26 * pressure["scar_load"] + 0.18 * pressure["uncertainty"] - 0.30 * inst.capacity - 0.18 * max(0.0, inst.legitimacy) - 0.14 * pressure["resilience"]
            inst.collapse_risk = round(_clamp(inst.collapse_risk * 0.74 + collapse_delta, 0.0, 2.0), 6)

            capacity_delta = 0.08 * pressure["cooperation_base"] + 0.06 * pressure["resilience"] - 0.10 * pressure["strain"] - 0.05 * inst.collapse_risk
            inst.capacity = round(_clamp(inst.capacity + capacity_delta, 0.05, 1.0), 6)

            enforcement_delta = 0.18 * pressure["strain"] + 0.12 * pressure["uncertainty"] - 0.16 * pressure["cooperation_base"] - 0.08 * pressure["resilience"] + type_bias.get("enforcement", 0.0)
            inst.enforcement_style = round(_clamp(inst.enforcement_style * 0.68 + enforcement_delta, -1.0, 1.0), 6)
            inst.path_dependency = round(_clamp(inst.path_dependency * 0.86 + abs(inst.legitimacy) * 0.08 + inst.mutation_count * 0.015, 0.0, 1.5), 6)

            mutation = self._maybe_mutate(inst, pressure, generation, label)
            if mutation:
                mutations.append(mutation)

        baseline_effect = self.compute_civic_baseline_effect()
        equilibrium = self.classify_equilibrium()
        self.mutation_log.extend(mutations)
        return InstitutionalEpochReport(
            generation=generation,
            label=label,
            inherited_memory={
                "fingerprint": memory_state.get("fingerprint", ""),
                "baseline_shift": memory_state.get("baseline_shift", {}),
                "pressure": pressure,
            },
            before_institutions=before,
            after_institutions=[i.to_dict() for i in self.institutions],
            mutations=mutations,
            civic_baseline_effect=baseline_effect,
            equilibrium=equilibrium,
        )

    def _type_bias(self, institution_type: str) -> Dict[str, float]:
        return {
            "governance": {"legitimacy": 0.02, "enforcement": 0.00},
            "justice": {"legitimacy": -0.01, "enforcement": 0.05},
            "welfare": {"legitimacy": 0.01, "enforcement": -0.05},
            "infrastructure": {"legitimacy": 0.03, "enforcement": -0.02},
            "civic_information": {"legitimacy": 0.00, "enforcement": -0.03},
        }.get(institution_type, {"legitimacy": 0.0, "enforcement": 0.0})

    def _maybe_mutate(self, inst: InstitutionState, pressure: Dict[str, float], generation: int, label: str) -> Optional[Dict[str, Any]]:
        trigger = None
        if inst.collapse_risk >= self.collapse_threshold:
            trigger = "collapse_reorganization"
            inst.doctrine = "emergency_containment"
            inst.capacity = round(_clamp(inst.capacity * 0.72, 0.05, 1.0), 6)
            inst.legitimacy = round(_clamp(inst.legitimacy - 0.22, -1.5, 1.5), 6)
            inst.enforcement_style = round(_clamp(inst.enforcement_style + 0.20, -1.0, 1.0), 6)
            inst.collapse_risk = round(_clamp(inst.collapse_risk * 0.62, 0.0, 2.0), 6)
        elif inst.reform_pressure >= self.reform_threshold and self.mutation_rate > 0.0:
            if pressure["cooperation_base"] >= pressure["public_withdrawal"]:
                trigger = "adaptive_reform"
                inst.doctrine = "participatory_resilience"
                inst.capacity = round(_clamp(inst.capacity + 0.12 * self.mutation_rate, 0.05, 1.0), 6)
                inst.enforcement_style = round(_clamp(inst.enforcement_style - 0.18 * self.mutation_rate, -1.0, 1.0), 6)
                inst.legitimacy = round(_clamp(inst.legitimacy + 0.12 * self.mutation_rate, -1.5, 1.5), 6)
            else:
                trigger = "control_reform"
                inst.doctrine = "risk_suppression"
                inst.capacity = round(_clamp(inst.capacity + 0.06 * self.mutation_rate, 0.05, 1.0), 6)
                inst.enforcement_style = round(_clamp(inst.enforcement_style + 0.16 * self.mutation_rate, -1.0, 1.0), 6)
                inst.legitimacy = round(_clamp(inst.legitimacy - 0.06 * self.mutation_rate, -1.5, 1.5), 6)
            inst.reform_pressure = round(_clamp(inst.reform_pressure * 0.42, 0.0, 2.0), 6)
        elif inst.legitimacy >= 0.32 and inst.capacity >= 0.58 and pressure["cooperation_base"] > pressure["public_withdrawal"] and inst.doctrine not in {"participatory_resilience", "civic_learning"}:
            trigger = "doctrine_consolidation"
            inst.doctrine = "civic_learning"
            inst.enforcement_style = round(_clamp(inst.enforcement_style - 0.08 * self.mutation_rate, -1.0, 1.0), 6)
            inst.path_dependency = round(_clamp(inst.path_dependency + 0.10, 0.0, 1.5), 6)

        if not trigger:
            inst.last_mutation = "no_structural_change"
            return None
        inst.mutation_count += 1
        inst.last_mutation = trigger
        mutation = {
            "generation": generation,
            "label": label,
            "institution_id": inst.institution_id,
            "institution_type": inst.institution_type,
            "mutation": trigger,
            "new_doctrine": inst.doctrine,
            "legitimacy": inst.legitimacy,
            "capacity": inst.capacity,
            "enforcement_style": inst.enforcement_style,
            "collapse_risk": inst.collapse_risk,
        }
        return mutation

    def compute_civic_baseline_effect(self) -> Dict[str, float]:
        if not self.institutions:
            return {k: 0.0 for k in CORE_SIGNALS}
        n = float(len(self.institutions))
        legitimacy = sum(i.legitimacy for i in self.institutions) / n
        capacity = sum(i.capacity for i in self.institutions) / n
        enforcement = sum(i.enforcement_style for i in self.institutions) / n
        collapse = sum(i.collapse_risk for i in self.institutions) / n
        reform = sum(i.reform_pressure for i in self.institutions) / n
        return {
            "stress_pressure": round(_clamp(0.18 * collapse + 0.10 * max(0.0, enforcement) - 0.10 * capacity, -0.75, 0.75), 6),
            "trust_pressure": round(_clamp(0.22 * legitimacy + 0.10 * capacity - 0.14 * collapse, -0.75, 0.75), 6),
            "volatility_pressure": round(_clamp(0.16 * collapse + 0.08 * reform - 0.08 * capacity, -0.75, 0.75), 6),
            "cooperation_pressure": round(_clamp(0.16 * capacity + 0.12 * max(0.0, legitimacy) - 0.12 * max(0.0, enforcement), -0.75, 0.75), 6),
            "withdrawal_pressure": round(_clamp(0.14 * collapse + 0.10 * max(0.0, enforcement) - 0.12 * max(0.0, legitimacy), -0.75, 0.75), 6),
        }

    def apply_to_simulator(self, simulator: Any) -> Dict[str, float]:
        effect = self.compute_civic_baseline_effect()
        state = simulator.tracker.state
        for key, delta in effect.items():
            if hasattr(state, key):
                setattr(state, key, round(_clamp(_as_float(getattr(state, key)) + delta, -2.0, 2.0), 6))
        return effect

    def classify_equilibrium(self) -> str:
        if not self.institutions:
            return "no_institutions"
        n = float(len(self.institutions))
        avg_legitimacy = sum(i.legitimacy for i in self.institutions) / n
        avg_collapse = sum(i.collapse_risk for i in self.institutions) / n
        avg_capacity = sum(i.capacity for i in self.institutions) / n
        avg_enforcement = sum(i.enforcement_style for i in self.institutions) / n
        if avg_collapse >= 0.95:
            return "breakdown_pressure"
        if avg_legitimacy >= 0.35 and avg_capacity >= 0.42 and avg_enforcement <= 0.25:
            return "adaptive_civic_equilibrium"
        if avg_enforcement >= 0.45 and avg_legitimacy < 0.15:
            return "coercive_stability"
        if avg_capacity < 0.22 and avg_collapse >= 0.55:
            return "institutional_fragility"
        return "contested_stability"

    def to_dict(self) -> Dict[str, Any]:
        payload = {
            "version": ENGINE_VERSION,
            "institutions": [i.to_dict() for i in self.institutions],
            "mutation_log": list(self.mutation_log),
            "civic_baseline_effect": self.compute_civic_baseline_effect(),
            "equilibrium": self.classify_equilibrium(),
        }
        payload["fingerprint"] = fingerprint(payload)
        return payload


def institutional_markdown(report: InstitutionalRunReport) -> str:
    d = report.to_dict()
    lines = [
        "# HRM_UNIFIED v2.5 Institutional Evolution Report",
        "",
        f"**Run:** {report.name}",
        f"**Version:** {report.version}",
        f"**Fingerprint:** `{d['fingerprint']}`",
        "",
        "## Core Loop",
        "",
        "generational memory -> institutional legitimacy shift -> institutional behavior mutation -> public adaptation -> new civic equilibrium or breakdown",
        "",
        "## Epoch Summary",
        "",
        "| Generation | Label | Mutations | Equilibrium | Trust Effect | Stress Effect | Constitution |",
        "|---:|---|---:|---|---:|---:|---|",
    ]
    for e in report.epochs:
        cp = "n/a" if e.constitution_passed is None else ("PASS" if e.constitution_passed else "FAIL")
        eff = e.civic_baseline_effect
        lines.append(f"| {e.generation} | {e.label} | {len(e.mutations)} | {e.equilibrium} | {eff.get('trust_pressure', 0):+.4f} | {eff.get('stress_pressure', 0):+.4f} | {cp} |")
    lines += ["", "## Final Institutions", "", "| Institution | Type | Legitimacy | Capacity | Enforcement | Reform | Collapse | Doctrine | Mutations |", "|---|---|---:|---:|---:|---:|---:|---|---:|"]
    for i in report.final_institutions:
        lines.append(f"| {i.get('institution_id')} | {i.get('institution_type')} | {float(i.get('legitimacy', 0)):+.4f} | {float(i.get('capacity', 0)):.4f} | {float(i.get('enforcement_style', 0)):+.4f} | {float(i.get('reform_pressure', 0)):.4f} | {float(i.get('collapse_risk', 0)):.4f} | {i.get('doctrine')} | {i.get('mutation_count')} |")
    lines += ["", "## Institution Benchmark", ""]
    for k, v in report.institution_benchmark.items():
        lines.append(f"- **{k}:** {v}")
    lines += ["", "## Mutations", ""]
    any_mutation = False
    for e in report.epochs:
        for m in e.mutations:
            any_mutation = True
            lines.append(f"- Generation {m.get('generation')} — `{m.get('institution_id')}`: **{m.get('mutation')}** -> {m.get('new_doctrine')}")
    if not any_mutation:
        lines.append("- No structural mutations crossed threshold in this run.")
    return "\n".join(lines)
