"""
hrm_unified/inject.py

The primary product interface for HRM.

Usage:
    from inject import SyntheticPanel, Stimulus

    panel = SyntheticPanel(n=1000, seed=42)
    result = panel.inject("Factory closures announced. 2,000 jobs lost.")
    print(result.summary())

This is what you sell: a synthetic research panel you can query with text.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

try:
    from .core.hrm_core_kernel import HRMCore, DEFAULT_CONFIG
    from .stimulus.nlsi import parse_stimulus, apply_stimulus
except ImportError:  # direct script / project-root usage
    from core.hrm_core_kernel import HRMCore, DEFAULT_CONFIG
    from stimulus.nlsi import parse_stimulus, apply_stimulus


@dataclass
class InjectionResult:
    stimulus_text: str
    population_size: int
    ticks_run: int
    baseline: Dict[str, float]
    post_injection: Dict[str, float]
    delta: Dict[str, float]
    control_post: Dict[str, float] = field(default_factory=dict)
    segment_breakdown: Dict[str, Any] = field(default_factory=dict)
    raw_snapshot: List[Dict] = field(default_factory=list)

    def summary(self) -> str:
        lines = [
            f"STIMULUS: {self.stimulus_text[:80]}{'...' if len(self.stimulus_text) > 80 else ''}",
            f"POPULATION: {self.population_size} agents",
            "",
            "POPULATION RESPONSE (delta vs no-stimulus control):",
        ]
        for k, v in self.delta.items():
            arrow = "↑" if v > 0.005 else ("↓" if v < -0.005 else "→")
            lines.append(f"  {arrow} {k:<20} {v:+.4f}")
        return "\n".join(lines)

    def to_json(self) -> str:
        d = asdict(self)
        d.pop("raw_snapshot", None)  # omit raw for clean export
        return json.dumps(d, indent=2)


def _population_averages(snapshot: List[Dict]) -> Dict[str, float]:
    if not snapshot:
        return {}
    keys = ["valence", "arousal", "dominance", "belief", "stress", "resources"]
    totals = {k: 0.0 for k in keys}
    for agent in snapshot:
        state = agent.get("state", {})
        for k in keys:
            totals[k] += state.get(k, 0.0)
    n = len(snapshot)
    return {k: round(v / n, 4) for k, v in totals.items()}


def _segment_breakdown(snapshot: List[Dict]) -> Dict[str, Any]:
    """Break population into high/mid/low stress thirds."""
    sorted_agents = sorted(snapshot, key=lambda a: a["state"].get("stress", 0))
    n = len(sorted_agents)
    third = n // 3

    def avg_state(agents):
        if not agents:
            return {}
        keys = ["valence", "stress", "belief"]
        return {k: round(sum(a["state"].get(k, 0) for a in agents) / len(agents), 4)
                for k in keys}

    return {
        "low_stress_third": avg_state(sorted_agents[:third]),
        "mid_stress_third": avg_state(sorted_agents[third:2*third]),
        "high_stress_third": avg_state(sorted_agents[2*third:]),
    }


class SyntheticPanel:
    """
    A persistent synthetic population you can inject stimuli into.

    Think of this as your focus group — always available, instantly queryable,
    calibrated to realistic human psychological distributions.
    """

    def __init__(
        self,
        n: int = 1000,
        seed: int = 42,
        warmup_ticks: int = 20,
        config: Optional[Dict] = None,
    ):
        cfg = dict(DEFAULT_CONFIG)
        cfg["num_agents"] = n
        cfg["seed"] = seed
        cfg["export"] = {"enabled": False}
        # SyntheticPanel measures response to the user-provided stimulus.
        # Disable DEFAULT_CONFIG demo events unless caller explicitly supplies events.
        cfg["events"] = []
        if config:
            cfg.update(config)

        self._config = cfg
        self._warmup_ticks = warmup_ticks
        self.sim = HRMCore(config=cfg)
        self.n = n
        self.seed = seed

        # Warm up the population to a stable baseline.
        for _ in range(warmup_ticks):
            self.sim.step()

        self._baseline = _population_averages(self.sim.observe_snapshot())

    def inject(
        self,
        text: str,
        run_ticks: int = 30,
        inject_tick: int = 5,
    ) -> InjectionResult:
        """
        Inject a text stimulus into the population and measure response.

        Args:
            text:         The stimulus — ad copy, news headline, policy text, etc.
            run_ticks:    How many ticks to run after injection.
            inject_tick:  Which tick to inject the stimulus on.

        Returns:
            InjectionResult with before/after population state and delta.
        """
        signal = parse_stimulus(text)

        # Build a deterministic counterfactual: same seed, same warmup, same ticks, no stimulus.
        # Delta is treatment minus this control so ordinary model drift does not masquerade as response.
        control = HRMCore(config=dict(self._config))
        for _ in range(self._warmup_ticks):
            control.step()
        for _ in range(run_ticks):
            control.step()
        control_post = _population_averages(control.observe_snapshot())
        control.close()

        for t in range(run_ticks):
            if t == inject_tick:
                apply_stimulus(self.sim, signal)
            self.sim.step()

        snapshot = self.sim.observe_snapshot()
        post = _population_averages(snapshot)
        delta = {k: round(post[k] - control_post.get(k, 0), 4) for k in post}

        return InjectionResult(
            stimulus_text=text,
            population_size=self.n,
            ticks_run=run_ticks,
            baseline=self._baseline,
            post_injection=post,
            delta=delta,
            control_post=control_post,
            segment_breakdown=_segment_breakdown(snapshot),
            raw_snapshot=snapshot,
        )

    def reset(self, warmup_ticks: int = 20) -> None:
        """Reset population to a fresh baseline."""
        self._warmup_ticks = warmup_ticks
        self._config = {
            **DEFAULT_CONFIG,
            "num_agents": self.n,
            "seed": self.seed,
            "events": [],
            "export": {"enabled": False},
        }
        self.sim = HRMCore(config=self._config)
        for _ in range(warmup_ticks):
            self.sim.step()
        self._baseline = _population_averages(self.sim.observe_snapshot())

    def compare(
        self,
        stimulus_a: str,
        stimulus_b: str,
        run_ticks: int = 30,
    ) -> Dict[str, InjectionResult]:
        """
        A/B test two stimuli against the same baseline population.
        Resets between runs to ensure identical starting conditions.
        """
        result_a = self.inject(stimulus_a, run_ticks=run_ticks)
        self.reset()
        result_b = self.inject(stimulus_b, run_ticks=run_ticks)
        self.reset()
        return {"A": result_a, "B": result_b}
