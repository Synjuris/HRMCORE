"""HRM_UNIFIED v2.8 Human Social Dynamics + DAS Deep Integration layer.

This module promotes previously side-car DAS concepts into persistent world state:
agent lifecycle, aging/death/reproduction pressure, pair bonds, kinship/family
continuity, sexuality/identity dynamics, factions, culture, beliefs, territory,
role specialization, and demographic inheritance.

The layer is deliberately structural and statistical. It does not script moral
claims, caricatures, identity stereotypes, or user/local assumptions. Gender and
sexuality are represented only as population-level identity/bonding/reproductive
forces that interact with institutions, culture, memory, and generational
continuity.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List, Optional
import hashlib
import json
import math
import random
import time

ENGINE_VERSION = "2.8"


def _stamp() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _canonical(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def fingerprint(obj: Any) -> str:
    return hashlib.sha256(_canonical(obj).encode("utf-8")).hexdigest()


def clamp(x: Any, lo: float = 0.0, hi: float = 1.0) -> float:
    try:
        v = float(x)
        if math.isnan(v):
            return lo
        return max(lo, min(hi, v))
    except Exception:
        return lo


def as_float(x: Any, default: float = 0.0) -> float:
    try:
        if x is None:
            return default
        v = float(x)
        return default if math.isnan(v) else v
    except Exception:
        return default


@dataclass
class SocialCohort:
    cohort_id: str
    generation: int
    share: float
    median_age: float = 0.50
    trust_baseline: float = 0.50
    resilience: float = 0.50
    fertility_norm: float = 0.50
    pair_bond_norm: float = 0.50
    identity_expression_norm: float = 0.50
    kinship_density: float = 0.40
    specialization: float = 0.35
    migration_pressure: float = 0.15
    encoded_at: str = field(default_factory=_stamp)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class HumanSocialState:
    generation_index: int = 0
    population_pressure: float = 0.50
    lifecycle_balance: float = 0.50
    reproduction_rate: float = 0.35
    mortality_pressure: float = 0.12
    pair_bond_stability: float = 0.45
    family_continuity: float = 0.45
    kinship_density: float = 0.40
    identity_expression: float = 0.50
    sexuality_expression: float = 0.50
    norm_tolerance: float = 0.50
    social_cohesion: float = 0.50
    factionalism: float = 0.25
    belief_rigidity: float = 0.30
    role_specialization: float = 0.35
    labor_stratification: float = 0.20
    migration_pressure: float = 0.15
    territorial_attachment: float = 0.45
    resource_family_stress: float = 0.20
    language_complexity: float = 0.35
    information_density: float = 0.35
    cohorts: List[SocialCohort] = field(default_factory=list)
    family_lines: List[Dict[str, Any]] = field(default_factory=list)
    social_events: List[Dict[str, Any]] = field(default_factory=list)
    das_integration: Dict[str, Any] = field(default_factory=dict)
    created_at: str = field(default_factory=_stamp)
    updated_at: str = field(default_factory=_stamp)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["fingerprint"] = fingerprint({k: v for k, v in d.items() if k != "fingerprint"})
        return d


class HumanSocialDynamicsEngine:
    """Persistent population/social dynamics layer fed by HRM+DAS state."""

    def __init__(self, seed: int = 42, inheritance_strength: float = 0.45, social_decay: float = 0.82):
        self.rng = random.Random(seed)
        self.inheritance_strength = clamp(inheritance_strength, 0.0, 1.0)
        self.social_decay = clamp(social_decay, 0.0, 0.99)
        self.state = HumanSocialState(
            cohorts=[SocialCohort("founding_social_cohort", 0, 1.0)],
            family_lines=[{"lineage_id": "lineage_000", "share": 1.0, "resilience": 0.50, "status": "founding"}],
            das_integration=self._das_capability_manifest(),
        )

    def _das_capability_manifest(self) -> Dict[str, Any]:
        # This is a runtime declaration of the DAS concepts this layer actively
        # consumes/encodes. It avoids pretending every DAS simulation object is
        # directly running inside HRM, while making the integration explicit.
        return {
            "integrated_layer": "human_social_dynamics",
            "das_components": [
                "biology", "reproduction", "generational", "factions", "culture",
                "beliefs", "goals", "territory", "logistics", "pressures",
                "language", "information", "memory", "specialization",
                "institutions", "governance", "innovation", "agent_lifecycle",
            ],
            "gender_and_sexuality_handling": "structural population dynamics only; no scripted stereotypes or moral labels",
            "integration_mode": "HRM summaries + institutional/memory/civilization state are converted into persistent DAS social state",
        }

    def to_dict(self) -> Dict[str, Any]:
        return self.state.to_dict()

    def apply_to_simulator(self, sim: Any) -> None:
        """Shift HRM pressure baselines using current persistent social state."""
        shifts = {
            "cooperation_pressure": 0.04 * (self.state.social_cohesion - 0.5) + 0.03 * (self.state.family_continuity - 0.5),
            "trust_pressure": 0.05 * (self.state.pair_bond_stability - 0.5) + 0.03 * (self.state.norm_tolerance - 0.5),
            "stress_pressure": 0.06 * (self.state.resource_family_stress - 0.5) + 0.04 * (self.state.factionalism - 0.5),
            "volatility_pressure": 0.05 * (self.state.migration_pressure - 0.5) + 0.04 * (self.state.belief_rigidity - 0.5),
            "withdrawal_pressure": -0.04 * (self.state.kinship_density - 0.5) + 0.03 * (self.state.identity_expression - 0.5),
        }
        # HistoricalSimulator exposes mutable starting pressures in different
        # versions. Patch only fields that exist; this keeps the layer tolerant.
        for key, delta in shifts.items():
            for obj_name in ("baseline", "initial_state", "state"):
                obj = getattr(sim, obj_name, None)
                if obj is not None and hasattr(obj, key):
                    setattr(obj, key, as_float(getattr(obj, key), 0.0) + delta)
            if hasattr(sim, key):
                setattr(sim, key, as_float(getattr(sim, key), 0.0) + delta)

    def step(
        self,
        generation: int,
        summary: Dict[str, Any],
        memory_state: Dict[str, Any],
        institution_state: Dict[str, Any],
        civilization_state: Dict[str, Any],
        label: str = "world",
    ) -> Dict[str, Any]:
        stress = clamp(summary.get("stress_pressure", 0.0), -1.0, 1.0)
        trust = clamp(summary.get("trust_pressure", 0.0), -1.0, 1.0)
        volatility = clamp(summary.get("volatility_pressure", 0.0), -1.0, 1.0)
        cooperation = clamp(summary.get("cooperation_pressure", 0.0), -1.0, 1.0)
        withdrawal = clamp(summary.get("withdrawal_pressure", 0.0), -1.0, 1.0)

        mem = memory_state or {}
        inst = institution_state or {}
        civ = civilization_state or {}
        institutional_memory = mem.get("institutional_memory", {}) if isinstance(mem, dict) else {}
        cultural_memory = mem.get("cultural_memory", {}) if isinstance(mem, dict) else {}
        scars = mem.get("historical_scars", {}) if isinstance(mem, dict) else {}
        legitimacy = as_float(institutional_memory.get("legitimacy"), 0.0)
        strain_memory = as_float(institutional_memory.get("strain_memory"), 0.0)
        cooperation_norm = as_float(cultural_memory.get("cooperation_norm"), 0.0)
        stress_scar = as_float(scars.get("stress_scar"), 0.0)
        shift_score = as_float((civ.get("civilization_metrics") or {}).get("civilization_shift_score") if isinstance(civ, dict) else 0.0, 0.0)
        average_adoption = as_float((civ.get("civilization_metrics") or {}).get("average_adoption") if isinstance(civ, dict) else 0.0, 0.0)

        s = self.state
        s.generation_index = generation
        # Lifecycle and reproduction are affected by stability, resources,
        # social trust, family stress, and modernization/novelty adoption.
        s.resource_family_stress = clamp(s.resource_family_stress * self.social_decay + 0.30 * stress + 0.20 * volatility + 0.12 * strain_memory - 0.14 * cooperation)
        s.pair_bond_stability = clamp(s.pair_bond_stability * self.social_decay + 0.18 * trust + 0.18 * cooperation - 0.18 * stress - 0.10 * withdrawal)
        s.kinship_density = clamp(s.kinship_density * self.social_decay + 0.20 * s.pair_bond_stability + 0.14 * cooperation - 0.12 * s.migration_pressure)
        s.family_continuity = clamp(s.family_continuity * self.social_decay + 0.22 * s.kinship_density + 0.18 * s.pair_bond_stability - 0.16 * s.resource_family_stress)
        s.reproduction_rate = clamp(s.reproduction_rate * self.social_decay + 0.20 * s.family_continuity + 0.13 * s.pair_bond_stability - 0.18 * s.resource_family_stress - 0.10 * average_adoption)
        s.mortality_pressure = clamp(s.mortality_pressure * self.social_decay + 0.16 * stress + 0.14 * volatility + 0.08 * stress_scar - 0.12 * cooperation)
        s.lifecycle_balance = clamp(0.5 + s.reproduction_rate * 0.45 - s.mortality_pressure * 0.35 - s.migration_pressure * 0.15)
        s.population_pressure = clamp(s.population_pressure * self.social_decay + 0.25 * s.reproduction_rate - 0.15 * s.mortality_pressure + 0.10 * s.lifecycle_balance)

        # Identity/sexuality expression is mediated by institutional legitimacy,
        # cultural tolerance, belief rigidity, and stress. It does not encode
        # value judgements; it is an expression/constraint signal.
        s.norm_tolerance = clamp(s.norm_tolerance * self.social_decay + 0.16 * legitimacy + 0.12 * cooperation_norm + 0.08 * trust - 0.10 * volatility - 0.08 * s.belief_rigidity)
        s.identity_expression = clamp(s.identity_expression * self.social_decay + 0.20 * s.norm_tolerance + 0.08 * trust - 0.08 * stress)
        s.sexuality_expression = clamp(s.sexuality_expression * self.social_decay + 0.18 * s.norm_tolerance + 0.10 * s.pair_bond_stability - 0.08 * s.resource_family_stress)

        # Factions, beliefs, territory, specialization, and information.
        s.factionalism = clamp(s.factionalism * self.social_decay + 0.20 * volatility + 0.16 * withdrawal + 0.10 * max(0.0, -legitimacy) - 0.12 * cooperation)
        s.belief_rigidity = clamp(s.belief_rigidity * self.social_decay + 0.15 * stress + 0.12 * volatility + 0.10 * s.factionalism - 0.08 * s.norm_tolerance)
        s.social_cohesion = clamp(s.social_cohesion * self.social_decay + 0.20 * cooperation + 0.16 * trust + 0.14 * s.kinship_density - 0.14 * s.factionalism)
        s.role_specialization = clamp(s.role_specialization * self.social_decay + 0.16 * average_adoption + 0.12 * s.information_density + 0.08 * s.family_continuity - 0.10 * stress)
        s.labor_stratification = clamp(s.labor_stratification * self.social_decay + 0.13 * s.role_specialization + 0.10 * shift_score - 0.08 * s.norm_tolerance)
        s.migration_pressure = clamp(s.migration_pressure * self.social_decay + 0.15 * volatility + 0.12 * stress + 0.08 * s.labor_stratification - 0.12 * s.territorial_attachment)
        s.territorial_attachment = clamp(s.territorial_attachment * self.social_decay + 0.14 * s.kinship_density + 0.12 * s.family_continuity - 0.10 * s.migration_pressure)
        s.language_complexity = clamp(s.language_complexity * self.social_decay + 0.12 * s.information_density + 0.08 * s.role_specialization + 0.05 * cooperation)
        s.information_density = clamp(s.information_density * self.social_decay + 0.18 * average_adoption + 0.10 * shift_score + 0.06 * s.language_complexity)

        self._turnover_cohorts(generation)
        self._update_family_lines(generation)
        event = self._classify_social_event(generation, label)
        if event:
            s.social_events.append(event)
            s.social_events = s.social_events[-200:]
        s.updated_at = _stamp()
        return self.social_metrics()

    def _turnover_cohorts(self, generation: int) -> None:
        s = self.state
        existing = []
        for c in s.cohorts:
            c.share = round(c.share * (1.0 - 0.24), 6)
            c.median_age = clamp(c.median_age + 0.06)
            existing.append(c)
        new_share = clamp(0.18 + 0.20 * s.reproduction_rate - 0.08 * s.mortality_pressure, 0.05, 0.42)
        existing.append(SocialCohort(
            cohort_id=f"social_cohort_{generation:04d}", generation=generation, share=new_share,
            median_age=0.08, trust_baseline=clamp(0.50 + 0.25 * (s.social_cohesion - 0.5)),
            resilience=clamp(0.50 + 0.25 * (s.family_continuity - 0.5) - 0.15 * s.resource_family_stress),
            fertility_norm=s.reproduction_rate, pair_bond_norm=s.pair_bond_stability,
            identity_expression_norm=s.identity_expression, kinship_density=s.kinship_density,
            specialization=s.role_specialization, migration_pressure=s.migration_pressure,
        ))
        total = sum(c.share for c in existing) or 1.0
        s.cohorts = sorted(existing, key=lambda c: c.generation)[-8:]
        total = sum(c.share for c in s.cohorts) or 1.0
        for c in s.cohorts:
            c.share = round(c.share / total, 6)

    def _update_family_lines(self, generation: int) -> None:
        s = self.state
        lines = []
        for line in s.family_lines:
            share = clamp(as_float(line.get("share"), 0.0) * (0.92 + 0.10 * s.family_continuity - 0.06 * s.migration_pressure), 0.0, 1.0)
            if share > 0.01:
                line = dict(line)
                line["share"] = round(share, 6)
                line["resilience"] = round(clamp(as_float(line.get("resilience"), 0.5) * 0.88 + 0.12 * s.family_continuity), 6)
                lines.append(line)
        if s.reproduction_rate > 0.42 and len(lines) < 12:
            lines.append({
                "lineage_id": f"lineage_{generation:04d}_{len(lines):02d}",
                "share": round(clamp(0.03 + 0.08 * s.reproduction_rate), 6),
                "resilience": round(clamp(0.45 + 0.20 * s.family_continuity), 6),
                "status": "emergent",
            })
        total = sum(as_float(x.get("share"), 0.0) for x in lines) or 1.0
        for line in lines:
            line["share"] = round(as_float(line.get("share"), 0.0) / total, 6)
        s.family_lines = lines[-12:]

    def _classify_social_event(self, generation: int, label: str) -> Optional[Dict[str, Any]]:
        s = self.state
        candidates = []
        if s.reproduction_rate < 0.22:
            candidates.append(("fertility_contraction", "Reproduction rate entered contraction band."))
        if s.family_continuity > 0.68:
            candidates.append(("kinship_consolidation", "Family continuity and kinship density consolidated."))
        if s.factionalism > 0.62:
            candidates.append(("factional_fragmentation", "Factionalism crossed high-fragmentation band."))
        if s.identity_expression > 0.66 and s.norm_tolerance > 0.58:
            candidates.append(("identity_normalization", "Identity expression normalized under tolerant social conditions."))
        if s.role_specialization > 0.66:
            candidates.append(("specialization_takeoff", "Role specialization crossed takeoff band."))
        if not candidates:
            return None
        typ, msg = candidates[-1]
        return {"generation": generation, "label": label, "event_type": typ, "message": msg, "created_at": _stamp()}

    def social_metrics(self) -> Dict[str, Any]:
        s = self.state
        metrics = {
            "population_pressure": round(s.population_pressure, 6),
            "lifecycle_balance": round(s.lifecycle_balance, 6),
            "reproduction_rate": round(s.reproduction_rate, 6),
            "mortality_pressure": round(s.mortality_pressure, 6),
            "pair_bond_stability": round(s.pair_bond_stability, 6),
            "family_continuity": round(s.family_continuity, 6),
            "kinship_density": round(s.kinship_density, 6),
            "identity_expression": round(s.identity_expression, 6),
            "sexuality_expression": round(s.sexuality_expression, 6),
            "norm_tolerance": round(s.norm_tolerance, 6),
            "social_cohesion": round(s.social_cohesion, 6),
            "factionalism": round(s.factionalism, 6),
            "belief_rigidity": round(s.belief_rigidity, 6),
            "role_specialization": round(s.role_specialization, 6),
            "labor_stratification": round(s.labor_stratification, 6),
            "migration_pressure": round(s.migration_pressure, 6),
            "territorial_attachment": round(s.territorial_attachment, 6),
            "language_complexity": round(s.language_complexity, 6),
            "information_density": round(s.information_density, 6),
            "cohort_count": len(s.cohorts),
            "family_line_count": len(s.family_lines),
            "social_event_count": len(s.social_events),
        }
        metrics["social_fingerprint"] = self.state.to_dict()["fingerprint"]
        return metrics


def social_report_markdown(state: Dict[str, Any], benchmark: Dict[str, Any]) -> str:
    lines = [
        "# HRM_UNIFIED v2.8 Human Social Dynamics Report",
        "",
        "This report summarizes the persistent DAS social layer: lifecycle, reproduction, pair bonding, kinship, identity/sexuality expression, factions, beliefs, specialization, territory, language, and information dynamics.",
        "",
        "## Benchmark",
    ]
    for key in sorted(benchmark):
        if key.endswith("fingerprint"):
            continue
        lines.append(f"- `{key}`: {benchmark[key]}")
    lines.extend(["", "## Social State"])
    for key in [
        "population_pressure", "lifecycle_balance", "reproduction_rate", "mortality_pressure",
        "pair_bond_stability", "family_continuity", "kinship_density", "identity_expression",
        "sexuality_expression", "norm_tolerance", "social_cohesion", "factionalism", "belief_rigidity",
        "role_specialization", "labor_stratification", "migration_pressure", "territorial_attachment",
        "language_complexity", "information_density",
    ]:
        lines.append(f"- `{key}`: {state.get(key)}")
    lines.extend(["", "## Recent Social Events"])
    events = state.get("social_events") or []
    if events:
        for ev in events[-12:]:
            lines.append(f"- generation {ev.get('generation')}: **{ev.get('event_type')}** — {ev.get('message')}")
    else:
        lines.append("- No major social threshold events recorded yet.")
    lines.extend(["", "## Integrity", f"Social fingerprint: `{state.get('fingerprint')}`"])
    return "\n".join(lines) + "\n"
