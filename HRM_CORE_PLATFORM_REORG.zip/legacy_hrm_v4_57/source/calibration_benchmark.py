#!/usr/bin/env python3
"""Deterministic v1.3 benchmark for calibrated population response."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

try:
    from .population.calibrated_panel import CalibratedPanel
except ImportError:
    from population.calibrated_panel import CalibratedPanel

STIMULI = [
    "Official agency report announces a severe regional economic slowdown and job losses.",
    "Neighbors share a rumor about a local safety threat near several schools.",
    "Public health officials announce a contained hospital capacity warning.",
    "Community volunteers organize broad relief support after a storm.",
    "News report describes a controversial policy change affecting household costs."
]
PROFILES = ["generic_mixed_region", "industrial_transition_region", "high_mobility_growth_region"]


def main() -> int:
    runs = []
    for profile in PROFILES:
        for stim in STIMULI:
            panel = CalibratedPanel(n=500, seed=42, profile=profile)
            result = panel.inject(stim, run_ticks=35)
            runs.append({
                "profile": result.profile_name,
                "stimulus": stim,
                "channel": result.source_channel,
                "delta": result.delta,
                "topology": result.topology_summary,
            })
    payload = {"version": "v1.3", "runs": runs}
    canonical = json.dumps(payload, sort_keys=True)
    fingerprint = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    payload["fingerprint_sha256"] = fingerprint
    out = Path("outputs/calibration_benchmark_v1_3.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"fingerprint_sha256={fingerprint}")
    print(f"wrote={out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
