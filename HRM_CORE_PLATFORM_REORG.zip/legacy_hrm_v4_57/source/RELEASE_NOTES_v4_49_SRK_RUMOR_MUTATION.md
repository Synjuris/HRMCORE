
## Hotfix: Homicide Detection (run_exp_E.py, run_exp_E_1k.py, run_exp_E_resume.py)
lethality.resolve_lethality() uses event_type="lethal_conflict" with
outcome="homicide" for kills. The aux_events loop was checking
event_type=="homicide" — wrong field, so kills were never caught.

Fix: check event_type=="lethal_conflict" AND outcome=="homicide".

Result: 70.7% of deaths now correctly logged as homicide (41/58 in 1000-tick run).
Tarn (Gen0 founder, stress 1.00) killed at tick 418.
Fern killed at tick 433, systemic_impact=1.00 (12 surviving relationships disrupted).

## Forensic Rumor Trace (agent.py)
At the moment of lethal escalation, the actor's current threat_near or
resource_scarce inbox message is captured and embedded in the lethal_conflict
event context as "rumor_trace":

  rumor_trace: {
    content_type       — which signal type triggered the kill
    source_id          — who the actor heard it from (not the original source)
    origin_tick        — when the original message was created
    fidelity           — confidence remaining at time of kill
    mutation_count     — how many relay hops mutated the payload
    semantic_drift     — cumulative drift accumulated across hops
    precision_loss     — worst precision degradation seen
    cross_faction_pressure — hostility level if cross-faction relay occurred
    payload_threat_level   — the perceived threat magnitude at kill time
  }

A mutation_count > 0 means the kill was preceded by a distorted signal.
A high semantic_drift with low fidelity means the killer acted on a rumor
that had degraded significantly from its original content.

Results (1000-tick run):
  37 homicides total
  8 (21.6%) preceded by mutated rumor (mutation_count > 0)
  All rumor-driven kills showed threat_perceived = 1.000 (ceiling)
  Fidelity on those messages: 0.111–0.475 (low-confidence signals)
  Semantic drift on those messages: 0.420 (max cap hit)

The killer was acting on what the rumor said, not what happened.
