"""
adapters/census_acs.py

Optional U.S. Census ACS adapter for HRM_UNIFIED.

Design rules:
- No locality is hardcoded.
- API keys are read from environment/.env.user, not source code.
- Live API output is normalized into a generic calibration profile.
- Cached JSON snapshots are used for reproducibility.
"""
from __future__ import annotations

import json
import os
import urllib.parse
import urllib.request
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Optional, Any

ACS_YEAR = "2024"
ACS_DATASET = "acs/acs5/profile"
BASE_URL = f"https://api.census.gov/data/{ACS_YEAR}/{ACS_DATASET}"

# ACS Data Profile variables. These are broad public population characteristics.
VARIABLES: Dict[str, str] = {
    "DP05_0001E": "population_total",
    "DP05_0018PE": "under_18_pct",
    "DP05_0024PE": "age_65_plus_pct",
    "DP03_0062E": "median_household_income",
    "DP03_0128PE": "poverty_pct",
    "DP03_0009PE": "unemployment_pct",
    "DP03_0033PE": "manufacturing_employment_pct",
    "DP02_0067PE": "bachelors_or_higher_pct",
    "DP04_0046PE": "renter_occupied_pct",
}


def load_env_file(path: str | Path = ".env.user") -> None:
    """Minimal .env loader to avoid adding a dependency."""
    p = Path(path)
    if not p.exists():
        return
    for raw in p.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def _to_float(value: Any) -> Optional[float]:
    if value in (None, "", "null"):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


@dataclass
class CalibrationProfile:
    source: str
    dataset: str
    geography_name: str
    geography_type: str
    state: str
    county: Optional[str]
    place: Optional[str]
    raw_metrics: Dict[str, Optional[float]]
    normalized: Dict[str, float]
    hrm_config_patch: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def build_query(*, state: str, county: str | None = None, place: str | None = None, api_key: str | None = None) -> str:
    if bool(county) == bool(place):
        raise ValueError("Provide exactly one of county= or place=.")
    get_vars = ["NAME", *VARIABLES.keys()]
    params = {"get": ",".join(get_vars)}
    if county:
        params["for"] = f"county:{county}"
        params["in"] = f"state:{state}"
    else:
        params["for"] = f"place:{place}"
        params["in"] = f"state:{state}"
    if api_key:
        params["key"] = api_key
    return BASE_URL + "?" + urllib.parse.urlencode(params, safe=",")


def fetch_acs_profile(*, state: str, county: str | None = None, place: str | None = None, api_key: str | None = None, timeout: int = 30) -> Dict[str, Any]:
    url = build_query(state=state, county=county, place=place, api_key=api_key)
    req = urllib.request.Request(url, headers={"User-Agent": "HRM_UNIFIED/1.2 real-data adapter"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        payload = resp.read().decode("utf-8")
    data = json.loads(payload)
    if not isinstance(data, list) or len(data) < 2:
        raise RuntimeError(f"Unexpected ACS response: {data!r}")
    headers, row = data[0], data[1]
    return dict(zip(headers, row))


def normalize_acs_record(record: Dict[str, Any], *, state: str, county: str | None, place: str | None) -> CalibrationProfile:
    raw = {label: _to_float(record.get(var)) for var, label in VARIABLES.items()}
    population = raw.get("population_total") or 0.0
    income = raw.get("median_household_income") or 0.0
    poverty = raw.get("poverty_pct") or 0.0
    unemployment = raw.get("unemployment_pct") or 0.0
    manufacturing = raw.get("manufacturing_employment_pct") or 0.0
    education = raw.get("bachelors_or_higher_pct") or 0.0
    renters = raw.get("renter_occupied_pct") or 0.0
    under18 = raw.get("under_18_pct") or 0.0
    senior = raw.get("age_65_plus_pct") or 0.0

    # Generic normalized drivers. These are calibration hints, not truth labels.
    economic_pressure = max(0.0, min(1.0, (poverty / 30.0) * 0.45 + (unemployment / 15.0) * 0.35 + (renters / 70.0) * 0.20))
    resource_baseline = max(0.15, min(0.90, 0.35 + (income / 120000.0) * 0.50 - economic_pressure * 0.20))
    volatility = max(0.05, min(0.95, economic_pressure * 0.55 + (manufacturing / 35.0) * 0.25 + (under18 / 35.0) * 0.10 + (senior / 30.0) * 0.10))
    social_complexity = max(0.05, min(0.95, (education / 60.0) * 0.35 + (population / 1_000_000.0) * 0.35 + (renters / 70.0) * 0.30))

    normalized = {
        "population_scale": round(max(0.0, min(1.0, population / 1_000_000.0)), 4),
        "economic_pressure": round(economic_pressure, 4),
        "resource_baseline": round(resource_baseline, 4),
        "volatility_pressure": round(volatility, 4),
        "social_complexity": round(social_complexity, 4),
        "manufacturing_dependency": round(max(0.0, min(1.0, manufacturing / 35.0)), 4),
        "education_signal": round(max(0.0, min(1.0, education / 60.0)), 4),
    }

    # HRM only supports broad trait config today. Keep patch small and inspectable.
    patch = {
        "traits": {
            "resource_level_mean": round(resource_baseline, 4),
            "resource_level_var": round(0.12 + economic_pressure * 0.18, 4),
            "anxiety_reactivity_mean": round(0.30 + economic_pressure * 0.35 + volatility * 0.10, 4),
            "social_sensitivity_mean": round(0.45 + social_complexity * 0.25, 4),
            "openness_mean": round(0.38 + normalized["education_signal"] * 0.22, 4),
            "neuroticism_mean": round(0.32 + economic_pressure * 0.24, 4),
        },
        "metadata": {
            "calibration_source": "US Census ACS Data Profile",
            "calibration_year": ACS_YEAR,
            "calibration_geography": record.get("NAME", "unknown"),
            "calibration_note": "Real public data converted into generic HRM trait priors; not a prediction model.",
        },
    }

    return CalibrationProfile(
        source="US Census Bureau API",
        dataset=f"{ACS_YEAR}/{ACS_DATASET}",
        geography_name=str(record.get("NAME", "unknown")),
        geography_type="county" if county else "place",
        state=state,
        county=county,
        place=place,
        raw_metrics=raw,
        normalized=normalized,
        hrm_config_patch=patch,
    )


def get_calibration_profile(*, state: str, county: str | None = None, place: str | None = None, api_key: str | None = None, cache_dir: str | Path = "datasets/cache", use_cache: bool = True) -> CalibrationProfile:
    load_env_file()
    try:
        from real_data_api_connector import get_dataset_api_key
        api_key = get_dataset_api_key(api_key, Path(__file__).resolve().parents[1])
    except Exception:
        api_key = api_key or os.getenv("DATASET_API_KEY") or os.getenv("CENSUS_API_KEY") or os.getenv("ACS_API_KEY")
    cache_root = Path(cache_dir)
    cache_root.mkdir(parents=True, exist_ok=True)
    geo = f"state{state}_county{county}" if county else f"state{state}_place{place}"
    cache_path = cache_root / f"acs_{ACS_YEAR}_{geo}.json"

    if use_cache and cache_path.exists():
        record = json.loads(cache_path.read_text(encoding="utf-8"))
    else:
        record = fetch_acs_profile(state=state, county=county, place=place, api_key=api_key)
        cache_path.write_text(json.dumps(record, indent=2, sort_keys=True), encoding="utf-8")

    return normalize_acs_record(record, state=state, county=county, place=place)
