"""Optional real-data adapters. Core HRM does not depend on these."""
