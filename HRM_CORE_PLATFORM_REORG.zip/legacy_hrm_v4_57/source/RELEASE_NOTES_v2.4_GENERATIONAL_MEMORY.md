# HRM_UNIFIED v2.4 — Generational Memory Layer

Purpose: make historical consequences persist across simulated generations, not just across runs.

Adds:

- cohort system
- inherited trust/stress/withdrawal baselines
- institutional memory
- cultural memory decay
- historical scar formation
- resilience inheritance
- generational turnover
- long-run benchmark output
- before/after generation report

Core loop:

```text
event pressure
-> civic adaptation
-> memory encoding
-> cohort inheritance
-> future baseline shift
-> different future response
```

Primary command:

```bash
python -m hrm_unified.run_generational_memory --generations 4 --n 600
```

Outputs default to:

```text
outputs/generational_memory_v2_4/generational_memory_report.json
outputs/generational_memory_v2_4/generational_memory_report.md
```

Notes:

- v2.4 builds on the v2.3 constitution layer.
- v2.2 endogenous evolution is preserved in the package lineage.
- The layer is generic and does not encode personal, local, or real-world causal claims.
