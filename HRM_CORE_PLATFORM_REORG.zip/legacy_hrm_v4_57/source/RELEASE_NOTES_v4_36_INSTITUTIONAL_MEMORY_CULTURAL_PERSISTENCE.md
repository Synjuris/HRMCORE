# HRM Unified v4.36 — Institutional Memory + Cultural Persistence

This build is a full-package build based on v4.35. No v4.35 files were intentionally omitted.

## New system

`das/institutional_memory.py`

Adds a closed-loop civilization memory layer:

- observes retained event stream
- compresses repeated events into cultural memory anchors
- derives faction/local cultural profiles from lived history
- transmits collective memory through knowledge/information/care/governance carriers and elders
- stabilizes proto-institutions from repeated social functions
- allows knowledge preservation, distortion, and loss
- feeds cultural priors back into agent trust, fear, cooperation, storage orientation, and ideology sensitivity

## Design constraint

The system does not assign historical-era professions or fixed government forms. It uses capability families and repeated functional pressures.

## New artifacts

Per run:

- `institutional_memory_ledger.json`

Top-level:

- `INSTITUTIONAL_MEMORY_AUDIT_v4_36.md`
- `FILE_INVENTORY_v4_36.txt`
- `OMISSION_CHECK_v4_36.txt`
- `VALIDATION_v4_36.txt`
