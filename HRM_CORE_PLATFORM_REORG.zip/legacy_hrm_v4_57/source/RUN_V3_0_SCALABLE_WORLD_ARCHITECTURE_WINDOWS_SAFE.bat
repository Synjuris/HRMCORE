@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo HRM_UNIFIED v3.0 - Scalable World Architecture
echo Folder: %CD%
echo ============================================================

set PY_CMD=
where py >nul 2>nul
if %ERRORLEVEL%==0 set PY_CMD=py -3
if not defined PY_CMD (
  where python >nul 2>nul
  if %ERRORLEVEL%==0 set PY_CMD=python
)
if not defined PY_CMD (
  where python3 >nul 2>nul
  if %ERRORLEVEL%==0 set PY_CMD=python3
)
if not defined PY_CMD (
  echo ERROR: Python was not found. Install Python 3.10+ and check "Add Python to PATH".
  pause
  exit /b 1
)

echo Using Python command: %PY_CMD%
%PY_CMD% run_scalable_world.py --mode desktop --n 1200 --cycles 2 --generations-per-cycle 2 --world-id default_world_v3
set ERR=%ERRORLEVEL%
echo.
if not "%ERR%"=="0" (
  echo Run completed with warnings or errors. Exit code: %ERR%
) else (
  echo Run completed successfully.
)
echo Outputs are in: outputs\scalable_world_v3_0\default_world_v3\reports
pause
exit /b %ERR%
