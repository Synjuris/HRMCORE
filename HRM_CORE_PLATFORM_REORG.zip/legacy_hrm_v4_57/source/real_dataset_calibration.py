#!/usr/bin/env python3
"""HRM_UNIFIED v3.3 real dataset ingestion + calibration layer.

This module is intentionally conservative:
- It can run fully offline from bundled/local CSV or JSON files.
- It can consume the existing optional Census ACS adapter when FIPS inputs are supplied.
- It writes normalized calibration patches rather than pretending raw public data is a full reality model.
- Missing sources become warnings, not crashes.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import statistics
import time
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

ENGINE_VERSION = "3.3"
SUPPORTED_SOURCE_TYPES = {"csv", "json", "acs_profile", "manual"}

NUMERIC_ALIASES: Dict[str, Tuple[str, ...]] = {
    "population_total": ("population_total", "population", "total_population", "pop", "DP05_0001E"),
    "median_household_income": ("median_household_income", "median_income", "income", "DP03_0062E"),
    "poverty_pct": ("poverty_pct", "poverty_rate", "percent_poverty", "DP03_0128PE"),
    "unemployment_pct": ("unemployment_pct", "unemployment_rate", "DP03_0009PE"),
    "under_18_pct": ("under_18_pct", "children_pct", "youth_pct", "DP05_0018PE"),
    "age_65_plus_pct": ("age_65_plus_pct", "senior_pct", "elderly_pct", "DP05_0024PE"),
    "bachelors_or_higher_pct": ("bachelors_or_higher_pct", "education_ba_pct", "college_pct", "DP02_0067PE"),
    "renter_occupied_pct": ("renter_occupied_pct", "renters_pct", "renter_pct", "DP04_0046PE"),
    "manufacturing_employment_pct": ("manufacturing_employment_pct", "manufacturing_pct", "DP03_0033PE"),
    "density_per_sq_mile": ("density_per_sq_mile", "density", "population_density"),
    "hospital_beds_per_1000": ("hospital_beds_per_1000", "beds_per_1000", "healthcare_capacity"),
    "violent_crime_rate": ("violent_crime_rate", "crime_rate", "violence_rate"),
    "commute_minutes": ("commute_minutes", "mean_commute_minutes", "travel_time_to_work"),
}


def clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, value))


def safe_float(value: Any) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if math.isnan(float(value)):
            return None
        return float(value)
    text = str(value).strip().replace(",", "")
    if not text or text.lower() in {"na", "n/a", "none", "null", "-"}:
        return None
    if text.endswith("%"):
        text = text[:-1].strip()
    try:
        return float(text)
    except ValueError:
        return None


def read_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path: str | Path, data: Any) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")


def file_sha256(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _records_from_csv(path: str | Path) -> List[Dict[str, Any]]:
    with Path(path).open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def _records_from_json(path: str | Path) -> List[Dict[str, Any]]:
    data = read_json(path)
    if isinstance(data, dict):
        if "raw_metrics" in data or "normalized" in data:
            return [data]
        if "records" in data and isinstance(data["records"], list):
            return [r for r in data["records"] if isinstance(r, dict)]
        return [data]
    if isinstance(data, list):
        return [r for r in data if isinstance(r, dict)]
    return []


def _first_present(record: Dict[str, Any], aliases: Iterable[str]) -> Optional[float]:
    lowered = {str(k).lower(): v for k, v in record.items()}
    for key in aliases:
        if key in record:
            got = safe_float(record.get(key))
            if got is not None:
                return got
        low = key.lower()
        if low in lowered:
            got = safe_float(lowered.get(low))
            if got is not None:
                return got
    return None


@dataclass
class DatasetSource:
    name: str
    source_type: str
    path: Optional[str] = None
    records: int = 0
    sha256: Optional[str] = None
    notes: List[str] = field(default_factory=list)


@dataclass
class CalibrationBundle:
    version: str
    geography_label: str
    generated_at_unix: float
    sources: List[DatasetSource]
    raw_metrics: Dict[str, Optional[float]]
    normalized: Dict[str, float]
    hrm_config_patch: Dict[str, Any]
    disease_patch: Dict[str, Any]
    era_patch: Dict[str, Any]
    scale_patch: Dict[str, Any]
    warnings: List[str]
    validation: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["sources"] = [asdict(s) for s in self.sources]
        return d


def load_dataset_file(path: str | Path, name: Optional[str] = None) -> Tuple[DatasetSource, List[Dict[str, Any]]]:
    p = Path(path)
    if not p.exists():
        return DatasetSource(name or p.name, "missing", str(p), 0, None, ["file_not_found"]), []
    suffix = p.suffix.lower().lstrip(".")
    if suffix == "csv":
        records = _records_from_csv(p)
        typ = "csv"
    elif suffix == "json":
        records = _records_from_json(p)
        typ = "json"
    else:
        records = []
        typ = "unsupported"
    return DatasetSource(name or p.name, typ, str(p), len(records), file_sha256(p), []), records


def extract_metrics(records: List[Dict[str, Any]], warnings: List[str]) -> Dict[str, Optional[float]]:
    by_metric: Dict[str, List[float]] = {k: [] for k in NUMERIC_ALIASES}
    for record in records:
        if "raw_metrics" in record and isinstance(record["raw_metrics"], dict):
            source = record["raw_metrics"]
        else:
            source = record
        for metric, aliases in NUMERIC_ALIASES.items():
            val = _first_present(source, aliases)
            if val is not None:
                by_metric[metric].append(val)
    out: Dict[str, Optional[float]] = {}
    for metric, vals in by_metric.items():
        if not vals:
            out[metric] = None
        elif metric == "population_total":
            out[metric] = float(sum(vals)) if len(vals) > 1 else float(vals[0])
        else:
            out[metric] = float(statistics.mean(vals))
    if all(v is None for v in out.values()):
        warnings.append("No recognized numeric calibration fields were found. See datasets/sample_real_dataset.csv for accepted field names.")
    return out


def normalize_metrics(raw: Dict[str, Optional[float]]) -> Dict[str, float]:
    population = raw.get("population_total") or 0.0
    income = raw.get("median_household_income") or 0.0
    poverty = raw.get("poverty_pct") or 0.0
    unemployment = raw.get("unemployment_pct") or 0.0
    renters = raw.get("renter_occupied_pct") or 0.0
    under18 = raw.get("under_18_pct") or 0.0
    senior = raw.get("age_65_plus_pct") or 0.0
    education = raw.get("bachelors_or_higher_pct") or 0.0
    manufacturing = raw.get("manufacturing_employment_pct") or 0.0
    density = raw.get("density_per_sq_mile") or 0.0
    beds = raw.get("hospital_beds_per_1000") or 0.0
    crime = raw.get("violent_crime_rate") or 0.0
    commute = raw.get("commute_minutes") or 0.0

    economic_pressure = clamp((poverty / 32.0) * 0.42 + (unemployment / 16.0) * 0.30 + (renters / 75.0) * 0.18 + max(0.0, (55000.0 - income) / 55000.0) * 0.10)
    resource_baseline = clamp(0.30 + (income / 130000.0) * 0.48 - economic_pressure * 0.16, 0.10, 0.92)
    demographic_youth = clamp(under18 / 34.0)
    demographic_aging = clamp(senior / 32.0)
    education_signal = clamp(education / 62.0)
    industrial_dependency = clamp(manufacturing / 35.0)
    density_pressure = clamp(density / 8000.0)
    healthcare_capacity = clamp(beds / 6.0)
    mobility_pressure = clamp(commute / 55.0)
    safety_pressure = clamp(crime / 1200.0)
    social_complexity = clamp(education_signal * 0.28 + clamp(population / 1_000_000.0) * 0.34 + clamp(renters / 75.0) * 0.18 + density_pressure * 0.20)
    volatility_pressure = clamp(economic_pressure * 0.38 + industrial_dependency * 0.16 + demographic_youth * 0.10 + demographic_aging * 0.10 + safety_pressure * 0.16 + mobility_pressure * 0.10)
    public_health_vulnerability = clamp(demographic_aging * 0.24 + economic_pressure * 0.24 + density_pressure * 0.18 + (1.0 - healthcare_capacity) * 0.22 + mobility_pressure * 0.12)
    institutional_load = clamp(economic_pressure * 0.28 + public_health_vulnerability * 0.24 + safety_pressure * 0.18 + social_complexity * 0.16 + density_pressure * 0.14)

    return {
        "population_scale": round(clamp(population / 1_000_000.0), 4),
        "economic_pressure": round(economic_pressure, 4),
        "resource_baseline": round(resource_baseline, 4),
        "demographic_youth": round(demographic_youth, 4),
        "demographic_aging": round(demographic_aging, 4),
        "education_signal": round(education_signal, 4),
        "industrial_dependency": round(industrial_dependency, 4),
        "density_pressure": round(density_pressure, 4),
        "healthcare_capacity": round(healthcare_capacity, 4),
        "mobility_pressure": round(mobility_pressure, 4),
        "safety_pressure": round(safety_pressure, 4),
        "social_complexity": round(social_complexity, 4),
        "volatility_pressure": round(volatility_pressure, 4),
        "public_health_vulnerability": round(public_health_vulnerability, 4),
        "institutional_load": round(institutional_load, 4),
    }


def build_patches(normalized: Dict[str, float], geography_label: str) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any], Dict[str, Any]]:
    econ = normalized["economic_pressure"]
    resources = normalized["resource_baseline"]
    complexity = normalized["social_complexity"]
    volatility = normalized["volatility_pressure"]
    health_vuln = normalized["public_health_vulnerability"]
    inst_load = normalized["institutional_load"]
    density = normalized["density_pressure"]

    hrm_config_patch = {
        "traits": {
            "resource_level_mean": round(resources, 4),
            "resource_level_var": round(0.10 + econ * 0.22, 4),
            "anxiety_reactivity_mean": round(0.25 + econ * 0.34 + volatility * 0.18, 4),
            "social_sensitivity_mean": round(0.40 + complexity * 0.28, 4),
            "openness_mean": round(0.34 + normalized["education_signal"] * 0.28, 4),
            "institutional_trust_baseline": round(clamp(0.64 - inst_load * 0.34 + resources * 0.10), 4),
            "civic_stress_baseline": round(clamp(0.20 + econ * 0.32 + volatility * 0.20), 4),
        },
        "environment": {
            "density_pressure": density,
            "mobility_pressure": normalized["mobility_pressure"],
            "economic_pressure": econ,
            "institutional_load": inst_load,
        },
        "metadata": {
            "calibration_source": "HRM v3.3 dataset ingestion bundle",
            "calibration_geography": geography_label,
            "calibration_note": "Public/local datasets converted into generic HRM priors; this is calibration, not ground truth prediction.",
        },
    }
    disease_patch = {
        "healthcare_capacity": normalized["healthcare_capacity"],
        "population_vulnerability": health_vuln,
        "transmission_multiplier": round(clamp(0.75 + density * 0.55 + normalized["mobility_pressure"] * 0.32), 4),
        "compliance_pressure": round(clamp(0.42 + inst_load * 0.30 - normalized["education_signal"] * 0.08), 4),
        "mortality_sensitivity": round(clamp(0.50 + health_vuln * 0.46), 4),
    }
    era_patch = {
        "reality_seed_adjustments": {
            "technology_distribution": round(clamp(0.55 + normalized["education_signal"] * 0.22 + complexity * 0.10), 4),
            "media_fragmentation": round(clamp(0.35 + complexity * 0.28 + volatility * 0.18), 4),
            "economic_baseline_pressure": econ,
            "institutional_capacity_stress": inst_load,
        }
    }
    scale_patch = {
        "recommended_mode": "toy" if normalized["population_scale"] < 0.08 else "desktop" if normalized["population_scale"] < 0.75 else "large",
        "active_fraction": round(clamp(0.18 - normalized["population_scale"] * 0.10, 0.03, 0.18), 4),
        "regional_fraction": round(clamp(0.42 + normalized["population_scale"] * 0.20, 0.42, 0.72), 4),
        "statistical_fraction": round(clamp(0.40 + normalized["population_scale"] * 0.28, 0.40, 0.90), 4),
        "checkpoint_prune_after": 24,
        "replay_compaction_enabled": True,
    }
    return hrm_config_patch, disease_patch, era_patch, scale_patch


def validate_bundle(raw: Dict[str, Optional[float]], normalized: Dict[str, float], sources: List[DatasetSource], warnings: List[str]) -> Dict[str, Any]:
    populated = [k for k, v in raw.items() if v is not None]
    missing = [k for k, v in raw.items() if v is None]
    if raw.get("population_total") is None:
        warnings.append("population_total missing; scale recommendation will be weak.")
    if raw.get("median_household_income") is None and raw.get("poverty_pct") is None:
        warnings.append("income/poverty fields missing; economic calibration will be weak.")
    if raw.get("hospital_beds_per_1000") is None:
        warnings.append("healthcare capacity missing; disease calibration uses conservative fallback.")
    usable_sources = [s for s in sources if s.records > 0]
    score = round(clamp(len(populated) / max(1, len(raw))) * 100, 2)
    return {
        "calibration_score_0_100": score,
        "recognized_metric_count": len(populated),
        "missing_metric_count": len(missing),
        "recognized_metrics": populated,
        "missing_metrics": missing,
        "usable_source_count": len(usable_sources),
        "source_count": len(sources),
        "ready_for_experiment": score >= 35 and len(usable_sources) >= 1,
        "notes": [
            "Score measures field coverage, not truth quality.",
            "Use multiple public/local sources for serious calibration.",
        ],
    }


def build_calibration_bundle(records: List[Dict[str, Any]], sources: List[DatasetSource], geography_label: str) -> CalibrationBundle:
    warnings: List[str] = []
    if not records:
        warnings.append("No source records loaded. Bundle will use fallback neutral priors.")
    raw = extract_metrics(records, warnings)
    normalized = normalize_metrics(raw)
    hrm_patch, disease_patch, era_patch, scale_patch = build_patches(normalized, geography_label)
    validation = validate_bundle(raw, normalized, sources, warnings)
    return CalibrationBundle(
        version=ENGINE_VERSION,
        geography_label=geography_label,
        generated_at_unix=time.time(),
        sources=sources,
        raw_metrics=raw,
        normalized=normalized,
        hrm_config_patch=hrm_patch,
        disease_patch=disease_patch,
        era_patch=era_patch,
        scale_patch=scale_patch,
        warnings=warnings,
        validation=validation,
    )


def calibration_report_markdown(bundle: CalibrationBundle) -> str:
    d = bundle.to_dict()
    lines = [
        f"# HRM_UNIFIED v{ENGINE_VERSION} Real Dataset Calibration Report",
        "",
        f"**Geography / baseline:** {bundle.geography_label}",
        f"**Calibration score:** {bundle.validation['calibration_score_0_100']} / 100",
        f"**Ready for experiment:** {bundle.validation['ready_for_experiment']}",
        "",
        "## Sources",
    ]
    for s in bundle.sources:
        lines.append(f"- `{s.name}` | type={s.source_type} | records={s.records} | sha256={s.sha256 or 'n/a'}")
        for note in s.notes:
            lines.append(f"  - warning: {note}")
    lines += ["", "## Normalized Calibration Drivers"]
    for k, v in bundle.normalized.items():
        lines.append(f"- `{k}`: {v}")
    lines += ["", "## Missing / Weak Fields"]
    for k in bundle.validation["missing_metrics"]:
        lines.append(f"- `{k}`")
    lines += ["", "## Warnings"]
    if bundle.warnings:
        for w in bundle.warnings:
            lines.append(f"- {w}")
    else:
        lines.append("- None")
    lines += [
        "",
        "## Generated Patches",
        "",
        "The JSON bundle contains four machine-readable sections:",
        "- `hrm_config_patch`",
        "- `disease_patch`",
        "- `era_patch`",
        "- `scale_patch`",
        "",
        "These are calibration priors. They do not claim predictive certainty.",
    ]
    return "\n".join(lines) + "\n"
