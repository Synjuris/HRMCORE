#!/usr/bin/env python3
"""Run HRM_UNIFIED v1.8 replayable historical timelines."""
from __future__ import annotations

import argparse
from pathlib import Path

try:
    from .population.history import HistoricalSimulator, load_timeline
    from .population.policy import load_policy_definitions, DEFAULT_POLICIES
    from .export_utils import ensure_dir, safe_slug
except ImportError:
    from population.history import HistoricalSimulator, load_timeline
    from population.policy import load_policy_definitions, DEFAULT_POLICIES
    from export_utils import ensure_dir, safe_slug


def write_history_outputs(result, output_dir: str, prefix: str = "history"):
    out = ensure_dir(output_dir)
    summary_json = out / f"{prefix}_summary.json"
    summary_md = out / f"{prefix}_summary.md"
    snapshots_csv = out / f"{prefix}_snapshots.csv"
    steps_csv = out / f"{prefix}_steps.csv"
    events_csv = out / f"{prefix}_events.csv"
    state_json = out / f"{prefix}_final_state.json"

    summary_json.write_text(result.to_json(), encoding="utf-8")
    import json
    state_json.write_text(json.dumps(result.final_state.to_dict(), indent=2), encoding="utf-8")

    lines = [
        "# HRM_UNIFIED v1.8 Replayable Historical Simulation Report",
        "",
        f"**Timeline:** {result.name}",
        f"**Profile:** {result.profile_name}",
        f"**Population:** {result.population_size}",
        f"**Seed:** {result.seed}",
        f"**Decay:** {result.decay:.4f}",
        f"**Fingerprint:** `{result.fingerprint()}`",
        f"**Total policy cost units:** {result.total_cost_units:.2f}",
        "",
        "## Final Civic Pressures",
        "",
        "| Pressure | Value |",
        "|---|---:|",
    ]
    for k, v in result.final_state.summary().items():
        lines.append(f"| {k} | {v:+.4f} |")

    lines += ["", "## Historical Snapshots", "", "| Period | Tick | Label | Stress | Trust | Volatility | Cooperation | Withdrawal | Events Seen |", "|---:|---:|---|---:|---:|---:|---:|---:|---:|"]
    for s in result.snapshots:
        st = s.state
        lines.append(
            f"| {s.period} | {s.tick} | {s.label} | "
            f"{float(st.get('stress_pressure', 0.0)):+.4f} | {float(st.get('trust_pressure', 0.0)):+.4f} | "
            f"{float(st.get('volatility_pressure', 0.0)):+.4f} | {float(st.get('cooperation_pressure', 0.0)):+.4f} | "
            f"{float(st.get('withdrawal_pressure', 0.0)):+.4f} | {s.events_seen} |"
        )

    lines += ["", "## Timeline Steps", "", "| Period | Tick | Type | Label | Cost | Stress Before | Stress After |", "|---:|---:|---|---|---:|---:|---:|"]
    for step in result.steps:
        b = step.state_before or {}
        a = step.state_after or {}
        lines.append(
            f"| {step.period} | {step.tick} | {step.kind} | {step.label} | {step.cost_units:.2f} | "
            f"{float(b.get('stress_pressure', 0.0)):+.4f} | {float(a.get('stress_pressure', 0.0)):+.4f} |"
        )

    lines += ["", "## Emergent Events", "", "| Tick | Kind | Scope | Severity | Message |", "|---:|---|---|---:|---|"]
    if result.events:
        for e in result.events:
            lines.append(f"| {e.tick} | {e.kind} | {e.scope} | {e.severity:.4f} | {e.message} |")
    else:
        lines.append("| — | none | — | 0.0000 | No thresholds crossed. |")
    summary_md.write_text("\n".join(lines), encoding="utf-8")

    with snapshots_csv.open("w", encoding="utf-8") as f:
        f.write("period,tick,label,stress_pressure,trust_pressure,volatility_pressure,cooperation_pressure,withdrawal_pressure,events_seen,fingerprint\n")
        for s in result.snapshots:
            st = s.state
            label = s.label.replace('"', '""')
            f.write(f'{s.period},{s.tick},"{label}",{st.get("stress_pressure",0.0)},{st.get("trust_pressure",0.0)},{st.get("volatility_pressure",0.0)},{st.get("cooperation_pressure",0.0)},{st.get("withdrawal_pressure",0.0)},{s.events_seen},{s.fingerprint}\n')

    with steps_csv.open("w", encoding="utf-8") as f:
        f.write("period,tick,kind,label,policy_id,cost_units,stress_before,stress_after,volatility_before,volatility_after\n")
        for s in result.steps:
            b = s.state_before or {}; a = s.state_after or {}
            label = s.label.replace('"', '""')
            f.write(f'{s.period},{s.tick},{s.kind},"{label}",{s.policy_id or ""},{s.cost_units},{b.get("stress_pressure",0.0)},{a.get("stress_pressure",0.0)},{b.get("volatility_pressure",0.0)},{a.get("volatility_pressure",0.0)}\n')

    with events_csv.open("w", encoding="utf-8") as f:
        f.write("tick,kind,scope,severity,message\n")
        for e in result.events:
            msg = e.message.replace('"', '""')
            f.write(f'{e.tick},{e.kind},{e.scope},{e.severity},"{msg}"\n')

    return {
        "summary_json": str(summary_json),
        "summary_md": str(summary_md),
        "snapshots_csv": str(snapshots_csv),
        "steps_csv": str(steps_csv),
        "events_csv": str(events_csv),
        "state_json": str(state_json),
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Replay a persistent synthetic civic history timeline.")
    ap.add_argument("timeline", nargs="?", help="Optional JSON/YAML timeline. Defaults to generic built-in timeline.")
    ap.add_argument("--policies", help="Optional JSON policy definition file.")
    ap.add_argument("--n", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--profile", default="generic_mixed_region")
    ap.add_argument("--decay", type=float, default=0.86)
    ap.add_argument("--name", default=None)
    ap.add_argument("--load-state", help="Optional saved state JSON to continue from.")
    ap.add_argument("--save-state", help="Optional path for final saved state JSON.")
    ap.add_argument("--output-dir", default="outputs/history_v1_8")
    args = ap.parse_args()

    timeline = load_timeline(args.timeline)
    name = args.name or str(timeline.get("name", Path(args.timeline).stem if args.timeline else "generic_recovery_history"))
    policies = load_policy_definitions(args.policies) if args.policies else DEFAULT_POLICIES
    sim = HistoricalSimulator(n=args.n, seed=args.seed, profile=args.profile, decay=args.decay, policies=policies)
    if args.load_state:
        sim.load_state(args.load_state)
    result = sim.run(timeline, name=name)
    print(result.summary())
    paths = write_history_outputs(result, args.output_dir, prefix=safe_slug("history_" + name))
    if args.save_state:
        paths["saved_state"] = str(sim.save_state(args.save_state, label=name))
    print("\nWrote:")
    for k, v in paths.items():
        print(f"  {k}: {v}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
