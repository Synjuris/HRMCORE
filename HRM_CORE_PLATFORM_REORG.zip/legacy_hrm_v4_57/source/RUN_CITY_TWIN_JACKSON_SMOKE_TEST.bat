@echo off
setlocal
cd /d "%~dp0"
echo Running small Jackson City Twin smoke test...
py -3 -m hrm_city_twin.jackson_tn --pop 250 --seed 42 --root .
pause
