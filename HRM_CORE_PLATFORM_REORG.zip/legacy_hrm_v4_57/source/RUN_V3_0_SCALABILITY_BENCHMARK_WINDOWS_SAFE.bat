@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo HRM_UNIFIED v3.0 - Scalability Benchmark
echo Folder: %CD%
echo ============================================================

set PY_CMD=
where py >nul 2>nul
if %ERRORLEVEL%==0 set PY_CMD=py -3
if not defined PY_CMD (
  where python >nul 2>nul
  if %ERRORLEVEL%==0 set PY_CMD=python
)
if not defined PY_CMD (
  where python3 >nul 2>nul
  if %ERRORLEVEL%==0 set PY_CMD=python3
)
if not defined PY_CMD (
  echo ERROR: Python was not found. Install Python 3.10+ and check "Add Python to PATH".
  pause
  exit /b 1
)

%PY_CMD% scalable_benchmark.py
pause
