#!/usr/bin/env python3
"""Deterministic benchmark for the HRM/DAS bridge layer."""
from __future__ import annotations

try:
    from .environment import SyntheticCivicEnvironment, EnvironmentConfig
    from .population.history import default_timeline
except ImportError:
    from environment import SyntheticCivicEnvironment, EnvironmentConfig
    from population.history import default_timeline


def main() -> int:
    cfg = EnvironmentConfig(population_size=300, seed=211, das_bridge_enabled=True, das_bridge_inertia=0.82)
    env = SyntheticCivicEnvironment(config=cfg)
    paths = env.run_timeline(default_timeline(), output_dir="outputs/das_bridge_benchmark", name="das_bridge_benchmark", build_observatory=False)
    bridge = env.das_bridge
    assert bridge is not None, "DAS bridge was not enabled"
    st = bridge.state.to_dict()
    required = ["structural_stress", "institutional_adaptation", "faction_volatility", "cooperation_capacity", "innovation_momentum", "resilience_memory"]
    missing = [k for k in required if k not in st]
    if missing:
        raise AssertionError(f"Missing bridge state keys: {missing}")
    if not (0.0 <= st["cooperation_capacity"] <= 1.0):
        raise AssertionError("cooperation_capacity out of bounds")
    print("HRM_UNIFIED v2.1 DAS bridge benchmark: PASS")
    print(f"Bridge fingerprint: {bridge.state.fingerprint()[:16]}")
    print(f"Manifest: {paths.get('summary_json')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
