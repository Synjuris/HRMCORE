"""Constitution/invariant audit layer for HRM_UNIFIED v2.3.

This module adds lightweight, explicit constraints over simulated civic state
transitions. It does not make real-world claims. It checks whether the internal
model changed in bounded, explainable ways.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List, Optional
import json
import hashlib
import time

ENGINE_VERSION = "2.3"


def _canonical(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def _hash(obj: Any) -> str:
    return hashlib.sha256(_canonical(obj).encode("utf-8")).hexdigest()


def _stamp() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _get_pressure(state: Dict[str, Any], key: str) -> float:
    try:
        return float(state.get(key, 0.0))
    except Exception:
        return 0.0


@dataclass
class ConstitutionRule:
    rule_id: str
    description: str
    severity: str = "error"
    limit: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ConstitutionFinding:
    rule_id: str
    passed: bool
    severity: str
    message: str
    evidence: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ConstitutionAuditRecord:
    tick: int
    label: str
    state_before_hash: str
    state_after_hash: str
    findings: List[ConstitutionFinding]
    created_at: str = field(default_factory=_stamp)
    record_hash: str = ""

    def finalize(self) -> "ConstitutionAuditRecord":
        payload = asdict(self)
        payload.pop("record_hash", None)
        self.record_hash = _hash(payload)
        return self

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tick": self.tick,
            "label": self.label,
            "state_before_hash": self.state_before_hash,
            "state_after_hash": self.state_after_hash,
            "findings": [f.to_dict() for f in self.findings],
            "created_at": self.created_at,
            "record_hash": self.record_hash,
        }


@dataclass
class ConstitutionAuditReport:
    version: str
    passed: bool
    records: List[ConstitutionAuditRecord]
    rules: List[ConstitutionRule]
    fingerprint: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "version": self.version,
            "passed": self.passed,
            "records": [r.to_dict() for r in self.records],
            "rules": [r.to_dict() for r in self.rules],
            "fingerprint": self.fingerprint,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)


DEFAULT_RULES = [
    ConstitutionRule("bounded_pressure", "Core pressure values must remain inside the synthetic [-2.0, +2.0] operating envelope.", "error", 2.0),
    ConstitutionRule("rate_limit_pressure", "Single-step pressure changes must remain bounded unless caused by an explicit event/policy step.", "error", 0.85),
    ConstitutionRule("memory_decay_floor", "Decay should not create negative phantom pressure in nonnegative civic channels.", "warning", 0.0),
    ConstitutionRule("institutional_inertia", "Institution strain should not jump without a recorded transition.", "warning", 0.75),
    ConstitutionRule("causal_transition", "Every nonzero state transition must have a timeline label/kind attached.", "error", 0.0),
]

CORE_PRESSURES = [
    "stress_pressure",
    "trust_pressure",
    "volatility_pressure",
    "cooperation_pressure",
    "withdrawal_pressure",
]


class ConstitutionEngine:
    def __init__(self, rules: Optional[List[ConstitutionRule]] = None):
        self.rules = rules or list(DEFAULT_RULES)

    def audit_transition(self, before: Dict[str, Any], after: Dict[str, Any], label: str, tick: int, kind: str = "scenario") -> ConstitutionAuditRecord:
        findings: List[ConstitutionFinding] = []
        cause_present = bool(str(label).strip() or str(kind).strip())

        for key in CORE_PRESSURES:
            value = _get_pressure(after, key)
            passed = -2.0 <= value <= 2.0
            findings.append(ConstitutionFinding(
                rule_id="bounded_pressure",
                passed=passed,
                severity="error",
                message=f"{key} inside bounded operating envelope" if passed else f"{key} escaped bounded operating envelope",
                evidence={"signal": key, "value": round(value, 6), "limit": 2.0},
            ))

            delta = abs(value - _get_pressure(before, key))
            # Policy steps can be direct interventions; they still get watched, but at a looser band.
            limit = 1.15 if kind == "policy" else 0.85
            passed = delta <= limit
            findings.append(ConstitutionFinding(
                rule_id="rate_limit_pressure",
                passed=passed,
                severity="error",
                message=f"{key} transition rate within limit" if passed else f"{key} transition exceeded rate limit",
                evidence={"signal": key, "delta": round(delta, 6), "limit": limit, "kind": kind},
            ))

            nonzero_change = delta > 1e-9
            findings.append(ConstitutionFinding(
                rule_id="causal_transition",
                passed=(not nonzero_change) or cause_present,
                severity="error",
                message="transition has explicit timeline cause" if ((not nonzero_change) or cause_present) else "transition lacked explicit timeline cause",
                evidence={"signal": key, "delta": round(delta, 6), "label": label, "kind": kind},
            ))

        for key in CORE_PRESSURES:
            value = _get_pressure(after, key)
            if key in {"stress_pressure", "volatility_pressure", "withdrawal_pressure", "cooperation_pressure"}:
                findings.append(ConstitutionFinding(
                    rule_id="memory_decay_floor",
                    passed=value >= -1e-9,
                    severity="warning",
                    message=f"{key} did not decay below zero" if value >= -1e-9 else f"{key} decayed below zero",
                    evidence={"signal": key, "value": round(value, 6)},
                ))

        before_inst = before.get("institution_strain", {}) or {}
        after_inst = after.get("institution_strain", {}) or {}
        for inst_id, after_value_raw in after_inst.items():
            try:
                after_value = float(after_value_raw)
                before_value = float(before_inst.get(inst_id, 0.0))
            except Exception:
                continue
            jump = abs(after_value - before_value)
            findings.append(ConstitutionFinding(
                rule_id="institutional_inertia",
                passed=jump <= 0.75,
                severity="warning",
                message="institution strain shift within inertia band" if jump <= 0.75 else "institution strain shifted faster than inertia band",
                evidence={"institution": inst_id, "delta": round(jump, 6), "limit": 0.75},
            ))

        return ConstitutionAuditRecord(
            tick=int(tick),
            label=str(label),
            state_before_hash=_hash(before),
            state_after_hash=_hash(after),
            findings=findings,
        ).finalize()

    def audit_historical_result(self, result: Any) -> ConstitutionAuditReport:
        records: List[ConstitutionAuditRecord] = []
        for step in getattr(result, "steps", []):
            before = getattr(step, "state_before", {}) or {}
            after = getattr(step, "state_after", {}) or {}
            label = getattr(step, "label", "")
            tick = getattr(step, "tick", 0)
            kind = getattr(step, "kind", "scenario")
            records.append(self.audit_transition(before, after, label=label, tick=tick, kind=kind))
        passed = all(f.passed or f.severity != "error" for r in records for f in r.findings)
        payload = {"version": ENGINE_VERSION, "records": [r.to_dict() for r in records], "rules": [r.to_dict() for r in self.rules]}
        return ConstitutionAuditReport(ENGINE_VERSION, passed, records, self.rules, _hash(payload))


def constitution_markdown(report: ConstitutionAuditReport) -> str:
    total = sum(len(r.findings) for r in report.records)
    failed = [f for r in report.records for f in r.findings if not f.passed]
    lines = [
        "# HRM_UNIFIED v2.3 Constitution Audit",
        "",
        f"**Status:** {'PASS' if report.passed else 'FAIL'}",
        f"**Records:** {len(report.records)}",
        f"**Findings:** {total}",
        f"**Failed findings:** {len(failed)}",
        f"**Fingerprint:** `{report.fingerprint}`",
        "",
        "## Rules",
        "",
        "| Rule | Severity | Limit | Description |",
        "|---|---|---:|---|",
    ]
    for rule in report.rules:
        lines.append(f"| {rule.rule_id} | {rule.severity} | {rule.limit:.4f} | {rule.description} |")
    lines += ["", "## Transition Records", "", "| Tick | Label | Status | Record Hash |", "|---:|---|---|---|"]
    for rec in report.records:
        rec_failed = [f for f in rec.findings if not f.passed and f.severity == "error"]
        lines.append(f"| {rec.tick} | {rec.label} | {'FAIL' if rec_failed else 'PASS'} | `{rec.record_hash[:16]}` |")
    if failed:
        lines += ["", "## Failed Findings", "", "| Rule | Severity | Message | Evidence |", "|---|---|---|---|"]
        for f in failed[:50]:
            lines.append(f"| {f.rule_id} | {f.severity} | {f.message} | `{json.dumps(f.evidence, sort_keys=True)}` |")
    return "\n".join(lines)
