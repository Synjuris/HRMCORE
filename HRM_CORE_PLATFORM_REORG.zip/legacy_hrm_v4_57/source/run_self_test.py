from validation.self_test_fingerprint import run_and_fingerprint

if __name__ == "__main__":
    count, digest = run_and_fingerprint()
    print("Self-test records:", count)
    print("Self-test SHA256:", digest)
