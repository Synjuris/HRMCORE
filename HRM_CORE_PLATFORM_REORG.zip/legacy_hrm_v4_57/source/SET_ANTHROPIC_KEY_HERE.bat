@echo off
cd /d "%~dp0"
echo Paste your Anthropic key below, then press Enter:
set /p KEY=
echo ANTHROPIC_API_KEY=%KEY%> .env.user
echo Saved key to %CD%\.env.user
pause
