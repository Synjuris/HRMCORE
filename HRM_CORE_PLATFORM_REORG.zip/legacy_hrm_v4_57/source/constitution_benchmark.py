"""Deterministic benchmark for the HRM_UNIFIED v2.3 constitution layer."""
from __future__ import annotations

try:
    from .population.history import HistoricalSimulator, load_timeline
    from .constitution import ConstitutionEngine
except ImportError:
    from population.history import HistoricalSimulator, load_timeline
    from constitution import ConstitutionEngine


def main() -> int:
    timeline = load_timeline(None)
    sim = HistoricalSimulator(n=400, seed=23, profile="generic_mixed_region", decay=0.86)
    result = sim.run(timeline, name="constitution_benchmark")
    report = ConstitutionEngine().audit_historical_result(result)
    print("HRM_UNIFIED v2.3 constitution benchmark:", "PASS" if report.passed else "FAIL")
    print("fingerprint:", report.fingerprint[:16])
    print("records:", len(report.records))
    return 0 if report.passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
