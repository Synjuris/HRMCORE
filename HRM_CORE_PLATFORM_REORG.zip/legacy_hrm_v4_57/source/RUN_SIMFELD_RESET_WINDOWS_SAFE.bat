@echo off
cd /d "%~dp0"
echo Resetting HRM ARW Simfeld season data...
py agentic_real_world\run_episode.py --reset
pause
