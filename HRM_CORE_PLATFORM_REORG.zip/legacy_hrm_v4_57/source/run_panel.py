from __future__ import annotations

import argparse
from inject import SyntheticPanel
from export_utils import write_panel_result, safe_slug


def main() -> None:
    parser = argparse.ArgumentParser(description="Run one text stimulus through the HRM synthetic panel.")
    parser.add_argument("stimulus", help="Stimulus text, e.g. 'Factory closures announced across Madison County.'")
    parser.add_argument("--n", type=int, default=1000, help="Synthetic population size.")
    parser.add_argument("--seed", type=int, default=42, help="Deterministic seed.")
    parser.add_argument("--warmup", type=int, default=20, help="Baseline warmup ticks.")
    parser.add_argument("--ticks", type=int, default=30, help="Ticks to run after injection window starts.")
    parser.add_argument("--inject-tick", type=int, default=5, help="Tick where stimulus is injected.")
    parser.add_argument("--output-dir", default="outputs", help="Directory for JSON/Markdown/CSV outputs.")
    parser.add_argument("--no-raw", action="store_true", help="Do not export per-agent JSONL snapshot.")
    args = parser.parse_args()

    panel = SyntheticPanel(n=args.n, seed=args.seed, warmup_ticks=args.warmup)
    result = panel.inject(args.stimulus, run_ticks=args.ticks, inject_tick=args.inject_tick)
    print(result.summary())
    paths = write_panel_result(result, args.output_dir, prefix=safe_slug(args.stimulus), include_raw=not args.no_raw)
    print("\nOutputs:")
    for label, path in paths.items():
        print(f"  {label}: {path}")


if __name__ == "__main__":
    main()
