@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo ============================================================
echo HRM_UNIFIED v3.3.1 - Real Data API Connector + Calibration
echo Folder: %CD%
echo ============================================================
echo.

set PYTHON_CMD=
where py >nul 2>nul
if %ERRORLEVEL%==0 (
    set PYTHON_CMD=py -3
) else (
    where python >nul 2>nul
    if %ERRORLEVEL%==0 (
        set PYTHON_CMD=python
    ) else (
        where python3 >nul 2>nul
        if %ERRORLEVEL%==0 (
            set PYTHON_CMD=python3
        )
    )
)

if "%PYTHON_CMD%"=="" (
    echo ERROR: Python was not found.
    echo Install Python 3 from https://www.python.org/downloads/ and check "Add Python to PATH".
    pause
    exit /b 1
)

echo Using Python command: %PYTHON_CMD%
%PYTHON_CMD% --version

echo.
echo Key discovery order:
echo   1. Existing DATASET_API_KEY environment variable
echo   2. Existing CENSUS_API_KEY environment variable
echo   3. Existing ACS_API_KEY environment variable
echo   4. .env or .env.user in this folder
echo.
echo If no key is found, this still runs safely using cache/sample fallback.
echo.

if not exist ".env.user" (
    echo # Local secrets. Do NOT share this file.> .env.user
    echo # Put your real key after the equals sign, then rerun this launcher.>> .env.user
    echo DATASET_API_KEY=PASTE_YOUR_KEY_HERE>> .env.user
    echo CENSUS_API_KEY=PASTE_YOUR_KEY_HERE>> .env.user
    echo Created .env.user template.
    echo.
)

echo Running live ACS calibration if a key is present; otherwise sample fallback remains safe.
%PYTHON_CMD% run_real_dataset_calibration.py --api-health --state 47 --county 113 --geography "Madison County TN / Jackson TN baseline" --use-sample --output-dir outputs\real_data_api_connector_v3_3_1
set EXITCODE=%ERRORLEVEL%

echo.
if not "%EXITCODE%"=="0" (
    echo ERROR: Real data API connector run failed with code %EXITCODE%.
    pause
    exit /b %EXITCODE%
)

echo Done.
echo Report: outputs\real_data_api_connector_v3_3_1\real_dataset_calibration_report.md
echo API health: outputs\real_data_api_connector_v3_3_1\api_health_report.json
echo Bundle: outputs\real_data_api_connector_v3_3_1\real_dataset_calibration_bundle.json
echo.
pause
