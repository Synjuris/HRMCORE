#!/usr/bin/env python3
"""Compare two v1.8 historical timeline branches."""
from __future__ import annotations

import argparse
import json

try:
    from .population.history import HistoricalSimulator, load_timeline, compare_histories
    from .export_utils import ensure_dir, safe_slug
except ImportError:
    from population.history import HistoricalSimulator, load_timeline, compare_histories
    from export_utils import ensure_dir, safe_slug


def run_one(path: str, n: int, seed: int, profile: str, decay: float, name: str):
    timeline = load_timeline(path)
    sim = HistoricalSimulator(n=n, seed=seed, profile=profile, decay=decay)
    return sim.run(timeline, name=name or str(timeline.get("name", "timeline")))


def main() -> int:
    ap = argparse.ArgumentParser(description="Compare two replayable synthetic history branches.")
    ap.add_argument("timeline_a")
    ap.add_argument("timeline_b")
    ap.add_argument("--name-a", default="branch_a")
    ap.add_argument("--name-b", default="branch_b")
    ap.add_argument("--n", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--profile", default="generic_mixed_region")
    ap.add_argument("--decay", type=float, default=0.86)
    ap.add_argument("--output-dir", default="outputs/history_compare_v1_8")
    args = ap.parse_args()

    a = run_one(args.timeline_a, args.n, args.seed, args.profile, args.decay, args.name_a)
    b = run_one(args.timeline_b, args.n, args.seed, args.profile, args.decay, args.name_b)
    cmp = compare_histories(a, b)
    out = ensure_dir(args.output_dir)
    path = out / f"compare_{safe_slug(args.name_a)}_vs_{safe_slug(args.name_b)}.json"
    path.write_text(json.dumps(cmp, indent=2), encoding="utf-8")
    print("HRM_UNIFIED v1.8 HISTORY BRANCH COMPARISON")
    print(f"A: {args.name_a} {a.fingerprint()[:16]}")
    print(f"B: {args.name_b} {b.fingerprint()[:16]}")
    print("Final pressure delta B - A:")
    for k, v in cmp["final_pressure_delta_b_minus_a"].items():
        print(f"  {k:<24} {v:+.4f}")
    print(f"Event count delta: {cmp['event_count_delta_b_minus_a']:+d}")
    print(f"Cost delta: {cmp['cost_delta_b_minus_a']:+.4f}")
    print(f"Wrote: {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
