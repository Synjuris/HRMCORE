#!/usr/bin/env python3
"""Run a timeline and emit the controlled HRM/DAS bridge report."""
from __future__ import annotations

import argparse
from pathlib import Path

try:
    from .environment import SyntheticCivicEnvironment, load_environment_config
    from .population.history import load_timeline
    from .population.policy import load_policy_definitions, DEFAULT_POLICIES
except ImportError:
    from environment import SyntheticCivicEnvironment, load_environment_config
    from population.history import load_timeline
    from population.policy import load_policy_definitions, DEFAULT_POLICIES


def main() -> int:
    ap = argparse.ArgumentParser(description="Run HRM timeline with controlled DAS bridge enabled.")
    ap.add_argument("timeline", nargs="?", help="Optional timeline JSON/YAML. Defaults to generic built-in timeline.")
    ap.add_argument("--config", help="Optional environment config JSON.")
    ap.add_argument("--policies", help="Optional policy definition JSON.")
    ap.add_argument("--name", help="Override run name.")
    ap.add_argument("--n", type=int, default=None)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--profile", default=None)
    ap.add_argument("--decay", type=float, default=None)
    ap.add_argument("--bridge-inertia", type=float, default=0.82)
    ap.add_argument("--output-dir", default="outputs/das_bridge_v2_1")
    args = ap.parse_args()

    policies = load_policy_definitions(args.policies) if args.policies else DEFAULT_POLICIES
    config = load_environment_config(args.config)
    if args.n is not None:
        config.population_size = args.n
    if args.seed is not None:
        config.seed = args.seed
    if args.profile is not None:
        config.profile = args.profile
    if args.decay is not None:
        config.decay = args.decay
    config.das_bridge_enabled = True
    config.das_bridge_inertia = args.bridge_inertia

    env = SyntheticCivicEnvironment(config=config, policies=policies)
    timeline = load_timeline(args.timeline)
    name = args.name or str(timeline.get("name") or (Path(args.timeline).stem if args.timeline else "das_bridge_run"))
    paths = env.run_timeline(timeline, output_dir=args.output_dir, name=name, build_observatory=True)

    print("HRM_UNIFIED v2.1 HRM/DAS BRIDGE")
    print(f"Run: {name}")
    print(f"DAS state fingerprint: {env.das_bridge.state.fingerprint()[:16] if env.das_bridge else 'disabled'}")
    print("Wrote:")
    for k, v in paths.items():
        print(f"  {k}: {v}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
