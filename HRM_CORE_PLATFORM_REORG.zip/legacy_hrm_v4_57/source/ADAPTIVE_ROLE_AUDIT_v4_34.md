# v4.34 Adaptive Role Audit

Base package: `HRM_UNIFIED_v4_33_WORLD_PRESSURE_SUBSISTENCE_FULL_WINDOWS_SAFE.zip`

## Omission check

Base file count: 395
New file count before final zip: 400
Missing base files: 0
Added files: 5

Missing base files list:

```text
NONE
```

## Static-role repair

The build now centralizes role interpretation in `das/adaptive_roles.py`. Legacy names such as gatherer/defender/planner/diplomat remain accepted only as compatibility aliases. New mechanics should use role families:

- subsistence
- protection
- coordination
- diplomacy
- craft
- care
- knowledge
- logistics
- governance
- information

## Files intentionally changed

```text
das/adaptive_roles.py
das/specialization.py
das/agent.py
das/schemas.py
das/governance.py
das/information.py
das/innovation.py
das/persistence.py
das/subsistence.py
das/continuity.py
das/run_sim.py
RUN_V4_34_ADAPTIVE_SPECIALIZATION_WINDOWS_SAFE.bat
RELEASE_NOTES_v4_34_ADAPTIVE_SPECIALIZATION.md
```

## Validation

- Full compile: passed
- DAS smoke run: passed
- Benchmark file emitted: `benchmark_v04_34.json`
- Base omission count: 0
