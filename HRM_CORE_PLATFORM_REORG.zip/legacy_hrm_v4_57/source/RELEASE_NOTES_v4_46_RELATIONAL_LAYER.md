# HRM_UNIFIED v4.46 — Relational Layer Repair

Three gaps identified in the sexuality/relational layer assessment.

## Fixed

### 1. Pair bond formation ignored biological attraction (generational.py, biology.py)
Bonds formed purely on trust + attachment scores from the relationship ledger.
attraction_score() existed but was never called during bond formation.
An agent could bond with someone they had zero biological attraction toward.

Fix: biology module imported into generational.py. attraction_score() called
for each candidate pair during bond evaluation. Mutual attraction < 0.05 blocks
bond formation entirely. Mutual attraction adds up to 0.16 to bond strength.
Result: bond strength now ranges 0.507–0.877 with meaningful spread.
Low-attraction pairs form weaker bonds; high mutual attraction produces strong bonds.

### 2. Bond dissolution didn't exist (generational.py)
pair_bond_strength only ever increased (took max of current and new).
Bonds never broke from conflict, infidelity, grief, or incompatibility.

Fix: dissolution logic added to generational tick:
- Partner death: bond erodes 0.002/tick, clears when below 0.10
- High resentment (>0.55) or repeated conflict (>8 conflicts): erosion proportional
  to excess, bond clears when below 0.15
- _pair_bond_partner_id cleared on dissolution so agent becomes available again

### 3. Infidelity mechanic was unconnected (biology.py, run_sim.py)
check_infidelity_attempt() existed but had no call site. The function also had
a bug: agent.traits.dominance (dominance lives on agent.state, not traits).
Thresholds (dominance > 0.72, risk > 0.65, libido > 0.55) were too high for
the population distributions being generated.

Fix: dominance attribute corrected to agent.state.dominance. Thresholds
lowered to dominance > 0.55, risk > 0.50, libido > 0.35. Infidelity check
wired into biology tick in run_sim.py — bonded agents checked against nearby
non-partner agents at 1.5% per tick. Successful attempts log as deception
events toward the partner with context.deception_type = 'infidelity_attempt'.

Note: infidelity requires libido > 0.35. In high-stress long runs, libido
suppresses to ~0.075 — below threshold. Feature requires lower-stress conditions
(blind date show / peaceful scenarios) to observe.
