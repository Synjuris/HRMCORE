#!/usr/bin/env python3
"""HRM_UNIFIED v3.3.1 real data API connector utilities.

This layer fixes the v3.3 weakness: launchers and adapters can now discover
API keys consistently from local-only sources without hardcoding secrets into
source code or the release zip.
"""
from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

ENGINE_VERSION = "3.3.1"
KEY_NAMES = ("DATASET_API_KEY", "CENSUS_API_KEY", "ACS_API_KEY")
ENV_FILES = (".env", ".env.user")


def load_env_files(base_dir: str | Path | None = None) -> Dict[str, str]:
    """Load .env/.env.user into os.environ without overwriting existing env vars."""
    root = Path(base_dir or Path.cwd())
    loaded: Dict[str, str] = {}
    for name in ENV_FILES:
        p = root / name
        if not p.exists():
            continue
        for raw in p.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if not key:
                continue
            loaded[key] = value
            os.environ.setdefault(key, value)
    return loaded


def get_dataset_api_key(explicit: str | None = None, base_dir: str | Path | None = None) -> Optional[str]:
    """Return a dataset/Census key from explicit arg, environment, or .env files."""
    if explicit and explicit.strip() and "PASTE_" not in explicit:
        return explicit.strip()
    load_env_files(base_dir)
    for name in KEY_NAMES:
        value = os.getenv(name)
        if value and value.strip() and "PASTE_" not in value:
            return value.strip()
    return None


def masked_key(key: str | None) -> str:
    if not key:
        return "not_found"
    if len(key) <= 8:
        return "***"
    return key[:4] + "..." + key[-4:]


@dataclass
class APIHealth:
    connector_version: str
    provider: str
    key_found: bool
    key_source_names_checked: List[str]
    key_preview: str
    live_fetch_attempted: bool
    live_fetch_ok: bool
    status: str
    notes: List[str]
    generated_at_unix: float

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def census_health_check(key: str | None = None, timeout: int = 15) -> APIHealth:
    """Small live Census call; safe to fail offline."""
    api_key = get_dataset_api_key(key, Path(__file__).resolve().parent)
    notes: List[str] = []
    live_ok = False
    attempted = False
    status = "offline_or_no_key"
    if not api_key:
        notes.append("No API key found. Set DATASET_API_KEY or CENSUS_API_KEY in environment, .env, or .env.user.")
    else:
        attempted = True
        url = "https://api.census.gov/data/2024/acs/acs5/profile?get=NAME,DP05_0001E&for=county:113&in=state:47&key=" + api_key
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "HRM_UNIFIED/3.3.1 real-data-api-connector"})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                payload = resp.read().decode("utf-8")
            data = json.loads(payload)
            if isinstance(data, list) and len(data) >= 2:
                live_ok = True
                status = "live_fetch_ok"
                notes.append("Census API live fetch succeeded for default health-check geography: state 47, county 113.")
            else:
                status = "unexpected_response"
                notes.append(f"Unexpected Census response shape: {type(data).__name__}")
        except urllib.error.HTTPError as exc:
            status = f"http_error_{exc.code}"
            notes.append(f"Census API returned HTTP {exc.code}. Key may be wrong, quota-limited, or query rejected.")
        except Exception as exc:
            status = "live_fetch_failed"
            notes.append(f"Live fetch failed: {type(exc).__name__}: {exc}")
    return APIHealth(
        connector_version=ENGINE_VERSION,
        provider="US Census ACS Data API",
        key_found=bool(api_key),
        key_source_names_checked=list(KEY_NAMES) + list(ENV_FILES),
        key_preview=masked_key(api_key),
        live_fetch_attempted=attempted,
        live_fetch_ok=live_ok,
        status=status,
        notes=notes,
        generated_at_unix=time.time(),
    )


def write_health_report(path: str | Path, health: APIHealth) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(health.to_dict(), indent=2, sort_keys=True), encoding="utf-8")
