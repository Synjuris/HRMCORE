# HRM_UNIFIED v3.3.1 — Real Data API Connector

Rebuild target: fix v3.3 real dataset API usage by adding a real connector module, safe key discovery, health reporting, and a Windows-safe launcher.

## Added

- `real_data_api_connector.py`
- `RUN_V3_3_1_REAL_DATA_API_CONNECTOR_WINDOWS_SAFE.bat`
- `REAL_DATA_API_CONNECTOR_v3_3_1_README.md`
- API key discovery from `DATASET_API_KEY`, `CENSUS_API_KEY`, `ACS_API_KEY`, `.env`, `.env.user`
- API health report: `api_health_report.json`
- Default ACS target for Jackson/Madison County baseline: TN state FIPS `47`, Madison County FIPS `113`
- Offline/sample fallback remains intact

## Fixed

- The Census ACS adapter now checks the generic dataset key variable, not only `CENSUS_API_KEY`.
- The real dataset runner can write API health output before calibration.
- The launcher now creates a `.env.user` template when missing.

## Safety

No API key is hardcoded into the package.
