# HRM Unified v4.33 — World Pressure + Subsistence Engine

This build is a full-package continuation from the v4.32 patched full package. It copies the entire v4.32 tree forward and adds the v4.33 world-pressure/subsistence layer.

## Added

- `das/subsistence.py`
  - Environment-driven season profiles: spring, summer, autumn, winter.
  - World-level drought and harsh-winter pressure.
  - Wild fauna ecology with population, reproduction, migration pressure, disease load, and overhunting pressure.
  - Hunting outcomes with success/failure, calories, hides, exhaustion, injury, and fauna depletion.
  - Gathering outcomes tied to plant growth and drought.
  - Proto-domestication pathway through repeated animal contact, tolerance, domestication, and herd wealth.
  - Herd births/deaths driven by season, disease, and winter pressure.
  - Subsistence benchmark metrics and `subsistence.json` output.

## Modified

- `das/run_sim.py`
  - Version moved to `v04.33`.
  - Default output root moved to `runs_v04_33`.
  - Benchmark file moved to `benchmark_v04_33.json`.
  - Instantiates `SubsistenceWorld` in `make_world_systems()`.
  - Applies seasonal pressure to each environment phase.
  - Emits world-level `season_transition` events.
  - Applies per-agent subsistence pressure each tick.
  - Includes subsistence metrics in periodic metrics and final summary.
  - Writes `subsistence.json` into each run folder.

## Architectural rule preserved

Seasons are coded into the environment/world layer, not hardcoded as fixed agent traits. Agents respond through existing pressure variables such as hunger, energy, safety, exhaustion, stress, resources, and culture.

## Validation run

Validated with:

```bash
cd hrm_unified/das
DAS_RUNS=1 DAS_TICKS=30 DAS_OUTPUT_ROOT=/mnt/data/build_v433_smoke python3 run_sim.py
```

Validation completed and wrote `benchmark_v04_33.json`.
