# HRM_UNIFIED v4.48 — Innovation Gate Fix + Death Module + Resume Harness

## Summary
Three major fixes identified from v4.47 assessment and tonight's session.

---

## Fixed

### 1. Innovation never firing (information.py, innovation.py)
Root cause: `specialist_present` messages only emitted on `apprenticeship_formed`
events, but `apprenticeship.apply_tick()` is a stub that emits nothing.
Without `specialist_present`, 9 of 14 recombination pairs could never match.

Fix (two parts):
- `information.py`: `specialist_present` now also emits on `hunt` events when
  agent has `specialization_depth > 0.12`. Resource event scanner broadened to
  include `gathering` and `hunt` event types.
- `innovation.py`: fidelity floor lowered 0.20 → 0.12 so messages that survive
  hop decay still qualify for recombination attempts.

Result: 588–965 innovation successes per 1000-tick run, 280–294 practice registry.

### 2. Death module not wired in experiment scripts (run_exp_E.py)
Root cause: `agent.check_death()` was never called in custom experiment scripts.
Aux events (homicide) were never processed. Result: zero deaths regardless of
stress level — founders running at stress 1.00 were immortal.

Fix: after each agent tick loop:
- `check_death()` called on every living agent
- `aux_events` iterated for homicide events; victims marked dead, death ledger
  updated, grief propagated
- `build_death_record()` and `psychology_mod.notify_death_to_population()` called
  with correct signatures

Result: 18–24 deaths per 1000-tick run. Gen0 founders now die. Grief propagates.

### 3. No true resume capability
Previous resume attempts were reseeds — new runs seeded from old population
state. RNG stream, practice registry, faction hostility, governance records,
and meme carrier assignments were all lost between sessions.

Fix: `run_exp_E_resume.py` — full continuation harness.

Restored on resume:
- Global RNG state (exact continuation of random stream)
- Per-agent RNG states
- Full practice registry (all practices, not top 10)
- Full culture pool (all memes + agent-meme assignments)
- Faction membership + full hostility matrix
- Governance leader records + legitimacy
- Death ledger
- Config hash (validated on startup)
- Session manifest (tracks tick ranges per session)

Not restored (reinitializes from seed, deterministic):
- Zone fauna objects (FaunaPopulation not directly JSON-serializable)

Modes:
- FULL: loads from checkpoint_full_NNNNNN.json (true resume)
- PARTIAL: falls back to old-style checkpoint (warns: RNG reseeded)
- RESEED: falls back to agents_final.json only (warns: not true resume)

Usage:
  python run_exp_E_resume.py                        # indefinite
  python run_exp_E_resume.py --ticks 2000
  python run_exp_E_resume.py --from /path/to/run_1
  python run_exp_E_resume.py --snap-every 250

---

## Added Files
- run_exp_E.py — experiment E with death module wired
- run_exp_E_1k.py — 1000-tick version of experiment E
- run_exp_E_resume.py — true resume harness

## Modified Files
- information.py — specialist_present on hunt success; broadened event scanner
- innovation.py — fidelity floor 0.20 → 0.12
