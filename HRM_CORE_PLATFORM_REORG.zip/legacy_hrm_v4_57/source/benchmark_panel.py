from __future__ import annotations

import hashlib
import json
from pathlib import Path
from inject import SyntheticPanel
from export_utils import ensure_dir, write_panel_result, safe_slug

BENCHMARK_STIMULI = [
    ("economic_shock", "Major layoffs and factory closures announced across Madison County."),
    ("crime_fear", "Police report a citywide spike in robberies near schools and shopping centers."),
    ("public_health", "Hospitals issue a public warning about a severe flu outbreak."),
    ("community_support", "Neighborhood churches and volunteers launch a large food relief program."),
    ("policy_controversy", "City council passes a controversial new tax policy after a heated public meeting."),
]


def main() -> None:
    out = ensure_dir("outputs/benchmark")
    aggregate = []
    for name, text in BENCHMARK_STIMULI:
        panel = SyntheticPanel(n=500, seed=42)
        result = panel.inject(text, run_ticks=30, inject_tick=5)
        write_panel_result(result, out, prefix=f"{name}_{safe_slug(text)}", include_raw=False)
        aggregate.append({
            "name": name,
            "stimulus": text,
            "delta": result.delta,
            "control_post": result.control_post,
            "post_injection": result.post_injection,
        })

    payload = json.dumps(aggregate, sort_keys=True, indent=2)
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    (out / "benchmark_summary.json").write_text(payload, encoding="utf-8")
    (out / "benchmark_fingerprint.txt").write_text(digest + "\n", encoding="utf-8")
    print("Benchmark scenarios:", len(aggregate))
    print("Benchmark SHA256:", digest)
    print("Output:", out)


if __name__ == "__main__":
    main()
