#!/usr/bin/env python3
"""HRM_UNIFIED v2.9 World Inspection Dashboard.

Local-only dashboard for inspecting persistent HRM/DAS world outputs.
It serves only files from the selected world output directory and does not
require Flask, Node, npm, browser extensions, or Python file associations.
"""
from __future__ import annotations

from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, unquote
import argparse
import json
import mimetypes
import os
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from typing import Any, Dict, List, Optional

ENGINE_VERSION = "2.9"


def read_json(path: Path, default: Any) -> Any:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"error": f"Could not read {path.name}: {exc}"}
    return default


def read_text(path: Path, default: str = "") -> str:
    try:
        if path.exists():
            return path.read_text(encoding="utf-8", errors="replace")
    except Exception as exc:
        return f"Could not read {path.name}: {exc}"
    return default


def latest_default_world_dir() -> Path:
    candidates = [
        Path("outputs/human_social_dynamics_v2_8/default_world"),
        Path("outputs/persistent_world_v2_7/default_world"),
        Path("outputs/emergent_civilization_v2_6/default_world"),
    ]
    for c in candidates:
        if (c / "world_state_latest.json").exists() or c.exists():
            return c
    return candidates[0]


def compact_float(value: Any) -> Any:
    if isinstance(value, float):
        return round(value, 4)
    return value


def summarize_world(world_dir: Path) -> Dict[str, Any]:
    latest = read_json(world_dir / "world_state_latest.json", {})
    timeline = read_json(world_dir / "evolution_timeline.json", {"events": []})
    social = read_json(world_dir / "human_social_state_latest.json", {})
    state = latest.get("state", {}) if isinstance(latest, dict) else {}
    benchmark = latest.get("benchmark", {}) if isinstance(latest, dict) else {}
    events = timeline.get("events", []) if isinstance(timeline, dict) else []
    novelties = state.get("novelties", []) if isinstance(state, dict) else []
    institutions = state.get("institutions", []) if isinstance(state, dict) else []
    memory = state.get("memory", {}) if isinstance(state, dict) else {}
    social_state = state.get("human_social_dynamics", social) if isinstance(state, dict) else social
    return {
        "engine_version": ENGINE_VERSION,
        "world_dir": str(world_dir),
        "exists": world_dir.exists(),
        "latest_cycle": latest.get("cycle") if isinstance(latest, dict) else None,
        "latest_generation": latest.get("generation") if isinstance(latest, dict) else None,
        "latest_fingerprint": latest.get("fingerprint") if isinstance(latest, dict) else None,
        "created_at": latest.get("created_at") if isinstance(latest, dict) else None,
        "benchmark": {k: compact_float(v) for k, v in benchmark.items()},
        "counts": {
            "events": len(events),
            "novelties": len(novelties),
            "institutions": len(institutions),
            "cohorts": len(memory.get("cohorts", [])) if isinstance(memory, dict) else 0,
            "social_events": len(social_state.get("social_events", [])) if isinstance(social_state, dict) else 0,
            "lineages": len(social_state.get("lineages", [])) if isinstance(social_state, dict) else 0,
            "factions": len(social_state.get("factions", [])) if isinstance(social_state, dict) else 0,
        },
        "recent_events": events[-25:],
        "top_novelties": sorted([n for n in novelties if isinstance(n, dict)], key=lambda x: float(x.get("adoption", 0) or 0), reverse=True)[:25],
        "institutions": institutions[:50] if isinstance(institutions, list) else [],
        "memory": memory,
        "social": social_state,
    }


DASHBOARD_HTML = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>HRM_UNIFIED v2.9 World Dashboard</title>
<style>
:root{--bg:#0f1117;--panel:#171b24;--panel2:#202635;--text:#e8ebf2;--muted:#9aa5b5;--line:#30394d;--accent:#c6a15b;--bad:#d66868;--good:#74b984}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:14px/1.45 system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif}.wrap{max-width:1320px;margin:0 auto;padding:24px}.top{display:flex;justify-content:space-between;gap:16px;align-items:flex-start;margin-bottom:18px}.title h1{margin:0;font-size:24px}.title p{margin:6px 0 0;color:var(--muted)}.pill{border:1px solid var(--line);background:var(--panel);border-radius:999px;padding:8px 12px;color:var(--muted)}.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.card{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:14px;box-shadow:0 8px 24px rgba(0,0,0,.15)}.card h2{margin:0 0 10px;font-size:16px}.metric{font-size:26px;font-weight:700}.muted{color:var(--muted)}.section{margin-top:14px}.twocol{display:grid;grid-template-columns:1fr 1fr;gap:12px}.threecol{display:grid;grid-template-columns:1.2fr 1fr 1fr;gap:12px}table{width:100%;border-collapse:collapse}td,th{border-bottom:1px solid var(--line);padding:8px;text-align:left;vertical-align:top}th{color:var(--muted);font-weight:600}.tabs{display:flex;gap:8px;flex-wrap:wrap;margin:14px 0}.tabs button{background:var(--panel);border:1px solid var(--line);border-radius:999px;color:var(--text);padding:9px 12px;cursor:pointer}.tabs button.active{background:var(--accent);color:#15120a;border-color:var(--accent)}.tab{display:none}.tab.active{display:block}pre{white-space:pre-wrap;word-break:break-word;background:#0b0d12;border:1px solid var(--line);border-radius:12px;padding:12px;max-height:520px;overflow:auto}.bar{height:8px;background:var(--panel2);border-radius:99px;overflow:hidden}.bar span{display:block;height:100%;background:var(--accent)}a{color:var(--accent)}.controls{display:flex;gap:8px;flex-wrap:wrap}.controls input{background:var(--panel);border:1px solid var(--line);border-radius:10px;color:var(--text);padding:9px;min-width:260px}.controls button{background:var(--accent);border:0;border-radius:10px;color:#16130b;padding:9px 12px;font-weight:700;cursor:pointer}@media(max-width:900px){.grid,.twocol,.threecol{grid-template-columns:1fr}.top{display:block}.controls input{min-width:100%}}
</style>
</head>
<body><div class="wrap">
<div class="top"><div class="title"><h1>HRM_UNIFIED v2.9 World Inspection Dashboard</h1><p id="subtitle">Local world-state inspection. No cloud connection.</p></div><div class="pill" id="status">loading</div></div>
<div class="controls"><input id="filter" placeholder="Filter tables by text…"><button onclick="refresh()">Refresh</button><button onclick="markViewed()">Mark viewed</button></div>
<div class="grid section" id="metrics"></div>
<div class="tabs"><button class="active" onclick="showTab('overview',this)">Overview</button><button onclick="showTab('events',this)">Events</button><button onclick="showTab('novelties',this)">Ideas/Products/Discoveries</button><button onclick="showTab('institutions',this)">Institutions</button><button onclick="showTab('social',this)">Human Social Dynamics</button><button onclick="showTab('reports',this)">Reports</button><button onclick="showTab('raw',this)">Raw State</button></div>
<div id="overview" class="tab active"></div><div id="events" class="tab"></div><div id="novelties" class="tab"></div><div id="institutions" class="tab"></div><div id="social" class="tab"></div><div id="reports" class="tab"></div><div id="raw" class="tab"></div>
</div><script>
let DATA=null, REPORTS=null;
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const pct=x=>Math.max(0,Math.min(100,Number(x||0)*100));
function row(k,v){return `<tr><th>${esc(k)}</th><td>${esc(typeof v==='number'?Math.round(v*10000)/10000:v)}</td></tr>`}
function table(rows,cols){let f=(document.getElementById('filter').value||'').toLowerCase();rows=(rows||[]).filter(r=>!f||JSON.stringify(r).toLowerCase().includes(f));return `<table><thead><tr>${cols.map(c=>`<th>${esc(c.label)}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${cols.map(c=>`<td>${esc(c.get(r))}</td>`).join('')}</tr>`).join('')}</tbody></table>`}
function metric(label,value,sub=''){return `<div class="card"><div class="muted">${esc(label)}</div><div class="metric">${esc(value??'—')}</div><div class="muted">${esc(sub)}</div></div>`}
function showTab(id,btn){document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.tabs button').forEach(x=>x.classList.remove('active'));document.getElementById(id).classList.add('active');btn.classList.add('active')}
async function refresh(){
  const [d,r]=await Promise.all([fetch('/api/world').then(r=>r.json()),fetch('/api/reports').then(r=>r.json())]); DATA=d; REPORTS=r; render();
}
async function markViewed(){await fetch('/api/mark-viewed',{method:'POST'}); await refresh();}
function render(){
 document.getElementById('status').textContent=DATA.exists?'world loaded':'no world output yet';
 document.getElementById('subtitle').textContent=`World dir: ${DATA.world_dir}`;
 document.getElementById('metrics').innerHTML=[metric('Cycle',DATA.latest_cycle),metric('Generation',DATA.latest_generation),metric('Events',DATA.counts.events),metric('Novelties',DATA.counts.novelties),metric('Institutions',DATA.counts.institutions),metric('Social events',DATA.counts.social_events),metric('Lineages',DATA.counts.lineages),metric('Fingerprint',String(DATA.latest_fingerprint||'none').slice(0,12))].join('');
 const b=DATA.benchmark||{};
 document.getElementById('overview').innerHTML=`<div class="twocol"><div class="card"><h2>Benchmark</h2><table>${Object.keys(b).sort().map(k=>row(k,b[k])).join('')}</table></div><div class="card"><h2>Memory / Cohorts</h2><pre>${esc(JSON.stringify(DATA.memory,null,2))}</pre></div></div>`;
 document.getElementById('events').innerHTML=`<div class="card"><h2>Recent Timeline Events</h2>${table(DATA.recent_events,[{label:'Cycle',get:r=>r.cycle},{label:'Gen',get:r=>r.generation},{label:'Type',get:r=>r.event_type},{label:'Severity',get:r=>r.severity},{label:'Message',get:r=>r.message}])}</div>`;
 document.getElementById('novelties').innerHTML=`<div class="card"><h2>Ideas / Products / Discoveries</h2>${table(DATA.top_novelties,[{label:'Name',get:r=>r.name},{label:'Kind',get:r=>r.kind||r.type},{label:'Adoption',get:r=>r.adoption},{label:'Normalization',get:r=>r.normalization},{label:'Resistance',get:r=>r.resistance},{label:'Generated',get:r=>r.generated}])}</div>`;
 document.getElementById('institutions').innerHTML=`<div class="card"><h2>Institutions</h2>${table(DATA.institutions,[{label:'Name',get:r=>r.name},{label:'Type',get:r=>r.type},{label:'Legitimacy',get:r=>r.legitimacy},{label:'Enforcement',get:r=>r.enforcement_style},{label:'Doctrine',get:r=>r.doctrine},{label:'Stability',get:r=>r.stability}])}</div>`;
 document.getElementById('social').innerHTML=`<div class="threecol"><div class="card"><h2>Social State</h2><pre>${esc(JSON.stringify(DATA.social,null,2))}</pre></div><div class="card"><h2>Factions</h2><pre>${esc(JSON.stringify((DATA.social||{}).factions||[],null,2))}</pre></div><div class="card"><h2>Lineages / Kinship</h2><pre>${esc(JSON.stringify((DATA.social||{}).lineages||[],null,2))}</pre></div></div>`;
 document.getElementById('reports').innerHTML=`<div class="twocol"><div class="card"><h2>Since Last Viewed</h2><pre>${esc(REPORTS.since_last_viewed||'No report found yet.')}</pre></div><div class="card"><h2>Human Social Dynamics Report</h2><pre>${esc(REPORTS.human_social||'No report found yet.')}</pre></div></div>`;
 document.getElementById('raw').innerHTML=`<div class="card"><h2>Raw Dashboard Payload</h2><pre>${esc(JSON.stringify(DATA,null,2))}</pre></div>`;
}
document.getElementById('filter').addEventListener('input',()=>DATA&&render());
refresh().catch(e=>{document.getElementById('status').textContent='error';document.getElementById('raw').innerHTML='<pre>'+esc(e.stack||e)+'</pre>'});
</script></body></html>'''


class DashboardHandler(BaseHTTPRequestHandler):
    world_dir: Path = latest_default_world_dir()

    def log_message(self, fmt: str, *args: Any) -> None:
        # Keep console clean while still allowing hard errors through exceptions.
        return

    def send_json(self, payload: Any, status: int = 200) -> None:
        data = json.dumps(payload, indent=2, sort_keys=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_text(self, payload: str, content_type: str = "text/plain; charset=utf-8", status: int = 200) -> None:
        data = payload.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path in ("/", "/index.html"):
            return self.send_text(DASHBOARD_HTML, "text/html; charset=utf-8")
        if path == "/api/world":
            return self.send_json(summarize_world(self.world_dir))
        if path == "/api/reports":
            reports_dir = self.world_dir / "reports"
            return self.send_json({
                "since_last_viewed": read_text(reports_dir / "since_last_viewed_report.md"),
                "human_social": read_text(reports_dir / "human_social_dynamics_report.md"),
            })
        if path.startswith("/files/"):
            rel = Path(unquote(path[len("/files/"):]))
            target = (self.world_dir / rel).resolve()
            root = self.world_dir.resolve()
            if root not in target.parents and target != root:
                return self.send_text("Forbidden", status=403)
            if not target.exists() or not target.is_file():
                return self.send_text("Not found", status=404)
            ctype = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
            data = target.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        return self.send_text("Not found", status=404)

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        if path == "/api/mark-viewed":
            latest = read_json(self.world_dir / "world_state_latest.json", {})
            if latest:
                out = self.world_dir / "world_state_last_viewed.json"
                out.write_text(json.dumps(latest, indent=2, sort_keys=True), encoding="utf-8")
                return self.send_json({"ok": True, "marked": str(out)})
            return self.send_json({"ok": False, "error": "No latest checkpoint found."}, status=404)
        return self.send_text("Not found", status=404)


def choose_port(preferred: int) -> int:
    for port in [preferred] + list(range(preferred + 1, preferred + 20)):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    return preferred


def main() -> int:
    ap = argparse.ArgumentParser(description="Run HRM_UNIFIED v2.9 local world inspection dashboard.")
    ap.add_argument("--world-dir", default=str(latest_default_world_dir()), help="World output directory containing world_state_latest.json.")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--no-browser", action="store_true")
    args = ap.parse_args()

    world_dir = Path(args.world_dir)
    DashboardHandler.world_dir = world_dir
    port = choose_port(args.port)
    server = ThreadingHTTPServer((args.host, port), DashboardHandler)
    url = f"http://{args.host}:{port}/"
    print("HRM_UNIFIED v2.9 WORLD INSPECTION DASHBOARD")
    print(f"World directory: {world_dir}")
    print(f"Dashboard URL: {url}")
    print("Press CTRL+C to stop.")
    if not args.no_browser:
        threading.Timer(0.75, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nDashboard stopped.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
