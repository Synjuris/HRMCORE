# HRM_UNIFIED v2.2 — Endogenous Evolution Layer

## Purpose

v2.2 converts the HRM/DAS bridge from one-way pressure translation into a controlled feedback loop:

```text
HRM civic pressure
    -> DAS substrate adaptation
    -> bounded endogenous feedback
    -> future civic baseline shift
```

This does not claim real-world prediction. It makes synthetic history path-dependent inside the package.

## Added

- `bridge/endogenous.py`
- `run_endogenous_evolution.py`
- `endogenous_benchmark.py`
- `--enable-das-feedback` flag in `run_environment.py`
- persistent endogenous feedback state in environment snapshots
- faction emergence markers
- institutional adaptation/degradation markers
- innovation/recombination markers
- cultural drift markers
- generational memory placeholder
- bounded baseline modifiers that alter later civic state

## Verified

- `python run_self_test.py`
- `python validate_engine.py`
- `python endogenous_benchmark.py`
- `python run_environment.py --n 200 --enable-das-feedback --no-observatory --output-dir outputs/smoke_v2_2`

## Boundaries

- No personal hardcoding
- No locality-specific hardcoding
- No API key embedded
- DAS feedback remains optional and inspectable
- Feedback is bounded and reportable
