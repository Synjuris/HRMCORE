#!/usr/bin/env python3
"""Entry point for HRM_UNIFIED v2.9 dashboard."""
try:
    from .world_dashboard import main
except ImportError:
    from world_dashboard import main

if __name__ == "__main__":
    raise SystemExit(main())
