"""Emergent civilization layer for HRM_UNIFIED v2.6.

This layer generalizes intervention beyond policies/events. It models novelty:
products, ideas, discoveries, doctrines, media forms, infrastructure concepts,
market instruments, and social movements. Novelty is metabolized by population,
institutions, cultural memory, and generational inheritance.

No real-world local facts or user-specific assumptions are encoded here.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List, Optional
import hashlib
import json
import math
import random
import time

ENGINE_VERSION = "2.6"

NOVELTY_TYPES = [
    "product",
    "idea",
    "discovery",
    "technology",
    "doctrine",
    "media_system",
    "market_instrument",
    "social_movement",
    "infrastructure_concept",
]

DEFAULT_NOVELTIES = [
    {
        "name": "low_cost_coordination_tool",
        "novelty_type": "technology",
        "benefit": 0.34,
        "disruption": 0.18,
        "contagion": 0.42,
        "institutional_threat": 0.10,
        "dependency_risk": 0.16,
        "equity_effect": 0.10,
        "description": "A generic tool that reduces coordination cost across groups.",
    },
    {
        "name": "status_market_product",
        "novelty_type": "product",
        "benefit": 0.18,
        "disruption": 0.28,
        "contagion": 0.55,
        "institutional_threat": 0.04,
        "dependency_risk": 0.38,
        "equity_effect": -0.12,
        "description": "A high-adoption consumer product that reshapes social attention.",
    },
    {
        "name": "resilience_doctrine",
        "novelty_type": "doctrine",
        "benefit": 0.28,
        "disruption": 0.08,
        "contagion": 0.30,
        "institutional_threat": 0.02,
        "dependency_risk": 0.05,
        "equity_effect": 0.15,
        "description": "A civic norm that increases mutual aid and long-run resilience.",
    },
    {
        "name": "automated_substitution_system",
        "novelty_type": "technology",
        "benefit": 0.30,
        "disruption": 0.42,
        "contagion": 0.35,
        "institutional_threat": 0.22,
        "dependency_risk": 0.32,
        "equity_effect": -0.18,
        "description": "A generic automation shift that improves throughput while destabilizing roles.",
    },
]


def _stamp() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _canonical(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def fingerprint(obj: Any) -> str:
    return hashlib.sha256(_canonical(obj).encode("utf-8")).hexdigest()


def _clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, float(value)))


def _as_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        if isinstance(value, float) and math.isnan(value):
            return default
        return float(value)
    except Exception:
        return default


def load_novelty_definitions(path: Optional[str]) -> List[Dict[str, Any]]:
    if not path:
        return list(DEFAULT_NOVELTIES)
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    if isinstance(raw, dict):
        raw = raw.get("novelties", [])
    if not isinstance(raw, list):
        raise ValueError("Novelty file must be a JSON list or object with a 'novelties' list.")
    return [dict(x) for x in raw]


@dataclass
class NoveltyState:
    name: str
    novelty_type: str
    benefit: float = 0.0
    disruption: float = 0.0
    contagion: float = 0.0
    institutional_threat: float = 0.0
    dependency_risk: float = 0.0
    equity_effect: float = 0.0
    adoption: float = 0.02
    resistance: float = 0.18
    normalization: float = 0.0
    institutional_reaction: float = 0.0
    cultural_lock_in: float = 0.0
    description: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class CivilizationEpochReport:
    generation: int
    label: str
    novelty_before: List[Dict[str, Any]]
    novelty_after: List[Dict[str, Any]]
    institutional_equilibrium: str
    civilization_metrics: Dict[str, float]
    dominant_shift: str
    warnings: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class CivilizationRunReport:
    version: str
    name: str
    epochs: List[CivilizationEpochReport]
    final_novelties: List[Dict[str, Any]]
    final_institutions: List[Dict[str, Any]]
    benchmark: Dict[str, Any]
    created_at: str = field(default_factory=_stamp)

    def to_dict(self) -> Dict[str, Any]:
        payload = {
            "version": self.version,
            "name": self.name,
            "epochs": [e.to_dict() for e in self.epochs],
            "final_novelties": self.final_novelties,
            "final_institutions": self.final_institutions,
            "benchmark": self.benchmark,
            "created_at": self.created_at,
        }
        payload["fingerprint"] = fingerprint(payload)
        return payload

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)


class EmergentCivilizationEngine:
    """Models adoption, resistance, institutional reaction, and normalization of novelty."""

    def __init__(self, novelties: Optional[List[Dict[str, Any]]] = None, seed: int = 42, invention_rate: float = 0.22):
        self.rng = random.Random(seed)
        self.invention_rate = _clamp(invention_rate, 0.0, 1.0)
        self.novelties = [self._coerce_novelty(n) for n in (novelties or DEFAULT_NOVELTIES)]
        self.generated_count = 0

    def _coerce_novelty(self, raw: Dict[str, Any]) -> NoveltyState:
        return NoveltyState(
            name=str(raw.get("name") or f"novelty_{len(raw)}"),
            novelty_type=str(raw.get("novelty_type") or raw.get("type") or "idea"),
            benefit=_as_float(raw.get("benefit"), 0.0),
            disruption=_as_float(raw.get("disruption"), 0.0),
            contagion=_as_float(raw.get("contagion"), 0.0),
            institutional_threat=_as_float(raw.get("institutional_threat"), 0.0),
            dependency_risk=_as_float(raw.get("dependency_risk"), 0.0),
            equity_effect=_as_float(raw.get("equity_effect"), 0.0),
            adoption=_clamp(_as_float(raw.get("adoption"), 0.02), 0.0, 1.0),
            resistance=_clamp(_as_float(raw.get("resistance"), 0.18), 0.0, 1.0),
            normalization=_clamp(_as_float(raw.get("normalization"), 0.0), 0.0, 1.0),
            institutional_reaction=_clamp(_as_float(raw.get("institutional_reaction"), 0.0), -1.0, 1.0),
            cultural_lock_in=_clamp(_as_float(raw.get("cultural_lock_in"), 0.0), 0.0, 1.0),
            description=str(raw.get("description") or ""),
        )

    def step(self, generation: int, civic_summary: Dict[str, float], memory_state: Dict[str, Any], institutions: Any, label: str = "epoch") -> CivilizationEpochReport:
        before = [n.to_dict() for n in self.novelties]
        self._maybe_generate_novelty(generation, civic_summary, memory_state)

        inst_state = institutions.to_dict() if hasattr(institutions, "to_dict") else {}
        inst_list = inst_state.get("institutions", []) if isinstance(inst_state, dict) else []
        avg_legitimacy = sum(_as_float(i.get("legitimacy")) for i in inst_list) / max(1, len(inst_list))
        max_collapse = max([_as_float(i.get("collapse_risk")) for i in inst_list] or [0.0])
        resilience = _as_float(memory_state.get("resilience_inheritance"), 0.0)
        cultural = memory_state.get("cultural_memory", {}) or {}
        uncertainty = _as_float(cultural.get("uncertainty_norm"), 0.0) + _as_float(civic_summary.get("volatility_pressure"), 0.0)
        withdrawal = _as_float(cultural.get("withdrawal_norm"), 0.0) + _as_float(civic_summary.get("withdrawal_pressure"), 0.0)
        cooperation = _as_float(cultural.get("cooperation_norm"), 0.0) + _as_float(civic_summary.get("cooperation_pressure"), 0.0)

        for n in self.novelties:
            institutional_friction = max(0.0, n.institutional_threat - max(0.0, avg_legitimacy) * 0.12)
            adoption_push = n.contagion * 0.24 + n.benefit * 0.20 + cooperation * 0.05 + resilience * 0.04 + uncertainty * 0.03
            resistance_push = n.disruption * 0.17 + n.dependency_risk * 0.14 + institutional_friction * 0.22 + withdrawal * 0.04 + max_collapse * 0.05
            n.resistance = round(_clamp(n.resistance * 0.74 + resistance_push, 0.0, 1.0), 6)
            n.adoption = round(_clamp(n.adoption + adoption_push * (1.0 - n.adoption) - n.resistance * 0.08, 0.0, 1.0), 6)
            n.normalization = round(_clamp(n.normalization * 0.82 + n.adoption * 0.18 - n.disruption * 0.03, 0.0, 1.0), 6)
            n.institutional_reaction = round(_clamp(n.institutional_reaction * 0.70 + institutional_friction * 0.35 - avg_legitimacy * 0.04, -1.0, 1.0), 6)
            n.cultural_lock_in = round(_clamp(n.cultural_lock_in * 0.80 + n.normalization * 0.12 + n.dependency_risk * n.adoption * 0.08, 0.0, 1.0), 6)

        metrics = self.metrics(memory_state, inst_state)
        warnings = self.warnings(metrics)
        return CivilizationEpochReport(
            generation=generation,
            label=label,
            novelty_before=before,
            novelty_after=[n.to_dict() for n in self.novelties],
            institutional_equilibrium=institutions.classify_equilibrium() if hasattr(institutions, "classify_equilibrium") else "unknown",
            civilization_metrics=metrics,
            dominant_shift=self.classify_shift(metrics),
            warnings=warnings,
        )

    def _maybe_generate_novelty(self, generation: int, civic_summary: Dict[str, float], memory_state: Dict[str, Any]) -> None:
        pressure = _as_float(civic_summary.get("stress_pressure"), 0.0) + _as_float(civic_summary.get("volatility_pressure"), 0.0)
        resilience = _as_float(memory_state.get("resilience_inheritance"), 0.0)
        chance = _clamp(self.invention_rate + pressure * 0.04 + resilience * 0.03, 0.0, 0.75)
        if self.rng.random() > chance:
            return
        self.generated_count += 1
        kind = self.rng.choice(NOVELTY_TYPES)
        generated = NoveltyState(
            name=f"generated_{kind}_{generation}_{self.generated_count}",
            novelty_type=kind,
            benefit=round(self.rng.uniform(0.08, 0.42), 4),
            disruption=round(self.rng.uniform(0.04, 0.45), 4),
            contagion=round(self.rng.uniform(0.12, 0.58), 4),
            institutional_threat=round(self.rng.uniform(0.00, 0.35), 4),
            dependency_risk=round(self.rng.uniform(0.02, 0.42), 4),
            equity_effect=round(self.rng.uniform(-0.22, 0.22), 4),
            adoption=0.01,
            resistance=0.15,
            description="Endogenously generated novelty produced by pressure/adaptation dynamics.",
        )
        self.novelties.append(generated)

    def metrics(self, memory_state: Dict[str, Any], inst_state: Dict[str, Any]) -> Dict[str, float]:
        count = max(1, len(self.novelties))
        avg_adoption = sum(n.adoption for n in self.novelties) / count
        avg_normalization = sum(n.normalization for n in self.novelties) / count
        disruption_load = sum(n.disruption * n.adoption for n in self.novelties) / count
        dependency_load = sum(n.dependency_risk * n.cultural_lock_in for n in self.novelties) / count
        benefit_realized = sum(n.benefit * n.adoption for n in self.novelties) / count
        institutional_threat = sum(max(0.0, n.institutional_reaction) * n.adoption for n in self.novelties) / count
        equity_shift = sum(n.equity_effect * n.adoption for n in self.novelties) / count
        resilience = _as_float(memory_state.get("resilience_inheritance"), 0.0)
        inst_list = inst_state.get("institutions", []) if isinstance(inst_state, dict) else []
        avg_legitimacy = sum(_as_float(i.get("legitimacy")) for i in inst_list) / max(1, len(inst_list))
        civilization_shift = benefit_realized + avg_normalization * 0.35 + resilience * 0.10 - disruption_load * 0.55 - dependency_load * 0.35 - institutional_threat * 0.25
        return {
            "novelty_count": float(len(self.novelties)),
            "generated_novelty_count": float(self.generated_count),
            "average_adoption": round(avg_adoption, 6),
            "average_normalization": round(avg_normalization, 6),
            "benefit_realized": round(benefit_realized, 6),
            "disruption_load": round(disruption_load, 6),
            "dependency_load": round(dependency_load, 6),
            "institutional_threat": round(institutional_threat, 6),
            "equity_shift": round(equity_shift, 6),
            "institutional_legitimacy_average": round(avg_legitimacy, 6),
            "civilization_shift_score": round(civilization_shift, 6),
        }

    def classify_shift(self, metrics: Dict[str, float]) -> str:
        score = metrics.get("civilization_shift_score", 0.0)
        threat = metrics.get("institutional_threat", 0.0)
        dependency = metrics.get("dependency_load", 0.0)
        disruption = metrics.get("disruption_load", 0.0)
        if score >= 0.22 and threat < 0.12:
            return "adaptive_acceleration"
        if dependency >= 0.16:
            return "dependency_lock_in"
        if disruption >= 0.18 or threat >= 0.16:
            return "destabilizing_transition"
        if score <= -0.05:
            return "maladaptive_absorption"
        return "mixed_civilization_shift"

    def warnings(self, metrics: Dict[str, float]) -> List[str]:
        out: List[str] = []
        if metrics.get("dependency_load", 0.0) >= 0.15:
            out.append("dependency_lock_in_risk")
        if metrics.get("institutional_threat", 0.0) >= 0.15:
            out.append("institutional_displacement_pressure")
        if metrics.get("disruption_load", 0.0) >= 0.18:
            out.append("social_disruption_pressure")
        if metrics.get("equity_shift", 0.0) <= -0.08:
            out.append("negative_equity_shift")
        return out

    def to_dict(self) -> Dict[str, Any]:
        payload = {"version": ENGINE_VERSION, "novelties": [n.to_dict() for n in self.novelties], "generated_count": self.generated_count}
        payload["fingerprint"] = fingerprint(payload)
        return payload


def civilization_markdown(report: CivilizationRunReport) -> str:
    data = report.to_dict()
    lines = [
        f"# HRM_UNIFIED v{report.version} Emergent Civilization Report",
        "",
        f"Run name: `{report.name}`",
        f"Created: `{data['created_at']}`",
        f"Fingerprint: `{data['fingerprint']}`",
        "",
        "## Benchmark",
        "",
    ]
    for k, v in report.benchmark.items():
        lines.append(f"- **{k}**: {v}")
    lines += ["", "## Generation Results", ""]
    for e in report.epochs:
        lines.append(f"### Generation {e.generation}: {e.dominant_shift}")
        lines.append(f"- Institutional equilibrium: {e.institutional_equilibrium}")
        for k, v in e.civilization_metrics.items():
            lines.append(f"- {k}: {v}")
        if e.warnings:
            lines.append(f"- warnings: {', '.join(e.warnings)}")
        lines.append("")
    lines += ["## Final Novelties", ""]
    for n in report.final_novelties:
        lines.append(f"- **{n.get('name')}** ({n.get('novelty_type')}): adoption={n.get('adoption')}, normalization={n.get('normalization')}, resistance={n.get('resistance')}")
    lines.append("")
    return "\n".join(lines)
