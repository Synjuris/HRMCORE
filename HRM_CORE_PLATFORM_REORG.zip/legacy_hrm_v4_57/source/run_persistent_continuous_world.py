#!/usr/bin/env python3
"""Run HRM_UNIFIED v2.7 persistent continuous world layer."""
from __future__ import annotations

import argparse
import time

try:
    from .population.history import HistoricalSimulator, load_timeline
    from .population.policy import load_policy_definitions, DEFAULT_POLICIES
    from .constitution import ConstitutionEngine
    from .generational_memory import GenerationalMemoryEngine, _summary_from_state
    from .institutional_evolution import InstitutionalEvolutionEngine
    from .emergent_civilization import EmergentCivilizationEngine, load_novelty_definitions
    from .world_persistence import PersistentWorldStore, extract_major_events, ENGINE_VERSION
except ImportError:
    from population.history import HistoricalSimulator, load_timeline
    from population.policy import load_policy_definitions, DEFAULT_POLICIES
    from constitution import ConstitutionEngine
    from generational_memory import GenerationalMemoryEngine, _summary_from_state
    from institutional_evolution import InstitutionalEvolutionEngine
    from emergent_civilization import EmergentCivilizationEngine, load_novelty_definitions
    from world_persistence import PersistentWorldStore, extract_major_events, ENGINE_VERSION


def main() -> int:
    ap = argparse.ArgumentParser(description="Run persistent continuous HRM world with checkpoint/replay reports.")
    ap.add_argument("timeline", nargs="?", help="Optional timeline JSON/YAML. Defaults to built-in generic timeline.")
    ap.add_argument("--policies", help="Optional policy definition JSON.")
    ap.add_argument("--novelties", help="Optional novelty/product/idea/discovery JSON.")
    ap.add_argument("--n", type=int, default=600)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--profile", default="generic_mixed_region")
    ap.add_argument("--decay", type=float, default=0.86)
    ap.add_argument("--cycles", type=int, default=3, help="Number of unattended cycles to run now. Use 0 with --report-only to only report.")
    ap.add_argument("--generations-per-cycle", type=int, default=2)
    ap.add_argument("--sleep", type=float, default=0.0, help="Seconds to sleep between cycles for continuous mode.")
    ap.add_argument("--autosave-every", type=int, default=1, help="Save checkpoint every N cycles.")
    ap.add_argument("--world-id", default="default_world")
    ap.add_argument("--output-dir", default="outputs/persistent_world_v2_7")
    ap.add_argument("--name", default="persistent_continuous_world")
    ap.add_argument("--resume", action="store_true", help="Resume cycle/generation counters from latest checkpoint.")
    ap.add_argument("--mark-viewed", action="store_true", help="Mark latest checkpoint as viewed after report generation.")
    ap.add_argument("--report-only", action="store_true", help="Only generate since-last-viewed report from existing checkpoints.")
    ap.add_argument("--cultural-decay", type=float, default=0.72)
    ap.add_argument("--institutional-decay", type=float, default=0.88)
    ap.add_argument("--cohort-turnover", type=float, default=0.30)
    ap.add_argument("--inheritance-strength", type=float, default=0.42)
    ap.add_argument("--mutation-rate", type=float, default=0.38)
    ap.add_argument("--invention-rate", type=float, default=0.24)
    args = ap.parse_args()

    store = PersistentWorldStore(args.output_dir, args.world_id)
    if args.report_only:
        report = store.write_since_report(mark_viewed=args.mark_viewed)
        print("HRM_UNIFIED v2.7 PERSISTENT CONTINUOUS WORLD")
        print("Report only mode.")
        print("Wrote:", report)
        return 0

    policies = load_policy_definitions(args.policies) if args.policies else DEFAULT_POLICIES
    timeline = load_timeline(args.timeline)
    novelties = load_novelty_definitions(args.novelties)

    memory = GenerationalMemoryEngine(
        cultural_decay=args.cultural_decay,
        institutional_decay=args.institutional_decay,
        cohort_turnover=args.cohort_turnover,
        inheritance_strength=args.inheritance_strength,
    )
    institutions = InstitutionalEvolutionEngine(mutation_rate=args.mutation_rate)
    civilization = EmergentCivilizationEngine(novelties=novelties, seed=args.seed, invention_rate=args.invention_rate)

    start_cycle = 0
    start_generation = 0
    if args.resume:
        latest = store.latest()
        if latest:
            start_cycle = int(latest.get("cycle", 0) or 0)
            start_generation = int(latest.get("generation", 0) or 0)

    constitution_failures = 0
    final_checkpoint = None

    for cycle_i in range(1, max(0, args.cycles) + 1):
        cycle = start_cycle + cycle_i
        last_epoch = None
        for gen_i in range(1, max(1, args.generations_per_cycle) + 1):
            generation = start_generation + ((cycle_i - 1) * max(1, args.generations_per_cycle)) + gen_i
            sim = HistoricalSimulator(n=args.n, seed=args.seed + generation - 1, profile=args.profile, decay=args.decay, policies=policies)
            memory.apply_baseline_to_simulator(sim)
            institutions.apply_to_simulator(sim)
            result = sim.run(timeline, name=f"{args.name}_cycle_{cycle}_generation_{generation}")
            audit = ConstitutionEngine().audit_historical_result(result)
            if not audit.passed:
                constitution_failures += 1
            summary = _summary_from_state(result.final_state)
            memory.encode_result(result, generation_label=f"generation_{generation}")
            institutions.evolve(memory.to_dict(), summary, generation=generation, label=str(timeline.get("name") or "default_timeline"))
            last_epoch = civilization.step(generation, summary, memory.to_dict(), institutions, label=str(timeline.get("name") or "default_timeline"))

        civ_state = civilization.to_dict()
        inst_state = institutions.to_dict()
        mem_state = memory.to_dict()
        final_metrics = last_epoch.civilization_metrics if last_epoch else {}
        benchmark = {
            "engine_version": ENGINE_VERSION,
            "cycles_completed": cycle,
            "generations_completed": start_generation + cycle_i * max(1, args.generations_per_cycle),
            "constitution_failures": constitution_failures,
            "novelty_count": int(final_metrics.get("novelty_count", 0.0)),
            "generated_novelty_count": int(final_metrics.get("generated_novelty_count", 0.0)),
            "final_shift": last_epoch.dominant_shift if last_epoch else "none",
            "average_adoption": final_metrics.get("average_adoption", 0.0),
            "average_normalization": final_metrics.get("average_normalization", 0.0),
            "civilization_shift_score": final_metrics.get("civilization_shift_score", 0.0),
            "civilization_fingerprint": civ_state.get("fingerprint"),
            "institution_fingerprint": inst_state.get("fingerprint"),
            "memory_fingerprint": mem_state.get("fingerprint"),
        }
        state = {
            "memory": mem_state,
            "institutions": inst_state.get("institutions", []),
            "novelties": civ_state.get("novelties", []),
            "civilization": civ_state,
        }
        if cycle % max(1, args.autosave_every) == 0 or cycle_i == args.cycles:
            final_checkpoint = store.save_checkpoint(cycle, benchmark["generations_completed"], state, benchmark, notes=["autosave"])
            for event in extract_major_events(cycle, benchmark["generations_completed"], benchmark, state):
                store.append_event(event)
        if args.sleep > 0 and cycle_i < args.cycles:
            time.sleep(args.sleep)

    report = store.write_since_report(mark_viewed=args.mark_viewed)
    print("HRM_UNIFIED v2.7 PERSISTENT CONTINUOUS WORLD")
    print(f"Cycles completed this run: {args.cycles}")
    print(f"Latest checkpoint: {final_checkpoint.get('checkpoint_file') if final_checkpoint else 'none'}")
    print("Wrote:")
    print("  latest:", store.latest_path)
    print("  timeline:", store.event_timeline_path)
    print("  report:", report)
    return 0 if constitution_failures == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())
