
from __future__ import annotations
from dataclasses import dataclass, field

@dataclass
class SimParams:
    # Core
    n: int = 800
    ticks: int = 150
    ticks_per_year: float = 50.0
    save_agent_state: bool = False

    # Influence
    peer_lambda: float = 0.08
    media_lambda: float = 0.02
    emotion_lambda: float = 0.2

    # Traits baseline
    trait_config: dict = field(default_factory=lambda: {})

    # Life
    enable_life: bool = True
    enable_homelessness: bool = True

    # Anchors (stubbed)
    real_world_anchor: bool = False
    anchor_data: dict | None = None
    anchor_strength: float = 0.5
    anchor_frequency: int = 10

    # Resonance
    enable_resonance: bool = True
    num_resonance: int = 6
    resonance_lambda: float = 0.08
    resonance_decay: float = 0.02
    resonance_learning: float = 0.4
    resonance_noise: float = 0.02

    # Demographics
    enable_identity_dimensions: bool = True
    demo_modifiers: dict = field(default_factory=lambda: {
        "life_stage": {
            "infant":      {"learning_rate": 1.0, "compliance": 1.0,  "emotionality": 1.0},
            "child":       {"learning_rate": 1.4, "compliance": 1.1,  "emotionality": 1.0},
            "adolescent":  {"learning_rate": 1.3, "compliance": 0.85, "emotionality": 1.2},
            "young_adult": {"learning_rate": 1.1, "compliance": 0.95, "emotionality": 1.05},
            "adult":       {"learning_rate": 1.0, "compliance": 1.0,  "emotionality": 1.0},
            "senior":      {"learning_rate": 0.8, "compliance": 1.05, "emotionality": 0.95, "memory_weight": 1.3},
        },
        "gender_expression": {"empathy": 0.05, "assertiveness": -0.05},
    })

    # Geography / regions
    num_regions: int = 4
    scenario_region_index: int | None = None

    # NLSI
    enable_nlsi: bool = True
    scenario_text: str | None = None
    scenario_tick: int = 0
    scenario_scale: float = 1.0
    scenario_delay: int = 1
    local_multiplier: float = 1.0
    national_multiplier: float = 0.5

    # Timeline
    enable_timeline: bool = False
    timeline_events: list = field(default_factory=list)

    # Socialization
    enable_social: bool = True
    avg_degree: int = 10
    rewire_p: float = 0.05
    trust_decay: float = 0.01
    new_link_prob: float = 0.001

    # Emotions
    enable_emotions: bool = True

def load_params_from_dict(d: dict) -> 'SimParams':
    return SimParams(**d)
