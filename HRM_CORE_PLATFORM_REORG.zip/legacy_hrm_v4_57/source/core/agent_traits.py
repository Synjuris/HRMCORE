# backend/hrm/core/agent_traits.py
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any
import math
import random

def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))

def sample_bounded(rng: random.Random, mean: float, var: float) -> float:
    if var <= 0:
        return clamp(mean)
    val = rng.normalvariate(mean, math.sqrt(var))
    return clamp(val)

@dataclass
class Traits:
    mood_stability: float
    impulse_control: float
    anxiety_reactivity: float
    social_sensitivity: float
    resource_level: float
    openness: float
    conscientiousness: float
    extraversion: float
    agreeableness: float
    neuroticism: float

@dataclass
class AgentState:
    valence: float = 0.0
    arousal: float = 0.3
    dominance: float = 0.5
    belief: float = 0.5
    stress: float = 0.0
    resources: float = 0.5
    last_action: str = "neutral"

@dataclass
class RelationshipEntry:
    """Lightweight per-dyad relationship state stored directly on Agent.
    Mirrors the fields used by RelationshipBook in relationships.py so the
    kernel can read them without importing that module.
    """
    trust: float = 0.5
    resentment: float = 0.0
    avoidance: float = 0.0

@dataclass
class Agent:
    id: int
    traits: Traits
    state: AgentState = field(default_factory=AgentState)
    neighbors: List[int] = field(default_factory=list)
    # Relational ledger: neighbor_id -> RelationshipEntry
    # Populated lazily on first interaction; kernel reads it during
    # neighbor aggregation to weight social signals by relationship quality.
    _relationships: Dict[int, RelationshipEntry] = field(default_factory=dict)

    def get_relationship(self, other_id: int) -> "RelationshipEntry":
        if other_id not in self._relationships:
            self._relationships[other_id] = RelationshipEntry()
        return self._relationships[other_id]

    def update_relationship(
        self,
        other_id: int,
        trust_delta: float = 0.0,
        resentment_delta: float = 0.0,
        avoidance_delta: float = 0.0,
    ) -> None:
        r = self.get_relationship(other_id)
        r.trust = clamp(r.trust + trust_delta)
        r.resentment = clamp(r.resentment + resentment_delta)
        r.avoidance = clamp(r.avoidance + avoidance_delta)

    def to_observation(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "traits": asdict(self.traits),
            "state": asdict(self.state),
            "neighbors": list(self.neighbors),
        }