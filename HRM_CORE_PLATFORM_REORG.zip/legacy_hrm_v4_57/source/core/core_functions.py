
from __future__ import annotations
import torch
from .utils import init_trait_vectors, to_cpu
from .life import init_life_vectors, update_life, STATUS_HOMELESS
from .resonance import init_resonance, update_resonance
from .anchor import apply_anchors
from .demographics import apply_demographic_modifiers
from .nlsi import parse_event_text, map_tags_to_effects
from .social import init_social, apply_social_influence
from .emotion import init_emotions, update_emotions
from .pecs_layers import init_pecs_state, update_pecs
from . import life_events

def simulate(params, gen=None, device="cpu", torch_dtype=torch.float32):
    n = int(params.n); T = int(params.ticks)
    FEATURES = 3  # ideology, satisfaction, affect
    IDEOLOGY, SATISFACTION, AFFECT = 0, 1, 2

    if gen is None: gen = torch.Generator()
    X = torch.zeros((n, FEATURES), device=device, dtype=torch_dtype)
    X[:, IDEOLOGY] = 2*torch.rand((n,), generator=gen, device=device, dtype=torch_dtype) - 1.0
    X[:, SATISFACTION] = 2*torch.rand((n,), generator=gen, device=device, dtype=torch_dtype) - 1.0
    X[:, AFFECT] = torch.rand((n,), generator=gen, device=device, dtype=torch_dtype)

    traits = init_trait_vectors(params.trait_config, n, gen, device, torch_dtype)
    life = init_life_vectors(params, n, gen, device, torch_dtype) if params.enable_life else None
    if params.enable_identity_dimensions:
        apply_demographic_modifiers(traits, life if life is not None else {}, params)
    field = init_resonance(params, device, torch_dtype, FEATURES, IDEOLOGY, SATISFACTION, gen) if params.enable_resonance else None
    social = init_social(n, gen, device, torch_dtype, int(getattr(params,"avg_degree",8)), float(getattr(params,"rewire_p",0.05))) if getattr(params,"enable_social",True) else None
    E = init_emotions(n, device, torch_dtype) if getattr(params,"enable_emotions",True) else None

    # PECS-style human layer (energy, intentions, roles)
    pecs = init_pecs_state(n, device, torch_dtype)


    # Timeline
    events_by_tick = {}
    for e in (getattr(params,'timeline_events',[]) or []):
        events_by_tick.setdefault(int(e["tick"]), []).append(e)

    # Scenario (single free-text)
    scenario_tags = None
    if getattr(params, "enable_nlsi", True) and getattr(params, "scenario_text", None):
        scenario_tags = parse_event_text(params.scenario_text)

    mean_ideol = torch.empty(T, device=device, dtype=torch_dtype)
    mean_sat   = torch.empty(T, device=device, dtype=torch_dtype)
    homeless_pct = torch.empty(T, device=device, dtype=torch_dtype)
    field_energy = torch.empty((T, int(params.num_resonance)), device=device, dtype=torch_dtype)

    for t in range(T):
        # Timeline events
        if events_by_tick.get(t):
            for ev in events_by_tick[t]:
                tags = parse_event_text(ev["text"])
                # local
                local_scope = float(tags.get("local_scope", 0.05))
                eff_local = map_tags_to_effects(tags, scale=float(ev.get("scale",1.0))*float(getattr(params,"local_multiplier",1.0)), scope_override=local_scope)
                mask = None
                if life is not None and ev.get("region_index") is not None:
                    mask = (life["region"] == int(ev["region_index"]))
                else:
                    mask = (torch.rand((n,), generator=gen, device=device) < local_scope)
                _apply_effects(mask, eff_local, X, life, field, IDEOLOGY, SATISFACTION, AFFECT)

                # national (delayed within the same tick if delay==0)
                delay = int(ev.get("delay", 0))
                if delay == 0:
                    nat_scope = float(tags.get("national_scope", max(0.6, float(tags.get("scope",0.6)))))
                    eff_nat = map_tags_to_effects(tags, scale=float(ev.get("scale",1.0))*float(getattr(params,"national_multiplier",0.5)), scope_override=nat_scope)
                    if life is not None and ev.get("region_index") is not None:
                        mask = (life["region"] != int(ev["region_index"])) & (torch.rand((n,), generator=gen, device=device) < nat_scope)
                    else:
                        mask = (torch.rand((n,), generator=gen, device=device) < nat_scope)
                    _apply_effects(mask, eff_nat, X, life, field, IDEOLOGY, SATISFACTION, AFFECT)
                else:
                    # record a pending national wave by scheduling into events_by_tick
                    events_by_tick.setdefault(t+delay, []).append({**ev, "text": ev["text"]+" [national_wave]", "delay": 0})

        # Single scenario (legacy)
        if scenario_tags is not None and t == int(getattr(params, "scenario_tick", 0)):
            eff = map_tags_to_effects(scenario_tags, scale=float(getattr(params, "scenario_scale", 1.0)), scope_override=float(scenario_tags.get("scope",1.0)))
            scope = float(eff.get("affect_d",0)) # not used; kept for interface compat

        # Social influence
        if social is not None:
            social = apply_social_influence(params, X, traits, life, social)

        # Emotions
        if E is not None:
            E, X = update_emotions(params, X, life, E)

        # Peer + media + resonance
        ideol = X[:, IDEOLOGY]
        affect = X[:, AFFECT]
        peer_target = ideol.mean()
        delta_peer = params.peer_lambda * traits["compliance"] * (peer_target - ideol)
        delta_media = params.media_lambda * (0.0 - ideol)
        if params.enable_resonance:
            delta_res = update_resonance(params, field, X, affect, device, torch_dtype, FEATURES, IDEOLOGY, SATISFACTION, None)
        else:
            delta_res = 0.0
        X[:, IDEOLOGY] = (ideol + delta_peer + delta_media + delta_res).clamp(-1,1)

        # Satisfaction update
        sat = X[:, SATISFACTION]
        base = 0.5 * (affect - 0.5)
        if life is not None:
            base += 0.2 * (life["health"] - 0.5) + 0.2 * (life["income"] - 0.5)
        X[:, SATISFACTION] = torch.clamp(sat + params.emotion_lambda * base, -1, 1)

        if life is not None:
            life = update_life(params, X, life, t, None, device, torch_dtype)

        apply_anchors(params, X, life, t)

        # Update PECS-style human layer (energy, intentions, roles)
        pecs = update_pecs(params, X, life, traits, pecs, t)

        # metrics
        mean_ideol[t] = X[:, IDEOLOGY].mean()
        mean_sat[t] = X[:, SATISFACTION].mean()
        if life is not None:
            homeless_pct[t] = (life["housing_status"] == STATUS_HOMELESS).float().mean()
        else:
            homeless_pct[t] = torch.tensor(0.0, device=device, dtype=torch_dtype)
        if params.enable_resonance:
            field_energy[t] = field["energy"]
        else:
            field_energy[t] = torch.zeros(int(params.num_resonance), device=device, dtype=torch_dtype)

    return {
        "metrics": {
            "mean_ideology": to_cpu(mean_ideol),
            "mean_satisfaction": to_cpu(mean_sat),
            "homeless_pct": to_cpu(homeless_pct),
            "resonance_energy": to_cpu(field_energy),
        },
        "summary": {}
    }

def _apply_effects(mask, eff, X, life, field, IDEOLOGY, SATISFACTION, AFFECT):
    if mask is None: return
    X[mask, AFFECT]       = (X[mask, AFFECT] + eff["affect_d"]).clamp(0.0, 1.0)
    X[mask, SATISFACTION] = (X[mask, SATISFACTION] + eff["satis_d"]).clamp(-1.0, 1.0)
    X[mask, IDEOLOGY]     = (X[mask, IDEOLOGY] + eff["ideology_d"]).clamp(-1.0, 1.0)
    if life is not None:
        life["stress"][mask] = (life["stress"][mask] + eff["stress_d"]).clamp(0.0, 1.0)
        life["income"][mask] = (life["income"][mask] + eff["income_d"]).clamp(0.0, 1.0)
    if field is not None and "energy" in field and eff.get("resonance_boost"):
        for idx, delta in eff["resonance_boost"].items():
            if 0 <= idx < field["energy"].shape[0]:
                field["energy"][idx] = (field["energy"][idx] + delta).clamp(0.0)