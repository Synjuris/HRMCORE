
# [HRM] life_events.py
#
# Unified life-shock + disease + community event system.
# Optional, deterministic, and non-intrusive:
# it only perturbs stress/support/trust inputs, which are already
# consumed by emotion.py -> resonance.py -> social/nlsi.py.

from __future__ import annotations

import csv
import os
import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any


@dataclass
class LifeEvent:
    type: str
    tick_start: int
    duration: int
    impact: float
    scope: str = "agent"  # "agent" | "region"
    meta: Dict[str, Any] = field(default_factory=dict)

    @property
    def tick_end(self) -> int:
        return self.tick_start + self.duration

    def active(self, tick: int) -> bool:
        return self.tick_start <= tick < self.tick_end


@dataclass
class EventTemplate:
    type: str
    impact: float
    duration: int
    min_age: int = 0
    max_age: int = 120
    base_prob_per_year: float = 0.0
    scope: str = "agent"
    category: str = "personal"


DEFAULT_TEMPLATES: List[EventTemplate] = [
    # Personal & economic
    EventTemplate("bereavement", -0.40, 40, min_age=15, base_prob_per_year=0.02, category="personal"),
    EventTemplate("job_loss", -0.30, 30, min_age=18, max_age=70, base_prob_per_year=0.05, category="economic"),
    EventTemplate("promotion", 0.30, 30, min_age=21, max_age=70, base_prob_per_year=0.03, category="economic"),
    EventTemplate("marriage", 0.25, 60, min_age=20, max_age=60, base_prob_per_year=0.03, category="social"),
    EventTemplate("divorce", -0.25, 60, min_age=22, max_age=70, base_prob_per_year=0.015, category="social"),
    EventTemplate("child_birth", 0.20, 45, min_age=20, max_age=45, base_prob_per_year=0.04, category="development"),
    EventTemplate("retirement", 0.10, 90, min_age=60, max_age=75, base_prob_per_year=0.10, category="development"),
    # Community / region
    EventTemplate("disaster", -0.35, 20, base_prob_per_year=0.005, scope="region", category="community"),
    EventTemplate("infrastructure_failure", -0.15, 10, base_prob_per_year=0.01, scope="region", category="community"),
    EventTemplate("crime_wave", -0.25, 30, base_prob_per_year=0.02, scope="region", category="community"),
    # Disease & recovery
    EventTemplate("illness_mild", -0.15, 7, base_prob_per_year=0.20, category="disease"),
    EventTemplate("illness_severe", -0.35, 21, base_prob_per_year=0.03, category="disease"),
    EventTemplate("recovery_boost", 0.25, 14, base_prob_per_year=0.0, category="disease"),
]


class LifeEventEngine:
    def __init__(self, seed: int = 0,
                 templates: Optional[List[EventTemplate]] = None,
                 base_path: str = "."):
        self.rng = random.Random(seed + 19871)
        self.templates = list(templates or DEFAULT_TEMPLATES)
        self.base_path = base_path
        self._load_external_profiles()

    def _load_external_profiles(self) -> None:
        # Optional: disease_profiles.csv
        disease_csv = os.path.join(self.base_path, "disease_profiles.csv")
        if os.path.exists(disease_csv):
            try:
                with open(disease_csv, newline="") as f:
                    for row in csv.DictReader(f):
                        try:
                            rate = float(row.get("annual_incidence_per_100k", "0")) / 100000.0
                        except ValueError:
                            rate = 0.0
                        self.templates.append(EventTemplate(
                            type=row.get("type", "disease_mild"),
                            impact=float(row.get("impact", "-0.15")),
                            duration=int(row.get("duration", "7")),
                            min_age=int(row.get("age_min", "0")),
                            max_age=int(row.get("age_max", "120")),
                            base_prob_per_year=rate,
                            category="disease",
                        ))
            except Exception:
                pass

        # Optional: region_shocks.csv
        region_csv = os.path.join(self.base_path, "region_shocks.csv")
        if os.path.exists(region_csv):
            try:
                with open(region_csv, newline="") as f:
                    for row in csv.DictReader(f):
                        try:
                            rate = float(row.get("annual_rate", "0"))
                        except ValueError:
                            rate = 0.0
                        self.templates.append(EventTemplate(
                            type=row.get("type", "region_shock"),
                            impact=float(row.get("impact", "-0.2")),
                            duration=int(row.get("duration", "14")),
                            base_prob_per_year=rate,
                            scope="region",
                            category="community",
                        ))
            except Exception:
                pass

    # -------- Assignment --------

    def assign_initial_events(self, agents, max_ticks: int, region_lookup=None) -> None:
        for a in agents:
            if not hasattr(a, "life_events"):
                a.life_events = []

        for a in agents:
            age = getattr(a, "age", 40)
            for tpl in self.templates:
                if tpl.scope != "agent":
                    continue
                if not (tpl.min_age <= age <= tpl.max_age):
                    continue
                if tpl.base_prob_per_year <= 0:
                    continue
                chance = min(1.0, tpl.base_prob_per_year)
                if self.rng.random() < chance:
                    start = self.rng.randint(1, max(1, max_ticks - tpl.duration))
                    a.life_events.append(LifeEvent(
                        type=tpl.type,
                        tick_start=start,
                        duration=tpl.duration,
                        impact=tpl.impact,
                        scope="agent",
                        meta={"category": tpl.category},
                    ))

        if region_lookup is not None:
            for tpl in self.templates:
                if tpl.scope != "region" or tpl.base_prob_per_year <= 0:
                    continue
                for region_id, region in region_lookup.items():
                    if not hasattr(region, "life_events"):
                        region.life_events = []
                    if self.rng.random() < tpl.base_prob_per_year:
                        start = self.rng.randint(1, max(1, max_ticks - tpl.duration))
                        region.life_events.append(LifeEvent(
                            type=tpl.type,
                            tick_start=start,
                            duration=tpl.duration,
                            impact=tpl.impact,
                            scope="region",
                            meta={"category": tpl.category},
                        ))

    # -------- Application --------

    def apply_agent_events(self, agent, tick: int) -> Dict[str, float]:
        if not hasattr(agent, "life_events"):
            return {"stress": 0.0, "support": 0.0, "trust": 0.0}
        total = 0.0
        for ev in agent.life_events:
            if ev.active(tick):
                total += ev.impact
        if total == 0:
            return {"stress": 0.0, "support": 0.0, "trust": 0.0}
        if total < 0:
            mag = -total
            return {"stress": +mag, "support": -0.5 * mag, "trust": -0.3 * mag}
        else:
            mag = total
            return {"stress": -0.5 * mag, "support": +mag, "trust": +0.2 * mag}

    def apply_region_events(self, region, tick: int) -> Dict[str, float]:
        if region is None or not hasattr(region, "life_events"):
            return {"stress": 0.0, "support": 0.0, "trust": 0.0}
        total = 0.0
        for ev in region.life_events:
            if ev.active(tick):
                total += ev.impact
        if total == 0:
            return {"stress": 0.0, "support": 0.0, "trust": 0.0}
        if total < 0:
            mag = -total
            return {"stress": +0.7 * mag, "support": -0.3 * mag, "trust": -0.4 * mag}
        else:
            mag = total
            return {"stress": -0.3 * mag, "support": +0.5 * mag, "trust": +0.3 * mag}

    # -------- Disease dynamics --------

    def step_disease(self, agents, tick: int,
                     infection_scale: float = 1.0,
                     recovery_prob: float = 0.02) -> None:
        infectious = 0
        for a in agents:
            for ev in getattr(a, "life_events", []):
                if ev.active(tick) and ev.type.startswith("illness"):
                    infectious += 1
                    break
        if infectious == 0:
            return
        pressure = infection_scale * infectious / max(1, len(agents))
        for a in agents:
            if not hasattr(a, "life_events"):
                a.life_events = []
            sick_now = any(ev.active(tick) and ev.type.startswith("illness")
                           for ev in a.life_events)
            if sick_now:
                if self.rng.random() < recovery_prob:
                    self._schedule_recovery(a, tick)
                continue
            if self.rng.random() < 0.02 * pressure:
                if self.rng.random() < 0.7:
                    etype, impact, dur = "illness_mild", -0.15, 7
                else:
                    etype, impact, dur = "illness_severe", -0.35, 21
                a.life_events.append(LifeEvent(
                    type=etype,
                    tick_start=tick,
                    duration=dur,
                    impact=impact,
                    scope="agent",
                    meta={"category": "disease"},
                ))

    def _schedule_recovery(self, agent, tick: int) -> None:
        agent.life_events.append(LifeEvent(
            type="recovery_boost",
            tick_start=tick,
            duration=14,
            impact=0.25,
            scope="agent",
            meta={"category": "disease"},
        ))


_ENGINE_CACHE: Dict[str, LifeEventEngine] = {}


def get_engine(key: str = "default", seed: int = 0, base_path: str = ".") -> LifeEventEngine:
    if key not in _ENGINE_CACHE:
        _ENGINE_CACHE[key] = LifeEventEngine(seed=seed, base_path=base_path)
    return _ENGINE_CACHE[key]


def initialize_life_events(agents,
                           max_ticks: int,
                           seed: int,
                           region_lookup=None,
                           base_path: str = ".",
                           key: str = "default") -> None:
    engine = get_engine(key=key, seed=seed, base_path=base_path)
    engine.assign_initial_events(agents, max_ticks=max_ticks, region_lookup=region_lookup)


def apply_all_life_effects(agent,
                           tick: int,
                           region=None,
                           key: str = "default") -> Dict[str, float]:
    engine = _ENGINE_CACHE.get(key)
    if engine is None:
        return {"stress": 0.0, "support": 0.0, "trust": 0.0}
    da = engine.apply_agent_events(agent, tick)
    dr = engine.apply_region_events(region, tick)
    return {
        "stress": da["stress"] + dr["stress"],
        "support": da["support"] + dr["support"],
        "trust": da["trust"] + dr["trust"],
    }


def step_disease_layer(agents, tick: int, key: str = "default") -> None:
    engine = _ENGINE_CACHE.get(key)
    if engine is not None:
        engine.step_disease(agents, tick)
