# backend/hrm/core/hrm_core_kernel.py
from __future__ import annotations

import json
import random
from dataclasses import asdict
from typing import Dict, Any, List, Optional

from .agent_traits import Agent, Traits, AgentState, clamp, sample_bounded

class Event:
    __slots__ = ("start", "end", "type", "intensity")

    def __init__(self, start: int, end: int, type: str, intensity: float):
        self.start = start
        self.end = end
        self.type = type
        self.intensity = float(intensity)

class EventEngine:
    def __init__(self, events_cfg: List[Dict[str, Any]]):
        self.events: List[Event] = [
            Event(
                start=int(e["start"]),
                end=int(e["end"]),
                type=str(e["type"]),
                intensity=float(e["intensity"]),
            )
            for e in events_cfg
        ]

    def active_events(self, t: int) -> List[Event]:
        return [e for e in self.events if e.start <= t <= e.end]

DEFAULT_CONFIG: Dict[str, Any] = {
    "seed": 42,
    "num_agents": 1000,
    "ticks": 200,
    "network": {"avg_degree": 6},
    "traits": {
        "mood_stability_mean": 0.7,
        "mood_stability_var": 0.10,
        "impulse_control_mean": 0.7,
        "impulse_control_var": 0.15,
        "anxiety_reactivity_mean": 0.4,
        "anxiety_reactivity_var": 0.15,
        "social_sensitivity_mean": 0.6,
        "social_sensitivity_var": 0.15,
        "resource_level_mean": 0.6,
        "resource_level_var": 0.20,
        "openness_mean": 0.5,
        "conscientiousness_mean": 0.6,
        "extraversion_mean": 0.5,
        "agreeableness_mean": 0.6,
        "neuroticism_mean": 0.4,
        "personality_var": 0.15,
    },
    "events": [
        {"start": 20, "end": 40, "type": "economic_stress", "intensity": 0.5},
        {"start": 60, "end": 80, "type": "fear_rumor", "intensity": 0.6},
        {"start": 120, "end": 130, "type": "positive_news", "intensity": 0.5},
    ],
    "emotion": {"base_decay": 0.08, "contagion_strength": 0.25},
    "belief": {"base_update_rate": 0.15},
    "stress": {
        "resource_stress_weight": 0.6,
        "event_stress_weight": 0.8,
        "social_stress_weight": 0.4,
        "relief_factor": 0.05,
    },
    "export": {
        "enabled": True,
        "path": "outputs/hrm_core_kernel_run.jsonl",
        "log_interval": 1,
        "sample_ratio": 1.0,
    },
}

class HRMCore:
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        base = dict(DEFAULT_CONFIG)
        if config:
            for k, v in config.items():
                if isinstance(v, dict) and k in base and isinstance(base[k], dict):
                    merged = dict(base[k])
                    merged.update(v)
                    base[k] = merged
                else:
                    base[k] = v
        self.config: Dict[str, Any] = base
        self.rng = random.Random(self.config.get("seed", 42))
        self.num_agents = int(self.config.get("num_agents", 200))
        self.emotion_cfg = self.config["emotion"]
        self.belief_cfg = self.config["belief"]
        self.stress_cfg = self.config["stress"]
        self.export_cfg = self.config["export"]
        self.event_engine = EventEngine(self.config.get("events", []))
        self.agents: List[Agent] = []
        self.t: int = 0
        self._init_agents()
        self._init_network()
        self._fh = None
        if self.export_cfg.get("enabled", False):
            path = self.export_cfg.get("path", "outputs/hrm_core_kernel_run.jsonl")
            import os
            os.makedirs(os.path.dirname(path), exist_ok=True)
            self._fh = open(path, "w", encoding="utf-8")

    def _init_agents(self) -> None:
        trs = self.config["traits"]
        for i in range(self.num_agents):
            traits = Traits(
                mood_stability=sample_bounded(self.rng, trs["mood_stability_mean"], trs["mood_stability_var"]),
                impulse_control=sample_bounded(self.rng, trs["impulse_control_mean"], trs["impulse_control_var"]),
                anxiety_reactivity=sample_bounded(self.rng, trs["anxiety_reactivity_mean"], trs["anxiety_reactivity_var"]),
                social_sensitivity=sample_bounded(self.rng, trs["social_sensitivity_mean"], trs["social_sensitivity_var"]),
                resource_level=sample_bounded(self.rng, trs["resource_level_mean"], trs["resource_level_var"]),
                openness=sample_bounded(self.rng, trs["openness_mean"], trs["personality_var"]),
                conscientiousness=sample_bounded(self.rng, trs["conscientiousness_mean"], trs["personality_var"]),
                extraversion=sample_bounded(self.rng, trs["extraversion_mean"], trs["personality_var"]),
                agreeableness=sample_bounded(self.rng, trs["agreeableness_mean"], trs["personality_var"]),
                neuroticism=sample_bounded(self.rng, trs["neuroticism_mean"], trs["personality_var"]),
            )
            state = AgentState(
                valence=0.0,
                arousal=0.3,
                dominance=0.5,
                belief=0.5,
                stress=0.0,
                resources=traits.resource_level,
                last_action="neutral",
            )
            self.agents.append(Agent(id=i, traits=traits, state=state))

    def _init_network(self) -> None:
        avg_deg = self.config["network"]["avg_degree"]
        for a in self.agents:
            a.neighbors = []
        target_edges = self.num_agents * avg_deg // 2
        attempts = 0
        max_attempts = self.num_agents * avg_deg * 10
        while target_edges > 0 and attempts < max_attempts:
            a = self.rng.randrange(self.num_agents)
            b = self.rng.randrange(self.num_agents)
            if a != b and (b not in self.agents[a].neighbors):
                self.agents[a].neighbors.append(b)
                self.agents[b].neighbors.append(a)
                target_edges -= 1
            attempts += 1

    def step(self) -> None:
        active_events = self.event_engine.active_events(self.t)
        global_mood_shift = 0.0
        global_stress_boost = 0.0
        rumor_push = 0.0
        for ev in active_events:
            if ev.type == "economic_stress":
                global_stress_boost += ev.intensity
            elif ev.type == "fear_rumor":
                rumor_push += ev.intensity
                global_stress_boost += ev.intensity * 0.5
            elif ev.type == "positive_news":
                global_mood_shift += ev.intensity
                global_stress_boost -= ev.intensity * 0.5
        neighbor_cache = self._compute_neighbor_aggregates()
        for agent in self.agents:
            self._update_agent(
                agent,
                neighbor_cache[agent.id],
                global_mood_shift,
                global_stress_boost,
                rumor_push,
            )
        self.t += 1
        self._maybe_log()

    def _compute_neighbor_aggregates(self) -> Dict[int, Dict[str, float]]:
        """Relationship-weighted neighbor aggregation.

        Each neighbor's contribution is modulated by the dyadic relationship:
        - trust amplifies valence contagion (good relationships carry mood)
        - resentment amplifies stress contagion (bad relationships spread tension)
        - avoidance attenuates all signals (checked-out neighbors barely register)

        Weight formula per neighbor n:
            signal_weight = trust * (1 - avoidance)          # how much their state lands
            stress_weight = (0.5 + resentment) * (1 - avoidance)  # resentment makes stress louder

        Falls back to uniform flat averaging (trust=0.5, resentment=0, avoidance=0)
        for neighbors with no relationship history yet — identical to prior behavior.
        """
        out: Dict[int, Dict[str, float]] = {}
        for agent in self.agents:
            if not agent.neighbors:
                out[agent.id] = {
                    "avg_valence": 0.0,
                    "avg_belief": 0.5,
                    "avg_stress": 0.0,
                }
                continue

            vs = bs = ss = 0.0
            total_sig_w = total_str_w = 0.0

            for nid in agent.neighbors:
                n = self.agents[nid]
                rel = agent.get_relationship(nid)

                signal_w = rel.trust * (1.0 - rel.avoidance)
                stress_w = (0.5 + rel.resentment) * (1.0 - rel.avoidance)

                # Floor weights so uninitialized relationships still contribute
                signal_w = max(signal_w, 0.05)
                stress_w = max(stress_w, 0.05)

                vs += n.state.valence * signal_w
                bs += n.state.belief  * signal_w
                ss += n.state.stress  * stress_w

                total_sig_w += signal_w
                total_str_w += stress_w

            out[agent.id] = {
                "avg_valence": vs / total_sig_w if total_sig_w > 0 else 0.0,
                "avg_belief":  bs / total_sig_w if total_sig_w > 0 else 0.5,
                "avg_stress":  ss / total_str_w if total_str_w > 0 else 0.0,
            }
        return out

    def _update_agent(
        self,
        agent: Agent,
        neighbors: Dict[str, float],
        global_mood_shift: float,
        global_stress_boost: float,
        rumor_push: float,
    ) -> None:
        s = agent.state
        tr = agent.traits
        resource_component = (1.0 - s.resources) * self.stress_cfg["resource_stress_weight"]
        social_component = neighbors["avg_stress"] * tr.social_sensitivity * self.stress_cfg["social_stress_weight"]
        event_component = max(0.0, global_stress_boost) * self.stress_cfg["event_stress_weight"]
        raw_stress = (resource_component + social_component + event_component)
        raw_stress *= (0.5 + tr.anxiety_reactivity)
        raw_stress -= self.stress_cfg["relief_factor"] * tr.mood_stability
        s.stress = clamp(raw_stress, 0.0, 1.0)
        base_decay = self.emotion_cfg["base_decay"]
        contagion_strength = self.emotion_cfg["contagion_strength"]
        target_valence = global_mood_shift - s.stress
        social_pull = neighbors["avg_valence"] * (tr.social_sensitivity * contagion_strength)
        effective_decay = base_decay * (1.0 + (1.0 - tr.mood_stability))
        new_val = s.valence * (1 - effective_decay) + effective_decay * (target_valence + social_pull)
        s.valence = max(-1.0, min(1.0, new_val))
        s.arousal = clamp(0.2 + 0.6 * s.stress + 0.2 * tr.extraversion)
        s.dominance = clamp(0.5 + 0.3 * (s.resources - s.stress))
        belief = s.belief
        base_rate = self.belief_cfg["base_update_rate"]
        social_weight = 0.5 + 0.5 * (tr.agreeableness + tr.social_sensitivity) / 2
        target_from_neighbors = neighbors["avg_belief"]
        new_belief = belief
        new_belief += base_rate * social_weight * (target_from_neighbors - belief)
        new_belief += 0.5 * base_rate * rumor_push
        s.belief = clamp(new_belief)
        s.last_action = self._choose_action(agent)
        delta_res = -0.02 * s.stress * (1.0 - tr.conscientiousness)
        if s.stress < 0.3:
            delta_res += 0.01 * tr.conscientiousness
        s.resources = clamp(s.resources + delta_res)

        # ── Relationship updates ───────────────────────────────────────────
        # Evolve dyadic state toward neighbors based on this tick's action.
        # This is what connects the relational layer to the kernel:
        # trust/resentment/avoidance now shift each tick, which feeds back
        # into next tick's weighted neighbor aggregation.
        self._update_relationships(agent)

    def _update_relationships(self, agent: Agent) -> None:
        """Evolve dyadic relationship state each tick based on agent's current action and stress.

        This is the restoring force that enables oscillation:
        - Prosocial actions build trust, reduce resentment
        - High stress bleeds resentment into all neighbor relationships
        - Withdrawal increases avoidance (reduces signal from those neighbors)
        - Passive recovery: resentment and avoidance decay slowly toward zero
          even with no interaction — people calm down if left alone

        These deltas are small by design. Relationship state moves on a slower
        timescale than emotional state, which is what creates the lag that
        produces oscillation rather than lockstep collapse.
        """
        s = agent.state
        action = s.last_action

        for nid in agent.neighbors:
            # Action-driven deltas
            if action == "prosocial_help":
                trust_d      =  0.008
                resentment_d = -0.004
                avoidance_d  = -0.003
            elif action == "impulsive_risk":
                trust_d      = -0.010
                resentment_d =  0.008
                avoidance_d  =  0.002
            elif action == "withdraw":
                trust_d      = -0.002
                resentment_d =  0.0
                avoidance_d  =  0.006
            elif action == "signal_threat":
                trust_d      = -0.004
                resentment_d =  0.005
                avoidance_d  =  0.002
            else:  # neutral / quiet
                trust_d      =  0.001
                resentment_d =  0.0
                avoidance_d  =  0.0

            # Stress bleeds resentment regardless of action
            stress_bleed = s.stress * 0.003
            resentment_d += stress_bleed

            # Passive recovery — resentment and avoidance decay toward zero
            # This is the "people calm down if left alone" mechanic
            rel = agent.get_relationship(nid)
            passive_resent_decay = -rel.resentment * 0.02
            passive_avoid_decay  = -rel.avoidance  * 0.015

            agent.update_relationship(
                nid,
                trust_delta      = trust_d,
                resentment_delta = resentment_d + passive_resent_decay,
                avoidance_delta  = avoidance_d  + passive_avoid_decay,
            )

    def _choose_action(self, agent: Agent) -> str:
        s = agent.state
        tr = agent.traits
        r = self.rng.random()
        if s.stress > 0.8 and tr.impulse_control < 0.4:
            return "impulsive_risk"
        if s.valence < -0.5 and s.stress > 0.6:
            return "withdraw"
        if s.valence > 0.4 and s.arousal > 0.5 and tr.extraversion > 0.6:
            return "prosocial_help"
        if s.belief > 0.7 and s.stress > 0.5:
            return "signal_threat" if r < 0.8 else "quiet"
        return "neutral"

    def observe_agent(self, agent_id: int) -> Dict[str, Any]:
        return self.agents[agent_id].to_observation()

    def observe_snapshot(self) -> List[Dict[str, Any]]:
        return [a.to_observation() for a in self.agents]

    def _maybe_log(self) -> None:
        if not self.export_cfg.get("enabled", False) or self._fh is None:
            return
        interval = int(self.export_cfg.get("log_interval", 1)) or 1
        if self.t % interval != 0:
            return
        ratio = float(self.export_cfg.get("sample_ratio", 1.0))
        for agent in self.agents:
            if ratio < 1.0 and self.rng.random() > ratio:
                continue
            record = {
                "t": self.t,
                "id": agent.id,
                "traits": asdict(agent.traits),
                "state": asdict(agent.state),
            }
            self._fh.write(json.dumps(record) + "\n")

    def close(self) -> None:
        if self._fh:
            self._fh.close()
            self._fh = None