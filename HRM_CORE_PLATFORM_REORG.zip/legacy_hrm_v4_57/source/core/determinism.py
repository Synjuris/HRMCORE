"""
core/determinism.py — deterministic runtime initialization and run fingerprinting.

v4.56: extended with RunFingerprint for reproducibility validation.
PYTHONHASHSEED is set externally before process start (see kernel __main__ guard).
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import sys
from pathlib import Path
from typing import Any, Dict

import random
try:
    import numpy as np
except ImportError:
    np = None


def initialize_determinism(seed: int | None) -> None:
    """
    Initialize global RNG state for deterministic runs.
    Safe no-op if seed is None.
    """
    if seed is None:
        return
    try:
        random.seed(seed)
        if np is not None:
            np.random.seed(seed)
    except Exception:
        pass


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_str(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


class RunFingerprint:
    """
    Captures a deterministic identity snapshot of a runtime instance.

    Used by ValidationHarness to compare runs for reproducibility.
    Reads runtime state non-mutatively.
    """

    def __init__(self, runtime: Any) -> None:
        self.runtime = runtime

    def build(self) -> Dict[str, Any]:
        cfg = getattr(self.runtime, "cfg", None)
        scheduler = getattr(self.runtime, "scheduler", None)
        return {
            "python_version": sys.version,
            "platform": platform.platform(),
            "python_hash_seed": os.environ.get("PYTHONHASHSEED"),
            "seed": getattr(cfg, "seed", None),
            "scheduler": getattr(scheduler, "name", "default"),
            "tick": getattr(self.runtime, "_tick", 0),
            "config_hash": self._config_hash(),
        }

    def _config_hash(self) -> str:
        cfg = getattr(self.runtime, "cfg", None)
        if cfg is None:
            return ""
        try:
            return sha256_str(canonical_json(cfg.to_dict()))
        except Exception:
            return ""

    def state_hash(self) -> str:
        agents = self.runtime.sorted_agents()
        state = {
            "tick": getattr(self.runtime, "_tick", 0),
            "agents": [_agent_fingerprint(a) for a in agents],
        }
        return sha256_str(canonical_json(state))

    def write(self, output_dir: str) -> None:
        payload = self.build()
        payload["state_hash"] = self.state_hash()
        path = Path(output_dir) / "run_fingerprint.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _agent_fingerprint(agent: Any) -> Dict[str, Any]:
    """Minimal deterministic agent snapshot for hashing."""
    state = getattr(agent, "state", None)
    return {
        "id": getattr(agent, "id", None),
        "creation_index": getattr(agent, "creation_index", None),
        "alive": getattr(agent, "alive", None),
        "generation": getattr(agent, "generation", None),
        "energy": round(float(getattr(state, "energy", 0.0)), 4) if state else None,
        "stress": round(float(getattr(state, "stress", 0.0)), 4) if state else None,
    }
