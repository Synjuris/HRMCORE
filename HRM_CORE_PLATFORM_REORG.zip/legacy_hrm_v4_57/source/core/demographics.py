
from __future__ import annotations
from typing import Dict
import torch

STAGES = ("infant","child","adolescent","young_adult","adult","senior")

def life_stage_from_age(age_years: torch.Tensor) -> torch.Tensor:
    stage = torch.full_like(age_years, 4, dtype=torch.long)
    stage[age_years < 30] = 3
    stage[age_years < 18] = 2
    stage[age_years < 13] = 1
    stage[age_years < 3]  = 0
    stage[age_years >= 65] = 5
    return stage

def apply_demographic_modifiers(traits: Dict[str, torch.Tensor], life: Dict[str, torch.Tensor], params) -> None:
    if not getattr(params, "enable_identity_dimensions", True):
        return
    if not traits:
        return
    any_tensor = next(iter(traits.values()))
    if "life_stage" not in life and "age" in life:
        life["life_stage"] = life_stage_from_age(life["age"])
    if "gender_expression_factor" not in life:
        life["gender_expression_factor"] = torch.full_like(life.get("age", any_tensor), 0.5)
    stage_mods = params.demo_modifiers.get("life_stage", {})
    ls = life.get("life_stage", None)
    if ls is not None:
        for idx, name in enumerate(STAGES):
            if name not in stage_mods:
                continue
            mask = (ls == idx)
            if not mask.any():
                continue
            mods = stage_mods[name]
            for k, mult in mods.items():
                if k in traits and isinstance(mult, (int, float)):
                    traits[k][mask] = traits[k][mask] * float(mult)
    gmods = params.demo_modifiers.get("gender_expression", {})
    gef = life["gender_expression_factor"].clamp(0.0, 1.0)
    if "empathy" in traits and "empathy" in gmods:
        traits["empathy"] = traits["empathy"] + gmods["empathy"] * (gef - 0.5)
    if "assertiveness" in traits and "assertiveness" in gmods:
        traits["assertiveness"] = traits["assertiveness"] + gmods["assertiveness"] * (gef - 0.5)
