
from __future__ import annotations
import torch

def init_resonance(params, device, dtype, FEATURES, IDEOLOGY, SATISFACTION, gen):
    K = int(params.num_resonance)
    centers = torch.zeros((K, FEATURES), device=device, dtype=dtype)
    ideos = torch.linspace(-1.0, 1.0, K, device=device, dtype=dtype)
    sats  = torch.linspace(-1.0, 1.0, K, device=device, dtype=dtype).flip(0)
    centers[:, IDEOLOGY] = ideos
    centers[:, SATISFACTION] = sats
    centers += 0.05 * (2*torch.rand((K, FEATURES), generator=gen, device=device, dtype=dtype) - 1.0)
    centers = torch.clamp(centers, -1.0, 1.0)
    energy = torch.zeros((K,), device=device, dtype=dtype)
    return {"centers": centers, "energy": energy}

def update_resonance(params, field, X, affect, device, dtype, FEATURES, IDEOLOGY, SATISFACTION, gen):
    ideol = X[:, IDEOLOGY]
    c = field["centers"]
    d = (ideol.view(-1,1) - c[:, IDEOLOGY].view(1,-1)).abs()
    base = torch.clamp(1.0 - d, 0.0, 1.0)
    emo  = 0.5 + affect.view(-1,1).clamp(0.0, 1.0) * 0.5
    resonance = base * emo
    mean_res = resonance.mean(dim=0)
    field["energy"] = (1.0 - params.resonance_decay) * field["energy"] + params.resonance_learning * mean_res
    field["energy"] += params.resonance_noise * (2*torch.rand(field["energy"].shape, generator=gen, device=device, dtype=dtype) - 1.0)
    field["energy"].clamp_(0.0)
    weights = field["energy"].clamp(min=1e-6)
    _, idx = d.min(dim=1)
    target = c[idx, IDEOLOGY]
    pull = params.resonance_lambda * weights[idx] * (target - ideol)
    return pull
