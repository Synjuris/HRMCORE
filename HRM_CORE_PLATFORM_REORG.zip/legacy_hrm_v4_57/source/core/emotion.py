
from __future__ import annotations
import torch

def init_emotions(n, device, dtype):
    return torch.zeros((n,4), device=device, dtype=dtype)  # fear, anger, hope, pride

def update_emotions(params, X, life, E):
    IDEO, SAT, AFF = 0,1,2
    fear, anger, hope, pride = 0,1,2,3
    stress = life["stress"] if life is not None else torch.zeros_like(X[:,0])
    support = life["support"] if life is not None else torch.zeros_like(X[:,0])
    E[:,fear]  = torch.clamp(E[:,fear]  + 0.20*stress + 0.30*(0.5 - X[:,AFF]), 0, 1)
    E[:,hope]  = torch.clamp(E[:,hope]  + 0.20*X[:,AFF] + 0.10*support, 0, 1)
    X[:,AFF]  = torch.clamp(X[:,AFF]  + params.emotion_lambda*0.2*(E[:,hope]-E[:,fear]), 0, 1)
    X[:,SAT]  = torch.clamp(X[:,SAT]  + 0.10*(E[:,hope]-E[:,fear]), -1, 1)
    return E, X
