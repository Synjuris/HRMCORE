
from __future__ import annotations
import torch

"""
PECS-style extensions for HRM v1.0 foundation (non-breaking).

This module adds:
- A lightweight "physis" layer (energy) linked to existing life + stress.
- A simple intention buffer derived from unmet needs proxies.
- A role / norm hook (optional) that can modulate traits.

The goal is to enrich human realism while:
- Keeping HRM deterministic and vectorized.
- Avoiding changes to the public simulate() API.
- Preserving backward compatibility: if not used, behavior is close
  to the original with only mild, bounded adjustments.
"""

def init_pecs_state(n:int, device:str, dtype):
    # Start everyone fully energized; intentions empty.
    return {
        "energy": torch.ones((n,), device=device, dtype=dtype),
        # Four generic intention channels: affiliation, security, control, mastery
        "intent_affil": torch.zeros((n,), device=device, dtype=dtype),
        "intent_secure": torch.zeros((n,), device=device, dtype=dtype),
        "intent_control": torch.zeros((n,), device=device, dtype=dtype),
        "intent_mastery": torch.zeros((n,), device=device, dtype=dtype),
        # Optional role weights and simple norm bias; left zero unless scenario sets.
        "role_weight_civic": torch.zeros((n,), device=device, dtype=dtype),
        "role_weight_family": torch.zeros((n,), device=device, dtype=dtype),
        "role_weight_worker": torch.zeros((n,), device=device, dtype=dtype),
    }


def update_pecs(params,
                X,
                life,
                traits,
                pecs,
                t:int):
    """
    Update PECS-style state and feed subtle effects back into HRM core.

    - Uses SAT (satisfaction) and AFFECT as proxies for psychological needs.
    - Uses life['stress'], life['health'] if available as physis inputs.
    - Intention channels become slow-moving biases; they do not overwrite X.

    This is intentionally conservative: it should not blow up calibrated
    behavior, only add structure for future use.
    """
    IDEOLOGY, SATISFACTION, AFFECT = 0, 1, 2

    # --- Physis: energy from health & stress --- #
    energy = pecs["energy"]
    # Base metabolic drain
    base_decay = getattr(params, "physis_decay", 0.005)
    energy = energy - base_decay

    if life is not None:
        stress = life.get("stress", torch.zeros_like(energy))
        health = life.get("health", torch.ones_like(energy))
    else:
        stress = torch.zeros_like(energy)
        health = torch.ones_like(energy)

    # Stress drains, health restores
    energy = energy - 0.01 * stress + 0.01 * (health - 0.5)

    # Clamp and keep for later use
    energy = torch.clamp(energy, 0.1, 1.0)  # never fully zero to avoid divide-by-zero behaviors
    pecs["energy"] = energy

    # --- Need proxies from X --- #
    sat = X[:, SATISFACTION].clamp(-1, 1)
    aff = X[:, AFFECT].clamp(0.0, 1.0)

    # Map to four coarse needs:
    # safety    ~ higher sat & lower stress
    # belonging ~ positive affect
    # autonomy  ~ sat + affect (very rough; can be refined)
    # competence~ sat and trend over time (here just sat proxy)
    safety_need    = (sat + 1) / 2.0 - 0.3 * stress
    belonging_need = aff
    autonomy_need  = ((sat + 1) / 2.0 + aff) / 2.0
    competence_need= (sat + 1) / 2.0

    # Lower value => stronger intention.
    intent_affil   = torch.clamp(1.0 - belonging_need, 0.0, 1.0)
    intent_secure  = torch.clamp(1.0 - safety_need, 0.0, 1.0)
    intent_control = torch.clamp(1.0 - autonomy_need, 0.0, 1.0)
    intent_mastery = torch.clamp(1.0 - competence_need, 0.0, 1.0)

    # Smooth intentions over time (slow, like goals)
    alpha = getattr(params, "intent_smoothing", 0.9)
    for key, target in [
        ("intent_affil", intent_affil),
        ("intent_secure", intent_secure),
        ("intent_control", intent_control),
        ("intent_mastery", intent_mastery),
    ]:
        prev = pecs[key]
        pecs[key] = torch.clamp(alpha * prev + (1 - alpha) * target, 0.0, 1.0)

    # --- Feed subtle effects back: energy gates reactivity --- #
    # Reduce extreme opinion & affect swings for exhausted agents.
    reactivity_scale = 0.5 + 0.5 * energy  # 0.5..1.0
    # scale satisfaction & affect small adjustments implicitly elsewhere by exposing this.
    pecs["reactivity_scale"] = reactivity_scale

    # --- Optional: roles / norms hook (no-op by default) --- #
    # These weights can be set by scenarios; here we only compute a soft aggregate
    # that can later be used to bias compliance/empathy etc.
    rw_c = pecs["role_weight_civic"]
    rw_f = pecs["role_weight_family"]
    rw_w = pecs["role_weight_worker"]
    total_rw = rw_c + rw_f + rw_w + 1e-6
    civic_share  = rw_c / total_rw
    family_share = rw_f / total_rw
    worker_share = rw_w / total_rw

    # Example: civic role -> slightly higher compliance,
    #          family role -> slightly higher empathy,
    #          worker role -> slightly higher assertiveness.
    if traits is not None:
        if "compliance" in traits:
            traits["compliance"] = torch.clamp(
                traits["compliance"] * (1.0 + 0.05 * civic_share),
                0.0, 2.0
            )
        if "empathy" in traits:
            traits["empathy"] = torch.clamp(
                traits["empathy"] * (1.0 + 0.05 * family_share),
                0.0, 2.0
            )
        if "assertiveness" in traits:
            traits["assertiveness"] = torch.clamp(
                traits["assertiveness"] * (1.0 + 0.05 * worker_share),
                0.0, 2.0
            )

    return pecs
