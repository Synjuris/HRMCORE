@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo ============================================================
echo HRM_UNIFIED v3.1 - Era Seeding / Reality Baseline
echo Folder: %CD%
echo ============================================================
echo.

set "PYTHON_CMD="
where py >nul 2>nul
if %ERRORLEVEL%==0 set "PYTHON_CMD=py -3"
if not defined PYTHON_CMD (
  where python >nul 2>nul
  if %ERRORLEVEL%==0 set "PYTHON_CMD=python"
)
if not defined PYTHON_CMD (
  where python3 >nul 2>nul
  if %ERRORLEVEL%==0 set "PYTHON_CMD=python3"
)
if not defined PYTHON_CMD (
  echo ERROR: Python was not found.
  echo Install Python 3.11+ from https://www.python.org/downloads/ and check "Add Python to PATH".
  pause
  exit /b 1
)

echo Using Python command: %PYTHON_CMD%
%PYTHON_CMD% --version

echo.
echo Running modern/current baseline smoke run...
%PYTHON_CMD% run_era_seeding.py --era modern --start-year 2026 --location "generic" --mode toy --n 150 --cycles 1 --generations-per-cycle 1 --world-id reality_seeded_world_v3_1 --output-dir outputs/era_seeded_world_v3_1
set "RC=%ERRORLEVEL%"

echo.
if not "%RC%"=="0" (
  echo Run finished with warning/error code %RC%.
  echo Check outputs\era_seeded_world_v3_1\reality_seeded_world_v3_1\reports
) else (
  echo Run complete.
  echo Reports:
  echo outputs\era_seeded_world_v3_1\reality_seeded_world_v3_1\reports\reality_divergence_report.md
)

echo.
pause
exit /b %RC%
