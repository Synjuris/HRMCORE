# HRM Unified v4.32 — Continuity Engine Recovery Build

This package is a complete recovered build assembled from the full historical chain available in this session:

v2.6 → v2.7 → v2.8 → v2.9 → v3.0 → v3.1 → v3.2 → v3.3 → v3.3.1 → v4.31 overlay → v4.32 continuity layer.

## What changed in v4.32

- Adds `das/continuity.py`.
- Writes per-run continuity artifacts under `runs.../run_N/continuity/`:
  - `life_history_ledger.json`
  - `lineages.json`
  - `death_memory.json`
  - `culture_timeline.json`
  - `civilization_chronicle.md`
- Updates DAS run summary with continuity counts.
- Preserves v4.31 psychology/development overlay files.
- Restores missing runtime support modules required by the DAS runner.

## Recovery note

The uploaded v4.31 archive was an overlay, not a complete runnable package. This build uses the latest complete v3.x package plus all available subsequent overlay files, then adds v4.32.
