#!/usr/bin/env python3
"""Deterministic benchmark for HRM_UNIFIED v1.6 civic dynamics."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

try:
    from .population.civic_dynamics import run_civic_sequence
    from .export_utils import ensure_dir
except ImportError:
    from population.civic_dynamics import run_civic_sequence
    from export_utils import ensure_dir


def main() -> int:
    result = run_civic_sequence(n=600, seed=1606, profile="generic_mixed_region", decay=0.86)
    payload = json.loads(result.to_json())
    # Stable fingerprint excludes full free-form event messages only if needed later;
    # for now every threshold and event is intentionally part of regression behavior.
    fingerprint = hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()
    out = ensure_dir("outputs/civic_v1_6")
    report = {
        "version": "HRM_UNIFIED_v1.6_EMERGENT_CIVIC_DYNAMICS",
        "fingerprint": fingerprint,
        "event_count": len(result.events),
        "final_state": result.final_state.summary(),
        "events": [e.to_dict() for e in result.events],
    }
    p = Path(out) / "civic_benchmark.json"
    p.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("HRM_UNIFIED v1.6 civic benchmark complete")
    print(f"fingerprint: {fingerprint}")
    print(f"events: {len(result.events)}")
    print(f"wrote: {p}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
