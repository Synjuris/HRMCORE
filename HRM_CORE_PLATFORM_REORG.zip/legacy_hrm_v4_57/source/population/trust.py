"""Trust-channel routing and heterogeneous response weights."""
from __future__ import annotations

from typing import Dict, Any

from .calibration import SegmentProfile, clamp

SOURCE_HINTS = {
    "authority": ["official", "agency", "government", "mayor", "court", "police", "school board", "public health", "regulator"],
    "media": ["news", "report", "broadcast", "article", "headline", "journalist"],
    "peer": ["friend", "neighbor", "coworker", "family", "heard", "rumor", "shared"],
    "local": ["local", "nearby", "neighborhood", "community", "town", "city", "county"],
    "institutional": ["hospital", "school", "employer", "bank", "utility", "university", "company"],
}


def infer_source_channel(text: str) -> str:
    t = text.lower()
    hits = {k: 0 for k in SOURCE_HINTS}
    for channel, words in SOURCE_HINTS.items():
        hits[channel] = sum(1 for w in words if w in t)
    best = max(hits, key=hits.get)
    return best if hits[best] > 0 else "media"


def trust_for_channel(seg: SegmentProfile, channel: str) -> float:
    return {
        "authority": seg.authority_trust,
        "media": seg.media_trust,
        "peer": seg.peer_trust,
        "local": seg.local_trust,
        "institutional": seg.institutional_trust,
    }.get(channel, seg.media_trust)


def segment_response_scale(seg: SegmentProfile, signal: Dict[str, Any], channel: str) -> float:
    tags = signal.get("tags", {})
    valence = float(tags.get("valence", 0.0))
    severity = float(tags.get("severity", 1.0))
    trust = trust_for_channel(seg, channel)

    exposure = 0.45 + 0.70 * seg.media_exposure
    credibility = 0.55 + 0.75 * trust
    vulnerability = 0.75 + (0.35 if seg.economic_band == "low_stability" else 0.0) - (0.15 if seg.economic_band == "high_stability" else 0.0)
    age_reactivity = {"under_25": 1.08, "25_44": 1.03, "45_64": 0.98, "65_plus": 0.94}[seg.age_band]
    if valence < 0:
        risk_component = 0.85 + (1.0 - seg.risk_tolerance) * 0.45
    else:
        risk_component = 0.85 + seg.risk_tolerance * 0.25
    return clamp(exposure * credibility * vulnerability * age_reactivity * risk_component * (0.85 + 0.08 * severity), 0.20, 2.20)
