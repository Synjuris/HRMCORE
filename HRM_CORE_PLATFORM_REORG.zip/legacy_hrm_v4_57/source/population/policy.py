"""Policy injection layer for HRM_UNIFIED v1.7.

This module tests synthetic interventions against the civic dynamics layer.
It is not a policy recommendation engine and does not claim real-world prediction.
It provides traceable before/after pressure comparisons inside the synthetic model.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional
import json
import copy

try:
    from .calibration import clamp
    from .calibrated_panel import CalibratedPanel
    from .civic_dynamics import CivicDynamicsTracker, CivicState, CivicEvent
except ImportError:
    from population.calibration import clamp
    from population.calibrated_panel import CalibratedPanel
    from population.civic_dynamics import CivicDynamicsTracker, CivicState, CivicEvent


@dataclass
class PolicyDefinition:
    id: str
    name: str
    stimulus: str
    cost_units: float = 1.0
    target_districts: List[str] = field(default_factory=list)
    target_institutions: List[str] = field(default_factory=list)
    effects: Dict[str, float] = field(default_factory=dict)
    notes: str = ""

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> "PolicyDefinition":
        return PolicyDefinition(
            id=str(data.get("id", "policy")),
            name=str(data.get("name", data.get("id", "Policy"))),
            stimulus=str(data.get("stimulus", "")),
            cost_units=float(data.get("cost_units", 1.0)),
            target_districts=list(data.get("target_districts", [])),
            target_institutions=list(data.get("target_institutions", [])),
            effects=dict(data.get("effects", {})),
            notes=str(data.get("notes", "")),
        )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class PolicyStep:
    tick: int
    kind: str
    label: str
    stimulus: str
    policy_id: Optional[str] = None
    delta: Dict[str, float] = field(default_factory=dict)
    state_before: Dict[str, Any] = field(default_factory=dict)
    state_after: Dict[str, Any] = field(default_factory=dict)
    direct_effects: Dict[str, float] = field(default_factory=dict)
    cost_units: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class PolicyRunResult:
    profile_name: str
    population_size: int
    scenario_name: str
    steps: List[PolicyStep]
    events: List[CivicEvent]
    final_state: CivicState
    policies: List[PolicyDefinition]
    total_cost_units: float

    def to_json(self) -> str:
        return json.dumps({
            "profile_name": self.profile_name,
            "population_size": self.population_size,
            "scenario_name": self.scenario_name,
            "steps": [s.to_dict() for s in self.steps],
            "events": [e.to_dict() for e in self.events],
            "final_state": self.final_state.to_dict(),
            "policies": [p.to_dict() for p in self.policies],
            "total_cost_units": round(self.total_cost_units, 4),
            "cost_benefit": self.cost_benefit(),
        }, indent=2)

    def cost_benefit(self) -> Dict[str, float]:
        if not self.steps:
            return {}
        first = self.steps[0].state_after or self.final_state.to_dict()
        final = self.final_state.to_dict()
        start_stress = float(first.get("stress_pressure", 0.0))
        start_vol = float(first.get("volatility_pressure", 0.0))
        final_stress = float(final.get("stress_pressure", 0.0))
        final_vol = float(final.get("volatility_pressure", 0.0))
        pressure_reduction = max(0.0, (start_stress + start_vol) - (final_stress + final_vol))
        cost = max(0.0001, self.total_cost_units)
        return {
            "pressure_reduction": round(pressure_reduction, 4),
            "cost_units": round(self.total_cost_units, 4),
            "reduction_per_cost_unit": round(pressure_reduction / cost, 4),
        }

    def summary(self) -> str:
        lines = [
            "HRM_UNIFIED v1.7 POLICY INJECTION RUN",
            f"Scenario: {self.scenario_name}",
            f"Profile: {self.profile_name}",
            f"Population: {self.population_size}",
            f"Policy cost units: {self.total_cost_units:.2f}",
            "",
            "Final civic pressures:",
        ]
        for k, v in self.final_state.summary().items():
            lines.append(f"  {k:<24} {v:+.4f}")
        cb = self.cost_benefit()
        if cb:
            lines += ["", "Cost/benefit proxy:"]
            for k, v in cb.items():
                lines.append(f"  {k:<24} {v:+.4f}")
        lines += ["", "Steps:"]
        for step in self.steps:
            marker = "POLICY" if step.kind == "policy" else "SCENARIO"
            lines.append(f"  tick {step.tick:>3} | {marker:<8} | {step.label}")
        lines += ["", "Emergent events:"]
        if not self.events:
            lines.append("  none")
        for e in self.events:
            lines.append(f"  tick {e.tick:>3} | {e.kind:<28} severity={e.severity:.3f} | {e.message}")
        return "\n".join(lines)


DEFAULT_POLICIES: Dict[str, PolicyDefinition] = {
    "emergency_aid": PolicyDefinition(
        id="emergency_aid",
        name="Emergency aid distribution",
        stimulus="Emergency aid, supply distribution, and temporary support services are announced with clear eligibility information.",
        cost_units=3.0,
        effects={"stress_pressure": -0.08, "withdrawal_pressure": -0.04, "cooperation_pressure": 0.08},
        notes="Generic relief intervention; reduces synthetic stress and withdrawal pressure."
    ),
    "clear_public_notice": PolicyDefinition(
        id="clear_public_notice",
        name="Clear public notice",
        stimulus="Institutions publish a clear, coordinated public update with timelines, responsibilities, and next steps.",
        cost_units=1.0,
        effects={"trust_pressure": -0.05, "volatility_pressure": -0.04, "cooperation_pressure": 0.04},
        notes="Generic communications intervention; reduces ambiguity-driven volatility."
    ),
    "small_business_relief": PolicyDefinition(
        id="small_business_relief",
        name="Small business relief",
        stimulus="A temporary small business relief program is opened with fast processing and transparent reporting.",
        cost_units=4.0,
        target_districts=["commercial", "industrial"],
        effects={"stress_pressure": -0.05, "trust_pressure": -0.03, "cooperation_pressure": 0.05},
        notes="Generic economic stabilization intervention."
    ),
    "institutional_messaging": PolicyDefinition(
        id="institutional_messaging",
        name="Institutional messaging campaign",
        stimulus="Trusted institutions coordinate messages through employers, schools, health providers, and community organizations.",
        cost_units=2.0,
        effects={"trust_pressure": -0.04, "volatility_pressure": -0.03, "withdrawal_pressure": -0.02, "cooperation_pressure": 0.05},
        notes="Generic multi-channel trust repair intervention."
    ),
    "targeted_service_restore": PolicyDefinition(
        id="targeted_service_restore",
        name="Targeted service restoration",
        stimulus="Service restoration crews prioritize disrupted districts and publish progress updates at predictable intervals.",
        cost_units=3.0,
        target_districts=["urban_core", "commercial", "suburban"],
        effects={"stress_pressure": -0.06, "volatility_pressure": -0.03, "withdrawal_pressure": -0.03},
        notes="Generic operational recovery intervention."
    ),
}


def default_policy_scenario() -> List[Dict[str, Any]]:
    return [
        {"tick": 0, "kind": "scenario", "label": "economic shock", "stimulus": "A regional employer announces temporary layoffs and reduced hours.", "ticks": 28},
        {"tick": 1, "kind": "scenario", "label": "service disruption", "stimulus": "A utility outage disrupts several commercial and residential districts.", "ticks": 28},
        {"tick": 2, "kind": "policy", "label": "clear public notice", "policy_id": "clear_public_notice", "ticks": 18},
        {"tick": 3, "kind": "policy", "label": "emergency aid", "policy_id": "emergency_aid", "ticks": 18},
        {"tick": 4, "kind": "scenario", "label": "continued uncertainty", "stimulus": "Residents report confusion about schedules, resources, and service availability.", "ticks": 28},
        {"tick": 5, "kind": "policy", "label": "institutional messaging", "policy_id": "institutional_messaging", "ticks": 18},
    ]


def _state_snapshot(state: CivicState) -> Dict[str, Any]:
    return copy.deepcopy(state.to_dict())


def _apply_direct_policy_effects(tracker: CivicDynamicsTracker, policy: PolicyDefinition) -> Dict[str, float]:
    """Apply bounded synthetic pressure changes after the policy stimulus is ingested."""
    s = tracker.state
    applied: Dict[str, float] = {}
    for field_name, raw_change in policy.effects.items():
        if not hasattr(s, field_name):
            continue
        old = float(getattr(s, field_name))
        change = float(raw_change)
        new = clamp(old + change, 0.0, 10.0)
        setattr(s, field_name, new)
        applied[field_name] = round(new - old, 4)

    for did in policy.target_districts:
        rec = s.district_pressures.setdefault(did, {"stress": 0.0, "withdrawal": 0.0, "volatility": 0.0})
        if "stress_pressure" in policy.effects:
            rec["stress"] = clamp(rec.get("stress", 0.0) + float(policy.effects["stress_pressure"]) * 0.45, 0.0, 10.0)
        if "withdrawal_pressure" in policy.effects:
            rec["withdrawal"] = clamp(rec.get("withdrawal", 0.0) + float(policy.effects["withdrawal_pressure"]) * 0.45, 0.0, 10.0)
        if "volatility_pressure" in policy.effects:
            rec["volatility"] = clamp(rec.get("volatility", 0.0) + float(policy.effects["volatility_pressure"]) * 0.45, 0.0, 10.0)

    for inst in policy.target_institutions:
        if inst in s.institution_strain:
            s.institution_strain[inst] = clamp(s.institution_strain[inst] - 0.04, 0.0, 10.0)

    return applied


def run_policy_sequence(
    sequence: Optional[List[Dict[str, Any]]] = None,
    policies: Optional[Dict[str, PolicyDefinition]] = None,
    n: int = 1000,
    seed: int = 42,
    profile: str = "generic_mixed_region",
    decay: float = 0.86,
    scenario_name: str = "default_policy_sequence",
) -> PolicyRunResult:
    sequence = sequence or default_policy_scenario()
    policies = policies or DEFAULT_POLICIES

    panel = CalibratedPanel(n=n, seed=seed, profile=profile)
    tracker = CivicDynamicsTracker(decay=decay)
    steps: List[PolicyStep] = []
    used_policies: List[PolicyDefinition] = []
    total_cost = 0.0

    for idx, item in enumerate(sequence):
        tick = int(item.get("tick", idx))
        kind = str(item.get("kind", "scenario"))
        label = str(item.get("label", kind))
        ticks = int(item.get("ticks", 28))
        policy_id = item.get("policy_id")

        if kind == "policy":
            if not policy_id or str(policy_id) not in policies:
                raise ValueError(f"Unknown policy_id at tick {tick}: {policy_id}")
            policy = policies[str(policy_id)]
            stimulus = str(item.get("stimulus") or policy.stimulus)
            cost = float(item.get("cost_units", policy.cost_units))
        else:
            policy = None
            stimulus = str(item.get("stimulus", ""))
            cost = 0.0

        state_before = _state_snapshot(tracker.state)
        result = panel.inject(stimulus, run_ticks=ticks)
        tracker.ingest(result, tick)
        direct_effects: Dict[str, float] = {}

        if policy is not None:
            direct_effects = _apply_direct_policy_effects(tracker, policy)
            used_policies.append(policy)
            total_cost += cost

        state_after = _state_snapshot(tracker.state)
        steps.append(PolicyStep(
            tick=tick,
            kind=kind,
            label=label,
            stimulus=stimulus,
            policy_id=str(policy_id) if policy_id else None,
            delta={k: round(float(v), 4) for k, v in result.delta.items()},
            state_before=state_before,
            state_after=state_after,
            direct_effects=direct_effects,
            cost_units=cost,
        ))

    return PolicyRunResult(
        profile_name=panel.profile_name,
        population_size=n,
        scenario_name=scenario_name,
        steps=steps,
        events=tracker.events,
        final_state=tracker.state,
        policies=used_policies,
        total_cost_units=total_cost,
    )


def load_policy_definitions(path: str) -> Dict[str, PolicyDefinition]:
    data = json.loads(open(path, "r", encoding="utf-8").read())
    items = data.get("policies", data) if isinstance(data, dict) else data
    if not isinstance(items, list):
        raise ValueError("Policy file must be a list or an object with a 'policies' list.")
    return {PolicyDefinition.from_dict(x).id: PolicyDefinition.from_dict(x) for x in items}


def load_policy_sequence(path: str) -> List[Dict[str, Any]]:
    data = json.loads(open(path, "r", encoding="utf-8").read())
    if isinstance(data, dict):
        return list(data.get("sequence", []))
    if isinstance(data, list):
        return data
    raise ValueError("Scenario file must be a list or an object with a 'sequence' list.")
