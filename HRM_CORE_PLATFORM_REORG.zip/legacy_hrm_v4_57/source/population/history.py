"""Replayable historical simulation for HRM_UNIFIED v1.8.

This layer turns scenario/policy steps into a persistent synthetic timeline.
It does not claim prediction. It records how the current synthetic model evolves
when pressures, policies, decay, and prior state are carried forward instead of
resetting between runs.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple
from pathlib import Path
import copy
import hashlib
import json
import re

try:
    from .calibrated_panel import CalibratedPanel
    from .civic_dynamics import CivicDynamicsTracker, CivicState, CivicEvent
    from .policy import PolicyDefinition, DEFAULT_POLICIES, _apply_direct_policy_effects
except ImportError:
    from population.calibrated_panel import CalibratedPanel
    from population.civic_dynamics import CivicDynamicsTracker, CivicState, CivicEvent
    from population.policy import PolicyDefinition, DEFAULT_POLICIES, _apply_direct_policy_effects


def _snapshot(state: CivicState) -> Dict[str, Any]:
    return copy.deepcopy(state.to_dict())


def _canonical(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def fingerprint(obj: Any) -> str:
    return hashlib.sha256(_canonical(obj).encode("utf-8")).hexdigest()


@dataclass
class HistoricalStep:
    period: int
    tick: int
    kind: str
    label: str
    stimulus: str = ""
    policy_id: Optional[str] = None
    ticks: int = 28
    cost_units: float = 0.0
    delta: Dict[str, float] = field(default_factory=dict)
    state_before: Dict[str, Any] = field(default_factory=dict)
    state_after: Dict[str, Any] = field(default_factory=dict)
    direct_effects: Dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class HistoricalSnapshot:
    period: int
    tick: int
    label: str
    state: Dict[str, Any]
    events_seen: int
    fingerprint: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class HistoricalRunResult:
    name: str
    profile_name: str
    population_size: int
    seed: int
    decay: float
    steps: List[HistoricalStep]
    snapshots: List[HistoricalSnapshot]
    events: List[CivicEvent]
    final_state: CivicState
    total_cost_units: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "profile_name": self.profile_name,
            "population_size": self.population_size,
            "seed": self.seed,
            "decay": self.decay,
            "steps": [s.to_dict() for s in self.steps],
            "snapshots": [s.to_dict() for s in self.snapshots],
            "events": [e.to_dict() for e in self.events],
            "final_state": self.final_state.to_dict(),
            "total_cost_units": round(self.total_cost_units, 4),
            "fingerprint": self.fingerprint(),
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)

    def fingerprint(self) -> str:
        return fingerprint({
            "name": self.name,
            "profile_name": self.profile_name,
            "population_size": self.population_size,
            "seed": self.seed,
            "decay": self.decay,
            "steps": [s.to_dict() for s in self.steps],
            "final_state": self.final_state.to_dict(),
            "events": [e.to_dict() for e in self.events],
        })

    def summary(self) -> str:
        lines = [
            "HRM_UNIFIED v1.8 REPLAYABLE HISTORY RUN",
            f"Timeline: {self.name}",
            f"Profile: {self.profile_name}",
            f"Population: {self.population_size}",
            f"Seed: {self.seed}",
            f"Snapshots: {len(self.snapshots)}",
            f"Events: {len(self.events)}",
            f"Policy cost units: {self.total_cost_units:.2f}",
            "",
            "Final civic pressures:",
        ]
        for k, v in self.final_state.summary().items():
            lines.append(f"  {k:<24} {v:+.4f}")
        lines += ["", f"Fingerprint: {self.fingerprint()[:16]}", "", "Timeline steps:"]
        for s in self.steps:
            marker = "POLICY" if s.kind == "policy" else "SCENARIO"
            lines.append(f"  period {s.period:>2} tick {s.tick:>3} | {marker:<8} | {s.label}")
        if self.events:
            lines += ["", "Emergent events:"]
            for e in self.events[:20]:
                lines.append(f"  tick {e.tick:>3} | {e.kind:<28} severity={e.severity:.3f} | {e.message}")
            if len(self.events) > 20:
                lines.append(f"  ... {len(self.events) - 20} more events")
        return "\n".join(lines)


class HistoricalSimulator:
    def __init__(self, n: int = 1000, seed: int = 42, profile: str = "generic_mixed_region", decay: float = 0.86,
                 policies: Optional[Dict[str, PolicyDefinition]] = None):
        self.panel = CalibratedPanel(n=n, seed=seed, profile=profile)
        self.tracker = CivicDynamicsTracker(decay=decay)
        self.n = n
        self.seed = seed
        self.decay = decay
        self.profile = profile
        self.policies = policies or DEFAULT_POLICIES
        self.steps: List[HistoricalStep] = []
        self.snapshots: List[HistoricalSnapshot] = []
        self.total_cost = 0.0

    def save_state(self, path: str | Path, label: str = "manual_snapshot") -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "label": label,
            "n": self.n,
            "seed": self.seed,
            "profile": self.profile,
            "decay": self.decay,
            "state": self.tracker.state.to_dict(),
            "events": [e.to_dict() for e in self.tracker.events],
            "steps": [s.to_dict() for s in self.steps],
            "total_cost_units": self.total_cost,
            "fingerprint": fingerprint(self.tracker.state.to_dict()),
        }
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return path

    def load_state(self, path: str | Path) -> None:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        self.tracker.state = CivicState(**payload.get("state", {}))
        self.tracker.events = [CivicEvent(**e) for e in payload.get("events", [])]
        self.steps = [HistoricalStep(**s) for s in payload.get("steps", [])]
        self.total_cost = float(payload.get("total_cost_units", 0.0))

    def _record_snapshot(self, period: int, tick: int, label: str) -> None:
        state = _snapshot(self.tracker.state)
        self.snapshots.append(HistoricalSnapshot(
            period=period,
            tick=tick,
            label=label,
            state=state,
            events_seen=len(self.tracker.events),
            fingerprint=fingerprint(state),
        ))

    def apply_step(self, item: Dict[str, Any], period: int, idx: int) -> HistoricalStep:
        tick = int(item.get("tick", idx))
        kind = str(item.get("kind", "scenario"))
        label = str(item.get("label", kind))
        ticks = int(item.get("ticks", 28))
        policy_id = item.get("policy_id")

        policy: Optional[PolicyDefinition] = None
        cost = 0.0
        if kind == "policy":
            if not policy_id or str(policy_id) not in self.policies:
                raise ValueError(f"Unknown policy_id at period {period} tick {tick}: {policy_id}")
            policy = self.policies[str(policy_id)]
            stimulus = str(item.get("stimulus") or policy.stimulus)
            cost = float(item.get("cost_units", policy.cost_units))
        elif kind in {"snapshot", "checkpoint"}:
            self._record_snapshot(period, tick, label)
            return HistoricalStep(period=period, tick=tick, kind=kind, label=label, ticks=0,
                                  state_before=_snapshot(self.tracker.state), state_after=_snapshot(self.tracker.state))
        else:
            stimulus = str(item.get("stimulus", ""))

        before = _snapshot(self.tracker.state)
        result = self.panel.inject(stimulus, run_ticks=ticks)
        self.tracker.ingest(result, tick)
        direct: Dict[str, float] = {}
        if policy is not None:
            direct = _apply_direct_policy_effects(self.tracker, policy)
            self.total_cost += cost
        after = _snapshot(self.tracker.state)
        step = HistoricalStep(
            period=period,
            tick=tick,
            kind=kind,
            label=label,
            stimulus=stimulus,
            policy_id=str(policy_id) if policy_id else None,
            ticks=ticks,
            cost_units=cost,
            delta={k: round(float(v), 4) for k, v in result.delta.items()},
            state_before=before,
            state_after=after,
            direct_effects=direct,
        )
        self.steps.append(step)
        return step

    def run(self, timeline: Dict[str, Any], name: str = "historical_timeline") -> HistoricalRunResult:
        periods = timeline.get("periods") or timeline.get("timeline") or timeline.get("sequence") or []
        if not isinstance(periods, list):
            raise ValueError("Timeline must contain a 'periods' list, or a list of steps.")
        self._record_snapshot(0, 0, "initial_state")
        for p_idx, period in enumerate(periods, start=1):
            if isinstance(period, dict) and "steps" in period:
                period_label = str(period.get("label", f"period_{p_idx}"))
                steps = list(period.get("steps", []))
            else:
                period_label = f"period_{p_idx}"
                steps = [period]
            for s_idx, item in enumerate(steps):
                if not isinstance(item, dict):
                    raise ValueError(f"Timeline step must be an object: period {p_idx}, step {s_idx}")
                self.apply_step(item, period=p_idx, idx=s_idx)
            self._record_snapshot(p_idx, int(steps[-1].get("tick", len(steps) - 1)) if steps and isinstance(steps[-1], dict) else 0, period_label)
        return HistoricalRunResult(
            name=name,
            profile_name=self.panel.profile_name,
            population_size=self.n,
            seed=self.seed,
            decay=self.decay,
            steps=self.steps,
            snapshots=self.snapshots,
            events=self.tracker.events,
            final_state=self.tracker.state,
            total_cost_units=self.total_cost,
        )


def default_timeline() -> Dict[str, Any]:
    return {
        "name": "generic_recovery_history",
        "periods": [
            {"label": "initial disruption", "steps": [
                {"tick": 0, "kind": "scenario", "label": "regional economic shock", "stimulus": "A major regional employer announces reduced hours and temporary layoffs.", "ticks": 28},
                {"tick": 1, "kind": "scenario", "label": "service disruption", "stimulus": "A utility outage disrupts commercial and residential routines.", "ticks": 28},
            ]},
            {"label": "public response", "steps": [
                {"tick": 2, "kind": "policy", "label": "clear public notice", "policy_id": "clear_public_notice", "ticks": 18},
                {"tick": 3, "kind": "policy", "label": "emergency aid", "policy_id": "emergency_aid", "ticks": 18},
            ]},
            {"label": "secondary uncertainty", "steps": [
                {"tick": 4, "kind": "scenario", "label": "continued confusion", "stimulus": "Residents report confusion about schedules, resources, and service availability.", "ticks": 28},
                {"tick": 5, "kind": "policy", "label": "institutional messaging", "policy_id": "institutional_messaging", "ticks": 18},
            ]},
            {"label": "stabilization", "steps": [
                {"tick": 6, "kind": "scenario", "label": "community recovery", "stimulus": "Community organizations coordinate recovery information, services, and support channels.", "ticks": 28},
            ]},
        ],
    }


def _parse_scalar(value: str) -> Any:
    value = value.strip()
    if value == "":
        return ""
    if value[0:1] in {'"', "'"} and value[-1:] == value[0]:
        return value[1:-1]
    if value.lower() in {"true", "false"}:
        return value.lower() == "true"
    try:
        if "." in value:
            return float(value)
        return int(value)
    except ValueError:
        return value


def _simple_yaml_load(text: str) -> Dict[str, Any]:
    """Very small YAML subset loader for this package's timeline files.

    Supports root keys, `periods:`, list periods with `label:`, and nested
    `steps:` list of one-line mapping entries. JSON remains the preferred path
    for complex input; this avoids making PyYAML mandatory.
    """
    # Prefer PyYAML if it exists in the user's environment.
    try:
        import yaml  # type: ignore
        data = yaml.safe_load(text)
        if isinstance(data, dict):
            return data
    except Exception:
        pass

    lines = [ln.rstrip() for ln in text.splitlines() if ln.strip() and not ln.strip().startswith("#")]
    root: Dict[str, Any] = {}
    periods: List[Dict[str, Any]] = []
    current_period: Optional[Dict[str, Any]] = None
    in_steps = False
    for ln in lines:
        stripped = ln.strip()
        if not ln.startswith(" ") and ":" in stripped and not stripped.startswith("-"):
            key, val = stripped.split(":", 1)
            key = key.strip()
            val = val.strip()
            if key == "periods":
                root["periods"] = periods
            else:
                root[key] = _parse_scalar(val)
            in_steps = False
            continue
        if stripped.startswith("- ") and "label:" in stripped and not in_steps:
            current_period = {"label": _parse_scalar(stripped.split("label:", 1)[1].strip()), "steps": []}
            periods.append(current_period)
            continue
        if stripped == "steps:":
            in_steps = True
            continue
        if stripped.startswith("- ") and in_steps and current_period is not None:
            body = stripped[2:].strip()
            # Parse inline JSON object when possible.
            if body.startswith("{"):
                current_period["steps"].append(json.loads(body))
            else:
                item: Dict[str, Any] = {}
                for part in re.split(r",\s*(?=[A-Za-z_][A-Za-z0-9_]*\s*:)", body):
                    if ":" in part:
                        k, v = part.split(":", 1)
                        item[k.strip()] = _parse_scalar(v.strip())
                current_period["steps"].append(item)
    if periods and "periods" not in root:
        root["periods"] = periods
    return root


def load_timeline(path: Optional[str]) -> Dict[str, Any]:
    if not path:
        return default_timeline()
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    if p.suffix.lower() == ".json":
        data = json.loads(text)
    else:
        data = _simple_yaml_load(text)
    if isinstance(data, list):
        return {"name": p.stem, "periods": data}
    if not isinstance(data, dict):
        raise ValueError("Timeline must parse to a JSON/YAML object or list.")
    return data


def compare_histories(a: HistoricalRunResult, b: HistoricalRunResult) -> Dict[str, Any]:
    sa = a.final_state.summary()
    sb = b.final_state.summary()
    return {
        "a_name": a.name,
        "b_name": b.name,
        "a_fingerprint": a.fingerprint(),
        "b_fingerprint": b.fingerprint(),
        "final_pressure_delta_b_minus_a": {k: round(float(sb.get(k, 0.0)) - float(sa.get(k, 0.0)), 4) for k in sorted(set(sa) | set(sb))},
        "event_count_delta_b_minus_a": len(b.events) - len(a.events),
        "cost_delta_b_minus_a": round(b.total_cost_units - a.total_cost_units, 4),
    }
