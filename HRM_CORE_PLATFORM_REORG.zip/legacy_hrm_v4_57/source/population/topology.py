"""Social topology tools for calibrated synthetic populations."""
from __future__ import annotations

from typing import List
import random

from .calibration import SegmentProfile


def rebuild_segmented_network(sim, segments: List[SegmentProfile], seed: int, avg_degree: int = 6) -> None:
    """Replace the random graph with a clustered, bridge-node topology.

    Homophily is structural only: age/economic/connectivity bands influence edge
    probability. Hub segments get more ties; isolated segments get fewer.
    """
    rng = random.Random(seed + 1301)
    n = len(sim.agents)
    for a in sim.agents:
        a.neighbors = []

    degree_target = []
    for seg in segments:
        base = avg_degree
        if seg.connectivity_band == "hub":
            base += 7
        elif seg.connectivity_band == "isolated":
            base -= 3
        base += int(round((seg.mobility - 0.5) * 4))
        degree_target.append(max(1, base))

    def compatible(i: int, j: int) -> float:
        a = segments[i]
        b = segments[j]
        score = 0.20
        if a.age_band == b.age_band:
            score += 0.20
        if a.economic_band == b.economic_band:
            score += 0.18
        if a.education_band == b.education_band:
            score += 0.12
        if a.connectivity_band == "hub" or b.connectivity_band == "hub":
            score += 0.25
        score += 0.15 * ((a.mobility + b.mobility) / 2.0)
        return min(0.95, score)

    attempts = 0
    max_attempts = n * avg_degree * 80
    while attempts < max_attempts:
        attempts += 1
        i = rng.randrange(n)
        if len(sim.agents[i].neighbors) >= degree_target[i]:
            continue
        if rng.random() < 0.70:
            candidates = [idx for idx, s in enumerate(segments)
                          if idx != i and len(sim.agents[idx].neighbors) < degree_target[idx]
                          and (s.age_band == segments[i].age_band or s.economic_band == segments[i].economic_band)]
            j = rng.choice(candidates) if candidates else rng.randrange(n)
        else:
            j = rng.randrange(n)
        if i == j or j in sim.agents[i].neighbors:
            continue
        if len(sim.agents[j].neighbors) >= degree_target[j]:
            continue
        if rng.random() <= compatible(i, j):
            sim.agents[i].neighbors.append(j)
            sim.agents[j].neighbors.append(i)

        if all(len(sim.agents[k].neighbors) >= max(1, degree_target[k] - 1) for k in range(n)):
            break
