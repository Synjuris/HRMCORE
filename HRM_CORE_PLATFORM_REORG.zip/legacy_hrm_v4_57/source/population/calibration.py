"""Population calibration primitives for HRM_UNIFIED v1.3.

This module intentionally contains no locality-specific defaults. Profiles are
abstract structural archetypes or externally supplied data snapshots.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, Any, List
import json
import math
import random
from pathlib import Path


AGE_BANDS = ("under_25", "25_44", "45_64", "65_plus")
ECONOMIC_BANDS = ("low_stability", "mid_stability", "high_stability")
EDUCATION_BANDS = ("lower", "middle", "higher")
CONNECTIVITY_BANDS = ("isolated", "typical", "hub")


@dataclass(frozen=True)
class SegmentProfile:
    age_band: str
    economic_band: str
    education_band: str
    connectivity_band: str
    institutional_trust: float
    peer_trust: float
    media_trust: float
    local_trust: float
    authority_trust: float
    risk_tolerance: float
    media_exposure: float
    mobility: float

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(x)))


def weighted_choice(rng: random.Random, weights: Dict[str, float]) -> str:
    total = sum(max(0.0, float(v)) for v in weights.values())
    if total <= 0:
        return next(iter(weights))
    r = rng.random() * total
    acc = 0.0
    for k, v in weights.items():
        acc += max(0.0, float(v))
        if r <= acc:
            return k
    return next(reversed(weights))


def normalize_distribution(d: Dict[str, float], keys: tuple[str, ...]) -> Dict[str, float]:
    out = {k: max(0.0, float(d.get(k, 0.0))) for k in keys}
    s = sum(out.values())
    if s <= 0:
        return {k: 1.0 / len(keys) for k in keys}
    return {k: v / s for k, v in out.items()}


def load_profile(path_or_name: str | Path) -> Dict[str, Any]:
    p = Path(path_or_name)
    if not p.exists():
        root = Path(__file__).resolve().parents[1]
        p = root / "profiles" / f"{path_or_name}.json"
    return json.loads(p.read_text(encoding="utf-8"))


def generic_profile() -> Dict[str, Any]:
    return {
        "name": "generic_mixed_region",
        "description": "Abstract, geography-agnostic civic population profile.",
        "population_structure": {
            "age": {"under_25": 0.30, "25_44": 0.34, "45_64": 0.23, "65_plus": 0.13},
            "economic": {"low_stability": 0.32, "mid_stability": 0.48, "high_stability": 0.20},
            "education": {"lower": 0.34, "middle": 0.43, "higher": 0.23},
            "connectivity": {"isolated": 0.18, "typical": 0.70, "hub": 0.12}
        },
        "baseline_factors": {
            "institutional_trust": 0.50,
            "peer_trust": 0.58,
            "media_trust": 0.44,
            "local_trust": 0.60,
            "authority_trust": 0.49,
            "risk_tolerance": 0.46,
            "media_exposure": 0.55,
            "mobility": 0.50
        }
    }


def derive_profile_from_real_snapshot(snapshot: Dict[str, Any]) -> Dict[str, Any]:
    """Convert a v1.2 real-data snapshot into abstract calibration parameters.

    The adapter is intentionally conservative: it maps public aggregate facts to
    broad structural distributions, not to identity claims or behavioral labels.
    """
    facts = snapshot.get("facts", snapshot)
    pop = float(facts.get("population", facts.get("B01003_001E", 100000)) or 100000)
    median_income = float(facts.get("median_household_income", facts.get("B19013_001E", 55000)) or 55000)
    bachelors = float(facts.get("bachelors_or_higher_pct", facts.get("DP02_0068PE", 25)) or 25) / 100.0
    under_18 = float(facts.get("under_18_pct", facts.get("DP05_0019PE", 22)) or 22) / 100.0
    over_65 = float(facts.get("over_65_pct", facts.get("DP05_0024PE", 15)) or 15) / 100.0

    low_econ = clamp(0.50 - (median_income / 140000.0), 0.18, 0.55)
    high_econ = clamp((median_income - 35000.0) / 120000.0, 0.10, 0.38)
    mid_econ = clamp(1.0 - low_econ - high_econ, 0.20, 0.70)

    higher_edu = clamp(bachelors, 0.08, 0.55)
    lower_edu = clamp(0.55 - bachelors * 0.7, 0.15, 0.55)
    middle_edu = clamp(1.0 - higher_edu - lower_edu, 0.20, 0.65)

    urban_scale = clamp(math.log10(max(pop, 1000)) / 6.0, 0.35, 0.85)
    return {
        "name": "external_data_profile",
        "description": "Profile derived from externally supplied aggregate dataset snapshot.",
        "population_structure": {
            "age": {
                "under_25": clamp(under_18 + 0.10, 0.18, 0.42),
                "25_44": 0.34,
                "45_64": clamp(1.0 - (under_18 + 0.10) - 0.34 - over_65, 0.18, 0.32),
                "65_plus": clamp(over_65, 0.08, 0.28),
            },
            "economic": {"low_stability": low_econ, "mid_stability": mid_econ, "high_stability": high_econ},
            "education": {"lower": lower_edu, "middle": middle_edu, "higher": higher_edu},
            "connectivity": {"isolated": clamp(0.30 - urban_scale * 0.18, 0.10, 0.26), "typical": 0.70, "hub": clamp(0.08 + urban_scale * 0.10, 0.10, 0.20)},
        },
        "baseline_factors": {
            "institutional_trust": 0.50,
            "peer_trust": 0.58,
            "media_trust": 0.44,
            "local_trust": 0.60,
            "authority_trust": 0.49,
            "risk_tolerance": clamp(0.50 - low_econ * 0.12, 0.35, 0.60),
            "media_exposure": clamp(0.45 + urban_scale * 0.20, 0.45, 0.70),
            "mobility": clamp(0.42 + urban_scale * 0.18, 0.38, 0.66),
        },
    }


def build_segments(n: int, seed: int, profile: Dict[str, Any] | None = None) -> List[SegmentProfile]:
    rng = random.Random(seed)
    profile = profile or generic_profile()
    structure = profile.get("population_structure", {})
    factors = profile.get("baseline_factors", {})
    age_w = normalize_distribution(structure.get("age", {}), AGE_BANDS)
    econ_w = normalize_distribution(structure.get("economic", {}), ECONOMIC_BANDS)
    edu_w = normalize_distribution(structure.get("education", {}), EDUCATION_BANDS)
    conn_w = normalize_distribution(structure.get("connectivity", {}), CONNECTIVITY_BANDS)

    out: List[SegmentProfile] = []
    for _ in range(n):
        age = weighted_choice(rng, age_w)
        econ = weighted_choice(rng, econ_w)
        edu = weighted_choice(rng, edu_w)
        conn = weighted_choice(rng, conn_w)

        econ_shift = {"low_stability": -0.12, "mid_stability": 0.0, "high_stability": 0.10}[econ]
        edu_shift = {"lower": -0.06, "middle": 0.0, "higher": 0.08}[edu]
        age_media = {"under_25": 0.12, "25_44": 0.06, "45_64": 0.0, "65_plus": -0.05}[age]
        conn_shift = {"isolated": -0.10, "typical": 0.0, "hub": 0.14}[conn]

        noise = lambda sd=0.04: rng.normalvariate(0.0, sd)
        out.append(SegmentProfile(
            age_band=age,
            economic_band=econ,
            education_band=edu,
            connectivity_band=conn,
            institutional_trust=clamp(factors.get("institutional_trust", 0.50) + edu_shift + econ_shift * 0.4 + noise()),
            peer_trust=clamp(factors.get("peer_trust", 0.58) + conn_shift * 0.3 + noise()),
            media_trust=clamp(factors.get("media_trust", 0.44) + edu_shift * 0.5 + noise()),
            local_trust=clamp(factors.get("local_trust", 0.60) + conn_shift * 0.2 + noise()),
            authority_trust=clamp(factors.get("authority_trust", 0.49) + edu_shift * 0.4 + econ_shift * 0.2 + noise()),
            risk_tolerance=clamp(factors.get("risk_tolerance", 0.46) + {"under_25":0.08,"25_44":0.04,"45_64":-0.02,"65_plus":-0.08}[age] + econ_shift * 0.3 + noise()),
            media_exposure=clamp(factors.get("media_exposure", 0.55) + age_media + conn_shift * 0.4 + noise()),
            mobility=clamp(factors.get("mobility", 0.50) + {"under_25":0.10,"25_44":0.08,"45_64":-0.02,"65_plus":-0.10}[age] + econ_shift * 0.2 + noise()),
        ))
    return out
