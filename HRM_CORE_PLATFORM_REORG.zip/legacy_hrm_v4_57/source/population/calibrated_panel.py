"""Calibrated synthetic panel with heterogeneity, topology, and persistence."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional
import json

try:
    from ..core.hrm_core_kernel import HRMCore, DEFAULT_CONFIG
    from ..stimulus.nlsi import parse_stimulus
    from .calibration import SegmentProfile, build_segments, generic_profile, load_profile, clamp
    from .topology import rebuild_segmented_network
    from .trust import infer_source_channel, segment_response_scale
    from .spatial import (
        build_districts, build_institutions, assign_locations, exposure_scale_for_agent,
        summarize_spatial_state, hotspot_report, default_spatial_profile,
    )
except ImportError:
    from core.hrm_core_kernel import HRMCore, DEFAULT_CONFIG
    from stimulus.nlsi import parse_stimulus
    from population.calibration import SegmentProfile, build_segments, generic_profile, load_profile, clamp
    from population.topology import rebuild_segmented_network
    from population.trust import infer_source_channel, segment_response_scale
    from population.spatial import (
        build_districts, build_institutions, assign_locations, exposure_scale_for_agent,
        summarize_spatial_state, hotspot_report, default_spatial_profile,
    )


@dataclass
class CalibratedResult:
    stimulus_text: str
    population_size: int
    ticks_run: int
    source_channel: str
    profile_name: str
    baseline: Dict[str, float]
    control_post: Dict[str, float]
    post_injection: Dict[str, float]
    delta: Dict[str, float]
    segment_breakdown: Dict[str, Any] = field(default_factory=dict)
    topology_summary: Dict[str, Any] = field(default_factory=dict)
    persistence_trace: List[Dict[str, float]] = field(default_factory=list)
    raw_snapshot: List[Dict[str, Any]] = field(default_factory=list)
    spatial_summary: Dict[str, Any] = field(default_factory=dict)
    hotspot_report: List[Dict[str, Any]] = field(default_factory=list)

    def summary(self) -> str:
        lines = [
            f"STIMULUS: {self.stimulus_text[:90]}{'...' if len(self.stimulus_text) > 90 else ''}",
            f"PROFILE: {self.profile_name}",
            f"SOURCE CHANNEL: {self.source_channel}",
            f"POPULATION: {self.population_size} agents",
            "",
            "HETEROGENEOUS RESPONSE (delta vs no-stimulus control):",
        ]
        for k, v in self.delta.items():
            arrow = "↑" if v > 0.005 else ("↓" if v < -0.005 else "→")
            lines.append(f"  {arrow} {k:<20} {v:+.4f}")
        return "\n".join(lines)

    def to_json(self) -> str:
        d = asdict(self)
        d.pop("raw_snapshot", None)
        return json.dumps(d, indent=2)


def population_averages(snapshot: List[Dict[str, Any]]) -> Dict[str, float]:
    keys = ["valence", "arousal", "dominance", "belief", "stress", "resources"]
    if not snapshot:
        return {k: 0.0 for k in keys}
    return {k: round(sum(a.get("state", {}).get(k, 0.0) for a in snapshot) / len(snapshot), 4) for k in keys}


def enrich_snapshot(snapshot: List[Dict[str, Any]], segments: List[SegmentProfile], locations: Optional[List[Any]] = None) -> List[Dict[str, Any]]:
    out = []
    for idx, (rec, seg) in enumerate(zip(snapshot, segments)):
        x = dict(rec)
        x["segment"] = seg.to_dict()
        if locations is not None and idx < len(locations):
            loc = locations[idx]
            x["location"] = loc.to_dict() if hasattr(loc, "to_dict") else dict(loc)
        out.append(x)
    return out


def segment_breakdown(snapshot: List[Dict[str, Any]], by: str = "economic_band") -> Dict[str, Any]:
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for rec in snapshot:
        key = rec.get("segment", {}).get(by, "unknown")
        groups.setdefault(key, []).append(rec)
    out: Dict[str, Any] = {}
    for key, rows in sorted(groups.items()):
        out[key] = {"n": len(rows), **population_averages(rows)}
    return out


def topology_summary(snapshot: List[Dict[str, Any]]) -> Dict[str, Any]:
    degrees = [len(a.get("neighbors", [])) for a in snapshot]
    if not degrees:
        return {}
    return {
        "avg_degree": round(sum(degrees) / len(degrees), 2),
        "min_degree": min(degrees),
        "max_degree": max(degrees),
        "isolated_count": sum(1 for d in degrees if d <= 1),
        "hub_count": sum(1 for d in degrees if d >= 10),
    }


class CalibratedPanel:
    """A synthetic panel with structural segments, trust channels, spatial districts, institutions, and decay."""

    def __init__(self, n: int = 1000, seed: int = 42, warmup_ticks: int = 20,
                 profile: Optional[Dict[str, Any] | str] = None, config: Optional[Dict[str, Any]] = None,
                 spatial_profile: Optional[Dict[str, Any]] = None):
        if isinstance(profile, str):
            self.profile = load_profile(profile)
        else:
            self.profile = profile or generic_profile()
        self.profile_name = str(self.profile.get("name", "generic_profile"))
        self.spatial_profile = spatial_profile or default_spatial_profile()
        self.n = n
        self.seed = seed
        self._warmup_ticks = warmup_ticks
        self._config = self._build_config(config)
        self.segments = build_segments(n=n, seed=seed, profile=self.profile)
        self.districts = build_districts(seed=seed, profile=self.spatial_profile)
        self.institutions = build_institutions(seed=seed, districts=self.districts, profile=self.spatial_profile)
        self.locations = assign_locations(seed=seed, segments=self.segments, districts=self.districts, institutions=self.institutions)
        self.sim = HRMCore(config=self._config)
        self._apply_segment_traits(self.sim)
        rebuild_segmented_network(self.sim, self.segments, seed=seed, avg_degree=self._config.get("network", {}).get("avg_degree", 6))
        for _ in range(warmup_ticks):
            self.sim.step()
        self._baseline = population_averages(self.sim.observe_snapshot())

    def _build_config(self, config: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        cfg = dict(DEFAULT_CONFIG)
        cfg["num_agents"] = self.n
        cfg["seed"] = self.seed
        cfg["events"] = []
        cfg["export"] = {"enabled": False}
        if config:
            cfg.update(config)
        return cfg

    def _apply_segment_traits(self, sim) -> None:
        for agent, seg in zip(sim.agents, self.segments):
            tr = agent.traits
            st = agent.state
            if seg.economic_band == "low_stability":
                tr.resource_level = clamp(tr.resource_level - 0.18)
                tr.anxiety_reactivity = clamp(tr.anxiety_reactivity + 0.08)
            elif seg.economic_band == "high_stability":
                tr.resource_level = clamp(tr.resource_level + 0.14)
                tr.anxiety_reactivity = clamp(tr.anxiety_reactivity - 0.04)
            if seg.connectivity_band == "hub":
                tr.social_sensitivity = clamp(tr.social_sensitivity + 0.08)
                tr.extraversion = clamp(tr.extraversion + 0.10)
            elif seg.connectivity_band == "isolated":
                tr.social_sensitivity = clamp(tr.social_sensitivity - 0.08)
                tr.extraversion = clamp(tr.extraversion - 0.08)
            if seg.education_band == "higher":
                tr.openness = clamp(tr.openness + 0.08)
                tr.conscientiousness = clamp(tr.conscientiousness + 0.04)
            st.resources = tr.resource_level

    def _fresh_control(self):
        control = HRMCore(config=dict(self._config))
        self._apply_segment_traits(control)
        rebuild_segmented_network(control, self.segments, seed=self.seed, avg_degree=self._config.get("network", {}).get("avg_degree", 6))
        for _ in range(self._warmup_ticks):
            control.step()
        return control

    def _apply_heterogeneous_signal(self, sim, signal: Dict[str, Any], channel: str, intensity: float) -> None:
        effects = signal.get("effects", {})
        stress_d = float(effects.get("stress_d", 0.0)) * intensity
        affect_d = float(effects.get("affect_d", 0.0)) * intensity
        satis_d = float(effects.get("satis_d", 0.0)) * intensity
        for agent, seg in zip(sim.agents, self.segments):
            scale = segment_response_scale(seg, signal, channel)
            # social sensitivity still matters, but it is no longer the only source of variance
            trait_scale = 0.65 + agent.traits.social_sensitivity * 0.55
            spatial_scale = exposure_scale_for_agent(self.locations[agent.id], seg, signal, signal.get("text", ""), self.districts, self.institutions) if hasattr(agent, "id") and agent.id < len(self.locations) else 1.0
            final_scale = scale * trait_scale * spatial_scale
            s = agent.state
            s.stress = clamp(s.stress + stress_d * final_scale)
            s.valence = max(-1.0, min(1.0, s.valence + affect_d * final_scale))
            s.belief = clamp(s.belief + satis_d * 0.45 * final_scale)

    def inject(self, text: str, run_ticks: int = 45, inject_tick: int = 5, half_life_ticks: int = 12) -> CalibratedResult:
        signal = parse_stimulus(text)
        signal["text"] = text
        channel = infer_source_channel(text)

        control = self._fresh_control()
        for _ in range(run_ticks):
            control.step()
        control_enriched = enrich_snapshot(control.observe_snapshot(), self.segments, self.locations)
        control_spatial = summarize_spatial_state(control_enriched)
        control_post = population_averages(control_enriched)
        control.close()

        persistence_trace: List[Dict[str, float]] = []
        for t in range(run_ticks):
            if t >= inject_tick:
                age = t - inject_tick
                intensity = 0.5 ** (age / max(1, half_life_ticks))
                if intensity > 0.05:
                    self._apply_heterogeneous_signal(self.sim, signal, channel, intensity)
                    persistence_trace.append({"tick": float(t), "intensity": round(float(intensity), 4)})
            self.sim.step()

        enriched = enrich_snapshot(self.sim.observe_snapshot(), self.segments, self.locations)
        post = population_averages(enriched)
        spatial_after = summarize_spatial_state(enriched)
        hotspots = hotspot_report(control_spatial, spatial_after, self.districts)
        delta = {k: round(post[k] - control_post.get(k, 0.0), 4) for k in post}
        return CalibratedResult(
            stimulus_text=text,
            population_size=self.n,
            ticks_run=run_ticks,
            source_channel=channel,
            profile_name=self.profile_name,
            baseline=self._baseline,
            control_post=control_post,
            post_injection=post,
            delta=delta,
            segment_breakdown={
                "economic_band": segment_breakdown(enriched, "economic_band"),
                "age_band": segment_breakdown(enriched, "age_band"),
                "connectivity_band": segment_breakdown(enriched, "connectivity_band"),
            },
            topology_summary=topology_summary(enriched),
            persistence_trace=persistence_trace,
            raw_snapshot=enriched,
            spatial_summary={
                "districts": [d.to_dict() for d in self.districts],
                "institutions": [i.to_dict() for i in self.institutions],
                "district_response": spatial_after,
            },
            hotspot_report=hotspots,
        )

    def reset(self) -> None:
        self.__init__(n=self.n, seed=self.seed, warmup_ticks=self._warmup_ticks, profile=self.profile, config=self._config, spatial_profile=self.spatial_profile)
