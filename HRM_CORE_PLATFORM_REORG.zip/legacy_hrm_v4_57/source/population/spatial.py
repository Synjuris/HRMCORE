"""Abstract spatial and institutional dynamics for HRM_UNIFIED v1.5.

No real locality is embedded here. Districts and institutions are generic civic
archetypes that can later be parameterized from external datasets.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Tuple
import math
import random

from .calibration import SegmentProfile, clamp, weighted_choice, normalize_distribution

DISTRICT_TYPES = (
    "urban_core",
    "industrial",
    "suburban",
    "rural_edge",
    "commercial",
    "institutional",
    "university",
)

INSTITUTION_TYPES = (
    "school",
    "employer",
    "local_government",
    "hospital",
    "media_hub",
    "community_center",
    "utility",
)


@dataclass(frozen=True)
class DistrictProfile:
    id: str
    kind: str
    density: float
    mobility: float
    economic_pressure: float
    institutional_trust: float
    local_connectivity: float
    x: float
    y: float

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class InstitutionProfile:
    id: str
    kind: str
    district_id: str
    trust: float
    reach: float
    influence: float
    channel: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class AgentLocation:
    home_district: str
    work_district: str
    anchor_institution: str | None
    movement_probability: float

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def default_spatial_profile() -> Dict[str, Any]:
    return {
        "name": "generic_spatial_civic_archetype",
        "description": "Geography-agnostic abstract districts and institutions.",
        "district_weights": {
            "urban_core": 0.18,
            "industrial": 0.14,
            "suburban": 0.28,
            "rural_edge": 0.13,
            "commercial": 0.12,
            "institutional": 0.09,
            "university": 0.06,
        },
        "institution_weights": {
            "school": 0.18,
            "employer": 0.24,
            "local_government": 0.10,
            "hospital": 0.10,
            "media_hub": 0.08,
            "community_center": 0.20,
            "utility": 0.10,
        },
    }


def build_districts(seed: int, profile: Dict[str, Any] | None = None, count: int = 9) -> List[DistrictProfile]:
    rng = random.Random(seed + 5011)
    profile = profile or default_spatial_profile()
    weights = normalize_distribution(profile.get("district_weights", {}), DISTRICT_TYPES)
    districts: List[DistrictProfile] = []

    defaults = {
        "urban_core":        (0.82, 0.72, 0.62, 0.46, 0.78),
        "industrial":        (0.55, 0.63, 0.74, 0.43, 0.56),
        "suburban":          (0.42, 0.58, 0.40, 0.55, 0.52),
        "rural_edge":        (0.24, 0.38, 0.48, 0.58, 0.38),
        "commercial":        (0.67, 0.78, 0.52, 0.50, 0.70),
        "institutional":     (0.60, 0.65, 0.36, 0.62, 0.66),
        "university":        (0.70, 0.76, 0.34, 0.57, 0.74),
    }
    for i in range(count):
        kind = weighted_choice(rng, weights)
        density, mobility, econ_pressure, trust, local_conn = defaults[kind]
        angle = (2 * math.pi * i / max(1, count)) + rng.uniform(-0.12, 0.12)
        radius = 0.25 + 0.65 * rng.random()
        districts.append(DistrictProfile(
            id=f"D{i:02d}",
            kind=kind,
            density=clamp(density + rng.normalvariate(0, 0.04)),
            mobility=clamp(mobility + rng.normalvariate(0, 0.04)),
            economic_pressure=clamp(econ_pressure + rng.normalvariate(0, 0.05)),
            institutional_trust=clamp(trust + rng.normalvariate(0, 0.05)),
            local_connectivity=clamp(local_conn + rng.normalvariate(0, 0.05)),
            x=round(radius * math.cos(angle), 4),
            y=round(radius * math.sin(angle), 4),
        ))
    return districts


def build_institutions(seed: int, districts: List[DistrictProfile], profile: Dict[str, Any] | None = None,
                       count: int = 16) -> List[InstitutionProfile]:
    rng = random.Random(seed + 5021)
    profile = profile or default_spatial_profile()
    weights = normalize_distribution(profile.get("institution_weights", {}), INSTITUTION_TYPES)
    channel_by_kind = {
        "school": "authority",
        "employer": "institutional",
        "local_government": "authority",
        "hospital": "authority",
        "media_hub": "media",
        "community_center": "local",
        "utility": "institutional",
    }
    districts_by_id = {d.id: d for d in districts}
    out: List[InstitutionProfile] = []
    for i in range(count):
        kind = weighted_choice(rng, weights)
        district = rng.choices(districts, weights=[0.3 + d.density + d.local_connectivity for d in districts], k=1)[0]
        trust_base = {
            "school": 0.58,
            "employer": 0.48,
            "local_government": 0.44,
            "hospital": 0.66,
            "media_hub": 0.42,
            "community_center": 0.64,
            "utility": 0.50,
        }[kind]
        reach_base = {
            "school": 0.48,
            "employer": 0.55,
            "local_government": 0.70,
            "hospital": 0.52,
            "media_hub": 0.78,
            "community_center": 0.42,
            "utility": 0.66,
        }[kind]
        d = districts_by_id[district.id]
        out.append(InstitutionProfile(
            id=f"I{i:02d}",
            kind=kind,
            district_id=district.id,
            trust=clamp((trust_base + d.institutional_trust) / 2.0 + rng.normalvariate(0, 0.04)),
            reach=clamp(reach_base * (0.65 + 0.55 * d.density) + rng.normalvariate(0, 0.04)),
            influence=clamp(0.35 + 0.45 * reach_base + 0.20 * d.local_connectivity + rng.normalvariate(0, 0.04)),
            channel=channel_by_kind[kind],
        ))
    return out


def assign_locations(seed: int, segments: List[SegmentProfile], districts: List[DistrictProfile],
                     institutions: List[InstitutionProfile]) -> List[AgentLocation]:
    rng = random.Random(seed + 5031)
    institutions_by_district: Dict[str, List[InstitutionProfile]] = {}
    for inst in institutions:
        institutions_by_district.setdefault(inst.district_id, []).append(inst)

    out: List[AgentLocation] = []
    for seg in segments:
        home_weights = []
        for d in districts:
            w = 0.25 + d.density + d.local_connectivity
            if seg.economic_band == "low_stability" and d.economic_pressure > 0.55:
                w += 0.35
            if seg.economic_band == "high_stability" and d.kind in ("suburban", "institutional", "university"):
                w += 0.30
            if seg.age_band == "under_25" and d.kind in ("university", "urban_core"):
                w += 0.25
            if seg.age_band == "65_plus" and d.kind in ("rural_edge", "suburban"):
                w += 0.20
            home_weights.append(max(0.01, w))
        home = rng.choices(districts, weights=home_weights, k=1)[0]

        if rng.random() < seg.mobility:
            work_weights = [0.20 + d.mobility + (0.40 if d.kind in ("commercial", "industrial", "institutional", "university") else 0.0) for d in districts]
            work = rng.choices(districts, weights=work_weights, k=1)[0]
        else:
            work = home

        possible = institutions_by_district.get(home.id, []) + institutions_by_district.get(work.id, [])
        anchor = None
        if possible and rng.random() < (0.30 + 0.45 * seg.local_trust):
            anchor = rng.choices(possible, weights=[0.1 + x.reach + x.trust for x in possible], k=1)[0].id

        out.append(AgentLocation(
            home_district=home.id,
            work_district=work.id,
            anchor_institution=anchor,
            movement_probability=clamp((seg.mobility + home.mobility + work.mobility) / 3.0),
        ))
    return out


def distance(a: DistrictProfile, b: DistrictProfile) -> float:
    return math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2)


def infer_target_context(text: str, institutions: List[InstitutionProfile], districts: List[DistrictProfile]) -> Dict[str, Any]:
    t = text.lower()
    inst_hits: List[str] = []
    kind_hits: List[str] = []
    district_kind_hits: List[str] = []
    for inst in institutions:
        if inst.kind.replace("_", " ") in t or inst.kind in t:
            inst_hits.append(inst.id)
            kind_hits.append(inst.kind)
    for d in districts:
        if d.kind.replace("_", " ") in t or d.kind in t:
            district_kind_hits.append(d.kind)
    return {
        "institution_ids": sorted(set(inst_hits)),
        "institution_kinds": sorted(set(kind_hits)),
        "district_kinds": sorted(set(district_kind_hits)),
    }


def exposure_scale_for_agent(location: AgentLocation, seg: SegmentProfile, signal: Dict[str, Any], text: str,
                             districts: List[DistrictProfile], institutions: List[InstitutionProfile]) -> float:
    d_by_id = {d.id: d for d in districts}
    inst_by_id = {i.id: i for i in institutions}
    context = infer_target_context(text, institutions, districts)
    home = d_by_id[location.home_district]
    work = d_by_id[location.work_district]
    base = 0.75 + 0.30 * home.local_connectivity + 0.20 * location.movement_probability
    base += 0.15 * seg.media_exposure

    if context["district_kinds"]:
        nearest_factor = 0.0
        for d in districts:
            if d.kind in context["district_kinds"]:
                nearest_factor = max(nearest_factor, 1.0 / (1.0 + distance(home, d)))
                nearest_factor = max(nearest_factor, 0.8 / (1.0 + distance(work, d)))
        base *= 0.75 + 0.65 * nearest_factor

    anchor = inst_by_id.get(location.anchor_institution or "")
    if anchor:
        if anchor.id in context["institution_ids"] or anchor.kind in context["institution_kinds"]:
            base *= 1.25 + 0.35 * anchor.trust
        else:
            base *= 1.0 + 0.10 * anchor.reach

    if context["institution_kinds"]:
        for inst in institutions:
            if inst.kind in context["institution_kinds"]:
                inst_d = d_by_id[inst.district_id]
                proximity = max(1.0 / (1.0 + distance(home, inst_d)), 0.8 / (1.0 + distance(work, inst_d)))
                base *= 0.90 + 0.18 * inst.reach * proximity
                break

    tags = signal.get("tags", {})
    if float(tags.get("valence", 0.0)) < 0:
        base *= 0.95 + 0.35 * home.economic_pressure
    else:
        base *= 0.95 + 0.25 * home.institutional_trust
    return clamp(base, 0.25, 2.40)


def summarize_spatial_state(snapshot: List[Dict[str, Any]]) -> Dict[str, Any]:
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for rec in snapshot:
        district = rec.get("location", {}).get("home_district", "unknown")
        groups.setdefault(district, []).append(rec)
    out: Dict[str, Any] = {}
    for district_id, rows in sorted(groups.items()):
        n = len(rows)
        if n == 0:
            continue
        out[district_id] = {
            "n": n,
            "stress": round(sum(r.get("state", {}).get("stress", 0.0) for r in rows) / n, 4),
            "valence": round(sum(r.get("state", {}).get("valence", 0.0) for r in rows) / n, 4),
            "belief": round(sum(r.get("state", {}).get("belief", 0.0) for r in rows) / n, 4),
        }
    return out


def hotspot_report(before: Dict[str, Any], after: Dict[str, Any], districts: List[DistrictProfile], top_n: int = 5) -> List[Dict[str, Any]]:
    d_meta = {d.id: d for d in districts}
    rows: List[Dict[str, Any]] = []
    for district_id, post in after.items():
        pre = before.get(district_id, {})
        stress_delta = round(float(post.get("stress", 0.0)) - float(pre.get("stress", 0.0)), 4)
        valence_delta = round(float(post.get("valence", 0.0)) - float(pre.get("valence", 0.0)), 4)
        belief_delta = round(float(post.get("belief", 0.0)) - float(pre.get("belief", 0.0)), 4)
        d = d_meta.get(district_id)
        rows.append({
            "district_id": district_id,
            "district_kind": d.kind if d else "unknown",
            "n": post.get("n", 0),
            "stress_delta": stress_delta,
            "valence_delta": valence_delta,
            "belief_delta": belief_delta,
            "hotspot_score": round(stress_delta - valence_delta * 0.5 - belief_delta * 0.25, 4),
        })
    rows.sort(key=lambda r: r["hotspot_score"], reverse=True)
    return rows[:top_n]
