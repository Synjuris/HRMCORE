"""Emergent civic dynamics for HRM_UNIFIED v1.6.

This layer does not claim prediction. It converts repeated synthetic panel runs into
traceable civic pressure signals so downstream tools can see when accumulated
stress, trust loss, recovery, or localized hotspots cross explicit thresholds.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional
import json

try:
    from .calibration import clamp
    from .calibrated_panel import CalibratedPanel, CalibratedResult
except ImportError:
    from population.calibration import clamp
    from population.calibrated_panel import CalibratedPanel, CalibratedResult


@dataclass
class CivicEvent:
    tick: int
    kind: str
    severity: float
    scope: str
    message: str
    evidence: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class CivicState:
    tick: int = 0
    stress_pressure: float = 0.0
    trust_pressure: float = 0.0
    volatility_pressure: float = 0.0
    cooperation_pressure: float = 0.0
    withdrawal_pressure: float = 0.0
    district_pressures: Dict[str, Dict[str, float]] = field(default_factory=dict)
    institution_strain: Dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def summary(self) -> Dict[str, float]:
        return {
            "stress_pressure": round(self.stress_pressure, 4),
            "trust_pressure": round(self.trust_pressure, 4),
            "volatility_pressure": round(self.volatility_pressure, 4),
            "cooperation_pressure": round(self.cooperation_pressure, 4),
            "withdrawal_pressure": round(self.withdrawal_pressure, 4),
        }


@dataclass
class CivicRunResult:
    profile_name: str
    population_size: int
    steps: List[Dict[str, Any]]
    state_trace: List[Dict[str, Any]]
    events: List[CivicEvent]
    final_state: CivicState

    def to_json(self) -> str:
        return json.dumps({
            "profile_name": self.profile_name,
            "population_size": self.population_size,
            "steps": self.steps,
            "state_trace": self.state_trace,
            "events": [e.to_dict() for e in self.events],
            "final_state": self.final_state.to_dict(),
        }, indent=2)

    def summary(self) -> str:
        lines = [
            "HRM_UNIFIED v1.6 CIVIC DYNAMICS RUN",
            f"Profile: {self.profile_name}",
            f"Population: {self.population_size}",
            "",
            "Final civic pressures:",
        ]
        for k, v in self.final_state.summary().items():
            lines.append(f"  {k:<24} {v:+.4f}")
        lines.append("")
        lines.append("Emergent events:")
        if not self.events:
            lines.append("  none")
        for e in self.events:
            lines.append(f"  tick {e.tick:>3} | {e.kind:<28} severity={e.severity:.3f} | {e.message}")
        return "\n".join(lines)


class CivicDynamicsTracker:
    """Accumulates panel outputs into traceable civic pressure states."""

    def __init__(self, decay: float = 0.86):
        self.decay = clamp(decay, 0.50, 0.99)
        self.state = CivicState()
        self.events: List[CivicEvent] = []
        self._fired_keys: set[str] = set()

    def _decay_state(self) -> None:
        s = self.state
        s.stress_pressure *= self.decay
        s.trust_pressure *= self.decay
        s.volatility_pressure *= self.decay
        s.cooperation_pressure *= self.decay
        s.withdrawal_pressure *= self.decay
        for d in list(s.district_pressures):
            for k in list(s.district_pressures[d]):
                s.district_pressures[d][k] *= self.decay
        for inst in list(s.institution_strain):
            s.institution_strain[inst] *= self.decay

    def _add_event_once(self, tick: int, kind: str, severity: float, scope: str, message: str, evidence: Dict[str, Any]) -> None:
        # bucket severity to avoid firing the same warning every step while still allowing escalation.
        bucket = int(max(0.0, severity) * 2.0)
        key = f"{kind}:{scope}:{bucket}"
        if key in self._fired_keys:
            return
        self._fired_keys.add(key)
        self.events.append(CivicEvent(tick=tick, kind=kind, severity=round(float(severity), 4), scope=scope, message=message, evidence=evidence))

    def ingest(self, result: CalibratedResult, tick: int) -> Dict[str, Any]:
        self.state.tick = tick
        self._decay_state()

        d = result.delta
        stress_delta = float(d.get("stress", 0.0))
        valence_delta = float(d.get("valence", 0.0))
        belief_delta = float(d.get("belief", 0.0))
        resource_delta = float(d.get("resources", 0.0))
        dominance_delta = float(d.get("dominance", 0.0))

        stress_signal = max(0.0, stress_delta)
        trust_loss_signal = max(0.0, -belief_delta) + max(0.0, -resource_delta) * 0.45
        recovery_signal = max(0.0, -stress_delta) + max(0.0, valence_delta) + max(0.0, belief_delta) * 0.35
        volatility_signal = max(0.0, stress_delta - valence_delta * 0.55 + abs(dominance_delta) * 0.20)
        withdrawal_signal = max(0.0, -valence_delta) + max(0.0, stress_delta) * 0.35

        s = self.state
        s.stress_pressure += stress_signal
        s.trust_pressure += trust_loss_signal
        s.volatility_pressure += volatility_signal
        s.cooperation_pressure += recovery_signal
        s.withdrawal_pressure += withdrawal_signal

        for h in result.hotspot_report:
            did = str(h.get("district_id", "unknown"))
            rec = s.district_pressures.setdefault(did, {"stress": 0.0, "withdrawal": 0.0, "volatility": 0.0})
            rec["stress"] += max(0.0, float(h.get("stress_delta", 0.0)))
            rec["withdrawal"] += max(0.0, -float(h.get("valence_delta", 0.0)))
            rec["volatility"] += max(0.0, float(h.get("hotspot_score", 0.0)))

        # Institution strain is not a claim about real institutions; it is a synthetic
        # pressure proxy based on low trust + broad reach + negative system deltas.
        for inst in result.spatial_summary.get("institutions", []):
            base = (1.0 - float(inst.get("trust", 0.5))) * float(inst.get("reach", 0.5))
            strain = base * (stress_signal + trust_loss_signal + max(0.0, -valence_delta))
            if strain > 0:
                s.institution_strain[str(inst.get("id", "unknown"))] = s.institution_strain.get(str(inst.get("id", "unknown")), 0.0) + strain

        self._detect_events(result, tick)
        return self.state.to_dict()

    def _detect_events(self, result: CalibratedResult, tick: int) -> None:
        s = self.state
        if s.stress_pressure >= 0.35:
            self._add_event_once(tick, "system_stress_threshold", s.stress_pressure, "system", "accumulated stress exceeded the watch band", s.summary())
        if s.volatility_pressure >= 0.45:
            self._add_event_once(tick, "volatility_threshold", s.volatility_pressure, "system", "population volatility crossed the threshold", s.summary())
        if s.withdrawal_pressure >= 0.40:
            self._add_event_once(tick, "withdrawal_threshold", s.withdrawal_pressure, "system", "negative valence and stress accumulated into withdrawal pressure", s.summary())
        if s.cooperation_pressure >= 0.30 and s.stress_pressure < 0.28:
            self._add_event_once(tick, "cooperation_recovery_wave", s.cooperation_pressure, "system", "recovery/cooperation pressure became dominant", s.summary())

        for did, rec in sorted(s.district_pressures.items()):
            if rec.get("volatility", 0.0) >= 0.18:
                self._add_event_once(tick, "localized_hotspot", rec["volatility"], did, f"district {did} accumulated localized hotspot pressure", dict(rec))
            if rec.get("withdrawal", 0.0) >= 0.15:
                self._add_event_once(tick, "localized_withdrawal", rec["withdrawal"], did, f"district {did} accumulated withdrawal pressure", dict(rec))

        if s.institution_strain:
            inst_id, strain = max(s.institution_strain.items(), key=lambda kv: kv[1])
            if strain >= 0.12:
                inst_meta = None
                for inst in result.spatial_summary.get("institutions", []):
                    if inst.get("id") == inst_id:
                        inst_meta = inst
                        break
                self._add_event_once(tick, "institutional_strain", strain, inst_id, f"institution {inst_id} crossed synthetic strain threshold", {"institution": inst_meta, "strain": round(strain, 4)})


def default_civic_sequence() -> List[Dict[str, Any]]:
    """Generic, non-local, non-personal scenario sequence."""
    return [
        {"tick": 0, "stimulus": "A regional employer announces temporary layoffs and reduced hours.", "ticks": 28},
        {"tick": 1, "stimulus": "A utility outage disrupts several commercial and residential districts.", "ticks": 28},
        {"tick": 2, "stimulus": "Local government issues an unclear public notice about service delays.", "ticks": 28},
        {"tick": 3, "stimulus": "Community centers organize volunteer aid and supply distribution.", "ticks": 28},
        {"tick": 4, "stimulus": "Hospitals and schools publish coordinated recovery information.", "ticks": 28},
    ]


def run_civic_sequence(sequence: Optional[List[Dict[str, Any]]] = None, n: int = 1000, seed: int = 42,
                       profile: str = "generic_mixed_region", decay: float = 0.86) -> CivicRunResult:
    sequence = sequence or default_civic_sequence()
    panel = CalibratedPanel(n=n, seed=seed, profile=profile)
    tracker = CivicDynamicsTracker(decay=decay)
    steps: List[Dict[str, Any]] = []
    state_trace: List[Dict[str, Any]] = []

    for idx, step in enumerate(sequence):
        tick = int(step.get("tick", idx))
        stimulus = str(step.get("stimulus", ""))
        ticks = int(step.get("ticks", 28))
        result = panel.inject(stimulus, run_ticks=ticks)
        state = tracker.ingest(result, tick)
        steps.append({
            "tick": tick,
            "stimulus": stimulus,
            "delta": result.delta,
            "top_hotspots": result.hotspot_report[:3],
        })
        state_trace.append(state)

    return CivicRunResult(
        profile_name=panel.profile_name,
        population_size=n,
        steps=steps,
        state_trace=state_trace,
        events=tracker.events,
        final_state=tracker.state,
    )
