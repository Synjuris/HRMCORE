"""
trace_run.py — v04.11 Structural Observatory
Single-run mode. No new mechanics. No aggregation. No narrative.

Writes a raw event stream and five audit logs:
  trace_out/dyad_lifecycle.jsonl     — every dyad transition (birth, conflict, coop, death)
  trace_out/conflict_lineage.jsonl   — each conflict tagged with causal chain fields
  trace_out/faction_topology.jsonl   — faction snapshot every TOPOLOGY_INTERVAL ticks
  trace_out/institution_log.jsonl    — each institution intervention with pre/post rel state
  trace_out/attractor_state.jsonl    — attractor classification + raw values every tick
  trace_out/raw_events.jsonl         — full event stream (one JSON object per line)
  trace_out/audit_report.json        — post-run integrity checks

Run:
  python trace_run.py
  DAS_TRACE_SEED=4 python trace_run.py      # seed = run_id used in benchmark
  DAS_TRACE_TICKS=1000 python trace_run.py
"""

import json
import os
import random
from collections import defaultdict
from pathlib import Path

from agent import Agent
from environment import EnvironmentCycle
from metrics import topology_metrics
from space import SpatialWorld
from resources import ResourceWorld
from factions import FactionRegistry
from territory import TerritoryMap
from institutions import InstitutionRegistry
from culture import CulturePool
from reproduction import ReproductionSystem
from language import WorldNarrative
from deception import DECEIVE_THRESHOLD
from experiential import TextureChronicle

# ── Config ────────────────────────────────────────────────────────────────────
SEED             = int(os.environ.get("DAS_TRACE_SEED", "4"))
TICKS            = int(os.environ.get("DAS_TRACE_TICKS", "500"))
TOPOLOGY_INTERVAL = int(os.environ.get("DAS_TOPOLOGY_INTERVAL", "50"))
OUTPUT_DIR       = Path(os.environ.get("DAS_TRACE_OUT", "trace_out"))
INITIAL_AGENTS   = 10
AGENT_NAMES      = ["Ada", "Bruno", "Cleo", "Dax", "Eli",
                    "Faye", "Gio", "Hana", "Ira", "Juno"]

# Attractor thresholds (same as run_sim.py classify_attractor)
ATTRACTOR_PEACEFUL_MAX  = 6.0
ATTRACTOR_CONFLICT_MIN  = 14.0


# ── Helpers ───────────────────────────────────────────────────────────────────

def dyad_key(a, b):
    return tuple(sorted([a, b]))

def faction_name(faction_registry, agent_id):
    if not faction_registry:
        return None
    f = faction_registry.faction_of(agent_id)
    return f.name if f else None

def classify_attractor(conflict_per_100):
    if conflict_per_100 is None:
        return "unknown"
    if conflict_per_100 < ATTRACTOR_PEACEFUL_MAX:
        return "peaceful"
    if conflict_per_100 > ATTRACTOR_CONFLICT_MIN:
        return "conflict"
    return "mixed"

def rel_snapshot(agent, other_id):
    """Capture the directed relationship state from agent -> other_id."""
    r = agent.relationships.get(other_id)
    return {
        "trust":      round(r.trust, 4),
        "resentment": round(r.resentment, 4),
        "attachment": round(r.attachment, 4),
        "avoidance":  round(r.avoidance, 4),
        "influence":  round(r.influence, 4),
        "interactions": r.interactions,
    }

def serialize_event(event):
    return {
        "tick":         event.tick,
        "phase":        event.phase,
        "actor_id":     event.actor_id,
        "event_type":   event.event_type,
        "participants": event.participants,
        "context":      event.context,
        "impact":       event.impact,
        "outcome":      event.outcome,
    }


# ── JSONL writer ──────────────────────────────────────────────────────────────

class LogWriter:
    def __init__(self, path: Path):
        self._path = path
        self._f = open(path, "w", encoding="utf-8")

    def write(self, obj: dict):
        self._f.write(json.dumps(obj) + "\n")

    def close(self):
        self._f.close()


# ── Dyad registry — tracks birth/death of interaction pairs ──────────────────

class DyadRegistry:
    """
    Tracks cross-faction dyad lifecycle.
    'Birth' = first conflict between a cross-faction pair.
    'Death' = one agent dies.
    Records every conflict and cooperation event per dyad.
    """
    def __init__(self):
        self._dyads = {}           # key -> record
        self._agent_factions = {}  # agent_id -> faction_name at birth

    def _get_or_create(self, key, a_id, b_id, fa, fb, tick):
        if key not in self._dyads:
            self._dyads[key] = {
                "dyad_id":           f"{key[0]}::{key[1]}",
                "agents":            list(key),
                "faction_pair":      sorted([fa, fb]),
                "born_tick":         tick,
                "died_tick":         None,
                "first_conflict_tick": None,
                "last_conflict_tick":  None,
                "conflict_count":    0,
                "cooperation_count": 0,
                "events":            [],   # (tick, outcome) for lineage
            }
        return self._dyads[key]

    def record_interaction(self, tick, a_id, b_id, fa, fb, outcome, log_writer):
        if not fa or not fb or fa == fb:
            return
        key = dyad_key(a_id, b_id)
        rec = self._get_or_create(key, a_id, b_id, fa, fb, tick)
        rec["events"].append((tick, outcome))

        is_new_conflict = (outcome == "conflict" and rec["first_conflict_tick"] is None)
        if outcome == "conflict":
            rec["conflict_count"] += 1
            if rec["first_conflict_tick"] is None:
                rec["first_conflict_tick"] = tick
            rec["last_conflict_tick"] = tick
        elif outcome == "cooperation":
            rec["cooperation_count"] += 1

        if is_new_conflict:
            log_writer.write({
                "event": "dyad_conflict_born",
                "tick":  tick,
                "dyad_id": rec["dyad_id"],
                "agents": rec["agents"],
                "faction_pair": rec["faction_pair"],
            })

    def record_agent_death(self, tick, dead_id, log_writer):
        for key, rec in self._dyads.items():
            if dead_id in key and rec["died_tick"] is None and rec["first_conflict_tick"] is not None:
                rec["died_tick"] = tick
                log_writer.write({
                    "event":      "dyad_death",
                    "tick":       tick,
                    "dyad_id":    rec["dyad_id"],
                    "agents":     rec["agents"],
                    "faction_pair": rec["faction_pair"],
                    "born_tick":  rec["born_tick"],
                    "first_conflict_tick": rec["first_conflict_tick"],
                    "lifespan":   tick - rec["first_conflict_tick"],
                    "conflict_count": rec["conflict_count"],
                    "cooperation_count": rec["cooperation_count"],
                    "dead_agent": dead_id,
                })

    def snapshot(self):
        return list(self._dyads.values())


# ── Conflict lineage tracker ──────────────────────────────────────────────────

class LineageTracker:
    """
    For each conflict event, tags:
      - whether either agent was involved in a prior conflict in the last N ticks
      - whether the dyad has a prior conflict (repeat conflict)
      - predecessor dyad if a prior-conflict agent is from a different dyad
    This is the handoff chain / propagation graph seed.
    """
    LOOKBACK = 50  # ticks to consider for "recent conflict participant"

    def __init__(self):
        # agent_id -> list of (tick, dyad_key) for conflicts they participated in
        self._agent_conflict_history = defaultdict(list)

    def tag_conflict(self, tick, actor_id, other_id, dyad_rec) -> dict:
        key = dyad_key(actor_id, other_id)
        is_repeat = (dyad_rec["conflict_count"] > 1) if dyad_rec else False

        # Check if either agent had a recent conflict with someone else
        predecessor_dyads = {}
        for agent_id in [actor_id, other_id]:
            recent = [
                (t, dk) for t, dk in self._agent_conflict_history[agent_id]
                if tick - t <= self.LOOKBACK and dk != key
            ]
            if recent:
                # Most recent different-dyad conflict
                most_recent = max(recent, key=lambda x: x[0])
                predecessor_dyads[agent_id] = {
                    "tick":    most_recent[0],
                    "dyad_id": f"{most_recent[1][0]}::{most_recent[1][1]}",
                    "lag":     tick - most_recent[0],
                }

        # Record this conflict
        self._agent_conflict_history[actor_id].append((tick, key))
        self._agent_conflict_history[other_id].append((tick, key))

        return {
            "is_repeat_dyad_conflict": is_repeat,
            "prior_conflict_count":    (dyad_rec["conflict_count"] - 1) if dyad_rec else 0,
            "predecessor_dyads":       predecessor_dyads,   # agent_id -> predecessor info
            "is_handoff":              bool(predecessor_dyads),
        }


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    OUTPUT_DIR.mkdir(exist_ok=True)

    # Writers
    wdyad   = LogWriter(OUTPUT_DIR / "dyad_lifecycle.jsonl")
    wlin    = LogWriter(OUTPUT_DIR / "conflict_lineage.jsonl")
    wtopo   = LogWriter(OUTPUT_DIR / "faction_topology.jsonl")
    winst   = LogWriter(OUTPUT_DIR / "institution_log.jsonl")
    wattr   = LogWriter(OUTPUT_DIR / "attractor_state.jsonl")
    wraw    = LogWriter(OUTPUT_DIR / "raw_events.jsonl")

    # World setup — same as run_sim.py make_world_systems(seed)
    world_rng        = random.Random(SEED)
    spatial_world    = SpatialWorld(width=20, height=20, interaction_radius=3.0)
    resource_world   = ResourceWorld(width=20, height=20, n_nodes=10, rng=world_rng)
    faction_registry = FactionRegistry()
    territory_map    = TerritoryMap(width=20, height=20)
    institution_registry = InstitutionRegistry()
    culture_pool     = CulturePool()
    reproduction_system = ReproductionSystem(max_population=20)
    world_narrative  = WorldNarrative()
    texture_chronicle = TextureChronicle()
    env              = EnvironmentCycle()

    agents = [
        Agent(name, seed=i + 1 + SEED * 100,
              spatial_world=spatial_world,
              faction_registry=faction_registry,
              culture_pool=culture_pool)
        for i, name in enumerate(AGENT_NAMES)
    ]
    initial_agent_ids = {a.id for a in agents}
    by_id = {a.id: a for a in agents}

    # Auxiliary trackers
    dyad_reg  = DyadRegistry()
    lineage   = LineageTracker()
    death_logged = set()
    deception_logged_this_tick = set()

    # Counters for audit
    total_interactions = 0
    total_conflicts    = 0
    total_cooperations = 0

    # Rolling window for attractor state
    interaction_window = []   # (tick, outcome)
    WINDOW = 100              # rolling window size for per-tick attractor

    print(f"trace_run.py | seed={SEED} ticks={TICKS} -> {OUTPUT_DIR}/")
    print()

    # ── Tick loop ─────────────────────────────────────────────────────────────
    for tick in range(TICKS):
        phase = env.get_phase(tick)
        deception_logged_this_tick = set()

        resource_world.tick_regen()
        territory_map.decay_all()
        culture_pool.decay()
        culture_pool.mutate(random.Random(tick + SEED), tick, agents)

        if tick % 10 == 0:
            faction_registry.pool_resources(agents)
        if tick % 20 == 0:
            institution_registry.try_form(agents, faction_registry, tick)
        institution_registry.tick(agents)
        texture_chronicle.spread_artifacts(tick, agents, random.Random(tick + SEED * 997))
        texture_chronicle.maybe_ritualize(tick, agents, random.Random(tick + SEED * 991))

        # ── Per-agent tick ────────────────────────────────────────────────────
        for agent in list(agents):
            was_alive = agent.alive
            event = agent.tick(
                tick, phase, agents,
                spatial_world=spatial_world,
                resource_world=resource_world,
                faction_registry=faction_registry,
                territory_map=territory_map,
                institution_registry=institution_registry,
                culture_pool=culture_pool,
                world_narrative=world_narrative,
                texture_chronicle=texture_chronicle,
            )

            if event:
                ev = serialize_event(event)
                wraw.write(ev)

                if event.event_type == "interaction" and event.participants:
                    other_id = event.participants[0]
                    total_interactions += 1
                    interaction_window.append((tick, event.outcome))

                    fa = faction_name(faction_registry, agent.id)
                    fb = faction_name(faction_registry, other_id)

                    # Dyad lifecycle
                    dyad_reg.record_interaction(tick, agent.id, other_id, fa, fb, event.outcome, wdyad)

                    if event.outcome == "conflict":
                        total_conflicts += 1
                        key = dyad_key(agent.id, other_id)
                        dyad_rec = dyad_reg._dyads.get(key)

                        # Conflict lineage
                        lin = lineage.tag_conflict(tick, agent.id, other_id, dyad_rec)

                        # Institution intervention detail
                        inst_supp = event.context.get("institution_suppression", 0.0)
                        prevented = event.context.get("institution_prevented_conflict", False)
                        # Note: this is a conflict that happened DESPITE suppression;
                        # institution_prevented_conflict=True events are cooperation outcomes.
                        # We log institution influence on this conflict anyway.

                        wlin.write({
                            "tick":        tick,
                            "phase":       event.phase,
                            "actor_id":    agent.id,
                            "actor_name":  agent.name,
                            "other_id":    other_id,
                            "other_name":  by_id.get(other_id, agent).name if other_id in by_id else other_id,
                            "dyad_id":     f"{key[0]}::{key[1]}",
                            "fa":          fa,
                            "fb":          fb,
                            "cross_faction": (fa != fb and fa and fb),
                            "raw_conflict_pull":   event.context.get("raw_conflict_pull"),
                            "inst_suppression":    round(inst_supp, 4),
                            "final_conflict_pull": event.context.get("final_conflict_pull"),
                            "cooperation_pull":    event.context.get("cooperation_pull"),
                            "outcome_noise":       event.context.get("outcome_noise"),
                            "faction_hostility":   event.context.get("faction_hostility"),
                            **lin,
                            # Relationship state at moment of conflict
                            "rel_actor_to_other": rel_snapshot(agent, other_id),
                        })

                    elif event.outcome == "cooperation":
                        total_cooperations += 1

                    # Institution prevention events (cooperation that was heading to conflict)
                    if event.context.get("institution_prevented_conflict"):
                        other_agent = by_id.get(other_id)
                        winst.write({
                            "tick":         tick,
                            "actor_id":     agent.id,
                            "actor_name":   agent.name,
                            "other_id":     other_id,
                            "other_name":   other_agent.name if other_agent else other_id,
                            "fa":           fa,
                            "fb":           fb,
                            "raw_conflict_pull":   event.context.get("raw_conflict_pull"),
                            "inst_suppression":    event.context.get("institution_suppression"),
                            "cooperation_pull":    event.context.get("cooperation_pull"),
                            "outcome":      "conflict_prevented",
                            # Pre-intervention relationship state
                            "rel_actor_pre": rel_snapshot(agent, other_id),
                            "rel_other_pre": rel_snapshot(other_agent, agent.id) if other_agent else None,
                        })

            # Aux events (deception, negotiation)
            for aux_event in getattr(agent, "aux_events", []):
                if aux_event.event_type == "deception" and aux_event.participants:
                    dec_key = (aux_event.tick, aux_event.actor_id, aux_event.participants[0])
                    if dec_key in deception_logged_this_tick:
                        continue
                    deception_logged_this_tick.add(dec_key)
                wraw.write(serialize_event(aux_event))
            agent.aux_events = []

            # Death
            if was_alive and not agent.alive and agent.id not in death_logged:
                death_logged.add(agent.id)
                dyad_reg.record_agent_death(tick, agent.id, wdyad)
                wraw.write({
                    "tick":       tick,
                    "phase":      phase.name,
                    "actor_id":   agent.id,
                    "event_type": "agent_death",
                    "participants": [],
                    "context":    {"name": agent.name},
                    "impact":     {},
                    "outcome":    "dead",
                })

        # ── Update by_id for newborns ─────────────────────────────────────────
        if tick % 25 == 0:
            newborns = reproduction_system.tick(
                agents, spatial_world, faction_registry,
                culture_pool, random.Random(tick + SEED * 7)
            )
            agents.extend(newborns)
            for nb in newborns:
                by_id[nb.id] = nb

        # ── Faction topology snapshot ─────────────────────────────────────────
        if tick % TOPOLOGY_INTERVAL == 0:
            topo = topology_metrics(agents, faction_registry, tick=tick)
            faction_snap = {}
            for fid, f in faction_registry.factions.items():
                members = [a for a in agents if a.alive and a.id in f.members]
                faction_snap[f.name] = {
                    "member_count": len(members),
                    "member_names": [a.name for a in members],
                }
            wtopo.write({
                "tick":     tick,
                "phase":    phase.name,
                "factions": faction_snap,
                **topo,
            })

        # ── Attractor state ───────────────────────────────────────────────────
        # Trim window
        interaction_window = [(t, o) for t, o in interaction_window if tick - t <= WINDOW]
        window_interactions = len(interaction_window)
        window_conflicts    = sum(1 for _, o in interaction_window if o == "conflict")
        c100_window = round(100.0 * window_conflicts / window_interactions, 4) if window_interactions else None
        c100_cumul  = round(100.0 * total_conflicts / total_interactions, 4) if total_interactions else None

        wattr.write({
            "tick":             tick,
            "phase":            phase.name,
            "attractor_window": classify_attractor(c100_window),
            "attractor_cumul":  classify_attractor(c100_cumul),
            "c100_window":      c100_window,
            "c100_cumul":       c100_cumul,
            "window_interactions": window_interactions,
            "window_conflicts":    window_conflicts,
            "total_interactions":  total_interactions,
            "total_conflicts":     total_conflicts,
        })

        # ── Progress ──────────────────────────────────────────────────────────
        if tick % 100 == 0:
            living = sum(1 for a in agents if a.alive)
            c100 = round(100.0 * total_conflicts / total_interactions, 4) if total_interactions else 0
            attr = classify_attractor(c100)
            print(f"  tick {tick:>4} | agents={living} interactions={total_interactions} "
                  f"conflicts={total_conflicts} ({c100}/100) attractor={attr}")

    # ── End-of-run ────────────────────────────────────────────────────────────
    print()
    living = [a for a in agents if a.alive]
    dead   = [a for a in agents if not a.alive]
    c100_final = round(100.0 * total_conflicts / total_interactions, 4) if total_interactions else None

    # ── Audit report ──────────────────────────────────────────────────────────
    dyad_records = dyad_reg.snapshot()
    qualifying_dyads = [d for d in dyad_records if d["conflict_count"] >= 3]
    persistent_dyads = [
        d for d in qualifying_dyads
        if d["first_conflict_tick"] is not None
        and (d["last_conflict_tick"] - d["first_conflict_tick"]) > 50
        and (d["conflict_count"] / max(1, d["last_conflict_tick"] - d["first_conflict_tick"])) > 0.1
    ]

    # Resilience = 1.0 check
    resilience_ceiling_agents = [
        {"id": a.id, "name": a.name, "resilience": a.traits.resilience}
        for a in agents if a.traits.resilience >= 0.99
    ]

    # Institution suppression downstream check:
    # Count prevented-conflict events; verify each maps to a cooperation outcome (not conflict).
    # We can verify this because institution_prevented_conflict=True only fires when
    # final conflict_pull <= cooperation_pull after suppression.
    # The audit simply counts them and flags any that appear with outcome=conflict (impossible
    # by logic, but worth verifying is zero).
    # (This requires re-reading institution_log.jsonl — done via the write buffer.)

    # Attractor boundary check: what is the raw value at the classify boundary?
    audit = {
        "seed":             SEED,
        "ticks":            TICKS,
        "total_interactions": total_interactions,
        "total_conflicts":    total_conflicts,
        "total_cooperations": total_cooperations,
        "conflict_per_100":   c100_final,
        "final_attractor":    classify_attractor(c100_final),
        "living":           len(living),
        "dead":             len(dead),
        "births":           reproduction_system.total_births,

        # Attractor boundary
        "attractor_boundary_check": {
            "peaceful_max":  ATTRACTOR_PEACEFUL_MAX,
            "conflict_min":  ATTRACTOR_CONFLICT_MIN,
            "c100_final":    c100_final,
            "note": "If c100_final is within 1.0 of a boundary, attractor classification is fragile."
        },

        # Dyad integrity
        "dyad_audit": {
            "total_xf_dyads_with_any_conflict": len(qualifying_dyads),
            "persistent_xf_dyads":              len(persistent_dyads),
            "dyads_with_resilience_ceiling":     resilience_ceiling_agents,
            "note_resilience_ceiling": (
                "agents with resilience >= 0.99 — check if ceiling is a clamp artifact"
                " or genuine trait distribution edge"
            ),
        },

        # Deception integrity
        "deception_audit": {
            "deceive_threshold":    DECEIVE_THRESHOLD,
            "initial_eligible":     sum(
                1 for a in agents[:INITIAL_AGENTS]
                if a.state.dominance * a.traits.risk_tolerance >= DECEIVE_THRESHOLD
            ),
            "note": "Deception events deduped by (tick, actor, target) as of v04.10."
        },

        # Institution integrity
        "institution_audit": {
            "institution_count_final": len(institution_registry.institutions),
            "note": (
                "institution_prevented_conflict=True fires only when raw_conflict_pull > coop_pull "
                "AND final_conflict_pull <= coop_pull. Verify institution_log.jsonl has no "
                "entries where outcome='conflict'."
            ),
        },

        "output_files": [
            str(OUTPUT_DIR / "dyad_lifecycle.jsonl"),
            str(OUTPUT_DIR / "conflict_lineage.jsonl"),
            str(OUTPUT_DIR / "faction_topology.jsonl"),
            str(OUTPUT_DIR / "institution_log.jsonl"),
            str(OUTPUT_DIR / "attractor_state.jsonl"),
            str(OUTPUT_DIR / "raw_events.jsonl"),
            str(OUTPUT_DIR / "audit_report.json"),
        ],
    }

    (OUTPUT_DIR / "audit_report.json").write_text(
        json.dumps(audit, indent=2), encoding="utf-8"
    )

    # Close all writers
    for w in [wdyad, wlin, wtopo, winst, wattr, wraw]:
        w.close()

    print(f"DONE — seed={SEED} | {total_interactions} interactions | "
          f"{total_conflicts} conflicts ({c100_final}/100) | attractor={classify_attractor(c100_final)}")
    print(f"  persistent XF dyads: {len(persistent_dyads)}")
    print(f"  resilience ceiling agents: {len(resilience_ceiling_agents)}")
    print(f"  output: {OUTPUT_DIR}/")
    print()
    print("Files:")
    for f in audit["output_files"]:
        path = Path(f)
        size = path.stat().st_size if path.exists() else 0
        print(f"  {path.name:<35} {size:>8} bytes")


if __name__ == "__main__":
    main()
