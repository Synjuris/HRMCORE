"""
Goals — Layer 1
Each agent maintains a priority-ordered goal stack.
Goals are selected from a fixed vocabulary; priority shifts based on
internal state (energy, stress, resource_stock) each tick.

v04.43: Added 'reproduce' goal.
    - Driven by libido, age relative to peak, pair bond strength
    - Modulated by ecological_context.reproduction_drive()
    - Environmental health gates the drive — spring abundance upregulates,
      winter scarcity suppresses, population crisis triggers urgency
    - Agents with active reproduce goal seek proximity and bonding with
      viable partners rather than waiting for world-level pairing
"""
import random
from typing import List, Optional, Any
from schemas import Goal, AgentState, DevelopmentalTraits


GOAL_VOCAB = ["survive", "acquire_resource", "bond", "reproduce", "dominate", "explore"]


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def compute_goal_priorities(
    state: AgentState,
    traits: DevelopmentalTraits,
    agent: Optional[Any] = None,
    eco_health: float = 0.5,
) -> dict:
    """Return priority weights for each goal label given current state."""

    # Reproduce priority — individual biology × environmental health
    if agent is not None:
        try:
            from ecological_context import reproduction_drive
            repro_priority = reproduction_drive(agent, eco_health)
        except Exception:
            repro_priority = 0.0
    else:
        # Fallback: libido-only if no agent ref or eco_health
        libido = clamp(getattr(agent, "libido", 0.0)) if agent else 0.0
        repro_priority = clamp(libido * eco_health)

    return {
        "survive":          clamp(state.stress * 0.70 + (1.0 - state.energy) * 0.40),
        "acquire_resource": clamp((1.0 - state.resource_stock) * 0.60 + state.stress * 0.20),
        "bond":             clamp(state.social_openness * 0.50 + state.cooperation * 0.30
                                  - state.fear * 0.20),
        "reproduce":        clamp(repro_priority),
        "dominate":         clamp(state.dominance * 0.60 - state.fear * 0.30
                                  + traits.risk_tolerance * 0.20),
        "explore":          clamp(state.curiosity * 0.60 - state.stress * 0.25
                                  + (1.0 - state.fear) * 0.15),
    }


class GoalStack:
    def __init__(self, rng: random.Random) -> None:
        self.goals: List[Goal] = [Goal(label=g) for g in GOAL_VOCAB]
        self._rng = rng

    def update(
        self,
        state: AgentState,
        traits: DevelopmentalTraits,
        agent: Optional[Any] = None,
        eco_health: float = 0.5,
    ) -> None:
        weights = compute_goal_priorities(state, traits, agent=agent, eco_health=eco_health)
        for g in self.goals:
            g.priority = weights.get(g.label, 0.10)

    @property
    def active(self) -> Goal:
        """Returns highest-priority non-achieved goal."""
        eligible = [g for g in self.goals if not g.achieved]
        return max(eligible, key=lambda g: g.priority) if eligible else self.goals[0]

    def record_progress(self, label: str, delta: float) -> None:
        for g in self.goals:
            if g.label == label:
                g.progress = clamp(g.progress + delta)
                if g.progress >= 1.0:
                    g.achieved = True
                    g.progress = 1.0
                break

    def reset_achieved(self) -> None:
        """Goals reset every N ticks so agents keep pursuing them."""
        for g in self.goals:
            if g.achieved:
                g.achieved = False
                g.progress = 0.0

    def snapshot(self) -> list:
        return [
            {"label": g.label, "priority": round(g.priority, 4),
             "progress": round(g.progress, 4), "achieved": g.achieved}
            for g in self.goals
        ]
