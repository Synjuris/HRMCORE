# HRM Session Changes — Spatial Agency Layer v1

## New Files Added to das/

### spatial_biomes.py
Zone biome definitions. Maps grid coordinates to biome profiles
(woodland, meadow, wetland, savanna) with gather/hunt multipliers.
Now also serves as zone config backbone for spatial_zone.py.

### spatial_zone.py
Zone grid system. Divides the world into 4x4=16 independent zones,
each with local fauna pools that deplete and recover independently.
Includes biome-specific seasonal modifiers — winters hit different
zones differently. Fauna drift slowly between adjacent zones.
Feature-flagged: SPATIAL_ECOLOGY_ENABLED.

### spatial_memory.py
Per-agent cognitive map of zone yield quality. Agents remember zones
they have personally visited. Memory decays so old info loses weight.
Knowledge spreads socially through trade/conversation (social_learn).
Distinct from subjective_memory.py which tracks beliefs about people.

### movement_goals.py
Goal-directed movement replacing random drift. Priority order:
1. Survival — hungry → best remembered food zone
2. Social — stable → trusted partner / trade contact
3. Care — care-role → attached low-energy agent
4. Explore — well-fed → unknown or long-unvisited zone
5. Home — default → productive home range
80% follow top goal, 20% noise. Includes inertia and home range bias.

### resource_transfer.py
Trade, theft, and charity system. Triggered by agent proximity and
resource asymmetry. Trade requires trust floor and surplus/deficit gap.
Theft requires desperation and low-trust target. Charity requires
attachment and surplus. All three write subjective memory beliefs
(perceived_fair_trader, perceived_thief, perceived_generous).
Cross-biome trades and cross-faction charities get bonuses.

### life_events.py
Stub for v04.48 life_events module (not present in this build).
Required to run custom experiment scripts without the v04.48 package.

### epochs.py
Stub for v04.48 epochs module (not present in this build).

## Modified Files

### agent.py
- Imports spatial_memory.SpatialMemory at init (graceful fallback if missing)
- Attaches self.spatial_memory to each agent
- Adds home_zone_id and _last_move_tick attributes

### subsistence.py
- Adds _zone_grid attribute (set externally when spatial ecology enabled)
- Hunt success depletes local zone fauna (in addition to global pool)
- Successful gather updates agent's spatial_memory with observed yield
- Calls movement_goals.update_home_zone after gather events
- Imports spatial_biomes.get_biome for position-based yield scaling
- SPATIAL_BIOMES feature flag for graceful fallback

### space.py
- Rewrites move_agent() to support goal-directed movement
- When _zone_grid is set, delegates to movement_goals.evaluate_and_move
- Falls back to legacy random drift if spatial agency not active
- Position is now float (was int) for smooth movement

### reproduction.py
- REPRODUCE_ENERGY_MIN lowered: 0.28 → 0.10
- REPRODUCE_STRESS_MAX raised: 0.82 → 0.88
- MAX_POPULATION raised: 36 → 50

### biology.py
- libido_energy_floor lowered: 0.30 → 0.10
- libido_stress_ceiling raised: 0.65 → 0.88
(Enables reproduction under moderate stress/scarcity)

## Experiment Run Scripts

### run_exp_A.py
Control: mixed memes (distrust intact) + spatial biomes. 5000 ticks.

### run_exp_B.py
Prosocial memes only + spatial biomes. 5000 ticks.

### run_exp_C.py / run_exp_C2.py
Prosocial memes + spatial biomes + resource transfer. 2000/5000 ticks.

### run_exp_D.py
Full Spatial Agency Layer: zone ecology + spatial memory + goal movement
+ prosocial memes + biomes + resource transfer. 5000 ticks.
Includes innovation diagnostics in snapshot output.

### run_four_groups.py / run_four_groups_resume.py
4 groups of 12, 40x40 world, moderate separation. Resume script
loads agents_final.json and continues from tick 2000.

### run_single_band.py
30 agents, single band, 20x20 world. 1000 ticks.

### run_three_groups.py
3 groups of 10, 30x30 world, strangers. 1000 ticks.

### run_civilization.py
16-20 founders, single band, 5000 ticks with 500-tick snapshots.

## Key Experimental Findings

- Feeding loop (subsistence.agent_tick) was missing from all custom
  run scripts — agents were starving silently. Fixed in all scripts.
- Reproduction system was never called from custom scripts. Fixed.
- Libido suppression thresholds blocked births under any stress.
  Patched to realistic values.
- Conflict rate progression across experiments:
  No biomes:     82% by tick 3000
  +Biomes:       74%
  +Prosocial:    67%
  +Trade:        63%
  +Spatial agency: 37% (STILL DECLINING)
- Innovation has not yet fired. Next investigation: innovation gate.

## Late-Session Fixes — Innovation and Lethality Gates

### information.py
Three fixes that finally connected the information pipeline:
1. messages_from_event() now generates resource_available from "gathering" events
   (previously only "resource_action_cost" — an event type our scripts never produced)
2. messages_from_event() now generates specialist_present from "hunt" events
   when agent specialization_depth > 0.12
3. apply_tick() now scans aux_events for "gathering" and "hunt" event types
   in addition to the original "resource_action_cost" and "apprenticeship_formed"

### innovation.py
- fidelity_floor lowered: 0.20 → 0.12
  Early-sim agents with low linguistic_complexity were generating messages
  that fell below the floor and failed silently. 0.12 allows imperfect early
  knowledge to recombine, producing lower-utility but real innovations.

### run_exp_E.py (and run_exp_D.py)
Three wiring fixes applied to the run loop:
1. Subsistence events now pushed to agent.aux_events after agent_tick()
   so information.apply_tick() can read them (previously they went to
   event_log only, invisible to the information pipeline)
2. cooperation_events collected each tick and passed to apply_innovation_tick()
   (previously None, so diffusion fell back to already-cleared aux_events)
3. _population_ref and _eco_health set on each agent before their tick
   (required by lethality system — was never set, lethality never fired)

## Result
Experiment E3 (first run with all fixes):
- 216 innovations by tick 500 (registry: 209)
- 937 innovations by tick 1000 (registry: 289)
- 2,286 innovations by tick 1500 (registry: 299)
- 9.4% conflict at tick 500 — lowest ever recorded
- Innovation was always possible. The signal routing was broken.
