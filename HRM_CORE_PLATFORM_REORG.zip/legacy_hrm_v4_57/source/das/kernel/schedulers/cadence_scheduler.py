"""Cadence scheduler — agents tick only on their personal cadence interval."""
from __future__ import annotations
from typing import Any
from .base_scheduler import BaseScheduler


class CadenceScheduler(BaseScheduler):
    name = "cadence"

    def activate(self, runtime: Any, tick: int, phase: Any, **kwargs) -> None:
        from harness import safe_agent_tick
        for agent in runtime.sorted_agents():
            if not getattr(agent, "alive", False):
                continue
            cadence = getattr(agent, "cadence", 1)
            if tick % cadence == 0:
                safe_agent_tick(agent, tick, phase, runtime.agents, **kwargs)
