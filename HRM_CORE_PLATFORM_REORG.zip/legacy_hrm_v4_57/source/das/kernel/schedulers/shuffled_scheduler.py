"""Shuffled scheduler — randomised order each tick, seeded deterministically."""
from __future__ import annotations
from typing import Any
from .base_scheduler import BaseScheduler


class ShuffledScheduler(BaseScheduler):
    name = "shuffled"

    def activate(self, runtime: Any, tick: int, phase: Any, **kwargs) -> None:
        from harness import safe_agent_tick
        ordered = runtime.sorted_agents()
        runtime.global_rng.shuffle(ordered)
        for agent in ordered:
            if not getattr(agent, "alive", False):
                continue
            safe_agent_tick(agent, tick, phase, runtime.agents, **kwargs)
