"""Sequential scheduler — agents tick in creation_index order."""
from __future__ import annotations
from typing import Any
from .base_scheduler import BaseScheduler


class SequentialScheduler(BaseScheduler):
    name = "sequential"

    def activate(self, runtime: Any, tick: int, phase: Any, **kwargs) -> None:
        from harness import safe_agent_tick
        for agent in runtime.sorted_agents():
            if not getattr(agent, "alive", False):
                continue
            safe_agent_tick(agent, tick, phase, runtime.agents, **kwargs)
