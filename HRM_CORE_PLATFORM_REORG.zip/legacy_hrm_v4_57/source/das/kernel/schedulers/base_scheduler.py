"""Scheduler base contract."""
from __future__ import annotations
from typing import Any


class BaseScheduler:
    name = "base"

    def activate(self, runtime: Any, tick: int, phase: Any, **kwargs) -> None:
        """
        Activate agents for this tick.

        Signature mirrors the kernel's safe_agent_tick call so schedulers
        can slot in without re-plumbing kwargs.
        """
        raise NotImplementedError
