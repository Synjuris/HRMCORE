"""Partial scheduler — only a fraction of agents tick each turn."""
from __future__ import annotations
from typing import Any
from .base_scheduler import BaseScheduler


class PartialScheduler(BaseScheduler):
    name = "partial"

    def __init__(self, activation_ratio: float = 0.4) -> None:
        self.activation_ratio = activation_ratio

    def activate(self, runtime: Any, tick: int, phase: Any, **kwargs) -> None:
        from harness import safe_agent_tick
        ordered = runtime.sorted_agents()
        alive = [a for a in ordered if getattr(a, "alive", False)]
        count = max(1, int(len(alive) * self.activation_ratio))
        selected = runtime.global_rng.sample(alive, min(count, len(alive)))
        for agent in selected:
            safe_agent_tick(agent, tick, phase, runtime.agents, **kwargs)
