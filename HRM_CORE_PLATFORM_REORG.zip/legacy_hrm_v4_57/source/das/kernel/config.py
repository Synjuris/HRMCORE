"""
kernel/config.py — Typed simulation config.

Replaces scattered module-level constants across run scripts.
All experiments express their parameters here.
"""

from __future__ import annotations
import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, List, Tuple, Any


@dataclass
class GroupConfig:
    label: str
    arrival_tick: int
    cluster_center: Tuple[float, float]
    names: List[str]
    seed_memes: List[str]


@dataclass
class KernelConfig:
    # Identity
    experiment_name: str = "exp_E"
    version: str = "K1"

    # World
    seed: int = 23
    world_w: int = 40
    world_h: int = 40
    max_population: int = 140
    ticks: int = 5000
    snap_every: int = 500

    # Output
    output_root: str = "/tmp/hrm_kernel"

    # Groups
    groups: List[GroupConfig] = field(default_factory=list)

    # Feature flags
    spatial_ecology_enabled: bool = True
    resource_transfer_enabled: bool = True
    srk_mutation_enabled: bool = True
    lethality_enabled: bool = True

    # K2-3C+ observability flags. These do not affect simulation state.
    cognition_observer_enabled: bool = False
    cognition_observer_every_n: int = 50
    cognition_observer_sample_size: int = 3
    cognition_observer_agent_ids: List[str] = field(default_factory=list)
    cognition_observer_output_file: str = "cognition_observations.jsonl"
    cognition_observer_include_prompt_packet: bool = True

    # Subsystem seed offsets
    subsistence_seed_offset: int = 43300
    logistics_seed_offset: int = 44000
    zone_seed_offset: int = 99000

    @property
    def output_path(self) -> Path:
        return Path(self.output_root)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "KernelConfig":
        d = dict(d)
        raw_groups = d.pop("groups", [])
        groups = [
            GroupConfig(
                label=g["label"],
                arrival_tick=g["arrival_tick"],
                cluster_center=tuple(g["cluster_center"]),
                names=g["names"],
                seed_memes=g.get("seed_memes", []),
            )
            for g in raw_groups
        ]
        valid = {f for f in cls.__dataclass_fields__}
        cfg = cls(**{k: v for k, v in d.items() if k in valid})
        cfg.groups = groups
        return cfg

    @classmethod
    def from_json(cls, path: str) -> "KernelConfig":
        return cls.from_dict(json.loads(Path(path).read_text()))

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_json(self, path: str) -> None:
        Path(path).write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")


# ── Standard group name pools ─────────────────────────────────────────────────

GROUP_NAMES = {
    "A": ["Alder","Brin","Cara","Dusk","Elm","Fern","Glen","Haze",
          "Iris","Jolt","Kale","Lorn"],
    "B": ["Tarn","Vera","Wren","Xen","Yael","Zora","Ash","Bay",
          "Cal","Dae","Eve","Finn"],
    "C": ["Gale","Holt","Ida","Jax","Koi","Lux","Mira","Noel",
          "Oak","Paz","Quo","Rex"],
    "D": ["Sage","Tam","Ula","Vex","Wil","Xio","Yew","Zed",
          "Abe","Bex","Cay","Dov"],
}


def make_exp_E_config(
    ticks: int = 5000,
    output_root: str = "/tmp/hrm_exp_E_kernel",
) -> KernelConfig:
    """Experiment E: staggered founding, group meme seeds, full spatial agency."""
    return KernelConfig(
        experiment_name="exp_E",
        seed=23,
        world_w=40, world_h=40,
        max_population=140,
        ticks=ticks,
        snap_every=500,
        output_root=output_root,
        groups=[
            GroupConfig("A", 0,   (10.0, 10.0), GROUP_NAMES["A"],
                        ["cooperation_norm", "collective_memory"]),
            GroupConfig("B", 200, (30.0, 10.0), GROUP_NAMES["B"],
                        ["resource_sharing", "reciprocal_exchange"]),
            GroupConfig("C", 400, (10.0, 30.0), GROUP_NAMES["C"],
                        ["collective_memory", "territorial_marking"]),
            GroupConfig("D", 600, (30.0, 30.0), GROUP_NAMES["D"],
                        ["dominance_hierarchy", "risk_taking"]),
        ],
    )
