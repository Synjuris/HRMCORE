"""
kernel/experiment_setup.py — Shared runner utilities.

All kernel experiment runners use these functions.
No simulation logic here — only setup and registration wiring.

Functions:
    register_standard_subsystems(rt)  — register the 9 core subsystems
    make_agent(...)                   — build and init one agent
    seed_group_culture(...)           — seed memes for one group
    setup_groups(rt, cfg)             — build and register all groups from config
"""

from __future__ import annotations
import random
from typing import Any, List, TYPE_CHECKING

if TYPE_CHECKING:
    from .runtime import HRMRuntime
    from .config import KernelConfig, GroupConfig

# ── Meme registry ─────────────────────────────────────────────────────────────

MEME_IDS = {
    "cooperation_norm":    "m_coop",
    "collective_memory":   "m_colmem",
    "resource_sharing":    "m_share",
    "reciprocal_exchange": "m_recip",
    "territorial_marking": "m_terr",
    "dominance_hierarchy": "m_dom",
    "risk_taking":         "m_risk",
    "distrust_outsiders":  "m_dist",
}

MEME_VALENCE = {
    "m_coop":   +0.8, "m_colmem": +0.6, "m_share":  +0.7,
    "m_recip":  +0.7, "m_terr":   -0.4, "m_dom":    -0.3,
    "m_risk":   -0.2, "m_dist":   -0.6,
}

MEME_SPREAD = {
    "m_coop": 0.28, "m_colmem": 0.25, "m_share": 0.26,
    "m_recip": 0.27, "m_terr": 0.24, "m_dom": 0.30,
    "m_risk": 0.22, "m_dist": 0.29,
}


# ── Subsystem registration ────────────────────────────────────────────────────

def register_standard_subsystems(rt: "HRMRuntime") -> None:
    """
    Register the 9 standard subsystem ticks with the kernel registry.
    Call this after rt.build_world() and before rt.run().
    All experiments use this same set.
    """
    from generational import apply_tick as gen_tick
    from apprenticeship import apply_tick as appr_tick
    from governance import apply_tick as gov_tick
    from innovation import apply_tick as innov_tick
    from information import apply_tick as info_tick
    from generational_psychology import (apply_storykeeper_transmission,
                                          apply_targeted_care_recovery)
    from institutional_memory import apply_institutional_memory_tick
    from social_viability import apply_population_viability_tick
    from cognition_observer import CognitionObserver, anthropic_renderer

    # v04.57: wire the real DAS↔HRM bridge upward aggregation subsystem.
    # This registers an upward step at METRICS phase that aggregates living
    # agent state into HRM civic pressure signals every UPWARD_INTERVAL ticks.
    # The bridge writes nothing until set_civic_state() is called — safe to
    # register even when running DAS standalone.
    try:
        import sys as _sys
        _sys.path.insert(0, str(__file__).rsplit("/das/", 1)[0])
        from bridge.das_hrm_bridge import DASHRMBridge
        das_hrm_bridge = DASHRMBridge()
        das_hrm_bridge.attach_to_runtime(rt)
        rt._das_hrm_bridge = das_hrm_bridge
    except Exception as _bridge_err:
        rt._das_hrm_bridge = None

    # v04.57: enable CognitionObserver by default with LLM renderer.
    # If no API key is available, anthropic_renderer falls back to
    # template_renderer automatically — the simulation never blocks.
    if not getattr(rt.cfg, "cognition_observer_enabled", False):
        rt.cfg.cognition_observer_enabled = True
    if not getattr(rt.cfg, "cognition_observer_every_n", 0):
        rt.cfg.cognition_observer_every_n = 50

    cognition_observer = CognitionObserver.from_runtime(rt, renderer=anthropic_renderer)

    def _noop_step(tick, r):
        # Observer-only subsystem. No simulation mutation occurs here.
        return None

    def _generational(tick, r):
        gen_tick(r.agents, tick, r.env_cycle.get_phase(tick).name,
                 r.generational_ledger)

    def _apprenticeship(tick, r):
        appr_tick(r.agents, tick, r.env_cycle.get_phase(tick).name,
                  r.apprenticeship_ledger)

    def _governance(tick, r):
        gov_tick(r.agents, tick, r.env_cycle.get_phase(tick).name,
                 r.governance_ledger, r.faction_registry)

    def _innovation(tick, r):
        coop = r.bus.cooperation_events_this_tick(tick)
        innov_tick(r.agents, tick, r.env_cycle.get_phase(tick).name,
                   r.innovation_engine, cooperation_events=coop)

    def _information(tick, r):
        info_tick(r.agents, tick, r.information_ledger)

    def _storykeeper(tick, r):
        apply_storykeeper_transmission(
            r.agents, tick, r.env_cycle.get_phase(tick).name,
            random.Random(tick + 1), r.genpsych_ledger)

    def _care_recovery(tick, r):
        apply_targeted_care_recovery(
            r.agents, tick, r.env_cycle.get_phase(tick).name,
            random.Random(tick + 2), r.genpsych_ledger)

    def _inst_memory(tick, r):
        apply_institutional_memory_tick(
            r.agents, tick, r.env_cycle.get_phase(tick).name,
            random.Random(tick + 3), r.inst_mem_ledger,
            r.bus.event_log, r.faction_registry)

    def _viability(tick, r):
        apply_population_viability_tick(
            r.agents, tick, r.env_cycle.get_phase(tick).name,
            r.spatial_world, random.Random(tick + r.cfg.seed))

    # K2-3B: register via SubsystemSpec with declared phases and dependencies.
    # Phase order: GENERATIONAL → GOVERNANCE → INFORMATION → INNOVATION
    #              → CULTURE (storykeeper, care_recovery, inst_memory) → VIABILITY
    from .system_registry import SubsystemSpec

    rt.registry.register_spec(SubsystemSpec(
        name="generational", phase="GENERATIONAL", fn=_generational,
        depends_on=(),
    ))
    rt.registry.register_spec(SubsystemSpec(
        name="apprenticeship", phase="GENERATIONAL", fn=_apprenticeship,
        depends_on=("generational",),
    ))
    rt.registry.register_spec(SubsystemSpec(
        name="governance", phase="GOVERNANCE", fn=_governance,
        depends_on=("generational",),   # earlier phase dep — ordering only
    ))
    rt.registry.register_spec(SubsystemSpec(
        name="information", phase="INFORMATION", fn=_information,
        depends_on=("governance",),     # earlier phase dep
    ))
    rt.registry.register_spec(SubsystemSpec(
        name="innovation", phase="INNOVATION", fn=_innovation,
        depends_on=("information",),    # earlier phase dep
    ))
    rt.registry.register_spec(SubsystemSpec(
        name="storykeeper", phase="CULTURE", fn=_storykeeper,
        depends_on=("innovation",),     # earlier phase dep
    ))
    rt.registry.register_spec(SubsystemSpec(
        name="care_recovery", phase="CULTURE", fn=_care_recovery,
        depends_on=("storykeeper",),
    ))
    rt.registry.register_spec(SubsystemSpec(
        name="inst_memory", phase="CULTURE", fn=_inst_memory,
        depends_on=("care_recovery",),
    ))
    rt.registry.register_spec(SubsystemSpec(
        name="viability", phase="VIABILITY", fn=_viability,
        depends_on=("inst_memory",),    # earlier phase dep
    ))

    # K2-3C+: optional read-only cognition observer. Registered as a METRICS
    # subsystem with a no-op step and an observe() hook. The observer writes
    # separate JSONL records and never writes back to Agent or runtime state.
    rt.registry.register_spec(SubsystemSpec(
        name="cognition_observer", phase="METRICS", fn=_noop_step,
        observe_fn=cognition_observer.observe,
        depends_on=("viability",),
    ))


# ── Agent construction ────────────────────────────────────────────────────────

def make_agent(
    name: str,
    seed: int,
    spatial_world: Any,
    faction_registry: Any,
    culture_pool: Any,
    position_x: float = 20.0,
    position_y: float = 20.0,
) -> Any:
    """Build and fully initialize one agent."""
    from agent import Agent
    from information import init_agent as init_info
    from innovation import init_agent as init_innov
    from governance import init_agent as init_gov
    import biology as bio

    a = Agent(name, seed=seed,
              spatial_world=spatial_world,
              faction_registry=faction_registry,
              culture_pool=culture_pool)
    init_info(a)
    init_innov(a)
    init_gov(a)
    bio.init_agent(a)

    a.position.x = float(max(0.0, min(spatial_world.width  - 1, position_x)))
    a.position.y = float(max(0.0, min(spatial_world.height - 1, position_y)))
    return a


# ── Culture seeding ───────────────────────────────────────────────────────────

def seed_group_culture(
    agents: List[Any],
    gcfg: "GroupConfig",
    culture_pool: Any,
) -> None:
    """Seed the memes defined in gcfg.seed_memes for the given agents."""
    from schemas import Meme

    if not hasattr(culture_pool, "_agent_memes"):
        culture_pool._agent_memes = {}

    for meme_name in gcfg.seed_memes:
        mid = MEME_IDS.get(meme_name, meme_name)
        valence = MEME_VALENCE.get(mid, 0.0)
        spread  = MEME_SPREAD.get(mid, 0.05)

        if mid not in culture_pool.memes:
            m = Meme(id=mid, label=meme_name, valence=valence,
                     spread_rate=spread, strength=0.25)
            culture_pool.memes[mid] = m

        for a in agents:
            slots = culture_pool._agent_memes.setdefault(a.id, [])
            if mid not in slots:
                slots.append(mid)


# ── Group setup ───────────────────────────────────────────────────────────────

def setup_groups(rt: "HRMRuntime") -> None:
    """
    Build all groups from rt.cfg.groups and register them with the runtime.
    Groups with arrival_tick==0 are added immediately.
    Pending groups are registered with on_arrival callbacks.
    """
    from social_viability import seed_viable_founder_band
    import life_events as life_events_mod

    cfg = rt.cfg

    for gcfg in cfg.groups:
        cx, cy = gcfg.cluster_center
        grp_agents = []

        for i, name in enumerate(gcfg.names):
            seed = ord(gcfg.label) * 100 + i + 1
            grng = random.Random(cfg.seed + ord(gcfg.label) * 1000 + i)

            a = make_agent(
                name, seed=seed,
                spatial_world=rt.spatial_world,
                faction_registry=rt.faction_registry,
                culture_pool=rt.culture_pool,
                position_x=cx + grng.uniform(-3, 3),
                position_y=cy + grng.uniform(-3, 3),
            )
            grp_agents.append(a)

        # Sex-balance the group
        seed_viable_founder_band(
            grp_agents, rt.spatial_world,
            random.Random(cfg.seed + ord(gcfg.label) * 43700))

        # Restore cluster positions after sex-balancing
        for i, a in enumerate(grp_agents):
            prng = random.Random(cfg.seed + ord(gcfg.label) * 1000 + i + 500)
            a.position.x = float(max(0.0, min(cfg.world_w - 1,
                                               cx + prng.uniform(-2, 2))))
            a.position.y = float(max(0.0, min(cfg.world_h - 1,
                                               cy + prng.uniform(-2, 2))))

        if gcfg.arrival_tick == 0:
            seed_group_culture(grp_agents, gcfg, rt.culture_pool)
            life_events_mod.initialize_life_events(
                grp_agents, max_ticks=cfg.ticks, seed=1, key="run_1")
            for a in grp_agents:
                rt.agent_group[a.id] = gcfg.label
            # v4.56 — stamp creation_index before adding to agent pool
            for a in grp_agents:
                a.creation_index = rt.next_agent_index()
            rt.agents.extend(grp_agents)
        else:
            # Closure captures gcfg and grp_agents correctly
            def _on_arrival(tick, runtime, _gcfg=gcfg, _grp=grp_agents):
                seed_group_culture(_grp, _gcfg, runtime.culture_pool)
                life_events_mod.initialize_life_events(
                    _grp, max_ticks=runtime.cfg.ticks,
                    seed=_gcfg.arrival_tick + ord(_gcfg.label),
                    key=f"run_1_{_gcfg.label}")

            rt.register_pending_group(
                gcfg.arrival_tick, gcfg.label, grp_agents,
                on_arrival=_on_arrival)
