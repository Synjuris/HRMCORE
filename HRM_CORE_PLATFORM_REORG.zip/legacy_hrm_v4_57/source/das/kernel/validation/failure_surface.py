"""
failure_surface.py — behavioral collapse detector.

Reads the last ArtifactMetrics snapshot and returns a list of
active failure conditions. Read-only; never mutates runtime.
"""

from __future__ import annotations
from typing import Any, List


THRESHOLDS = {
    "HIGH_SYNCHRONIZATION": ("sync_index",   ">",  0.80),
    "FROZEN_POPULATION":    ("frozen_ratio", ">",  0.30),
    "SPATIAL_COLLAPSE":     ("crowding_index", ">", 0.50),
    "MEME_MONOCULTURE":     ("meme_entropy", "<",  0.20),
}


class FailureSurface:
    def analyze(self, runtime: Any) -> List[str]:
        """
        Returns list of active failure flag strings.
        Requires runtime.artifact_metrics to be populated.
        """
        metrics = getattr(runtime, "artifact_metrics", None)
        if metrics is None or not getattr(metrics, "history", []):
            return []

        latest = metrics.history[-1]
        failures = []

        for flag, (field, op, threshold) in THRESHOLDS.items():
            value = latest.get(field)
            if value is None:
                continue
            if op == ">" and value > threshold:
                failures.append(flag)
            elif op == "<" and value < threshold:
                failures.append(flag)

        return failures

    def write(self, runtime: Any, output_dir: str) -> None:
        import json
        from pathlib import Path
        flags = self.analyze(runtime)
        latest = {}
        metrics = getattr(runtime, "artifact_metrics", None)
        if metrics and metrics.history:
            latest = metrics.history[-1]
        payload = {"tick": latest.get("tick"), "failures": flags, "metrics": latest}
        path = Path(output_dir) / "failure_surface.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
