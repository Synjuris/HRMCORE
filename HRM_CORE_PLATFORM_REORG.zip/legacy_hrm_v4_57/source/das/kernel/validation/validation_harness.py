"""
validation_harness.py — reproducibility and scheduler sensitivity tests.

RuntimeFactory signature:
    factory(cfg, seed) -> HRMRuntime (already built, not yet run)

The harness calls runtime.run() itself and reads state after completion.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional


class ValidationHarness:
    def __init__(self, runtime_factory: Callable) -> None:
        self.runtime_factory = runtime_factory

    def reproducibility_test(self, cfg: Any, seed: int, runs: int = 3) -> bool:
        """
        Returns True if all runs produce identical state hashes.
        Failure indicates non-determinism in the kernel or its dependencies.
        """
        hashes = []
        for i in range(runs):
            rt = self.runtime_factory(cfg, seed)
            rt.run()
            h = rt.fingerprint.state_hash()
            hashes.append(h)
            print(f"  [reproducibility] run {i+1}/{runs} state_hash={h[:12]}…")
        passed = len(set(hashes)) == 1
        print(f"  [reproducibility] {'PASS' if passed else 'FAIL'} — "
              f"{len(set(hashes))} distinct hash(es) over {runs} runs")
        return passed

    def scheduler_sensitivity_test(
        self,
        cfg: Any,
        seed: int,
        schedulers: List[Any],
    ) -> Dict[str, Any]:
        """
        Runs the simulation once per scheduler and returns macro outcome
        comparison. Directional stability (not hash equality) is expected.
        """
        from .failure_surface import FailureSurface
        fs = FailureSurface()
        results: Dict[str, Any] = {}

        for scheduler in schedulers:
            rt = self.runtime_factory(cfg, seed)
            rt.scheduler = scheduler
            rt.run()

            metrics = getattr(rt, "artifact_metrics", None)
            last = metrics.history[-1] if (metrics and metrics.history) else {}

            results[scheduler.name] = {
                "population": sum(1 for a in rt.agents if getattr(a, "alive", False)),
                "state_hash": rt.fingerprint.state_hash()[:12],
                "meme_entropy": last.get("meme_entropy"),
                "sync_index": last.get("sync_index"),
                "frozen_ratio": last.get("frozen_ratio"),
                "failures": fs.analyze(rt),
            }
            print(f"  [scheduler_sensitivity] {scheduler.name}: "
                  f"pop={results[scheduler.name]['population']} "
                  f"entropy={results[scheduler.name]['meme_entropy']}")

        return results

    def run_suite(self, cfg: Any, seed: int, schedulers: Optional[List[Any]] = None) -> Dict[str, Any]:
        """Convenience: run both tests and return combined report."""
        from ..schedulers import (
            SequentialScheduler, ShuffledScheduler,
            PartialScheduler, CadenceScheduler,
        )
        if schedulers is None:
            schedulers = [
                SequentialScheduler(),
                ShuffledScheduler(),
                PartialScheduler(),
                CadenceScheduler(),
            ]
        print("\n=== HRM v4.56 Validation Suite ===")
        repro = self.reproducibility_test(cfg, seed)
        sched = self.scheduler_sensitivity_test(cfg, seed, schedulers)
        return {"reproducibility_pass": repro, "scheduler_results": sched}


def write_scheduler_report(results: Dict[str, Any], output_dir: str) -> None:
    import json
    from pathlib import Path
    path = Path(output_dir) / "scheduler_report.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(results, indent=2), encoding="utf-8")
