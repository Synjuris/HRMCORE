"""
kernel/checkpoint.py — Full restorable checkpoint.

Replaces the patchwork of checkpoint_full_* logic spread across
run_exp_E_resume.py. One canonical save/load format.

Saves:
    - tick, config hash
    - global RNG state
    - per-agent RNG states
    - full agent snapshots
    - group map
    - faction state
    - full culture (all memes + agent-meme assignments)
    - full innovation registry
    - governance leader records
    - death ledger
    - session history
"""

from __future__ import annotations
import json
import time
import hashlib
import random
from dataclasses import asdict as _asdict
from pathlib import Path
from typing import Any, Dict, List, Optional


def _rng_state_to_json(rng: random.Random) -> list:
    s = rng.getstate()
    return [s[0], list(s[1]), s[2]]


def _rng_state_from_json(s: list) -> tuple:
    return (s[0], tuple(s[1]), s[2])


class KernelCheckpoint:
    """
    Saves and loads complete simulation state.

    Full checkpoint format: checkpoint_full_NNNNNN.json
    Contains everything needed for true resume (not reseed).
    """

    FORMAT = "hrm_kernel_checkpoint_v1"

    def __init__(self, output_dir: Path, config_hash: str):
        self.output_dir = output_dir
        self.config_hash = config_hash

    # ── Save ──────────────────────────────────────────────────────────────────

    def save(
        self,
        tick: int,
        runtime: Any,
    ) -> Path:
        """Write a full checkpoint. Returns the path written."""
        rt = runtime

        cp: Dict[str, Any] = {
            "format": self.FORMAT,
            "config_hash": self.config_hash,
            "tick": tick,
            "saved_at": time.time(),

            # RNG
            "global_rng_state": _rng_state_to_json(rt.global_rng),
            "agent_rng_states": {
                a.id: _rng_state_to_json(a.rng)
                for a in rt.agents
                if hasattr(a, "rng") and a.rng is not None
            },

            # Agents
            "agents": [a.snapshot() for a in rt.agents],
            "group_map": rt.agent_group,

            # Factions
            "factions": self._save_factions(rt),

            # Culture — full, not top-N
            "culture": self._save_culture(rt),

            # Innovation — full registry
            "innovation": self._save_innovation(rt),

            # Governance
            "governance": self._save_governance(rt),

            # Deaths
            "deaths": [
                _asdict(d) if hasattr(d, "__dataclass_fields__") else d
                for d in rt.ledger.deaths
            ],
        }

        path = self.output_dir / f"checkpoint_full_{tick:06d}.json"
        path.write_text(json.dumps(cp, indent=2), encoding="utf-8")
        print(f"  [checkpoint saved: tick {tick}, {sum(1 for a in rt.agents if a.alive)} alive, "
              f"{len(rt.innovation_engine.practice_registry)} practices]")
        return path

    # ── Load ──────────────────────────────────────────────────────────────────

    @classmethod
    def find_latest(cls, output_dir: Path) -> Optional[Path]:
        """Find most recent full checkpoint in output_dir."""
        full = sorted(output_dir.glob("checkpoint_full_*.json"))
        return full[-1] if full else None

    @classmethod
    def load(cls, path: Path) -> Dict[str, Any]:
        """Load checkpoint dict. Validation is caller's responsibility."""
        return json.loads(path.read_text())


    @classmethod
    def restore(cls, path: Path, runtime: Any) -> int:
        """Restore a full kernel checkpoint into an already-built runtime.

        Contract:
            rt = HRMRuntime(cfg)
            rt.build_world()
            register_standard_subsystems(rt)
            start_tick = KernelCheckpoint.restore(path, rt)
            rt.run(start_tick=start_tick)

        Returns the first tick after the restored checkpoint.
        """
        cp = cls.load(Path(path))
        rt = runtime

        if cp.get("format") and cp.get("format") != cls.FORMAT:
            print(f"  [warning] checkpoint format differs: {cp.get('format')}")

        saved_hash = cp.get("config_hash")
        current_hash = getattr(rt, "_config_hash", None)
        if saved_hash and current_hash and saved_hash != current_hash:
            print("WARNING: Config hash mismatch.")
            print(f"  Saved:   {saved_hash}")
            print(f"  Current: {current_hash}")
            print("  Proceeding with restore; verify world-identity params if results look wrong.")
        else:
            print(f"Config hash OK: {current_hash or saved_hash}")

        # RNG first: subsequent restored objects should not consume world RNG state.
        if cp.get("global_rng_state"):
            rt.global_rng.setstate(_rng_state_from_json(cp["global_rng_state"]))

        # World-level registries before agents/factions.
        cls._restore_culture(cp.get("culture") or {}, rt)
        cls._restore_innovation(cp.get("innovation") or {}, rt)
        cls._restore_governance(cp.get("governance") or {}, rt)
        cls._restore_deaths(cp.get("deaths") or [], rt)

        rt.agent_group = dict(cp.get("group_map") or {})
        rt.death_logged = {getattr(d, "agent_id", None) for d in getattr(rt.ledger, "deaths", [])}
        rt.death_logged.discard(None)

        agent_rng_states = cp.get("agent_rng_states") or {}
        restored_agents = []
        for snap in cp.get("agents") or []:
            rng_state = agent_rng_states.get(snap.get("id"))
            agent = cls._restore_agent(snap, rt, rng_state=rng_state)
            cls._init_spatial_for_agent(agent, rt)
            if agent.id not in rt.agent_group:
                rt.agent_group[agent.id] = "A"
            restored_agents.append(agent)
        rt.agents = restored_agents

        cls._restore_factions(cp.get("factions") or [], rt)

        start_tick = int(cp.get("tick", 0)) + 1
        rt._session_start_tick = start_tick
        rt._tick = start_tick - 1

        living_count = sum(1 for a in rt.agents if getattr(a, "alive", False))
        print(f"  Restored {living_count} living / {len(rt.agents)} total agents.")
        print(f"  Resume start tick: {start_tick}")
        return start_tick

    @staticmethod
    def _restore_agent(snap: Dict[str, Any], rt: Any, rng_state: Optional[list] = None) -> Any:
        from agent import Agent
        from schemas import AgentState, DevelopmentalTraits
        from space import Position
        import generational as generational_mod
        import apprenticeship as apprenticeship_mod
        import governance as governance_mod
        import biology as biology_mod
        import innovation as innovation_mod
        import information as information_mod

        # Seed is temporary; authoritative RNG state is restored below when present.
        a = Agent(
            snap.get("name", snap.get("id", "agent")),
            seed=hash(snap.get("id", "agent")) & 0xFFFFFF,
            spatial_world=rt.spatial_world,
            faction_registry=rt.faction_registry,
            culture_pool=None,  # avoid reseeding culture during restore
        )
        a.id = snap.get("id", a.id)
        a.name = snap.get("name", a.name)
        a.alive = snap.get("alive", True)
        a.generation = snap.get("generation", 0)
        a.household_id = snap.get("household_id")
        a.parent_ids = list(snap.get("parent_ids") or [])
        a.birth_tick = snap.get("birth_tick", 0)

        pos = snap.get("position") or {}
        a.position = Position(float(pos.get("x", 20.0)), float(pos.get("y", 20.0)))

        st = snap.get("state") or {}
        for attr, value in st.items():
            if hasattr(a.state, attr):
                setattr(a.state, attr, value)

        tr = snap.get("traits") or {}
        for attr, value in tr.items():
            if hasattr(a.traits, attr):
                setattr(a.traits, attr, value)
        if snap.get("role"):
            a.traits.role = snap["role"]

        bio = snap.get("biology") or {}
        for attr in (
            "biological_sex", "sexual_orientation", "physical_attractiveness",
            "libido", "gestation_ticks_remaining", "pair_bond_strength",
            "_pair_bond_partner_id",
        ):
            if attr in bio:
                setattr(a, attr, bio[attr])

        app = snap.get("apprenticeship") or {}
        for attr in ("mentor_id", "skill_transfer_given", "skill_transfer_received"):
            if attr in app:
                setattr(a, attr, app[attr])

        gov = snap.get("governance") or {}
        for attr in ("is_leader", "compliance_count", "defiance_count"):
            if attr in gov:
                setattr(a, attr, gov[attr])

        innov = snap.get("innovation") or {}
        for attr in ("innovation_attempts", "innovation_successes"):
            if attr in innov:
                setattr(a, attr, innov[attr])

        dev = snap.get("development") or {}
        if hasattr(a, "development") and getattr(a, "development", None):
            for attr, value in dev.items():
                if hasattr(a.development, attr):
                    setattr(a.development, attr, value)

        exp = snap.get("experience") or {}
        if hasattr(a, "experience"):
            if "identity_tags" in exp:
                a.experience.identity_tags = list(exp["identity_tags"])
            if "scars" in exp:
                a.experience.scars = exp["scars"]
            if "bonds" in exp and isinstance(exp["bonds"], dict):
                a.experience.bonds = exp["bonds"]
            if "grudges" in exp and isinstance(exp["grudges"], dict):
                a.experience.grudges = exp["grudges"]

        rels = snap.get("relationships") or {}
        if hasattr(a, "relationships") and isinstance(rels, dict):
            for oid, rdata in rels.items():
                try:
                    r = a.relationships.get(oid)
                    for attr, value in rdata.items():
                        if hasattr(r, attr):
                            setattr(r, attr, value)
                except Exception:
                    pass

        if rng_state:
            try:
                a.rng.setstate(_rng_state_from_json(rng_state))
            except Exception:
                pass

        # Re-run idempotent subsystem initializers so live object has required fields.
        generational_mod.init_agent(a, generation=a.generation,
                                    household_id=a.household_id,
                                    parents=a.parent_ids,
                                    birth_tick=a.birth_tick)
        apprenticeship_mod.init_agent(a)
        governance_mod.init_agent(a)
        biology_mod.init_agent(a)
        innovation_mod.init_agent(a)
        information_mod.init_agent(a)
        return a

    @staticmethod
    def _init_spatial_for_agent(agent: Any, rt: Any) -> None:
        try:
            from spatial_memory import SpatialMemory
            from movement_goals import init_agent_movement
            x = getattr(agent.position, "x", 20.0)
            y = getattr(agent.position, "y", 20.0)
            zid = rt.zone_grid.zone_id_for_position(x, y)
            init_agent_movement(agent, zid)
            if getattr(agent, "spatial_memory", None) is None:
                agent.spatial_memory = SpatialMemory()
        except Exception:
            pass

    @staticmethod
    def _restore_factions(factions_src: List[Dict[str, Any]], rt: Any) -> None:
        try:
            from schemas import Faction
            rt.faction_registry.factions = {}
            rt.faction_registry._agent_faction = {}
            for fdata in factions_src:
                fid = fdata.get("id")
                if not fid:
                    continue
                members = list(fdata.get("members") or [])
                f = Faction(
                    id=fid,
                    name=fdata.get("name", fid),
                    members=members,
                    hostility=dict(fdata.get("hostility") or {}),
                )
                if fdata.get("leader_id"):
                    setattr(f, "leader_id", fdata.get("leader_id"))
                rt.faction_registry.factions[fid] = f
                for aid in members:
                    rt.faction_registry._agent_faction[aid] = fid
        except Exception as e:
            print(f"  [warning] faction restore failed: {e}")
        print(f"  Restored {len(getattr(rt.faction_registry, 'factions', {}))} factions.")

    @staticmethod
    def _restore_culture(culture_src: Dict[str, Any], rt: Any) -> None:
        from schemas import Meme
        pool = rt.culture_pool
        pool.memes = {}
        pool._agent_memes = {}
        for mdata in list(culture_src.get("memes") or []) + list(culture_src.get("meme_list") or []):
            try:
                m = Meme(
                    id=mdata["id"],
                    label=mdata.get("label", mdata["id"]),
                    valence=mdata.get("valence", 0.0),
                    spread_rate=mdata.get("spread_rate", 0.05),
                    strength=mdata.get("strength", 0.5),
                    origin_tick=mdata.get("origin_tick", 0),
                )
                pool.memes[m.id] = m
            except Exception:
                pass
        if culture_src.get("agent_memes"):
            pool._agent_memes = {k: list(v) for k, v in culture_src.get("agent_memes", {}).items()}
        print(f"  Restored {len(pool.memes)} memes.")

    @staticmethod
    def _restore_innovation(innov_src: Dict[str, Any], rt: Any) -> None:
        from innovation import PracticeRecord
        ie = rt.innovation_engine
        ie.practice_registry = {}
        for name, pdata in (innov_src.get("practice_registry") or {}).items():
            try:
                p = PracticeRecord(
                    name=pdata.get("name", name),
                    domain=pdata.get("domain", "general"),
                    utility_score=pdata.get("utility_score", 0.5),
                    fidelity=pdata.get("fidelity", 0.5),
                    origin_agent_id=pdata.get("origin_agent_id", ""),
                    origin_tick=pdata.get("origin_tick", 0),
                    attempts=pdata.get("attempts", 0),
                    successes=pdata.get("successes", 0),
                    diffusion_count=pdata.get("diffusion_count", 0),
                    institutional_adoptions=pdata.get("institutional_adoptions", 0),
                    tags=list(pdata.get("tags", [])),
                )
                ie.practice_registry[p.name] = p
            except Exception:
                pass
        summ = innov_src.get("summary") or {}
        ie.total_attempts = summ.get("total_attempts", 0)
        ie.total_successes = summ.get("total_successes", 0)
        ie.total_diffusions = summ.get("total_diffusions", 0)
        ie.total_institutional_adoptions = summ.get("total_institutional_adoptions", 0)
        print(f"  Restored {len(ie.practice_registry)} practices.")

    @staticmethod
    def _restore_governance(gov_src: Dict[str, Any], rt: Any) -> None:
        from governance import LeaderRecord
        gl = rt.governance_ledger
        gl.leaders = {}
        gl.total_successions = gov_src.get("total_successions", 0)
        gl.total_compliance = gov_src.get("total_compliance", 0)
        gl.total_defiance = gov_src.get("total_defiance", 0)
        for fid, ldata in (gov_src.get("leaders") or {}).items():
            try:
                rec = LeaderRecord(
                    faction_id=fid,
                    leader_id=ldata.get("leader_id", ""),
                    legitimacy=ldata.get("legitimacy", 0.5),
                    burden_ticks=ldata.get("burden_ticks", ldata.get("ticks_in_power", 0)),
                    in_governance_gap=ldata.get("in_governance_gap", False),
                )
                gl.leaders[fid] = rec
            except Exception as e:
                print(f"  [warning] governance restore skipped {fid}: {e}")
        print(f"  Restored {len(gl.leaders)} governance records.")

    @staticmethod
    def _restore_deaths(deaths_src: List[Dict[str, Any]], rt: Any) -> None:
        from death_ledger import DeathRecord, Vacancy
        rt.ledger.deaths = []
        for item in deaths_src or []:
            if not isinstance(item, dict):
                continue
            try:
                d = dict(item)
                vac_d = d.pop("vacancy", None)
                vacancy = Vacancy(**vac_d) if isinstance(vac_d, dict) else None
                rt.ledger.deaths.append(DeathRecord(**d, vacancy=vacancy))
            except Exception:
                pass
        print(f"  Restored {len(rt.ledger.deaths)} death records.")

    # ── Manifest ──────────────────────────────────────────────────────────────

    @staticmethod
    def load_manifest(output_dir: Path) -> dict:
        mp = output_dir / "run_manifest.json"
        return json.loads(mp.read_text()) if mp.exists() else {
            "format": "hrm_kernel_manifest_v1",
            "config_hash": None,
            "sessions": [],
        }

    @staticmethod
    def save_manifest(output_dir: Path, manifest: dict,
                      tick_start: int, tick_end: int,
                      config_hash: str) -> None:
        manifest["config_hash"] = config_hash
        manifest["sessions"].append({
            "started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "tick_start": tick_start,
            "tick_end": tick_end,
        })
        (output_dir / "run_manifest.json").write_text(
            json.dumps(manifest, indent=2), encoding="utf-8")

    # ── Internal helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _save_factions(rt: Any) -> list:
        try:
            return [
                {
                    "id": f.id, "name": f.name,
                    "members": list(getattr(f, "members", set())),
                    "hostility": {k: round(v, 6) for k, v in
                                  getattr(f, "hostility", {}).items()},
                    "leader_id": getattr(f, "leader_id", None),
                }
                for f in rt.faction_registry.factions.values()
            ]
        except Exception:
            return []

    @staticmethod
    def _save_culture(rt: Any) -> dict:
        pool = rt.culture_pool
        return {
            "memes": [
                {
                    "id": m.id, "label": m.label, "valence": m.valence,
                    "spread_rate": m.spread_rate,
                    "strength": round(m.strength, 6),
                    "origin_tick": m.origin_tick,
                }
                for m in pool.memes.values()
            ],
            "agent_memes": {
                aid: list(mids)
                for aid, mids in
                (getattr(pool, "_agent_memes", {}) or {}).items()
            },
        }

    @staticmethod
    def _save_innovation(rt: Any) -> dict:
        ie = rt.innovation_engine
        return {
            "summary": {
                "total_attempts": ie.total_attempts,
                "total_successes": ie.total_successes,
                "total_diffusions": getattr(ie, "total_diffusions", 0),
                "total_institutional_adoptions": getattr(
                    ie, "total_institutional_adoptions", 0),
            },
            "practice_registry": {
                name: {
                    "name": p.name, "domain": p.domain,
                    "utility_score": round(p.utility_score, 6),
                    "fidelity": round(p.fidelity, 6),
                    "origin_agent_id": p.origin_agent_id,
                    "origin_tick": p.origin_tick,
                    "attempts": p.attempts, "successes": p.successes,
                    "diffusion_count": p.diffusion_count,
                    "institutional_adoptions": p.institutional_adoptions,
                    "tags": p.tags,
                }
                for name, p in ie.practice_registry.items()
            },
        }

    @staticmethod
    def _save_governance(rt: Any) -> dict:
        gl = rt.governance_ledger
        leaders = {}
        for fid, rec in gl.leaders.items():
            leaders[fid] = {
                "leader_id": rec.leader_id,
                "legitimacy": round(rec.legitimacy, 6),
                "ticks_in_power": getattr(rec, "ticks_in_power", 0),
                "in_governance_gap": getattr(rec, "in_governance_gap", False),
            }
        return {
            "total_successions": gl.total_successions,
            "total_compliance": gl.total_compliance,
            "total_defiance": gl.total_defiance,
            "leaders": leaders,
        }
