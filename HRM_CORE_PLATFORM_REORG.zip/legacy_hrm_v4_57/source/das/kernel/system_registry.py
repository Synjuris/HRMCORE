"""
kernel/system_registry.py — Declarative subsystem orchestration.

K2-3B: Phases are declared constants. Subsystems declare dependencies
explicitly. The registry validates and topo-sorts at freeze() before
the first tick. The kernel owns ordering.

Phase order (fixed, declared in SYSTEM_PHASES):
    PRE_AGENT    — world prep before agent ticks (ecology, env)
    AGENT        — reserved; runtime handles agent ticks directly
    POST_AGENT   — natural mortality check after agent ticks
    SUBSISTENCE  — feeding / subsistence world tick
    TRANSFER     — resource transfers between agents
    REPRODUCTION — birth system (every 25 ticks)
    GENERATIONAL — generational pressure, dependency load
    GOVERNANCE   — leadership, compliance, enforcement
    INFORMATION  — information propagation, ledger update
    INNOVATION   — practice attempts, diffusion
    CULTURE      — storykeeper transmission, care recovery, inst. memory
    VIABILITY    — population viability / extinction pressure
    METRICS      — metric collection (every 10 ticks)
    CHECKPOINT   — save state (every snap_every ticks)

Dependency rules (enforced at freeze()):
    - depends_on may only name subsystems in the SAME phase
      or subsystems in an EARLIER phase.
    - Forward cross-phase dependencies are a hard-fail.
    - Cycles within a phase are a hard-fail.
    - Unknown dep names are a hard-fail.
    - Duplicate subsystem names are a hard-fail.
    - Unknown phase names are a hard-fail.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple


# ── Canonical phase declaration ───────────────────────────────────────────────

SYSTEM_PHASES: Tuple[str, ...] = (
    "PRE_AGENT",
    "AGENT",        # reserved — runtime handles agent ticks directly
    "POST_AGENT",
    "SUBSISTENCE",
    "TRANSFER",
    "REPRODUCTION",
    "GENERATIONAL",
    "GOVERNANCE",
    "INFORMATION",
    "INNOVATION",
    "CULTURE",
    "VIABILITY",
    "METRICS",
    "CHECKPOINT",
)

# Phase index for ordering comparisons
_PHASE_ORDER: Dict[str, int] = {p: i for i, p in enumerate(SYSTEM_PHASES)}


# ── Legacy IntEnum shim ───────────────────────────────────────────────────────
# Preserved for any code that imports SystemPhase directly.
# Maps old enum names to new string phase names.

from enum import IntEnum

class SystemPhase(IntEnum):
    PRE_AGENT    = 10
    AGENT        = 20
    POST_AGENT   = 30
    SUBSISTENCE  = 40
    TRANSFER     = 50
    REPRODUCTION = 60
    SUBSYSTEMS   = 70   # legacy: maps to GENERATIONAL..VIABILITY range
    METRICS      = 80
    CHECKPOINT   = 90

_LEGACY_PHASE_MAP: Dict[SystemPhase, str] = {
    SystemPhase.PRE_AGENT:    "PRE_AGENT",
    SystemPhase.AGENT:        "AGENT",
    SystemPhase.POST_AGENT:   "POST_AGENT",
    SystemPhase.SUBSISTENCE:  "SUBSISTENCE",
    SystemPhase.TRANSFER:     "TRANSFER",
    SystemPhase.REPRODUCTION: "REPRODUCTION",
    SystemPhase.SUBSYSTEMS:   "GENERATIONAL",  # legacy registrations land here
    SystemPhase.METRICS:      "METRICS",
    SystemPhase.CHECKPOINT:   "CHECKPOINT",
}


# ── SubsystemSpec ─────────────────────────────────────────────────────────────

@dataclass
class SubsystemSpec:
    """
    Declarative description of one simulation subsystem.

    Fields:
        name         — unique identifier; used in depends_on references
        phase        — string phase name from SYSTEM_PHASES
        fn           — callable(tick, runtime) -> None
        observe_fn   — optional callable(tick, runtime) -> None
                       K2-3C: called during METRICS phase after all step()
                       calls complete. Non-mutating by convention — records
                       metrics only, must not alter simulation state.
        depends_on   — names of subsystems this must run after
                       (same phase or earlier phase only)
        every_n      — run every N ticks (default: 1 = every tick)
        enabled_flag — optional KernelConfig attribute name; if the
                       attribute is falsy the subsystem is skipped
    """
    name:         str
    phase:        str
    fn:           Callable
    observe_fn:   Optional[Callable] = None   # K2-3C
    depends_on:   Tuple[str, ...] = ()
    every_n:      int = 1
    enabled_flag: Optional[str] = None


# ── RegisteredSystem (internal execution record) ──────────────────────────────

@dataclass
class RegisteredSystem:
    """Internal: a validated, ordered subsystem ready for execution."""
    name:         str
    phase:        str
    fn:           Callable
    observe_fn:   Optional[Callable]   # K2-3C: non-mutating metrics hook
    every_n:      int
    enabled_flag: Optional[str]


# ── SystemRegistry ────────────────────────────────────────────────────────────

class SystemRegistry:
    """
    Declarative subsystem registry with startup validation.

    Usage:
        registry = SystemRegistry()

        # Register via SubsystemSpec (K2-3B style):
        registry.register_spec(SubsystemSpec(
            name="governance",
            phase="GOVERNANCE",
            fn=lambda tick, rt: gov_tick(...),
            depends_on=("generational",),
        ))

        # Legacy registration (still supported):
        registry.register("generational", SystemPhase.SUBSYSTEMS,
                          lambda tick, rt: gen_tick(...))

        # Call once before first tick — validates, topo-sorts, freezes:
        registry.freeze()

        # Each tick:
        registry.run_phase("GOVERNANCE", tick, runtime)

    Validation hard-fails on:
        - Unknown phase name
        - Duplicate subsystem name
        - Unknown dependency name
        - Forward cross-phase dependency
        - Circular dependency within a phase
    """

    def __init__(self):
        self._specs:   List[SubsystemSpec] = []
        self._plan:    List[RegisteredSystem] = []   # frozen execution order
        self._frozen:  bool = False

    # ── Registration ──────────────────────────────────────────────────────────

    def register_spec(self, spec: SubsystemSpec) -> None:
        """Register a subsystem via SubsystemSpec (K2-3B API)."""
        if self._frozen:
            raise RuntimeError(
                f"Cannot register '{spec.name}' after freeze(). "
                f"All registrations must occur before the first tick.")
        self._specs.append(spec)

    def register(
        self,
        name: str,
        phase: Any,           # SystemPhase enum or string
        fn:    Callable,
        every_n: int = 1,
        priority: int = 0,    # ignored post-K2-3B; ordering via depends_on
    ) -> None:
        """
        Legacy registration API. Converts SystemPhase enum to string phase.
        depends_on defaults to empty — ordering is by registration order
        within the phase (preserved for backward compat).
        """
        if isinstance(phase, SystemPhase):
            phase_str = _LEGACY_PHASE_MAP.get(phase, "GENERATIONAL")
        else:
            phase_str = str(phase)

        self.register_spec(SubsystemSpec(
            name=name,
            phase=phase_str,
            fn=fn,
            depends_on=(),
            every_n=every_n,
        ))

    # ── Freeze / validation ───────────────────────────────────────────────────

    def freeze(self) -> None:
        """
        Validate all registrations, topo-sort within phases, build
        frozen execution plan. Must be called before the first tick.
        Hard-fails on any violation.
        """
        if self._frozen:
            return

        errors: List[str] = []

        # 1. Unknown phase names
        for spec in self._specs:
            if spec.phase not in _PHASE_ORDER:
                errors.append(
                    f"Unknown phase '{spec.phase}' for subsystem '{spec.name}'. "
                    f"Valid phases: {SYSTEM_PHASES}")

        # 2. Duplicate names
        seen_names: Dict[str, int] = {}
        for i, spec in enumerate(self._specs):
            if spec.name in seen_names:
                errors.append(
                    f"Duplicate subsystem name '{spec.name}' "
                    f"(first at index {seen_names[spec.name]}, duplicate at {i}).")
            else:
                seen_names[spec.name] = i

        if errors:
            _fail(errors)

        # Build lookup: name -> spec
        by_name: Dict[str, SubsystemSpec] = {s.name: s for s in self._specs}

        # 3. Unknown dependency names
        for spec in self._specs:
            for dep in spec.depends_on:
                if dep not in by_name:
                    errors.append(
                        f"Subsystem '{spec.name}' depends_on unknown "
                        f"subsystem '{dep}'.")

        # 4. Forward cross-phase dependencies
        for spec in self._specs:
            my_order = _PHASE_ORDER[spec.phase]
            for dep in spec.depends_on:
                if dep not in by_name:
                    continue  # already caught above
                dep_order = _PHASE_ORDER[by_name[dep].phase]
                if dep_order > my_order:
                    errors.append(
                        f"Subsystem '{spec.name}' (phase={spec.phase}) "
                        f"depends_on '{dep}' (phase={by_name[dep].phase}) "
                        f"which is a later phase. "
                        f"Cross-phase forward dependencies are forbidden.")

        if errors:
            _fail(errors)

        # 5. Topo-sort within each phase + cycle detection
        plan: List[RegisteredSystem] = []
        phases_used = sorted(
            {s.phase for s in self._specs},
            key=lambda p: _PHASE_ORDER[p],
        )

        for phase in phases_used:
            phase_specs = [s for s in self._specs if s.phase == phase]
            ordered, cycle_errors = _topo_sort(phase_specs, by_name, phase)
            errors.extend(cycle_errors)
            for spec in ordered:
                plan.append(RegisteredSystem(
                    name=spec.name,
                    phase=spec.phase,
                    fn=spec.fn,
                    observe_fn=spec.observe_fn,   # K2-3C
                    every_n=spec.every_n,
                    enabled_flag=spec.enabled_flag,
                ))

        if errors:
            _fail(errors)

        self._plan   = plan
        self._frozen = True

    # ── Execution ─────────────────────────────────────────────────────────────

    def run_phase(self, phase: Any, tick: int, runtime: Any) -> None:
        """
        Run all subsystems registered to `phase` for this tick.
        `phase` may be a string or legacy SystemPhase enum.
        freeze() must have been called before the first run_phase().
        """
        if not self._frozen:
            self.freeze()

        if isinstance(phase, SystemPhase):
            phase_str = _LEGACY_PHASE_MAP.get(phase, str(phase))
        else:
            phase_str = str(phase)

        for s in self._plan:
            if s.phase != phase_str:
                continue
            if tick % s.every_n != 0:
                continue
            if s.enabled_flag is not None:
                if not getattr(runtime.cfg, s.enabled_flag, True):
                    continue
            try:
                s.fn(tick, runtime)
            except Exception as e:
                import traceback
                print(f"[SystemRegistry] ERROR in '{s.name}' "
                      f"(phase={s.phase}) at tick {tick}: {e}")
                traceback.print_exc()

    def run_all(self, tick: int, runtime: Any) -> None:
        """Run all phases in order for one tick (AGENT phase is skipped)."""
        if not self._frozen:
            self.freeze()
        for phase in SYSTEM_PHASES:
            if phase == "AGENT":
                continue
            self.run_phase(phase, tick, runtime)

    # ── Introspection ─────────────────────────────────────────────────────────

    def names(self) -> List[str]:
        if not self._frozen:
            return [s.name for s in self._specs]
        return [s.name for s in self._plan]

    def summary(self) -> str:
        if not self._frozen:
            return "(not frozen — call freeze() before summary)"
        lines = []
        for s in self._plan:
            every = f"every {s.every_n}" if s.every_n > 1 else "every tick"
            flag  = f" [flag={s.enabled_flag}]" if s.enabled_flag else ""
            lines.append(f"  [{s.phase:14s}] {s.name} ({every}){flag}")
        return "\n".join(lines)

    def run_observers(self, tick: int, runtime: Any) -> None:
        """
        K2-3C: Call observe_fn on all registered subsystems that expose one.

        Called during the METRICS phase after all step() (fn) calls complete.
        observe_fn is non-mutating by convention — it records metrics only
        and must not alter simulation state.

        Subsystems without observe_fn are skipped silently.
        enabled_flag and every_n gates are NOT applied here — observers
        decide their own sampling internally if needed.
        """
        if not self._frozen:
            self.freeze()
        for s in self._plan:
            if s.observe_fn is None:
                continue
            try:
                s.observe_fn(tick, runtime)
            except Exception as e:
                import traceback
                print(f"[SystemRegistry] ERROR in observer '{s.name}' "
                      f"at tick {tick}: {e}")
                traceback.print_exc()

    def execution_plan(self) -> List[Dict[str, Any]]:
        """Return the frozen execution plan as a list of dicts."""
        if not self._frozen:
            raise RuntimeError("Call freeze() first.")
        return [
            {"name": s.name, "phase": s.phase,
             "every_n": s.every_n, "enabled_flag": s.enabled_flag,
             "has_observer": s.observe_fn is not None}   # K2-3C
            for s in self._plan
        ]


# ── Helpers ───────────────────────────────────────────────────────────────────

def _topo_sort(
    specs:   List[SubsystemSpec],
    by_name: Dict[str, SubsystemSpec],
    phase:   str,
) -> Tuple[List[SubsystemSpec], List[str]]:
    """
    Kahn's algorithm topo-sort within a single phase.
    Same-phase deps only (cross-phase already validated out).
    Returns (ordered_list, error_list).
    """
    errors: List[str] = []
    phase_names = {s.name for s in specs}

    # Build adjacency: name -> set of names that must come before it
    in_phase_deps: Dict[str, List[str]] = {s.name: [] for s in specs}
    for spec in specs:
        for dep in spec.depends_on:
            if dep in phase_names:
                in_phase_deps[spec.name].append(dep)
            # Cross-phase deps (dep in earlier phase) are already validated;
            # they impose no ordering constraint within this phase.

    # Kahn's
    in_degree = {name: 0 for name in phase_names}
    for name, deps in in_phase_deps.items():
        for dep in deps:
            in_degree[name] += 1

    queue = [name for name in phase_names if in_degree[name] == 0]
    # Deterministic: sort queue for stable ordering
    queue = sorted(queue)
    result_names: List[str] = []

    while queue:
        node = queue.pop(0)
        result_names.append(node)
        # Find who depends on node
        for name in phase_names:
            if node in in_phase_deps[name]:
                in_degree[name] -= 1
                if in_degree[name] == 0:
                    queue.append(name)
                    queue.sort()

    if len(result_names) != len(specs):
        cycle_members = phase_names - set(result_names)
        errors.append(
            f"Circular dependency detected in phase '{phase}' among: "
            f"{sorted(cycle_members)}")
        # Return whatever we have so other errors can surface
        result_names.extend(sorted(cycle_members))

    name_to_spec = {s.name: s for s in specs}
    return [name_to_spec[n] for n in result_names], errors


def _fail(errors: List[str]) -> None:
    msg = "\n".join(f"  [{i+1}] {e}" for i, e in enumerate(errors))
    raise RuntimeError(
        f"\n\n[SystemRegistry] Startup validation failed "
        f"({len(errors)} error{'s' if len(errors) != 1 else ''}):\n{msg}\n")
