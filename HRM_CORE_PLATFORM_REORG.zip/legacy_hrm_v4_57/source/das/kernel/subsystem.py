"""
kernel/subsystem.py — HRM Kernel Contract Layer  (v4.57)

Defines the canonical lifecycle contract every HRM subsystem must satisfy.

─────────────────────────────────────────────────────────────────────────────
MOTIVATION

HRM has accumulated enough subsystems that implicit architecture is now a
compounding liability.  Each subsystem currently invents its own:

    - initialisation pattern  (some via build_world, some via experiment_setup)
    - mutation authority      (no phase boundary enforcement)
    - persistence             (checkpoint.py hard-codes each subsystem by name)
    - observability           (ad-hoc; only CognitionObserver uses observe_fn)
    - validation              (absent)

The contract layer makes all of these explicit and enforced.

─────────────────────────────────────────────────────────────────────────────
CONTRACT

Every subsystem MUST implement:

    step(tick, runtime)      — sole mutation window.  May write state.

Every subsystem SHOULD implement (defaults are safe no-ops):

    init(runtime)            — called once by build_world() after all world
                               objects exist.  May write to runtime world refs.
    observe(tick, runtime)   — called AFTER all step() calls complete.
                               MUST NOT mutate simulation state.
                               Used for metrics, logging, AI observation.
    persist()                — return JSON-serialisable dict of this subsystem's
                               world-level state.  Called by checkpoint.
    restore(state)           — absorb a dict previously returned by persist().
                               Called by checkpoint restore before first tick.
    validate()               — called at freeze() time.  Raise ValueError if
                               the subsystem detects a configuration problem.

─────────────────────────────────────────────────────────────────────────────
MUTATION AUTHORITY

Only step() may write simulation state.
observe(), persist(), restore(), validate() are read-only with respect to
the running simulation.  This is enforced by convention and verified by the
validation harness — not by Python's runtime — but the contract makes the
expectation unambiguous.

─────────────────────────────────────────────────────────────────────────────
REGISTRATION

Subsystem.spec() returns a SubsystemSpec ready to pass to
registry.register_spec().  Experiment code no longer constructs SubsystemSpec
manually for subsystems that extend this base class.

Example:

    class GovernanceSubsystem(Subsystem):
        name     = "governance"
        phase    = "GOVERNANCE"
        every_n  = 1
        depends_on = ("generational",)

        def __init__(self, governance_config=None):
            self._cfg = governance_config

        def step(self, tick, runtime):
            governance.tick(runtime.agents, tick, ...)

        def persist(self):
            return runtime_ref_snapshot(self._registry)   # hypothetical

        def restore(self, state):
            self._registry.load(state)

    rt.registry.register_spec(GovernanceSubsystem().spec(runtime))

─────────────────────────────────────────────────────────────────────────────
BACKWARD COMPATIBILITY

The base class is fully additive.  Existing lambda-based SubsystemSpec
registrations in experiment_setup.py are unaffected.  Adoption is
incremental: subsystems migrate to the contract class one at a time.

─────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Tuple


class Subsystem:
    """
    Base class for all HRM kernel subsystems.

    Class attributes (set by subclass, not instance):
        name        — unique identifier; used in registry and checkpoint keys
        phase       — string phase from SYSTEM_PHASES
        every_n     — activation cadence in ticks (default 1)
        depends_on  — tuple of subsystem names that must precede this one
        enabled_flag — optional KernelConfig attribute name; subsystem is
                       skipped when the attribute is falsy

    The subsystem holds a reference to the runtime after init() is called.
    This reference is set by register_and_init() and is available in all
    lifecycle methods.
    """

    # ── Class-level contract declarations (override in subclass) ──────────────

    name:         str = ""
    phase:        str = ""
    every_n:      int = 1
    depends_on:   Tuple[str, ...] = ()
    enabled_flag: Optional[str] = None

    def __init__(self) -> None:
        self._runtime: Optional[Any] = None

    # ── Lifecycle methods (override as needed) ────────────────────────────────

    def init(self, runtime: Any) -> None:
        """
        Called once by build_world() or setup_experiment() after all world
        objects exist.  May write to runtime attributes.
        Default: no-op.
        """

    def step(self, tick: int, runtime: Any) -> None:
        """
        The SOLE mutation window.  May read and write simulation state.
        Called once per tick (subject to every_n cadence) during the
        declared phase.
        MUST be overridden.
        """
        raise NotImplementedError(
            f"Subsystem '{self.name}' must implement step(tick, runtime)."
        )

    def observe(self, tick: int, runtime: Any) -> None:
        """
        Called AFTER all step() calls in a tick complete (METRICS phase).
        MUST NOT mutate simulation state.
        Default: no-op.
        """

    def persist(self) -> Dict[str, Any]:
        """
        Return a JSON-serialisable dict representing this subsystem's
        world-level state.  Called by checkpoint.save().
        Default: returns empty dict (subsystem has no persistent state).
        """
        return {}

    def restore(self, state: Dict[str, Any]) -> None:
        """
        Absorb a state dict previously returned by persist().
        Called by checkpoint.restore() before the first tick.
        Default: no-op.
        """

    def validate(self) -> None:
        """
        Called at freeze() time.  Raise ValueError if configuration is
        inconsistent.  Should not access runtime state (not yet built).
        Default: no-op.
        """

    # ── Registration helper ───────────────────────────────────────────────────

    def register(self, runtime: Any) -> None:
        """
        Convenience: call init() then register with the runtime's registry.
        Preferred over manually calling registry.register_spec().

        Usage:
            my_subsystem = GovernanceSubsystem(cfg)
            my_subsystem.register(rt)   # inits and registers in one call
        """
        self._runtime = runtime
        self.init(runtime)
        runtime.registry.register_spec(self._make_spec())

    def _make_spec(self) -> Any:
        """Build a SubsystemSpec from this subsystem's contract declarations."""
        from .system_registry import SubsystemSpec

        if not self.name:
            raise ValueError(
                f"{type(self).__name__} must declare a non-empty class attribute 'name'."
            )
        if not self.phase:
            raise ValueError(
                f"Subsystem '{self.name}' must declare a non-empty class attribute 'phase'."
            )

        return SubsystemSpec(
            name=self.name,
            phase=self.phase,
            fn=self.step,
            observe_fn=self._observe_fn_or_none(),
            depends_on=tuple(self.depends_on),
            every_n=self.every_n,
            enabled_flag=self.enabled_flag,
        )

    def _observe_fn_or_none(self):
        """
        Return observe bound method only if the subclass overrides it.
        Avoids registering a no-op observe_fn for subsystems that don't use it.
        """
        # If observe() is still the base class version, return None so the
        # registry doesn't call it unnecessarily every METRICS phase.
        if type(self).observe is Subsystem.observe:
            return None
        return self.observe

    # ── Persistence helpers ───────────────────────────────────────────────────

    @classmethod
    def collect_persist(cls, subsystems: list) -> Dict[str, Any]:
        """
        Collect persist() output from a list of Subsystem instances.
        Returns {name: state_dict, ...}.
        Used by checkpoint infrastructure.
        """
        return {
            s.name: s.persist()
            for s in subsystems
            if isinstance(s, Subsystem) and s.persist() != {}
        }

    @classmethod
    def dispatch_restore(cls, subsystems: list, checkpoint: Dict[str, Any]) -> None:
        """
        Dispatch restore() to each subsystem whose name appears in checkpoint.
        Used by checkpoint infrastructure.
        """
        for s in subsystems:
            if isinstance(s, Subsystem) and s.name in checkpoint:
                s.restore(checkpoint[s.name])

    # ── Introspection ─────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        return (
            f"<Subsystem name={self.name!r} phase={self.phase!r} "
            f"every_n={self.every_n}>"
        )


# ─────────────────────────────────────────────────────────────────────────────
# MutationGuard
#
# A thin context manager for defensive use in observe(), persist(), and
# validate() bodies.  Raises immediately if any write to a guarded attribute
# is attempted.  Opt-in; not enforced by the kernel.
#
# Usage:
#
#   def observe(self, tick, runtime):
#       with MutationGuard(runtime, "agents", "culture_pool"):
#           self._record_entropy(runtime)
#
# ─────────────────────────────────────────────────────────────────────────────

class MutationGuard:
    """
    Context manager that intercepts __setattr__ on a runtime object for
    named attributes and raises RuntimeError on any write attempt.

    Intended for use inside observe(), persist(), and validate() to catch
    accidental state mutation during read-only phases.

    This is a defensive development tool, not a security boundary.
    """

    def __init__(self, target: Any, *attr_names: str) -> None:
        self._target = target
        self._guarded = set(attr_names)
        self._original_setattr = None

    def __enter__(self):
        target = self._target
        guarded = self._guarded

        original = target.__class__.__setattr__

        def guarded_setattr(obj, name, value):
            if obj is target and name in guarded:
                raise RuntimeError(
                    f"[MutationGuard] Attempted write to '{name}' during "
                    f"a read-only phase (observe/persist/validate). "
                    f"Only step() may mutate simulation state."
                )
            original(obj, name, value)

        self._original_setattr = original
        target.__class__.__setattr__ = guarded_setattr
        return self

    def __exit__(self, *_):
        if self._original_setattr is not None:
            self._target.__class__.__setattr__ = self._original_setattr


# ─────────────────────────────────────────────────────────────────────────────
# SubsystemRegistry extension helper
#
# Adds collect_persist / dispatch_restore to a live SystemRegistry without
# modifying that class.  Called from checkpoint.py.
# ─────────────────────────────────────────────────────────────────────────────

def registry_collect_persist(registry: Any) -> Dict[str, Any]:
    """
    Walk a SystemRegistry's execution plan and call persist() on every
    registered Subsystem instance.

    The SystemRegistry stores callables (fn), not Subsystem instances.
    This function reverse-maps: if fn is a bound method of a Subsystem,
    extract the subsystem and call persist().

    Returns {name: state_dict} for all subsystems with non-empty state.
    """
    result: Dict[str, Any] = {}
    if not getattr(registry, "_frozen", False):
        return result
    for reg in registry._plan:
        subsystem = _extract_subsystem(reg.fn)
        if subsystem is not None:
            state = subsystem.persist()
            if state:
                result[reg.name] = state
    return result


def registry_dispatch_restore(registry: Any, checkpoint: Dict[str, Any]) -> None:
    """
    Walk a SystemRegistry's execution plan and call restore() on every
    Subsystem whose name appears in the checkpoint dict.
    """
    if not getattr(registry, "_frozen", False):
        return
    for reg in registry._plan:
        if reg.name not in checkpoint:
            continue
        subsystem = _extract_subsystem(reg.fn)
        if subsystem is not None:
            subsystem.restore(checkpoint[reg.name])


def _extract_subsystem(fn: Any) -> Optional["Subsystem"]:
    """
    If fn is a bound method whose __self__ is a Subsystem, return it.
    Otherwise return None.
    """
    self_obj = getattr(fn, "__self__", None)
    if isinstance(self_obj, Subsystem):
        return self_obj
    return None
