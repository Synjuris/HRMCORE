"""
kernel/runtime.py — HRMRuntime

Owns the tick loop, agent pool, world references, and system execution.
Experiments initialize the runtime then call run().

This replaces the main() functions in run_exp_*.py.
The runtime is not an experiment — it has no knowledge of groups,
meme seeds, or arrival ticks. Those belong in the experiment setup
that calls runtime.run().

Key contracts:
- runtime.agents is the canonical agent list (alive + dead)
- runtime.bus is the canonical event channel
- runtime.registry holds all registered systems
- runtime.global_rng is the canonical RNG (seed-derived)
- All systems receive (tick, runtime) — they pull what they need
"""

from __future__ import annotations

import random
import signal
import time
import json
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set

from .config import KernelConfig
from .event_bus import EventBus
from .system_registry import SystemRegistry, SystemPhase
from .checkpoint import KernelCheckpoint


class HRMRuntime:
    """
    The kernel runtime. Owns the tick loop and all shared world state.

    Initialization pattern:
        rt = HRMRuntime(cfg)
        rt.build_world()          # constructs all subsystems
        # experiment setup: add agents, seed culture, etc.
        rt.run()                  # tick loop until done or Ctrl+C
    """

    def __init__(self, cfg: KernelConfig):
        self.cfg = cfg
        self.global_rng = random.Random(cfg.seed)

        # Agent pool — single source of truth
        self.agents: List[Any] = []
        self.agent_group: Dict[str, str] = {}
        self.death_logged: Set[str] = set()

        # World subsystems — populated by build_world()
        self.env_cycle = None
        self.spatial_world = None
        self.resource_world = None
        self.faction_registry = None
        self.territory_map = None
        self.institution_registry = None
        self.culture_pool = None
        self.world_narrative = None
        self.texture_chronicle = None
        self.persistence_ledger = None
        self.logistics_world = None
        self.subsistence_world = None
        self.zone_grid = None
        self.reproduction_system = None
        self.settlement_ledger = None

        # Ledgers
        self.ledger = None              # DeathLedger
        self.generational_ledger = None
        self.apprenticeship_ledger = None
        self.governance_ledger = None
        self.information_ledger = None
        self.innovation_engine = None
        self.genpsych_ledger = None
        self.inst_mem_ledger = None
        self.constraint_ledger = None

        # Kernel infrastructure
        self.registry = SystemRegistry()
        self.bus: Optional[EventBus] = None
        self.checkpoint: Optional[KernelCheckpoint] = None

        # Hooks — experiment code registers these
        self._on_birth_hooks: List[Callable] = []
        self._on_death_hooks: List[Callable] = []
        self._pending_groups: Dict[str, List[Any]] = {}  # gl -> agents

        # Runtime state
        self._stop_requested = False
        self._tick = 0
        self._metric_log: List[dict] = []
        self._session_start_tick = 1

        # v4.56 — determinism, scheduler abstraction, artifact metrics
        self._next_creation_index: int = 0
        # Default scheduler is sequential (preserves existing behaviour).
        # Override after build_world() for sensitivity tests.
        from .schedulers import SequentialScheduler
        self.scheduler = SequentialScheduler()
        # Fingerprint and metrics are built lazily after world construction.
        self.fingerprint = None   # set by build_world()
        self.artifact_metrics = None  # set by build_world()

        # Config hash for checkpoint validation.
        # Excludes run-time-only params (ticks, output_root) so that
        # resuming with a different tick limit doesn't cause a hash mismatch.
        import hashlib
        _world_identity = {
            k: v for k, v in cfg.to_dict().items()
            if k not in (
                "ticks", "output_root", "snap_every", "version",
                "cognition_observer_enabled",
                "cognition_observer_every_n",
                "cognition_observer_sample_size",
                "cognition_observer_agent_ids",
                "cognition_observer_output_file",
                "cognition_observer_include_prompt_packet",
            )
        }
        self._config_hash = hashlib.sha256(
            json.dumps(_world_identity, sort_keys=True).encode()
        ).hexdigest()[:12]

    # ── World construction ────────────────────────────────────────────────────

    def build_world(self) -> None:
        """Construct all subsystems. Call once before run()."""
        import sys
        from pathlib import Path as _P
        # Ensure das/ is on path
        das_path = str(_P(__file__).parent.parent)
        if das_path not in sys.path:
            sys.path.insert(0, das_path)

        from environment import EnvironmentCycle
        from space import SpatialWorld
        from resources import ResourceWorld
        from factions import FactionRegistry
        from territory import TerritoryMap
        from institutions import InstitutionRegistry
        from culture import CulturePool
        from language import WorldNarrative
        from experiential import TextureChronicle
        from persistence import PersistenceLedger
        from logistics import LogisticsWorld
        from subsistence import SubsistenceWorld
        from reproduction import ReproductionSystem
        from settlements import SettlementLedger
        from spatial_zone import ZoneGrid
        from death_ledger import DeathLedger
        from generational import GenerationalLedger
        from apprenticeship import ApprenticeshipLedger
        from governance import GovernanceLedger
        from information import InformationLedger
        from innovation import InnovationEngine
        from generational_psychology import GenerationalPsychologyLedger
        from institutional_memory import InstitutionalMemoryLedger
        from constraints import ConstraintLedger
        from harness import EventStream, RollingCounters
        import salience as salience_mod

        cfg = self.cfg
        rng = self.global_rng

        self.env_cycle        = EnvironmentCycle()
        self.spatial_world    = SpatialWorld(width=cfg.world_w, height=cfg.world_h,
                                             interaction_radius=3)
        self.resource_world   = ResourceWorld(width=cfg.world_w, height=cfg.world_h,
                                              n_nodes=120, rng=rng)
        self.faction_registry = FactionRegistry()
        self.territory_map    = TerritoryMap(width=cfg.world_w, height=cfg.world_h)
        self.institution_registry = InstitutionRegistry()
        self.culture_pool     = CulturePool()
        self.culture_pool.memes = {}
        self.culture_pool._agent_memes = {}
        self.world_narrative  = WorldNarrative()
        self.texture_chronicle = TextureChronicle()
        self.persistence_ledger = PersistenceLedger()
        self.logistics_world  = LogisticsWorld(cfg.world_w, cfg.world_h,
                                               seed=cfg.seed + cfg.logistics_seed_offset)
        self.subsistence_world = SubsistenceWorld(cfg.world_w, cfg.world_h,
                                                  seed=cfg.seed + cfg.subsistence_seed_offset)
        self.reproduction_system = ReproductionSystem(max_population=cfg.max_population)
        self.settlement_ledger = SettlementLedger()

        # Wire logistics
        self.spatial_world.logistics_world  = self.logistics_world
        self.resource_world.logistics_world = self.logistics_world

        # Zone grid
        self.zone_grid = ZoneGrid(cfg.world_w, cfg.world_h,
                                  seed=cfg.seed + cfg.zone_seed_offset)
        self.spatial_world._zone_grid     = self.zone_grid
        self.subsistence_world._zone_grid = self.zone_grid
        print(f"ZoneGrid: {len(self.zone_grid.zones)} zones")

        # Ledgers
        self.ledger               = DeathLedger()
        self.generational_ledger  = GenerationalLedger()
        self.apprenticeship_ledger = ApprenticeshipLedger()
        self.governance_ledger    = GovernanceLedger()
        self.information_ledger   = InformationLedger()
        self.innovation_engine    = InnovationEngine()
        self.genpsych_ledger      = GenerationalPsychologyLedger()
        self.inst_mem_ledger      = InstitutionalMemoryLedger()
        self.constraint_ledger    = ConstraintLedger()

        # Event infrastructure
        output_dir = cfg.output_path / "run_1"
        output_dir.mkdir(parents=True, exist_ok=True)
        self._output_dir = output_dir

        _counters = RollingCounters()
        _stream   = EventStream(output_dir / "events.jsonl")
        self._counters = _counters

        self.bus = EventBus(
            stream=_stream,
            persistence_ledger=self.persistence_ledger,
            counters=_counters,
            salience_scorer=salience_mod.score,
        )

        # Death routing via bus listener
        self.bus.on("lethal_conflict", self._handle_lethal_conflict)

        # Checkpoint
        self.checkpoint = KernelCheckpoint(output_dir, self._config_hash)

        # v4.56 — fingerprint and artifact metrics
        from core.determinism import RunFingerprint
        from .metrics import ArtifactMetrics
        self.fingerprint = RunFingerprint(self)
        self.artifact_metrics = ArtifactMetrics()

    # ── Hooks ─────────────────────────────────────────────────────────────────


    # ── v4.56 agent ordering ──────────────────────────────────────────────────

    def next_agent_index(self) -> int:
        """Return monotonically increasing creation index and advance counter."""
        idx = self._next_creation_index
        self._next_creation_index += 1
        return idx

    def sorted_agents(self):
        """Return agents sorted by creation_index (deterministic order)."""
        return sorted(
            self.agents,
            key=lambda a: getattr(a, 'creation_index', 0),
        )

    def on_birth(self, fn: Callable) -> None:
        self._on_birth_hooks.append(fn)

    def on_death(self, fn: Callable) -> None:
        self._on_death_hooks.append(fn)

    def register_pending_group(self, arrival_tick: int, gl: str,
                                agents: List[Any],
                                on_arrival: Optional[Callable] = None) -> None:
        self._pending_groups[gl] = (arrival_tick, agents, on_arrival)

    # ── Main run loop ─────────────────────────────────────────────────────────

    def run(self, start_tick: int = 1) -> None:
        import psychology as psychology_mod
        import life_events as life_events_mod
        from harness import safe_agent_tick
        from ecological_context import ecological_health as _eco_health_fn
        from resource_transfer import apply_resource_transfers
        from generational import assign_child_context
        from information import init_agent as init_information_agent
        from innovation import init_agent as init_innovation_agent
        from governance import init_agent as init_governance_agent
        from spatial_memory import SpatialMemory
        from movement_goals import init_agent_movement
        import continuity as continuity_mod
        from metrics import population_metrics, topology_metrics
        from death_ledger import build_death_record

        cfg = self.cfg
        self._session_start_tick = start_tick
        self._stop_requested = False

        # Freeze execution plan — validates phases, deps, topo-sorts.
        # Hard-fails if any subsystem spec is invalid.
        self.registry.freeze()

        def _sigint(sig, frame):
            print("\n\n  [Ctrl+C] Finishing tick then saving...")
            self._stop_requested = True
        signal.signal(signal.SIGINT, _sigint)

        def _init_spatial(a):
            x = getattr(a.position, "x", 20.0)
            y = getattr(a.position, "y", 20.0)
            zid = self.zone_grid.zone_id_for_position(x, y)
            init_agent_movement(a, zid)
            if a.spatial_memory is None:
                a.spatial_memory = SpatialMemory()

        def _init_child(child, parents, tick):
            assign_child_context(child, parents, tick, self.generational_ledger)
            init_innovation_agent(child)
            init_information_agent(child)
            init_governance_agent(child)
            _init_spatial(child)
            for p in parents:
                if p.id in self.agent_group:
                    self.agent_group[child.id] = self.agent_group[p.id]
                    break

        def _record_death(agent, tick, cause=None):
            if agent.id in self.death_logged:
                return
            self.death_logged.add(agent.id)
            c = cause or getattr(agent, "_death_cause", "unknown")
            self.ledger.record(build_death_record(agent, self.agents, tick, cause=c))
            psychology_mod.notify_death_to_population(agent, self.agents, tick)
            for fn in self._on_death_hooks:
                try: fn(agent, tick)
                except Exception: pass

        tick = start_tick
        try:
            while tick <= cfg.ticks and not self._stop_requested:
                self._tick = tick

                # ── Spawn pending groups ──────────────────────────────────────
                for gl, (arrival, grp_agents, on_arrival) in list(self._pending_groups.items()):
                    if tick == arrival:
                        print(f"\n  >>> Group {gl} arrives at tick {tick} "
                              f"({len(grp_agents)} agents) <<<")
                        if on_arrival is not None:
                            try:
                                on_arrival(tick, self)
                            except Exception as e:
                                print(f"  [warning] on_arrival hook for group {gl} failed: {e}")
                        for a in grp_agents:
                            _init_spatial(a)
                            self.agent_group[a.id] = gl
                        # v4.56 — stamp creation_index on arrival
                        for a in grp_agents:
                            a.creation_index = self.next_agent_index()
                        self.agents.extend(grp_agents)
                        del self._pending_groups[gl]

                # ── Pre-agent ─────────────────────────────────────────────────
                self.registry.run_phase("PRE_AGENT", tick, self)

                phase = self.env_cycle.get_phase(tick)
                phase = self.subsistence_world.apply_to_phase(phase)

                for sub_ev in self.subsistence_world.begin_tick(tick):
                    self.bus.emit(sub_ev, salience=0.50)

                self.zone_grid.update_local_populations(self.agents)
                self.zone_grid.tick(phase.name)

                _eco = _eco_health_fn(
                    self.subsistence_world, self.agents,
                    recent_deaths=sum(1 for a in self.agents if not a.alive)
                )
                life_events_mod.step_disease_layer(self.agents, tick, key="run_1")
                living = [a for a in self.agents if a.alive]

                for a in living:
                    le = life_events_mod.apply_all_life_effects(a, tick, key="run_1")
                    if le["stress"]:
                        a.state.stress = max(0., min(1., a.state.stress + le["stress"] * 0.012))
                    if le["support"]:
                        a.state.cooperation = max(0., min(1., a.state.cooperation + le["support"] * 0.008))
                    if le["trust"]:
                        a.state.stability = max(0., min(1., a.state.stability + le["trust"] * 0.006))

                for a in living:
                    a._population_ref = self.agents
                    a._eco_health = _eco

                # ── Agent ticks ───────────────────────────────────────────────
                for a in list(living):
                    if not a.alive:
                        continue
                    ev = safe_agent_tick(
                        a, tick, phase, self.agents,
                        spatial_world=self.spatial_world,
                        resource_world=self.resource_world,
                        faction_registry=self.faction_registry,
                        territory_map=self.territory_map,
                        institution_registry=self.institution_registry,
                        culture_pool=self.culture_pool,
                        world_narrative=self.world_narrative,
                        texture_chronicle=self.texture_chronicle,
                        governance_ledger=self.governance_ledger,
                        eco_health=_eco,
                    )
                    if not ev:
                        continue

                    self.bus.emit(ev)

                    if ev.event_type == "birth":
                        child_id   = ev.context.get("child_id")
                        parent_ids = ev.context.get("parent_ids", [])
                        child = next((x for x in self.agents if x.id == child_id), None)
                        if child:
                            parents = [x for x in self.agents if x.id in parent_ids]
                            _init_child(child, parents, tick)
                            for fn in self._on_birth_hooks:
                                try: fn(child, parents, tick)
                                except Exception: pass

                    if ev.event_type == "death":
                        dead = next((x for x in self.agents if x.id == ev.actor_id), None)
                        if dead:
                            _record_death(dead, tick)

                    # Aux events (lethal_conflict, deception, etc.)
                    for aux_ev in getattr(a, "aux_events", []):
                        self.bus.emit(aux_ev, salience=0.90)
                    a.aux_events = []

                # ── POST_AGENT: natural mortality ────────────────────────────
                for a in list(self.agents):
                    if not a.alive:
                        continue
                    a.check_death()
                    if not a.alive:
                        _record_death(a, tick)

                self.registry.run_phase("POST_AGENT", tick, self)

                # ── SUBSISTENCE ───────────────────────────────────────────────
                for a in [x for x in self.agents if x.alive]:
                    for sub_ev in self.subsistence_world.agent_tick(
                            a, tick, phase.name,
                            culture_pool=self.culture_pool,
                            faction_registry=self.faction_registry):
                        self.bus.emit(sub_ev, salience=0.52)
                        a.aux_events.append(sub_ev)

                self.registry.run_phase("SUBSISTENCE", tick, self)

                # ── TRANSFER ──────────────────────────────────────────────────
                for a in [x for x in self.agents if x.alive]:
                    nearby = self.spatial_world.nearby_agents(a, self.agents)
                    for tev in apply_resource_transfers(
                            a, tick, phase.name, nearby,
                            random.Random(tick + hash(a.id) & 0xFFFF)):
                        self.bus.emit(tev, salience=0.72)

                self.registry.run_phase("TRANSFER", tick, self)

                # ── REPRODUCTION ──────────────────────────────────────────────
                if tick % 25 == 0:
                    newborns = self.reproduction_system.tick(
                        self.agents, self.spatial_world, self.faction_registry,
                        self.culture_pool, random.Random(tick * 7),
                        genpsych_ledger=self.genpsych_ledger, tick=tick,
                        eco_health=_eco,
                    )
                    for child in newborns:
                        birth_parents = list(getattr(child, "_birth_parents", []))
                        _init_child(child, birth_parents, tick)
                    # v4.56 — stamp creation_index on birth
                    for a in newborns:
                        a.creation_index = self.next_agent_index()
                    self.agents.extend(newborns)

                self.registry.run_phase("REPRODUCTION", tick, self)

                # ── SUBSYSTEMS ────────────────────────────────────────────────
                self.registry.run_phase("GENERATIONAL", tick, self)
                self.registry.run_phase("GOVERNANCE", tick, self)
                self.registry.run_phase("INFORMATION", tick, self)
                self.registry.run_phase("INNOVATION", tick, self)
                self.registry.run_phase("CULTURE", tick, self)
                self.registry.run_phase("VIABILITY", tick, self)

                # ── METRICS ───────────────────────────────────────────────────
                if tick % 10 == 0:
                    lv = [a for a in self.agents if a.alive]
                    pm = population_metrics(lv)
                    tm = topology_metrics(lv, self.faction_registry, tick)
                    row = {
                        "tick": tick, "phase": phase.name,
                        "alive_count": len(lv),
                        "deaths": len(self.ledger.deaths),
                        "births": sum(1 for a in self.agents if a.generation >= 1),
                        "meme_count": len(self.culture_pool.memes),
                        "factions": len(self.faction_registry.factions),
                        "conflict_cumulative": self._counters.conflict_total,
                        "interaction_cumulative": self._counters.interaction_total,
                        "max_generation": max((a.generation for a in lv), default=0),
                        **pm, **tm,
                    }
                    self._metric_log.append(row)

                self.registry.run_phase("METRICS", tick, self)
                # v4.56 — artifact metrics observe (read-only, after all step phases)
                if self.artifact_metrics is not None:
                    self.artifact_metrics.observe(tick, self)
                # K2-3C: execute observe() hooks after all step() calls.
                # Non-mutating by convention — metrics/observability only.
                self.registry.run_observers(tick, self)

                # ── CHECKPOINT ────────────────────────────────────────────────
                if tick % cfg.snap_every == 0:
                    self.checkpoint.save(tick, self)
                    self._flush_flat_files()
                    self._print_snapshot(tick, phase.name)

                self.registry.run_phase("CHECKPOINT", tick, self)

                tick += 1

        except Exception as e:
            import traceback
            print(f"\n\nERROR at tick {tick}: {e}")
            traceback.print_exc()

        finally:
            final_tick = tick - 1
            print(f"\n\nSaving state at tick {final_tick}...")
            self.checkpoint.save(final_tick, self)
            self._flush_flat_files()
            self._write_outputs(final_tick)
            manifest = KernelCheckpoint.load_manifest(self._output_dir)
            KernelCheckpoint.save_manifest(
                self._output_dir, manifest,
                self._session_start_tick, final_tick,
                self._config_hash,
            )
            living = sum(1 for a in self.agents if a.alive)
            print(f"Done. tick={final_tick} alive={living} "
                  f"deaths={len(self.ledger.deaths)} "
                  f"practices={len(self.innovation_engine.practice_registry)}")

    # ── Lethal conflict handler ───────────────────────────────────────────────

    def _handle_lethal_conflict(self, event: dict) -> None:
        import psychology as psychology_mod
        from death_ledger import build_death_record

        if event.get("outcome") != "homicide":
            return
        victim_id = (event.get("participants") or [None])[0]
        if not victim_id:
            return
        victim = next((a for a in self.agents if a.id == victim_id), None)
        if victim and victim.id not in self.death_logged:
            self.death_logged.add(victim.id)
            self.ledger.record(build_death_record(
                victim, self.agents, event.get("tick", self._tick),
                cause="homicide"))
            psychology_mod.notify_death_to_population(
                victim, self.agents, event.get("tick", self._tick))

    # ── Output helpers ────────────────────────────────────────────────────────

    def _flush_flat_files(self) -> None:
        """Write flat files compatible with resume script and tooling."""
        import dataclasses
        od = self._output_dir
        (od / "agents_final.json").write_text(
            json.dumps([a.snapshot() for a in self.agents], indent=2),
            encoding="utf-8")
        (od / "group_map.json").write_text(
            json.dumps(self.agent_group, indent=2), encoding="utf-8")
        (od / "deaths.json").write_text(
            json.dumps([
                dataclasses.asdict(d) if dataclasses.is_dataclass(d) else d
                for d in self.ledger.deaths
            ], indent=2), encoding="utf-8")

    def _write_outputs(self, final_tick: int) -> None:
        import dataclasses
        import continuity as continuity_mod
        od = self._output_dir
        self._flush_flat_files()
        (od / "metrics.json").write_text(
            json.dumps(self._metric_log, indent=2), encoding="utf-8")
        (od / "culture.json").write_text(
            json.dumps(self.culture_pool.snapshot(), indent=2), encoding="utf-8")
        (od / "factions.json").write_text(
            json.dumps([
                {"id": f.id, "name": f.name,
                 "members": list(getattr(f, "members", set())),
                 "hostility": getattr(f, "hostility", {})}
                for f in self.faction_registry.factions.values()
            ], indent=2), encoding="utf-8")
        (od / "innovation.json").write_text(
            json.dumps(self.innovation_engine.snapshot(), indent=2),
            encoding="utf-8")

        initial_ids = {a.id for a in self.agents if a.generation == 0}
        try:
            continuity_mod.build_continuity_outputs(
                od, self.agents, self.bus.event_log, initial_ids,
                self.culture_pool, self.faction_registry,
                self.generational_ledger)
        except Exception:
            pass

    def _print_snapshot(self, tick: int, phase_name: str) -> None:
        living = [a for a in self.agents if a.alive]
        top3   = sorted(living, key=lambda a: a.state.age, reverse=True)[:3]
        memes  = sorted(self.culture_pool.memes.values(),
                        key=lambda m: m.strength, reverse=True)[:4]
        meme_str = " | ".join(
            f"{m.label} ({'+' if m.valence>=0 else ''}{m.valence:.1f},{m.strength:.2f})"
            for m in memes)
        groups: Dict[str, int] = {}
        for a in living:
            g = self.agent_group.get(a.id, "?")
            groups[g] = groups.get(g, 0) + 1
        innov = self.innovation_engine.snapshot().get("summary", {})
        n_int = max(self._counters.interaction_total, 1)
        n_con = self._counters.conflict_total

        print(f"\n{'='*60}")
        print(f"  TICK {tick}  (session +{tick - self._session_start_tick})")
        print(f"{'='*60}")
        print(f"  Population  : {len(living)} alive / {len(self.agents)} total")
        print(f"  Max gen     : Gen{max((a.generation for a in self.agents), default=0)}")
        print(f"  Deaths      : {len(self.ledger.deaths)}")
        for g, n in sorted(groups.items()):
            print(f"  Group {g}     : {n} alive")
        print(f"  Conflict    : {n_con}/{n_int} ({100*n_con/n_int:.1f}%)")
        print(f"  Memes       : {len(self.culture_pool.memes)} active")
        if meme_str:
            print(f"  Top memes   : {meme_str}")
        print(f"  Innovation  : {innov.get('total_successes', 0)} successes, "
              f"registry={len(self.innovation_engine.practice_registry)}")
        for a in top3:
            tags = " ".join(a.experience.identity_tags[:3]) if hasattr(a, "experience") else ""
            g = self.agent_group.get(a.id, "?")
            print(f"  {a.name:<14} G{g} gen={a.generation:2d} age={a.state.age:5.0f} "
                  f"stress={a.state.stress:.2f} tags=[{tags}]")
