"""
artifact_metrics.py — behavioral aggregate metrics for failure-surface detection.

v4.56 adaptation notes:
  - sync_index: uses agent role (traits.role) as the action-type proxy, since
    DASAgent does not track last_action_type. Role is stable and meaningful.
  - frozen_ratio: uses _last_move_tick to detect spatial stagnation over 100
    ticks, as DASAgent has no ticks_since_state_change field.
  - meme_entropy: reads runtime.culture_pool._agent_memes + culture_pool.memes
    for label-level entropy across the live population.
  - crowding_index: uses agent.position.x/y (floats), discretised to int cell.

All methods are read-only. observe() must be called AFTER all step() phases.
"""

from __future__ import annotations

import math
from collections import Counter
from typing import Any, Dict, List


class ArtifactMetrics:
    def __init__(self) -> None:
        self.history: List[Dict[str, Any]] = []

    def observe(self, tick: int, runtime: Any) -> None:
        """Collect one snapshot. Called from the METRICS phase observer hook."""
        snapshot = {
            "tick": tick,
            "sync_index": self.sync_index(runtime),
            "frozen_ratio": self.frozen_ratio(runtime, tick),
            "meme_entropy": self.meme_entropy(runtime),
            "crowding_index": self.crowding_index(runtime),
        }
        self.history.append(snapshot)

    # ── Individual metrics ────────────────────────────────────────────────────

    def sync_index(self, runtime: Any) -> float:
        """
        Fraction of agents sharing the dominant role.
        Proxy for behavioural synchronisation (monoculture of action type).
        """
        roles = []
        for a in runtime.agents:
            if not getattr(a, "alive", False):
                continue
            traits = getattr(a, "traits", None)
            role = getattr(traits, "role", None) if traits else None
            if role is not None:
                roles.append(role)
        if not roles:
            return 0.0
        counts = Counter(roles)
        dominant = counts.most_common(1)[0][1]
        return dominant / len(roles)

    def frozen_ratio(self, runtime: Any, tick: int) -> float:
        """
        Fraction of agents that have not moved in the last 100 ticks.
        Uses _last_move_tick which movement_goals.py maintains.
        """
        frozen = 0
        total = 0
        for a in runtime.agents:
            if not getattr(a, "alive", False):
                continue
            total += 1
            last_move = getattr(a, "_last_move_tick", -999)
            if (tick - last_move) > 100:
                frozen += 1
        return frozen / max(1, total)

    def meme_entropy(self, runtime: Any) -> float:
        """
        Shannon entropy over meme labels held by the live population.
        Reads CulturePool._agent_memes without mutating it.
        """
        pool = getattr(runtime, "culture_pool", None)
        if pool is None:
            return 0.0

        agent_memes: dict = getattr(pool, "_agent_memes", {})
        meme_defs: dict = getattr(pool, "memes", {})

        live_ids = {
            getattr(a, "id", None)
            for a in runtime.agents
            if getattr(a, "alive", False)
        }

        labels: List[str] = []
        for aid, meme_ids in agent_memes.items():
            if aid not in live_ids:
                continue
            for mid in meme_ids:
                m = meme_defs.get(mid)
                label = getattr(m, "label", mid) if m else mid
                labels.append(label)

        if not labels:
            return 0.0

        counts = Counter(labels)
        total = sum(counts.values())
        entropy = 0.0
        for v in counts.values():
            p = v / total
            if p > 0:
                entropy -= p * math.log2(p)
        return entropy

    def crowding_index(self, runtime: Any) -> float:
        """
        Fraction of live agents occupying a grid cell with more than 3 agents.
        Uses agent.position.x/y, discretised to integer cells.
        """
        coords: Counter = Counter()
        total = 0
        for a in runtime.agents:
            if not getattr(a, "alive", False):
                continue
            pos = getattr(a, "position", None)
            if pos is None:
                continue
            cell = (int(getattr(pos, "x", 0)), int(getattr(pos, "y", 0)))
            coords[cell] += 1
            total += 1

        crowded = sum(v for v in coords.values() if v > 3)
        return crowded / max(1, total)
