# HRM Kernel Migration Audit — K2

## Status: K2-2 COMPLETE

---

## Script Migration Map

| Old Script | Status | Kernel Equivalent | Config |
|---|---|---|---|
| run_exp_A.py | LEGACY | run_kernel_exp_A.py | configs/exp_A.json |
| run_exp_B.py | LEGACY | run_kernel_exp_B.py | configs/exp_B.json |
| run_exp_C.py | LEGACY | run_kernel_exp_C.py | configs/exp_C.json |
| run_exp_C2.py | LEGACY → exp_C | run_kernel_exp_C.py | configs/exp_C.json |
| run_exp_D.py | LEGACY | run_kernel_exp_D.py | configs/exp_D.json |
| run_exp_E.py | LEGACY | run_kernel_exp_E.py | configs/exp_E.json |
| run_exp_E_1k.py | LEGACY | run_kernel_exp_E.py --ticks 1000 | configs/exp_E_1k.json |
| run_exp_E_resume.py | LEGACY | run_kernel_exp_E_resume.py | configs/exp_E.json |
| run_four_groups.py | LEGACY → exp_A | run_kernel_exp_A.py | configs/exp_A.json |
| run_single_band.py | LEGACY | run_kernel_single_band.py | configs/single_band.json |
| run_civilization.py | LEGACY | run_kernel_civilization.py | configs/civilization.json |
| run_sim.py | LEGACY — benchmark harness | NOT MIGRATED (see note) | — |

---

## Notes

### run_sim.py — NOT MIGRATED
`run_sim.py` is a multi-run benchmarking harness driven by env vars
(DAS_TICKS, DAS_RUNS, DAS_SCENARIO, DAS_RETENTION). It runs N independent
simulations, aggregates attractor metrics, and writes benchmark JSON.
It is not an experiment — it is a testing tool.
Migration path: replace with a kernel-aware benchmark runner in K2-3 or
wrap kernel.run() in a loop with its own metric aggregator.

### run_kernel_exp_E_resume.py — K2-PARTIAL
Resume requires loading agent state from checkpoint. The kernel owns the
tick loop from start_tick onward, but full agent state restoration
(beliefs, memory, relationships) is not yet kernel-native.
Full absorption deferred to K2-3: kernel checkpoint load/restore API.

### run_exp_C2.py — DEPRECATED
C2 is functionally identical to C. Maps to configs/exp_C.json.

### run_four_groups.py — DEPRECATED
Identical to exp_A (seed=17, no seed memes, simultaneous arrival).
Maps to configs/exp_A.json.

---

## What K2-2 Accomplished

- All experiments now have JSON configs (8 configs total)
- All experiments now have thin kernel wrappers (8 wrappers)
- Tick loop ownership: kernel only
- Death/birth routing: kernel only
- Checkpoint ownership: kernel only
- Old run scripts: still present as legacy reference, not the execution path

## Remaining for K2-3

1. Kernel checkpoint load/restore (enables true resume)
2. run_sim.py → kernel-aware benchmark harness
3. Formalize SYSTEM_PHASES constant in runtime.py
4. Add SubsystemSpec dependency declarations
5. Move observability hook (observe(tick, state)) into kernel METRICS phase

## After K2 Complete: SRK-2

Belief-mediated perception through kernel-managed hooks.
Requires observability to be kernel-native (K2-3 item 4 above).
