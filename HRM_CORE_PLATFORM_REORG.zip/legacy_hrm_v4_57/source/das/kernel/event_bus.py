"""
kernel/event_bus.py — Central event routing.

All systems emit events here. The bus handles:
- Serialization
- Salience scoring
- Writing to stream
- Writing to persistence ledger
- Feeding the rolling counters
- Death/birth routing

This is the single place where "something happened" becomes
"logged, counted, streamed, and available to other systems."
No more per-script event wiring.
"""

from __future__ import annotations
from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING


def _serialize(ev: Any) -> dict:
    if isinstance(ev, dict):
        return ev
    if hasattr(ev, "__dict__"):
        d = ev.__dict__.copy()
        d["phase"] = getattr(ev, "phase", getattr(ev, "phase_name", ""))
        for k, v in list(d.items()):
            if hasattr(v, "__dict__"):
                d[k] = v.__dict__
        return d
    return dict(ev)


class EventBus:
    """
    Routes events from systems to persistence, stream, counters, and
    any registered listeners.

    Systems call bus.emit(event) instead of manually writing to
    event_log, _stream, _counters, and persistence_ledger.
    """

    def __init__(
        self,
        stream=None,
        persistence_ledger=None,
        counters=None,
        salience_scorer: Optional[Callable] = None,
    ):
        self._stream = stream
        self._persistence = persistence_ledger
        self._counters = counters
        self._salience = salience_scorer
        self._event_log: List[dict] = []
        self._listeners: Dict[str, List[Callable]] = {}  # event_type -> [fn]

    # ── Core emit ─────────────────────────────────────────────────────────────

    def emit(self, event: Any, salience: Optional[float] = None) -> dict:
        """
        Serialize, score, route, and log one event.
        Returns the serialized dict.
        """
        d = _serialize(event)

        if salience is not None:
            d["salience"] = salience
        elif self._salience is not None:
            d["salience"] = self._salience(d)
        else:
            d.setdefault("salience", 0.5)

        if self._persistence is not None:
            self._persistence.record_event(d)
        if self._counters is not None:
            self._counters.record(d)
        if self._stream is not None:
            self._stream.write(d)

        self._event_log.append(d)
        self._route_listeners(d)
        return d

    def emit_many(self, events, salience: Optional[float] = None) -> List[dict]:
        return [self.emit(ev, salience) for ev in events]

    # ── Listener registration ─────────────────────────────────────────────────

    def on(self, event_type: str, fn: Callable) -> None:
        """Register a listener for a specific event_type."""
        self._listeners.setdefault(event_type, []).append(fn)

    def _route_listeners(self, d: dict) -> None:
        et = d.get("event_type", "")
        for fn in self._listeners.get(et, []):
            try:
                fn(d)
            except Exception:
                pass
        for fn in self._listeners.get("*", []):
            try:
                fn(d)
            except Exception:
                pass

    # ── Convenience access ────────────────────────────────────────────────────

    @property
    def event_log(self) -> List[dict]:
        return self._event_log

    def events_this_tick(self, tick: int) -> List[dict]:
        return [e for e in self._event_log[-2000:] if e.get("tick") == tick]

    def cooperation_events_this_tick(self, tick: int) -> List[dict]:
        return [
            e for e in self.events_this_tick(tick)
            if e.get("event_type") == "interaction"
            and e.get("outcome") == "cooperation"
        ]
