"""
kernel/subsystem_examples.py — Reference migrations to the contract layer.

This file is NOT imported by the kernel.  It exists to demonstrate correct
migration patterns for existing HRM subsystems.

EXAMPLE 1 — CognitionObserver
  The simplest migration: a pure observe() subsystem with no step() mutation
  and no persistent state.  Already uses observe_fn in experiment_setup.py.

EXAMPLE 2 — ArtifactMetrics (v4.56)
  A metrics subsystem with history that feeds FailureSurface.
  Demonstrates persist()/restore() for metrics history replay.

EXAMPLE 3 — GovernanceSubsystem (sketch)
  The most complex migration target: step() + persist()/restore() for the
  leadership registry.

All examples pass the syntax check.  Full migration requires wiring into
experiment_setup.py in place of the existing lambda registrations.
"""

from __future__ import annotations
from typing import Any, Dict

from .subsystem import Subsystem, MutationGuard


# ─────────────────────────────────────────────────────────────────────────────
# EXAMPLE 1 — CognitionObserver as a Subsystem
# ─────────────────────────────────────────────────────────────────────────────

class CognitionObserverSubsystem(Subsystem):
    """
    Migration of cognition_observer.py to the contract layer.

    No step() mutation.  Pure observe() subsystem.
    No persistent state (observations are already written to JSONL on disk).
    enabled_flag gates the whole subsystem via KernelConfig.

    Before (experiment_setup.py):
        rt.registry.register_spec(SubsystemSpec(
            name="cognition_observer", phase="METRICS", fn=_noop_step,
            observe_fn=cognition_observer.observe,
            depends_on=("viability",),
        ))

    After:
        CognitionObserverSubsystem().register(rt)
    """

    name         = "cognition_observer"
    phase        = "METRICS"
    depends_on   = ("viability",)
    enabled_flag = "cognition_observer_enabled"

    def __init__(self):
        super().__init__()
        self._observer = None

    def init(self, runtime: Any) -> None:
        from cognition_observer import CognitionObserver
        self._observer = CognitionObserver.from_runtime(runtime)

    def step(self, tick: int, runtime: Any) -> None:
        # CognitionObserver is intentionally read-only.
        # step() is a no-op; all work happens in observe().
        pass

    def observe(self, tick: int, runtime: Any) -> None:
        if self._observer is not None:
            self._observer.observe(tick, runtime)

    def validate(self) -> None:
        # Nothing to validate before runtime exists.
        pass


# ─────────────────────────────────────────────────────────────────────────────
# EXAMPLE 2 — ArtifactMetrics as a Subsystem
# ─────────────────────────────────────────────────────────────────────────────

class ArtifactMetricsSubsystem(Subsystem):
    """
    Migration of v4.56 ArtifactMetrics to the contract layer.

    observe() populates history.  persist()/restore() enable metrics replay
    without re-running the simulation.

    Before (runtime.py inline call):
        if self.artifact_metrics is not None:
            self.artifact_metrics.observe(tick, self)

    After (experiment_setup.py):
        ams = ArtifactMetricsSubsystem()
        ams.register(rt)
        rt.artifact_metrics = ams._metrics   # expose on runtime for FailureSurface
    """

    name       = "artifact_metrics"
    phase      = "METRICS"
    depends_on = ("cognition_observer",)

    def __init__(self):
        super().__init__()
        self._metrics = None

    def init(self, runtime: Any) -> None:
        from .metrics import ArtifactMetrics
        self._metrics = ArtifactMetrics()
        # Expose on runtime so FailureSurface and ValidationHarness can read it.
        runtime.artifact_metrics = self._metrics

    def step(self, tick: int, runtime: Any) -> None:
        # Metrics collection is read-only; all work in observe().
        pass

    def observe(self, tick: int, runtime: Any) -> None:
        if self._metrics is not None:
            self._metrics.observe(tick, runtime)

    def persist(self) -> Dict[str, Any]:
        if self._metrics is None:
            return {}
        return {"history": self._metrics.history}

    def restore(self, state: Dict[str, Any]) -> None:
        if self._metrics is not None and "history" in state:
            self._metrics.history = state["history"]

    def validate(self) -> None:
        pass


# ─────────────────────────────────────────────────────────────────────────────
# EXAMPLE 3 — GovernanceSubsystem (sketch)
#
# The highest-value migration target: complex persist state, clear step/observe
# separation, and validate() can enforce leader threshold constraints.
# ─────────────────────────────────────────────────────────────────────────────

class GovernanceSubsystem(Subsystem):
    """
    Sketch migration of governance.py to the contract layer.

    persist()/restore() cover the leadership registry so that checkpoint
    resume preserves leader legitimacy scores and succession history.
    validate() enforces config self-consistency.

    Full implementation requires accessing runtime.governance_ledger in step().
    This sketch shows the structure; production migration fills in the calls.
    """

    name         = "governance"
    phase        = "GOVERNANCE"
    depends_on   = ("generational",)

    def step(self, tick: int, runtime: Any) -> None:
        import governance
        phase_name = runtime.env_cycle.get_phase(tick).name
        rng = runtime.global_rng
        governance.tick(
            runtime.agents, tick, phase_name,
            rng, runtime.governance_ledger,
            runtime.faction_registry,
            runtime.institution_registry,
        )

    def persist(self) -> Dict[str, Any]:
        # governance_ledger serialisation goes here.
        # Returns {} until GovernanceLedger exposes snapshot().
        return {}

    def restore(self, state: Dict[str, Any]) -> None:
        # governance_ledger restore goes here.
        pass

    def validate(self) -> None:
        # Example: verify threshold consistency.
        # Can only validate config values, not runtime state.
        pass
