"""
HRM Kernel — Phase K1

Minimal runtime extraction. No new simulation ideas.
Goal: one canonical tick loop, system registration, event routing, checkpointing.

Phase K1 exports:
    HRMRuntime       — owns tick loop, agent pool, world subsystems
    EventBus         — routes events from systems to persistence/log/stream
    SystemRegistry   — registers ordered systems, calls them per tick
    SystemPhase      — enum of tick phases
    KernelConfig     — typed config loaded from dict or JSON
    KernelCheckpoint — save/restore full run state
"""

from .config import KernelConfig, GroupConfig, make_exp_E_config
from .event_bus import EventBus
from .system_registry import SystemRegistry, SystemPhase
from .checkpoint import KernelCheckpoint
from .runtime import HRMRuntime
from .experiment_setup import (
    register_standard_subsystems,
    setup_groups,
    make_agent,
    seed_group_culture,
)

__all__ = [
    "HRMRuntime",
    "EventBus",
    "SystemRegistry",
    "SystemPhase",
    "KernelConfig",
    "GroupConfig",
    "KernelCheckpoint",
    "make_exp_E_config",
    "register_standard_subsystems",
    "setup_groups",
    "make_agent",
    "seed_group_culture",
]
