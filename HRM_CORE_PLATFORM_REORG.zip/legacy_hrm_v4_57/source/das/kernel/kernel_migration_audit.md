# HRM Kernel Migration Audit — v4.50

## Status: Phase K1 complete, K2 in progress

---

## What the kernel owns (as of K1)

| Concern | Kernel location | Status |
|---|---|---|
| Tick loop | kernel/runtime.py HRMRuntime.run() | ✅ Done |
| Agent tick ordering | runtime.py — safe_agent_tick per living agent | ✅ Done |
| Death routing (natural) | runtime.py — check_death() after agent ticks | ✅ Done |
| Death routing (homicide) | runtime.py — bus listener _handle_lethal_conflict | ✅ Done |
| Birth routing | runtime.py — birth hook + _init_child | ✅ Done |
| Aux event processing | runtime.py — iterated per agent, emitted to bus | ✅ Done |
| Event serialization | event_bus.py — bus.emit() | ✅ Done |
| Salience scoring | event_bus.py — salience_scorer passed at init | ✅ Done |
| Persistence ledger routing | event_bus.py | ✅ Done |
| Rolling counters | event_bus.py | ✅ Done |
| Event stream (jsonl) | event_bus.py | ✅ Done |
| Subsystem registration | system_registry.py | ✅ Done |
| Subsystem tick ordering | system_registry.py — deterministic by SystemPhase | ✅ Done |
| Checkpoint (full) | checkpoint.py — KernelCheckpoint.save() | ✅ Done |
| Checkpoint (manifest) | checkpoint.py — save_manifest() / load_manifest() | ✅ Done |
| Config typing | config.py — KernelConfig, GroupConfig | ✅ Done |
| World construction | runtime.py — build_world() | ✅ Done |
| Subsistence loop | runtime.py | ✅ Done |
| Resource transfer loop | runtime.py | ✅ Done |
| Reproduction (every 25 ticks) | runtime.py | ✅ Done |
| Metric collection (every 10 ticks) | runtime.py | ✅ Done |
| Flat file flush | runtime.py — _flush_flat_files() | ✅ Done |
| Continuity outputs | runtime.py — _write_outputs() | ✅ Done |
| Ctrl+C clean save | runtime.py — signal handler + finally block | ✅ Done |

---

## What still lives only in old run scripts (K2 targets)

### Duplicated runtime logic (identical in every script)

Every old run script owns:
- Its own tick loop (`for tick in range(1, TICKS+1)`)
- Its own death logic (`check_death`, `build_death_record`, `notify_death_to_population`)
- Its own homicide detection (`aux_ev.event_type == "lethal_conflict"`)
- Its own event routing (`EventStream`, `RollingCounters`, `persistence_ledger`)
- Its own subsystem calls (`apply_generational_tick`, `apply_governance_tick`, etc.)
- Its own checkpoint wiring (`CheckpointWriter`, `ckpt.should_write`)
- Its own flat file writes

**This is the exact duplication the kernel eliminates.**

### Experiment-specific logic (legitimate, belongs in configs/runners)

| Script | Unique config | Unique behavior |
|---|---|---|
| run_exp_A | seed=17, mixed memes (distrust intact) | Control condition |
| run_exp_B | seed=17, prosocial memes only | Meme substitution |
| run_exp_C | seed=17, prosocial + resource_transfer | Transfer enabled |
| run_exp_D | seed=17, full spatial agency | All spatial systems |
| run_exp_E | seed=23, staggered founding, group-specific memes | Current canonical |
| run_four_groups | seed=17, 4 simultaneous groups | No stagger |
| run_single_band | seed=42, 30 agents, 20×20 world | Small band |
| run_three_groups | seed=99, 3 groups of 10, 30×30 | Strangers |
| run_civilization | seed=13, 16-20 founders, 18×18 world | Long-run civilization |
| run_exp_E_resume | resume path | Handled by kernel checkpoint |

---

## K2 Migration Plan

### Step 1: Config files (configs/)
Create `das/configs/` with JSON for each experiment.
Each config captures ONLY what differs between experiments:
seed, world size, ticks, max_pop, groups, meme seeds, feature flags.

### Step 2: Thin runners
Each old `run_exp_X.py` becomes a ~30-line wrapper:
```python
from kernel import HRMRuntime, KernelConfig
cfg = KernelConfig.from_json("configs/exp_X.json")
rt = HRMRuntime(cfg)
rt.build_world()
register_subsystems(rt)   # shared function
setup_groups(rt, cfg)     # experiment-specific group setup
rt.run()
```

### Step 3: Shared setup module
`das/kernel/experiment_setup.py` — shared functions all runners use:
- `register_standard_subsystems(rt)` — the 9 subsystem registrations
- `make_agent(name, seed, ...)` — agent construction
- `seed_group_culture(agents, gcfg, culture_pool)` — meme seeding
- `setup_groups(rt, cfg)` — builds and registers all groups from config

### Step 4: Deprecate old scripts
Old scripts get a deprecation header:
```
# DEPRECATED: This script's runtime logic has been migrated to the kernel.
# Use: python run_kernel_exp_X.py
# This file is preserved for reference. Do not add new simulation logic here.
```

### Step 5: Compatibility test
`das/kernel/tests/test_kernel_parity.py`:
- Run run_exp_E.py and run_kernel_exp_E.py with same seed
- Compare: final population, death count, cause distribution,
  max generation, meme count, innovation registry size
- Assert within 10% on stochastic metrics (RNG paths diverge slightly
  due to ordering differences; exact parity requires identical RNG threading)

---

## Bugs fixed exactly once by the kernel (never again in 3 files)

| Bug | Old fix | Kernel fix |
|---|---|---|
| Homicide detection: wrong event_type field | Fixed in run_exp_E, run_exp_E_1k, run_exp_E_resume separately | Fixed once in runtime._handle_lethal_conflict |
| Death module not wired | Fixed in run_exp_E, run_exp_E_1k separately | Built into runtime.run() |
| build_death_record wrong arg order | Fixed in run_exp_E_resume | Canonical in runtime._record_death |
| notify_death_to_population missing tick arg | Fixed in 3 scripts | Canonical in runtime._record_death |
| cooperation_events not collected for innovation | Fixed per-script | bus.cooperation_events_this_tick(tick) |

---

## Kernel validation (1000-tick run_kernel_exp_E vs run_exp_E_1k)

| Metric | run_exp_E_1k | run_kernel_exp_E | Delta |
|---|---|---|---|
| Deaths | 49–58 | 33–57 | Within run-to-run variance |
| Homicide % | 70.7% | 71.9% | ✅ Consistent |
| Innovation successes | 588–965 | 416–990 | Within variance |
| Practice registry | 284–294 | 290–294 | ✅ Consistent |
| Max generation | Gen6–Gen7 | Gen5–Gen8 | ✅ Consistent |
| Conflict rate | 21–43% | 27–36% | Within SRK variance |
| Memes active | 7 | 7 | ✅ Match |

Stochastic variance is expected — agent interaction order varies slightly
due to `list(living)` ordering differences between script implementations.
True bit-identical parity would require identical RNG threading across all
subsystems, which is out of scope for K2.

---

## Files to create in K2

```
das/configs/
  exp_A.json
  exp_B.json
  exp_C.json
  exp_D.json
  exp_E.json
  exp_E_1k.json
  four_groups.json
  single_band.json
  three_groups.json
  civilization.json

das/kernel/
  experiment_setup.py   (shared runner utilities)
  tests/
    __init__.py
    test_kernel_parity.py

das/
  run_kernel_exp_A.py   (thin wrapper)
  run_kernel_exp_B.py
  run_kernel_exp_C.py
  run_kernel_exp_D.py
  run_kernel_exp_E.py   (already exists)
```

---

## What K2 does NOT change

- No simulation behavior changes
- No new systems
- SRK Phase 2 starts AFTER K2 is validated
- Old scripts preserved with deprecation headers, not deleted
  (deletion after SRK-2 proves kernel stability)
