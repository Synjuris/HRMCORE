# HRM Kernel Subsystem Contract  (v4.57)

## The problem this solves

Every subsystem in HRM currently invents its own shape:

- `governance.py` exposes `tick()` called via a lambda closure in `experiment_setup.py`
- `culture.py` exposes a `CulturePool` object with no standard lifecycle
- `checkpoint.py` persists each subsystem by name, hard-coded
- `cognition_observer.py` exposes `observe()` registered via `observe_fn`
- `artifact_metrics.py` (v4.56) exposes `observe()` called directly from `runtime.py`

As the system grows, implicit architecture becomes a compounding liability:
- Adding persistence to a new subsystem requires editing `checkpoint.py`
- Replay validation has no hook to validate subsystem state
- The mutation authority boundary between step and observe is convention, not structure

## The contract

```python
class Subsystem:
    name:         str           # unique, used in registry + checkpoint keys
    phase:        str           # from SYSTEM_PHASES
    every_n:      int = 1
    depends_on:   tuple = ()
    enabled_flag: str | None = None

    def init(self, runtime): ...      # once, after world is built
    def step(self, tick, runtime): ...  # SOLE mutation window — REQUIRED
    def observe(self, tick, runtime): ...  # read-only, post-step
    def persist(self) -> dict: ...    # for checkpoint
    def restore(self, state): ...     # from checkpoint
    def validate(self): ...           # at freeze() time
```

### Mutation authority rules

| Method     | May write state? | Called when                        |
|------------|------------------|------------------------------------|
| `init`     | Yes              | Once, during world construction    |
| `step`     | **Yes**          | Every N ticks during declared phase|
| `observe`  | **No**           | After all step() calls, METRICS    |
| `persist`  | No               | During checkpoint.save()           |
| `restore`  | Yes (load only)  | During checkpoint.restore()        |
| `validate` | No               | At registry freeze()               |

`observe`, `persist`, and `restore` may optionally use `MutationGuard` for
defensive enforcement during development.

## Registration

Old pattern (still supported):
```python
rt.registry.register_spec(SubsystemSpec(
    name="governance", phase="GOVERNANCE", fn=_governance_fn,
    depends_on=("generational",),
))
```

New pattern:
```python
class GovernanceSubsystem(Subsystem):
    name       = "governance"
    phase      = "GOVERNANCE"
    depends_on = ("generational",)

    def step(self, tick, runtime):
        governance.tick(runtime.agents, tick, runtime.env_cycle.get_phase(tick).name,
                        runtime.global_rng, runtime.governance_ledger, ...)

    def persist(self):
        return self._ledger.snapshot()

    def restore(self, state):
        self._ledger.load(state)

gov = GovernanceSubsystem()
gov.register(rt)   # calls init(), then registry.register_spec()
```

## Checkpoint integration

`checkpoint.py` gains two calls in `save()` and `restore()`:

```python
# In checkpoint.save():
from .subsystem import registry_collect_persist
subsystem_state = registry_collect_persist(runtime.registry)
cp["subsystems"] = subsystem_state

# In checkpoint.restore():
from .subsystem import registry_dispatch_restore
registry_dispatch_restore(runtime.registry, cp.get("subsystems", {}))
```

Subsystems that don't implement `persist()` return `{}` and are skipped.
Existing hand-coded save/restore blocks in checkpoint.py remain valid —
migration is incremental.

## Migration order (recommended)

Priority is subsystems with the most persistence complexity:

1. `CognitionObserver` — already uses `observe_fn`; trivial migration
2. `ArtifactMetrics` (v4.56) — already structured as a class
3. `GovernanceSubsystem` — complex persist state (leadership registry)
4. `InnovationSubsystem` — large practice registry
5. `CultureSubsystem` — meme pool state
6. Remaining subsystems in `experiment_setup.py`

## What does NOT change

- `SystemRegistry`, `SubsystemSpec`, `SYSTEM_PHASES` — unchanged
- All lambda-based registrations in `experiment_setup.py` — still valid
- `checkpoint.py` hard-coded blocks — remain until subsystem migrates
- Phase execution order — unchanged

## Replay validation (future)

Once all subsystems implement `validate()`, the harness can:

1. Run simulation to tick N → checkpoint
2. Restore checkpoint into fresh runtime
3. Run from tick N → tick N+K
4. Compare state hash against original run at tick N+K

This is only possible when every subsystem can declare its own validity
constraints at restore time.
