"""
biology.py — DAS v04.26a biological substrate layer.

Adds sex, physical attractiveness, sexual orientation, libido, and
sex-differentiated trait distributions. None of this is narrative.
These are asymmetric biological pressures that produce differentiated
behavioral and social outcomes without scripting any of them.

Sex: male / female, assigned at birth 50/50, partially heritable.
Physical attractiveness: continuous [0,1], random with partial heritability.
Sexual orientation: continuous [0,1], 0=exclusively opposite-sex attracted,
    1=exclusively same-sex attracted, 0.5=bisexual. Normally distributed
    around 0.12 with long tail. Not environmentally responsive. Just is.
Libido: continuous [0,1] state variable. Fluctuates with age, energy,
    stress, pair bond status, and recent reproduction.

Key asymmetries (not better/worse, different):
    Males:   higher base dominance, higher risk_tolerance, higher conflict
             effectiveness, lower resilience, shorter peak window, stronger
             physical attractiveness weight in mate selection, higher libido
             variance, sexual competition conflict source.
    Females: higher base resilience, higher stress_limit (pain threshold),
             higher linguistic_complexity growth rate, higher attachment_rate,
             higher social_openness, longer effective contribution arc,
             security/resource-weighted mate selection, reproductive cost
             (gestation drain, caretaker burden weighting).

Homosexual and bisexual agents emerge from orientation distribution.
Same-sex pairs: no reproductive output, freed from reproductive cost
    overhead, deeper specialization and knowledge transfer capacity.
Social response to same-sex pairs is governed by faction ideology_alignment
    and cultural memes — not by a rule.
"""
from __future__ import annotations

import random
import math
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(x)))


# ── Constants ─────────────────────────────────────────────────────────────────

# Orientation distribution: beta-ish via normal truncated
ORIENTATION_MEAN = 0.12       # population skews toward heterosexual
ORIENTATION_STD  = 0.18       # long tail toward bisexual and homosexual
ORIENTATION_HOMOSEXUAL_THRESHOLD = 0.65   # above this: primarily same-sex attracted

# Attractiveness: uniform with slight normal skew
ATTRACTIVENESS_MEAN = 0.50
ATTRACTIVENESS_STD  = 0.22

# Libido age curve peaks
MALE_LIBIDO_PEAK_AGE   = 180   # ticks
FEMALE_LIBIDO_PEAK_AGE = 260
LIBIDO_ELDER_FLOOR     = 0.08

# Sex-differentiated trait biases (applied at init as additive offsets)
MALE_TRAIT_BIAS = {
    "dominance":        +0.08,
    "risk_tolerance":   +0.06,
    "resilience":       -0.05,
    "attachment_rate":  -0.02,
    "social_openness":  -0.04,
    "linguistic_complexity_growth": -0.15,   # multiplier on LANG_GROW_RATE
}
FEMALE_TRAIT_BIAS = {
    "dominance":        -0.06,
    "risk_tolerance":   -0.04,
    "resilience":       +0.06,
    "stress_limit":     +0.08,   # higher pain threshold
    "attachment_rate":  +0.03,
    "social_openness":  +0.05,
    "linguistic_complexity_growth": +0.20,
}

# Cooperation pull modifiers from sexual attraction
ATTRACTION_COOP_BONUS_MAX   = 0.18   # max cooperation pull bonus from attraction
LIBIDO_COOP_BONUS_MAX       = 0.12   # additional bonus from own high libido
MALE_COMPETITION_CONFLICT   = 0.14   # conflict pull added between competing males

# Reproductive cost modifiers
FEMALE_GESTATION_ENERGY_DRAIN = 0.004   # per tick during dependency period
FEMALE_GESTATION_MOBILITY_REDUCTION = 0.20
MALE_REPRODUCTION_ENERGY_EXTRA = 0.05   # on top of base reproduction cost

# Pair bond libido suppression toward others
PAIR_BOND_LIBIDO_SUPPRESSION = 0.55
INFIDELITY_DOMINANCE_THRESHOLD = 0.55
INFIDELITY_RISK_TOLERANCE_THRESHOLD = 0.50

# Same-sex pair specialization bonus
SAME_SEX_PAIR_SPECIALIZATION_BONUS = 0.0006   # per tick freed from caretaker burden


# ── Config ────────────────────────────────────────────────────────────────────

@dataclass
class BiologyConfig:
    orientation_mean: float = ORIENTATION_MEAN
    orientation_std: float  = ORIENTATION_STD
    attractiveness_mean: float = ATTRACTIVENESS_MEAN
    attractiveness_std: float  = ATTRACTIVENESS_STD
    libido_base: float = 0.35
    libido_energy_floor: float = 0.10      # below this energy → libido suppressed
    libido_stress_ceiling: float = 0.88    # above this stress → libido suppressed
    libido_recovery_rate: float = 0.004    # per tick recovery
    libido_post_repro_drop: float = 0.45   # libido drop after reproduction
    mate_pref_weight_male: float = 0.55    # how much attractiveness weights for males
    mate_pref_weight_female: float = 0.20  # females weight attractiveness less
    resource_status_weight_female: float = 0.45  # females weight resource/status more
    sexual_competition_radius: int = 3     # cells within which male competition fires


DEFAULT_CONFIG = BiologyConfig()


# ── Agent-level init ──────────────────────────────────────────────────────────

def assign_sex(rng: random.Random) -> str:
    return "male" if rng.random() < 0.50 else "female"


def assign_orientation(rng: random.Random) -> float:
    """
    Orientation scalar [0,1]. 0 = exclusively opposite-sex attracted,
    1 = exclusively same-sex attracted, 0.5 = bisexual.
    Normal distribution truncated to [0,1], mean ~0.12.
    """
    raw = rng.gauss(ORIENTATION_MEAN, ORIENTATION_STD)
    return clamp(raw)


def assign_attractiveness(rng: random.Random) -> float:
    raw = rng.gauss(ATTRACTIVENESS_MEAN, ATTRACTIVENESS_STD)
    return clamp(raw)


def init_agent(agent: Any, rng: Optional[random.Random] = None,
               cfg: BiologyConfig = DEFAULT_CONFIG) -> None:
    """
    Attach biological fields to an agent. Idempotent.
    If called at birth, applies sex-differentiated trait biases.
    """
    if rng is None:
        rng = agent.rng

    if not hasattr(agent, "biological_sex"):
        agent.biological_sex = assign_sex(rng)

    if not hasattr(agent, "sexual_orientation"):
        agent.sexual_orientation = assign_orientation(rng)

    if not hasattr(agent, "physical_attractiveness"):
        agent.physical_attractiveness = assign_attractiveness(rng)

    if not hasattr(agent, "libido"):
        agent.libido = clamp(rng.gauss(cfg.libido_base, 0.10))

    if not hasattr(agent, "gestation_ticks_remaining"):
        agent.gestation_ticks_remaining = 0

    if not hasattr(agent, "post_repro_recovery"):
        agent.post_repro_recovery = 0   # ticks remaining in post-reproduction recovery

    if not hasattr(agent, "_sex_biases_applied"):
        _apply_sex_biases(agent, cfg)
        agent._sex_biases_applied = True


def _apply_sex_biases(agent: Any, cfg: BiologyConfig) -> None:
    """Apply sex-differentiated trait and state offsets. Called once at init."""
    bias = MALE_TRAIT_BIAS if agent.biological_sex == "male" else FEMALE_TRAIT_BIAS
    t = agent.traits
    s = agent.state

    if "dominance" in bias:
        s.dominance = clamp(s.dominance + bias["dominance"])
    if "risk_tolerance" in bias:
        t.risk_tolerance = clamp(t.risk_tolerance + bias["risk_tolerance"])
    if "resilience" in bias:
        t.resilience = clamp(t.resilience + bias["resilience"])
    if "stress_limit" in bias:
        t.stress_limit = clamp(t.stress_limit + bias["stress_limit"], 0.5, 1.0)
    if "attachment_rate" in bias:
        t.attachment_rate = clamp(t.attachment_rate + bias["attachment_rate"], 0.01, 0.15)
    if "social_openness" in bias:
        s.social_openness = clamp(s.social_openness + bias["social_openness"])


# ── Libido dynamics ───────────────────────────────────────────────────────────

def _age_libido_curve(age: int, sex: str) -> float:
    """Age-dependent libido multiplier. Male peaks earlier, female later/longer."""
    if sex == "male":
        peak = MALE_LIBIDO_PEAK_AGE
        rise = 120
        fall = 400
    else:
        peak = FEMALE_LIBIDO_PEAK_AGE
        rise = 150
        fall = 550

    if age < rise:
        return clamp(age / rise * 0.8)
    elif age < peak:
        return clamp(0.8 + (age - rise) / max(1, peak - rise) * 0.2)
    elif age < fall:
        return 1.0
    else:
        # Elder decline
        elapsed = age - fall
        decay = elapsed / 300.0
        return clamp(1.0 - decay, lo=LIBIDO_ELDER_FLOOR)


def update_libido(agent: Any, cfg: BiologyConfig = DEFAULT_CONFIG) -> None:
    """Called each tick to update agent's libido state."""
    age = getattr(agent.state, "age", 0)
    sex = getattr(agent, "biological_sex", "male")

    age_mult = _age_libido_curve(age, sex)

    # Energy suppression
    energy_factor = clamp((agent.state.energy - cfg.libido_energy_floor)
                          / (1.0 - cfg.libido_energy_floor))
    # Stress suppression
    stress_factor = clamp(1.0 - max(0.0,
        (agent.state.stress - cfg.libido_stress_ceiling)
        / (1.0 - cfg.libido_stress_ceiling)))
    # Pair bond: partial suppression toward non-bonded agents
    pair_bond_strength = getattr(agent.state, "pair_bond_strength", 0.0)

    target_libido = (cfg.libido_base
                     * age_mult
                     * energy_factor
                     * stress_factor
                     * (1.0 - pair_bond_strength * 0.30))

    # v04.38: prevent healthy, mature surviving adults from reporting
    # permanent 0.000 libido. This is a viability floor, not a birth override.
    # It keeps reproductive psychology observable while stress/energy/age still
    # shape the actual value.
    if age >= 120 and agent.state.stress < 0.92:
        # Even depleted adults retain a low observable reproductive drive;
        # energy/stress still gate actual reproduction in ReproductionSystem.
        floor = 0.035 + 0.08 * energy_factor + 0.07 * stress_factor
        target_libido = max(target_libido, floor)

    # Post-reproduction suppression
    if agent.post_repro_recovery > 0:
        target_libido *= 0.20
        agent.post_repro_recovery = max(0, agent.post_repro_recovery - 1)

    # Gestation suppression for females
    if sex == "female" and agent.gestation_ticks_remaining > 0:
        target_libido *= 0.25
        # Gestation energy drain
        agent.state.energy = clamp(agent.state.energy - FEMALE_GESTATION_ENERGY_DRAIN)
        agent.gestation_ticks_remaining = max(0, agent.gestation_ticks_remaining - 1)

    # Drift toward target
    agent.libido = clamp(agent.libido + (target_libido - agent.libido) * 0.10)
    if age >= 120 and agent.state.stress < 0.92:
        agent.libido = max(agent.libido, min(0.18, target_libido * 0.55))


# ── Attraction computation ────────────────────────────────────────────────────

def attraction_score(agent: Any, target: Any,
                     cfg: BiologyConfig = DEFAULT_CONFIG) -> float:
    """
    How much sexual/romantic attraction agent feels toward target.
    Returns [0,1]. Zero if orientation makes target non-viable.
    Does not include relationship history — purely biological pull.
    """
    agent_sex = getattr(agent, "biological_sex", "male")
    target_sex = getattr(target, "biological_sex", "female")
    orientation = getattr(agent, "sexual_orientation", 0.0)

    same_sex = (agent_sex == target_sex)

    # Orientation gate
    if same_sex:
        orientation_weight = orientation  # 0=no same-sex attraction, 1=full
    else:
        orientation_weight = 1.0 - orientation  # 0=no opposite-sex, 1=full

    if orientation_weight < 0.05:
        return 0.0

    target_attractiveness = getattr(target, "physical_attractiveness", 0.5)
    agent_libido = getattr(agent, "libido", 0.3)

    # Sex-differentiated weighting
    if agent_sex == "male" and not same_sex:
        # Males weight physical attractiveness heavily
        attract_base = (target_attractiveness * cfg.mate_pref_weight_male
                        + 0.20)   # baseline
    elif agent_sex == "female" and not same_sex:
        # Females weight resource/status signals more
        resource_signal = clamp(target.state.resource_stock * 0.4
                                + target.state.specialization_depth * 0.35
                                + target.state.dominance * 0.25)
        attract_base = (target_attractiveness * cfg.mate_pref_weight_female
                        + resource_signal * cfg.resource_status_weight_female)
    else:
        # Same-sex: split evenly
        attract_base = (target_attractiveness * 0.38 + 0.20)

    return clamp(attract_base * orientation_weight * (0.5 + agent_libido * 0.5))


def cooperation_pull_from_attraction(agent: Any, target: Any,
                                      cfg: BiologyConfig = DEFAULT_CONFIG) -> float:
    """
    Bonus to cooperation pull derived from sexual attraction.
    Applied in agent.interact() alongside other pull components.
    """
    attr = attraction_score(agent, target, cfg)
    if attr < 0.05:
        return 0.0
    agent_libido = getattr(agent, "libido", 0.3)
    bonus = attr * ATTRACTION_COOP_BONUS_MAX + agent_libido * LIBIDO_COOP_BONUS_MAX * attr
    # Suppress if pair-bonded and target is not the pair bond partner
    pair_bond_strength = getattr(agent.state, "pair_bond_strength", 0.0)
    if pair_bond_strength > 0.5:
        # Check if target is the pair bond partner
        pair_partner_id = getattr(agent, "_pair_bond_partner_id", None)
        if pair_partner_id and pair_partner_id != target.id:
            bonus *= (1.0 - pair_bond_strength * PAIR_BOND_LIBIDO_SUPPRESSION)
    return clamp(bonus)


def male_competition_conflict_pressure(agent: Any, target: Any,
                                        agents: List[Any],
                                        cfg: BiologyConfig = DEFAULT_CONFIG) -> float:
    """
    Additional conflict pull between two male agents competing for the
    same female target. Called when agent and target are both male and
    a high-attractiveness female is nearby.
    Only fires if both males have meaningful attraction toward her.
    """
    if getattr(agent, "biological_sex", "male") != "male":
        return 0.0
    if getattr(target, "biological_sex", "male") != "male":
        return 0.0

    agent_libido = getattr(agent, "libido", 0.3)
    if agent_libido < 0.25:
        return 0.0

    # Find nearby high-attractiveness females both are attracted to
    for other in agents:
        if not getattr(other, "alive", False):
            continue
        if getattr(other, "biological_sex", "male") != "female":
            continue
        dist_a = ((agent.position.x - other.position.x) ** 2
                  + (agent.position.y - other.position.y) ** 2) ** 0.5
        dist_b = ((target.position.x - other.position.x) ** 2
                  + (target.position.y - other.position.y) ** 2) ** 0.5
        if dist_a > cfg.sexual_competition_radius or dist_b > cfg.sexual_competition_radius:
            continue
        attr_a = attraction_score(agent, other, cfg)
        attr_b = attraction_score(target, other, cfg)
        if attr_a > 0.30 and attr_b > 0.30:
            # Both males attracted to the same female — competition pressure
            competition = (attr_a + attr_b) / 2.0 * MALE_COMPETITION_CONFLICT
            return clamp(competition * agent_libido)
    return 0.0


# ── Infidelity check ──────────────────────────────────────────────────────────

def check_infidelity_attempt(agent: Any, target: Any,
                              rng: random.Random,
                              cfg: BiologyConfig = DEFAULT_CONFIG) -> bool:
    """
    Returns True if agent attempts to pursue target despite being pair-bonded.
    Gated on high dominance + risk_tolerance + libido.
    Modeled as a deception precondition — caller should trigger deception if True.
    """
    pair_bond_strength = getattr(agent.state, "pair_bond_strength", 0.0)
    if pair_bond_strength < 0.40:
        return False  # not strongly bonded, no infidelity dynamic
    if getattr(agent, "biological_sex", "male") != "male":
        # Female infidelity: gated on pair bond quality (low = seeking better)
        rel = agent.relationships.snapshot().get(
            getattr(agent, "_pair_bond_partner_id", ""), {})
        partner_trust = rel.get("trust", 0.8)
        if partner_trust > 0.55:
            return False  # satisfied pair bond
        # Low-quality bond: seek better partner
        resource_signal = clamp(target.state.resource_stock * 0.4
                                + target.state.specialization_depth * 0.35
                                + target.state.dominance * 0.25)
        return (resource_signal > 0.55
                and attraction_score(agent, target, cfg) > 0.35
                and rng.random() < 0.04)

    # Male infidelity: dominance + risk_tolerance + libido gated
    if (agent.state.dominance < INFIDELITY_DOMINANCE_THRESHOLD
            or agent.traits.risk_tolerance < INFIDELITY_RISK_TOLERANCE_THRESHOLD):
        return False
    libido = getattr(agent, "libido", 0.3)
    attr = attraction_score(agent, target, cfg)
    return (libido > 0.35
            and attr > 0.25
            and rng.random() < libido * attr * 0.15)


# ── Same-sex pair specialization bonus ───────────────────────────────────────

def apply_same_sex_pair_bonus(agent: Any, agents: List[Any]) -> None:
    """
    Same-sex pair bonded agents freed from reproductive overhead get a small
    per-tick specialization depth bonus. Called from apply_tick in run_sim.
    """
    if getattr(agent.state, "pair_bond_strength", 0.0) < 0.50:
        return
    partner_id = getattr(agent, "_pair_bond_partner_id", None)
    if not partner_id:
        return
    partner = next((a for a in agents if a.id == partner_id
                    and getattr(a, "alive", False)), None)
    if partner is None:
        return
    if getattr(agent, "biological_sex", "male") == getattr(partner, "biological_sex", "female"):
        # Same sex pair — apply specialization bonus
        agent.state.specialization_depth = clamp(
            agent.state.specialization_depth + SAME_SEX_PAIR_SPECIALIZATION_BONUS
        )


# ── Reproduction integration ──────────────────────────────────────────────────

def is_reproduction_viable(agent: Any, partner: Any,
                             cfg: BiologyConfig = DEFAULT_CONFIG) -> bool:
    """
    Can these two agents reproduce biologically?
    Requires opposite sex OR same-sex with external reproduction flag (future).
    Currently: biological reproduction requires male + female.
    Same-sex pairs form and bond but don't produce offspring directly.
    """
    agent_sex = getattr(agent, "biological_sex", "male")
    partner_sex = getattr(partner, "biological_sex", "female")
    return agent_sex != partner_sex


def on_reproduction(parent: Any, partner: Any, child: Any,
                     rng: random.Random,
                     cfg: BiologyConfig = DEFAULT_CONFIG) -> None:
    """
    Called after a reproduction event. Applies asymmetric costs and
    initializes child's biological traits.
    """
    # Identify which parent is female
    female_parent = parent if getattr(parent, "biological_sex", "male") == "female" else partner
    male_parent   = parent if getattr(parent, "biological_sex", "male") == "male"   else partner

    # Female gestation burden
    init_agent(female_parent, rng, cfg)
    female_parent.gestation_ticks_remaining = 90   # child dependency period
    female_parent.post_repro_recovery = 40
    female_parent.libido = clamp(female_parent.libido - cfg.libido_post_repro_drop)

    # Male cost (smaller)
    init_agent(male_parent, rng, cfg)
    male_parent.state.energy = clamp(male_parent.state.energy - MALE_REPRODUCTION_ENERGY_EXTRA)
    male_parent.post_repro_recovery = 10

    # Child biological inheritance
    init_agent(child, rng, cfg)

    # Sex: random 50/50 regardless of parents
    child.biological_sex = assign_sex(rng)

    # Orientation: heritable with strong mutation noise
    parent_orient = (getattr(female_parent, "sexual_orientation", ORIENTATION_MEAN)
                     + getattr(male_parent, "sexual_orientation", ORIENTATION_MEAN)) / 2.0
    noise = rng.gauss(0, 0.12)
    child.sexual_orientation = clamp(parent_orient * 0.3 + ORIENTATION_MEAN * 0.7 + noise)

    # Attractiveness: heritable with noise
    parent_attr = (getattr(female_parent, "physical_attractiveness", 0.5)
                   + getattr(male_parent, "physical_attractiveness", 0.5)) / 2.0
    child.physical_attractiveness = clamp(parent_attr * 0.5 + rng.gauss(0.5, 0.15) * 0.5)

    # Re-apply sex biases for child's sex
    child._sex_biases_applied = False
    _apply_sex_biases(child, cfg)
    child._sex_biases_applied = True

    # Set pair bond partner tracking
    if not hasattr(female_parent, "_pair_bond_partner_id"):
        female_parent._pair_bond_partner_id = male_parent.id
    if not hasattr(male_parent, "_pair_bond_partner_id"):
        male_parent._pair_bond_partner_id = female_parent.id


# ── Pair bond partner tracking ────────────────────────────────────────────────

def update_pair_bond_partner(agent: Any, ledger_events: List[Any]) -> None:
    """
    Sync _pair_bond_partner_id from generational pair bond events.
    Called after generational tick.
    """
    for ev in ledger_events:
        agents_in_bond = ev.get("agents", [])
        if agent.id in agents_in_bond:
            other_ids = [a for a in agents_in_bond if a != agent.id]
            if other_ids:
                agent._pair_bond_partner_id = other_ids[0]
                break


# ── Benchmark metrics ─────────────────────────────────────────────────────────

def benchmark_metrics(agents: List[Any]) -> Dict[str, Any]:
    living = [a for a in agents if getattr(a, "alive", False)]
    if not living:
        return {
            "biology_male_count": 0, "biology_female_count": 0,
            "biology_avg_libido": 0.0, "biology_avg_attractiveness": 0.0,
            "biology_homosexual_agents": 0, "biology_bisexual_agents": 0,
            "biology_avg_orientation": 0.0,
        }

    males   = [a for a in living if getattr(a, "biological_sex", "male") == "male"]
    females = [a for a in living if getattr(a, "biological_sex", "male") == "female"]

    orientations = [getattr(a, "sexual_orientation", 0.0) for a in living]
    homosexual   = sum(1 for o in orientations if o >= ORIENTATION_HOMOSEXUAL_THRESHOLD)
    bisexual     = sum(1 for o in orientations if 0.35 <= o < ORIENTATION_HOMOSEXUAL_THRESHOLD)

    avg_libido = sum(getattr(a, "libido", 0.0) for a in living) / len(living)
    avg_attr   = sum(getattr(a, "physical_attractiveness", 0.5) for a in living) / len(living)
    avg_orient = sum(orientations) / len(orientations)

    return {
        "biology_male_count": len(males),
        "biology_female_count": len(females),
        "biology_avg_libido": round(avg_libido, 4),
        "biology_avg_attractiveness": round(avg_attr, 4),
        "biology_homosexual_agents": homosexual,
        "biology_bisexual_agents": bisexual,
        "biology_avg_orientation": round(avg_orient, 4),
        "biology_gestation_active": sum(
            1 for a in living if getattr(a, "gestation_ticks_remaining", 0) > 0),
    }
