"""
governance.py — DAS v04.24 governance and legitimacy layer.

Who coordinates others, why agents comply, and what happens when authority fails.

Not politics as ideology. The substrate question is simpler:
- Which agent can issue coordination signals that others follow?
- Why do they follow? (track record, trust, survival outcomes)
- What does following cost the leader? (burden, energy, visibility)
- What happens when they stop following? (governance gap, institutional decay)

Core mechanics:
    LeadershipRegistry  — tracks one leader per faction, legitimacy score, burden
    CoordinationSignal  — what a leader asks of followers this tick
    compliance()        — whether an agent follows a signal
    enforcement()       — leader punishes non-compliance
    succession()        — leader replaced on death or legitimacy collapse
    governance_gap      — state when no leader clears legitimacy threshold

Institutional connection:
    InstitutionRegistry.inst_conflict_suppression() is multiplied by the
    backing leader's legitimacy_score. Institutions without a legitimate leader
    become advisory only — their strength decays faster.

Geographic scope:
    Leaders coordinate agents within coordination_radius. Long-distance signals
    cost extra legitimacy per tick. Large territories are expensive to govern.

No scripted outcomes. This is pressure and constraint, not narrative.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from adaptive_roles import role_family
from typing import Any, Dict, List, Optional, Tuple


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(x)))


# ── Config ────────────────────────────────────────────────────────────────────

@dataclass
class GovernanceConfig:
    # Leader emergence
    leader_score_floor: float = 0.35       # min emergence_score to lead
    challenge_gap: float = 0.12            # challenger must exceed leader by this
    leader_eval_interval: int = 20         # ticks between leadership evaluations

    # Legitimacy dynamics
    legitimacy_passive_decay: float = 0.002   # per tick
    legitimacy_compliance_gain: float = 0.006 # per compliant follower per tick
    legitimacy_defiance_loss: float = 0.018   # per defiant follower per tick
    legitimacy_enforcement_success: float = 0.010  # when punishment restores compliance
    legitimacy_enforcement_failure: float = 0.025  # when punishment fails/resisted
    legitimacy_survival_bonus: float = 0.004  # per tick followers survive above avg
    legitimacy_collapse_threshold: float = 0.18

    # Burden
    burden_base: float = 0.003             # energy/tick base cost of leading
    burden_per_follower: float = 0.0004    # additional per follower in radius
    burden_per_distant: float = 0.0008    # additional per follower outside core radius
    coordination_radius: int = 4           # cells — core zone
    distant_radius: int = 8               # cells — extended zone (higher cost)

    # Compliance
    compliance_base: float = 0.55         # base probability without any modifiers
    compliance_stress_penalty: float = 0.35   # max reduction from high stress
    compliance_trust_weight: float = 0.30     # trust to leader → compliance
    compliance_legitimacy_weight: float = 0.40 # legitimacy → compliance

    # Enforcement (punishment attempt)
    enforcement_energy_cost: float = 0.040   # leader energy spent
    enforcement_success_chance_base: float = 0.50
    enforcement_resentment_add: float = 0.08 # resentment from target after punishment
    enforcement_fear_add: float = 0.015      # fear added to all nearby observers
    enforcement_resistance_resentment_floor: float = 0.55  # target resentment above → resists

    # Succession
    governance_gap_threshold: float = 0.18  # below this = no governance
    succession_cooldown: int = 15           # ticks before new leader can emerge after collapse

    # Ledger
    max_events: int = 500


DEFAULT_CONFIG = GovernanceConfig()


# ── Emergence score ───────────────────────────────────────────────────────────

def emergence_score(agent: Any, faction_members: List[Any]) -> float:
    """
    How strong a leadership candidate this agent is.
    Inputs: plan_confidence, dominance, specialization_depth,
            role (planner/diplomat weighted), avg trust from faction members.
    """
    s = agent.state
    t = agent.traits

    fam = role_family(getattr(t, "role", "generalist"))
    role_bonus = 0.0
    if fam in ("coordination", "governance"):
        role_bonus = 0.08
    elif fam == "diplomacy":
        role_bonus = 0.06
    elif fam == "protection":
        role_bonus = 0.03

    # Avg trust other members have toward this agent
    trust_toward = []
    for m in faction_members:
        if m.id == agent.id:
            continue
        rel = m.relationships.snapshot().get(agent.id, {})
        trust_toward.append(rel.get("trust", 0.5))
    avg_trust = sum(trust_toward) / len(trust_toward) if trust_toward else 0.5

    score = clamp(
        s.plan_confidence * 0.28
        + s.dominance * 0.22
        + s.specialization_depth * 0.18
        + avg_trust * 0.20
        + role_bonus
        + (1.0 - s.stress) * 0.08
        + s.energy * 0.04
    )
    return round(score, 4)


# ── Data structures ───────────────────────────────────────────────────────────

@dataclass
class LeaderRecord:
    faction_id: str
    leader_id: str
    legitimacy: float = 0.60
    burden_ticks: int = 0
    tenure_start: int = 0
    compliance_count: int = 0
    defiance_count: int = 0
    enforcement_count: int = 0
    enforcement_successes: int = 0
    succession_count: int = 0
    last_succession_tick: int = -999
    in_governance_gap: bool = False
    gap_start_tick: Optional[int] = None


@dataclass
class CoordinationSignal:
    leader_id: str
    faction_id: str
    signal_type: str      # "seek_resource" | "avoid_conflict" | "defer_to_specialist" | "hold_position"
    tick: int
    target_id: Optional[str] = None   # target agent for "defer_to_specialist"
    target_cell: Optional[Tuple[int, int]] = None


class GovernanceLedger:
    def __init__(self, cfg: GovernanceConfig = DEFAULT_CONFIG) -> None:
        self.cfg = cfg
        self.leaders: Dict[str, LeaderRecord] = {}   # faction_id → LeaderRecord
        self.events: List[Dict] = []
        self.total_compliance: int = 0
        self.total_defiance: int = 0
        self.total_enforcement: int = 0
        self.total_successions: int = 0
        self.total_governance_gap_ticks: int = 0

    def get_leader(self, faction_id: str) -> Optional[LeaderRecord]:
        return self.leaders.get(faction_id)

    def get_leader_agent(self, faction_id: str, agents: List[Any]) -> Optional[Any]:
        rec = self.leaders.get(faction_id)
        if rec is None or rec.in_governance_gap:
            return None
        return next((a for a in agents if a.id == rec.leader_id
                     and getattr(a, "alive", False)), None)

    def record_event(self, tick: int, event_type: str, faction_id: str,
                     actor_id: str, context: dict, outcome: str) -> None:
        self.events.append({
            "tick": tick, "event_type": event_type, "faction_id": faction_id,
            "actor_id": actor_id, "context": context, "outcome": outcome,
        })
        if len(self.events) > self.cfg.max_events:
            self.events = self.events[-self.cfg.max_events:]

    def snapshot(self, agents: Optional[List[Any]] = None) -> Dict:
        faction_summaries = []
        for fid, rec in self.leaders.items():
            faction_summaries.append({
                "faction_id": fid,
                "leader_id": rec.leader_id,
                "legitimacy": round(rec.legitimacy, 4),
                "tenure_ticks": rec.burden_ticks,
                "in_governance_gap": rec.in_governance_gap,
                "compliance_count": rec.compliance_count,
                "defiance_count": rec.defiance_count,
                "enforcement_count": rec.enforcement_count,
                "enforcement_successes": rec.enforcement_successes,
                "succession_count": rec.succession_count,
            })
        return {
            "summary": {
                "factions_with_leaders": sum(
                    1 for r in self.leaders.values() if not r.in_governance_gap),
                "factions_in_gap": sum(
                    1 for r in self.leaders.values() if r.in_governance_gap),
                "total_compliance": self.total_compliance,
                "total_defiance": self.total_defiance,
                "total_enforcement": self.total_enforcement,
                "total_successions": self.total_successions,
                "total_governance_gap_ticks": self.total_governance_gap_ticks,
            },
            "factions": faction_summaries,
            "recent_events": self.events[-30:],
        }


# ── Helpers ───────────────────────────────────────────────────────────────────

def _agent_by_id(agents: List[Any], aid: str) -> Optional[Any]:
    for a in agents:
        if a.id == aid:
            return a
    return None


def _distance(a: Any, b: Any) -> float:
    return ((a.position.x - b.position.x) ** 2
            + (a.position.y - b.position.y) ** 2) ** 0.5


def _followers_in_radius(leader: Any, agents: List[Any],
                          radius: int) -> List[Any]:
    return [a for a in agents
            if a.id != leader.id
            and getattr(a, "alive", False)
            and _distance(leader, a) <= radius]


# ── Leadership evaluation ─────────────────────────────────────────────────────

def _evaluate_leadership(faction_id: str, faction_members: List[Any],
                          ledger: GovernanceLedger, tick: int,
                          cfg: GovernanceConfig) -> None:
    """
    Evaluate whether current leader should be replaced.
    Called every leader_eval_interval ticks.
    """
    rec = ledger.leaders.get(faction_id)
    living = [m for m in faction_members if getattr(m, "alive", False)]
    if not living:
        return

    # Score all candidates
    scores = [(emergence_score(m, living), m) for m in living]
    scores.sort(key=lambda x: x[0], reverse=True)
    if not scores:
        return

    best_score, best_candidate = scores[0]

    # No current leader or in governance gap
    if rec is None or rec.in_governance_gap:
        if (tick - (rec.last_succession_tick if rec else -999)
                >= cfg.succession_cooldown):
            if best_score >= cfg.leader_score_floor:
                _install_leader(faction_id, best_candidate, tick, ledger, cfg,
                                reason="emergence")
        return

    # Check if current leader is still alive
    leader_alive = any(m.id == rec.leader_id for m in living)
    if not leader_alive:
        _trigger_succession(faction_id, scores, tick, ledger, cfg,
                            reason="leader_death")
        return

    # Check legitimacy collapse
    if rec.legitimacy < cfg.legitimacy_collapse_threshold:
        _trigger_succession(faction_id, scores, tick, ledger, cfg,
                            reason="legitimacy_collapse")
        return

    # Check challenge: best candidate significantly better
    current_leader = _agent_by_id(living, rec.leader_id)
    if current_leader is None:
        return
    current_score = emergence_score(current_leader, living)
    if (best_candidate.id != rec.leader_id
            and best_score > current_score + cfg.challenge_gap
            and best_score >= cfg.leader_score_floor):
        _trigger_succession(faction_id, scores, tick, ledger, cfg,
                            reason="challenge")


def _install_leader(faction_id: str, candidate: Any, tick: int,
                     ledger: GovernanceLedger, cfg: GovernanceConfig,
                     reason: str) -> None:
    existing = ledger.leaders.get(faction_id)
    succession_count = (existing.succession_count + 1) if existing else 0
    ledger.leaders[faction_id] = LeaderRecord(
        faction_id=faction_id,
        leader_id=candidate.id,
        legitimacy=0.55,
        tenure_start=tick,
        succession_count=succession_count,
        last_succession_tick=tick,
    )
    ledger.total_successions += 1
    ledger.record_event(tick, "leadership_installed", faction_id,
                        candidate.id, {"reason": reason,
                                       "emergence_score": emergence_score(
                                           candidate, [candidate])},
                        "installed")


def _trigger_succession(faction_id: str,
                         scored_candidates: List[Tuple[float, Any]],
                         tick: int, ledger: GovernanceLedger,
                         cfg: GovernanceConfig, reason: str) -> None:
    existing = ledger.leaders.get(faction_id)
    succession_count = (existing.succession_count + 1) if existing else 0

    # Find best alive candidate who isn't current leader
    current_id = existing.leader_id if existing else None
    for score, candidate in scored_candidates:
        if candidate.id == current_id:
            continue
        if score >= cfg.leader_score_floor:
            ledger.leaders[faction_id] = LeaderRecord(
                faction_id=faction_id,
                leader_id=candidate.id,
                legitimacy=0.45,   # new leaders start with lower legitimacy
                tenure_start=tick,
                succession_count=succession_count,
                last_succession_tick=tick,
            )
            ledger.total_successions += 1
            ledger.record_event(tick, "succession", faction_id,
                                candidate.id,
                                {"reason": reason,
                                 "from_leader": current_id},
                                "succeeded")
            return

    # No qualified successor — governance gap
    if existing is not None:
        existing.in_governance_gap = True
        existing.gap_start_tick = tick
        existing.last_succession_tick = tick
    else:
        ledger.leaders[faction_id] = LeaderRecord(
            faction_id=faction_id,
            leader_id=current_id or "",
            legitimacy=0.0,
            in_governance_gap=True,
            gap_start_tick=tick,
            last_succession_tick=tick,
            succession_count=succession_count,
        )
    ledger.record_event(tick, "governance_gap", faction_id,
                        current_id or "", {"reason": reason}, "gap")


# ── Coordination signal ───────────────────────────────────────────────────────

def _choose_signal(leader: Any, followers: List[Any],
                   rng: random.Random) -> CoordinationSignal:
    """
    Leader reads population state and emits the most contextually useful signal.
    Signal types:
      seek_resource     — avg hunger/resource_stock low
      avoid_conflict    — avg stress/fear high
      defer_to_specialist — a high-depth specialist is nearby
      hold_position     — baseline / stable
    """
    if not followers:
        signal_type = "hold_position"
    else:
        avg_hunger = sum(getattr(f.state, "hunger", 0.0) for f in followers) / len(followers)
        avg_stress = sum(f.state.stress for f in followers) / len(followers)
        avg_resource = sum(f.state.resource_stock for f in followers) / len(followers)

        # Find a nearby specialist (highest depth, not the leader)
        specialist = max(followers,
                         key=lambda f: f.state.specialization_depth,
                         default=None)
        has_specialist = (specialist is not None
                          and specialist.state.specialization_depth > 0.22)

        if avg_hunger > 0.45 or avg_resource < 0.30:
            signal_type = "seek_resource"
        elif avg_stress > 0.55:
            signal_type = "avoid_conflict"
        elif has_specialist:
            signal_type = "defer_to_specialist"
        else:
            signal_type = "hold_position"

    specialist_id = None
    if signal_type == "defer_to_specialist" and followers:
        specialist_id = max(followers,
                            key=lambda f: f.state.specialization_depth).id

    return CoordinationSignal(
        leader_id=leader.id,
        faction_id=getattr(leader, "_current_faction_id", ""),
        signal_type=signal_type,
        tick=0,
        target_id=specialist_id,
    )


def _compliance_probability(follower: Any, leader: Any,
                             rec: LeaderRecord,
                             cfg: GovernanceConfig) -> float:
    """
    Probability this follower complies with the coordination signal.
    Base + legitimacy weight + trust weight − stress penalty.
    """
    rel = follower.relationships.snapshot().get(leader.id, {})
    trust = rel.get("trust", 0.5)
    stress_penalty = follower.state.stress * cfg.compliance_stress_penalty
    prob = clamp(
        cfg.compliance_base
        + rec.legitimacy * cfg.compliance_legitimacy_weight
        + trust * cfg.compliance_trust_weight
        - stress_penalty
    )
    return prob


def _apply_signal_effect(follower: Any, signal: CoordinationSignal) -> None:
    """
    Apply the small behavioral nudge from complying with a signal.
    These are pressures, not teleportation — they shift pulls slightly.
    """
    s = follower.state
    if signal.signal_type == "seek_resource":
        s.curiosity = clamp(s.curiosity + 0.012)
        s.goal_satisfaction = clamp(s.goal_satisfaction - 0.008)
    elif signal.signal_type == "avoid_conflict":
        s.fear = clamp(s.fear - 0.010)
        s.stress = clamp(s.stress - 0.008)
        s.cooperation = clamp(s.cooperation + 0.006)
    elif signal.signal_type == "defer_to_specialist":
        s.social_openness = clamp(s.social_openness + 0.008)
        s.cooperation = clamp(s.cooperation + 0.005)
    elif signal.signal_type == "hold_position":
        s.stability = clamp(s.stability + 0.006)


# ── Enforcement ───────────────────────────────────────────────────────────────

def _attempt_enforcement(leader: Any, target: Any, rec: LeaderRecord,
                          all_nearby: List[Any], tick: int,
                          ledger: GovernanceLedger,
                          cfg: GovernanceConfig,
                          rng: random.Random) -> str:
    """
    Leader punishes a defiant agent.
    Returns 'success' | 'failed' | 'resisted'.
    """
    if leader.state.energy < cfg.enforcement_energy_cost + 0.05:
        return "skipped"   # leader too depleted to enforce

    leader.state.energy = clamp(leader.state.energy - cfg.enforcement_energy_cost)
    rec.enforcement_count += 1
    ledger.total_enforcement += 1

    # Target resistance: resentment-gated
    target_rel = target.relationships.snapshot().get(leader.id, {})
    target_resentment = target_rel.get("resentment", 0.0)

    resists = target_resentment >= cfg.enforcement_resistance_resentment_floor
    if resists:
        # Resistance: legitimacy takes heavy hit
        rec.legitimacy = clamp(
            rec.legitimacy - cfg.legitimacy_enforcement_failure
        )
        target.relationships.update_after_interaction(
            leader.id,
            trust_delta=-0.04,
            resentment_delta=cfg.enforcement_resentment_add,
            attachment_delta=-0.02,
            influence_delta=0.0,
        )
        ledger.record_event(tick, "enforcement_resisted", rec.faction_id,
                            leader.id,
                            {"target": target.id,
                             "target_resentment": round(target_resentment, 4)},
                            "resisted")
        return "resisted"

    success = rng.random() < cfg.enforcement_success_chance_base
    if success:
        rec.legitimacy = clamp(
            rec.legitimacy + cfg.legitimacy_enforcement_success
        )
        rec.enforcement_successes += 1
        target.state.stress = clamp(target.state.stress + 0.020)
        target.state.fear = clamp(target.state.fear + 0.010)
        target.relationships.update_after_interaction(
            leader.id,
            trust_delta=-0.02,
            resentment_delta=cfg.enforcement_resentment_add * 0.5,
            attachment_delta=-0.01,
            influence_delta=0.0,
        )
        # Observers: mild fear increase
        for obs in all_nearby:
            if obs.id not in (leader.id, target.id):
                obs.state.fear = clamp(obs.state.fear + cfg.enforcement_fear_add)
        ledger.record_event(tick, "enforcement_success", rec.faction_id,
                            leader.id, {"target": target.id}, "success")
        return "success"
    else:
        rec.legitimacy = clamp(
            rec.legitimacy - cfg.legitimacy_enforcement_failure * 0.5
        )
        ledger.record_event(tick, "enforcement_failed", rec.faction_id,
                            leader.id, {"target": target.id}, "failed")
        return "failed"


# ── Institution legitimacy multiplier ─────────────────────────────────────────

def institution_legitimacy_multiplier(faction_id: str,
                                       ledger: GovernanceLedger) -> float:
    """
    Returns [0,1] multiplier for institution enforcement strength.
    Full legitimacy = 1.0. Governance gap = 0.25 (advisory only).
    Called by InstitutionRegistry or run_sim to scale inst_conflict_suppression.
    """
    rec = ledger.leaders.get(faction_id)
    if rec is None:
        return 0.40   # no leader on record — partial effectiveness
    if rec.in_governance_gap:
        return 0.20   # advisory only
    return clamp(rec.legitimacy)


# ── Main per-tick update ──────────────────────────────────────────────────────

def apply_tick(
    agents: List[Any],
    tick: int,
    phase_name: str,
    ledger: GovernanceLedger,
    faction_registry: Any,
    cfg: GovernanceConfig = DEFAULT_CONFIG,
    rng: Optional[random.Random] = None,
) -> List[Any]:
    """
    World-level governance update. Returns list of Event objects.
    Call after agent ticks, before metrics.
    """
    from schemas import Event

    if rng is None:
        rng = random.Random(tick)

    events: List[Any] = []
    living = [a for a in agents if getattr(a, "alive", False)]
    agent_map = {a.id: a for a in living}

    for faction_id, faction in faction_registry.factions.items():
        faction_members = [agent_map[mid] for mid in faction.members
                           if mid in agent_map]
        if not faction_members:
            continue

        # Tag members with current faction id for signal construction
        for m in faction_members:
            m._current_faction_id = faction_id

        # ── Leadership evaluation (every N ticks) ────────────────────────────
        if tick % cfg.leader_eval_interval == 0:
            _evaluate_leadership(faction_id, faction_members, ledger, tick, cfg)

        rec = ledger.leaders.get(faction_id)
        if rec is None:
            continue

        # ── Governance gap tracking ──────────────────────────────────────────
        if rec.in_governance_gap:
            ledger.total_governance_gap_ticks += 1
            # Try to resolve gap if succession cooldown has passed
            if tick - rec.last_succession_tick >= cfg.succession_cooldown:
                scores = [(emergence_score(m, faction_members), m)
                          for m in faction_members]
                scores.sort(key=lambda x: x[0], reverse=True)
                for score, candidate in scores:
                    if score >= cfg.leader_score_floor:
                        _install_leader(faction_id, candidate, tick, ledger,
                                        cfg, reason="gap_recovery")
                        events.append(Event(
                            tick=tick, phase=phase_name,
                            actor_id=candidate.id,
                            event_type="governance_gap_resolved",
                            participants=[m.id for m in faction_members],
                            context={"faction_id": faction_id,
                                     "gap_duration": tick - (rec.gap_start_tick or tick)},
                            impact={"legitimacy": 0.45},
                            outcome="gap_resolved",
                        ))
                        break
            continue

        leader = agent_map.get(rec.leader_id)
        if leader is None:
            continue

        # ── Leadership burden ────────────────────────────────────────────────
        followers_core = _followers_in_radius(leader, faction_members,
                                               cfg.coordination_radius)
        followers_distant = [
            f for f in _followers_in_radius(leader, faction_members,
                                             cfg.distant_radius)
            if f not in followers_core
        ]
        burden = (cfg.burden_base
                  + len(followers_core) * cfg.burden_per_follower
                  + len(followers_distant) * cfg.burden_per_distant)
        leader.state.energy = clamp(leader.state.energy - burden)
        rec.burden_ticks += 1

        # Passive legitimacy decay
        rec.legitimacy = clamp(rec.legitimacy - cfg.legitimacy_passive_decay)

        # ── Coordination signal ──────────────────────────────────────────────
        all_followers = followers_core + followers_distant
        if not all_followers:
            continue

        signal = _choose_signal(leader, all_followers, rng)
        signal.tick = tick

        compliant = []
        defiant = []
        for follower in all_followers:
            prob = _compliance_probability(follower, leader, rec, cfg)
            if rng.random() < prob:
                compliant.append(follower)
                _apply_signal_effect(follower, signal)
                rec.compliance_count += 1
                ledger.total_compliance += 1
            else:
                defiant.append(follower)
                rec.defiance_count += 1
                ledger.total_defiance += 1

        # Legitimacy update from compliance/defiance
        rec.legitimacy = clamp(
            rec.legitimacy
            + len(compliant) * cfg.legitimacy_compliance_gain
            - len(defiant) * cfg.legitimacy_defiance_loss
        )

        # Survival outcome bonus: if leader's followers survive above avg this tick
        avg_energy = (sum(a.state.energy for a in living) / len(living)
                      if living else 0.5)
        follower_avg_energy = (sum(f.state.energy for f in all_followers)
                               / len(all_followers) if all_followers else 0.5)
        if follower_avg_energy > avg_energy:
            rec.legitimacy = clamp(
                rec.legitimacy + cfg.legitimacy_survival_bonus
            )

        if compliant or defiant:
            events.append(Event(
                tick=tick, phase=phase_name, actor_id=leader.id,
                event_type="coordination",
                participants=[f.id for f in all_followers],
                context={
                    "faction_id": faction_id,
                    "signal_type": signal.signal_type,
                    "compliant": len(compliant),
                    "defiant": len(defiant),
                    "legitimacy": round(rec.legitimacy, 4),
                    "burden": round(burden, 4),
                    "core_followers": len(followers_core),
                    "distant_followers": len(followers_distant),
                },
                impact={"legitimacy_delta": round(
                    len(compliant) * cfg.legitimacy_compliance_gain
                    - len(defiant) * cfg.legitimacy_defiance_loss, 4)},
                outcome="coordination_issued",
            ))

        # ── Enforcement against defiant agents ───────────────────────────────
        # Leader enforces against at most one defiant agent per tick
        # (enforcement is costly; mass punishment is unrealistic each tick)
        if defiant and leader.state.energy > cfg.enforcement_energy_cost + 0.05:
            target = rng.choice(defiant)
            result = _attempt_enforcement(leader, target, rec, all_followers,
                                          tick, ledger, cfg, rng)
            if result not in ("skipped",):
                events.append(Event(
                    tick=tick, phase=phase_name, actor_id=leader.id,
                    event_type="enforcement",
                    participants=[target.id],
                    context={
                        "faction_id": faction_id,
                        "result": result,
                        "legitimacy_after": round(rec.legitimacy, 4),
                    },
                    impact={"target_stress": 0.02 if result == "success" else 0.0},
                    outcome=f"enforcement_{result}",
                ))

        # ── Collapse check ───────────────────────────────────────────────────
        if rec.legitimacy < cfg.legitimacy_collapse_threshold:
            scores = [(emergence_score(m, faction_members), m)
                      for m in faction_members]
            scores.sort(key=lambda x: x[0], reverse=True)
            _trigger_succession(faction_id, scores, tick, ledger, cfg,
                                reason="legitimacy_collapse")
            events.append(Event(
                tick=tick, phase=phase_name, actor_id=leader.id,
                event_type="legitimacy_collapse",
                participants=[m.id for m in faction_members],
                context={
                    "faction_id": faction_id,
                    "final_legitimacy": round(rec.legitimacy, 4),
                    "tenure_ticks": rec.burden_ticks,
                },
                impact={"coordination_loss": 1.0},
                outcome="legitimacy_collapsed",
            ))

    return events


# ── Agent-level init ──────────────────────────────────────────────────────────

def init_agent(agent: Any) -> None:
    """Attach governance tracking fields. Idempotent."""
    if not hasattr(agent, "is_leader"):
        agent.is_leader = False
    if not hasattr(agent, "_current_faction_id"):
        agent._current_faction_id = None
    if not hasattr(agent, "compliance_count"):
        agent.compliance_count = 0
    if not hasattr(agent, "defiance_count"):
        agent.defiance_count = 0


# ── Benchmark metrics ─────────────────────────────────────────────────────────

def benchmark_metrics(ledger: GovernanceLedger,
                       agents: List[Any]) -> Dict[str, Any]:
    living = [a for a in agents if getattr(a, "alive", False)]
    recs = list(ledger.leaders.values())
    avg_legitimacy = (
        sum(r.legitimacy for r in recs) / len(recs) if recs else 0.0
    )
    return {
        "factions_with_leaders": sum(
            1 for r in recs if not r.in_governance_gap),
        "factions_in_gap": sum(1 for r in recs if r.in_governance_gap),
        "avg_legitimacy": round(avg_legitimacy, 4),
        "total_compliance": ledger.total_compliance,
        "total_defiance": ledger.total_defiance,
        "total_enforcement": ledger.total_enforcement,
        "total_successions": ledger.total_successions,
        "governance_gap_ticks": ledger.total_governance_gap_ticks,
        "compliance_rate": round(
            ledger.total_compliance /
            max(1, ledger.total_compliance + ledger.total_defiance), 4
        ),
    }
