"""
Territory — Layer 5
TerritoryMap tracks which faction (if any) controls each grid cell.
Agents in a faction claim cells they occupy; contested cells raise
conflict pressure locally; agents in controlled territory get resource
and stress bonuses.
"""
from typing import Dict, Optional, Tuple
from schemas import Faction


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


Cell = Tuple[int, int]

CLAIM_STRENGTH_GAIN = 0.04
CLAIM_DECAY = 0.005
CONTROL_THRESHOLD = 0.60     # strength above this = controlled
CONTEST_BONUS_CONFLICT = 0.12  # extra conflict pressure in contested cell


class TerritoryMap:
    def __init__(self, width: int, height: int) -> None:
        self.width = width
        self.height = height
        # cell -> {faction_id: strength}
        self._claims: Dict[Cell, Dict[str, float]] = {}

    def _cell(self, x: int, y: int) -> Cell:
        return (x, y)

    def claim(self, x: int, y: int, faction_id: str) -> None:
        c = self._cell(x, y)
        if c not in self._claims:
            self._claims[c] = {}
        self._claims[c][faction_id] = clamp(
            self._claims[c].get(faction_id, 0.0) + CLAIM_STRENGTH_GAIN
        )

    def controller(self, x: int, y: int) -> Optional[str]:
        c = self._cell(x, y)
        claims = self._claims.get(c, {})
        if not claims:
            return None
        top_fid, top_str = max(claims.items(), key=lambda kv: kv[1])
        return top_fid if top_str >= CONTROL_THRESHOLD else None

    def is_contested(self, x: int, y: int) -> bool:
        c = self._cell(x, y)
        claims = self._claims.get(c, {})
        if len(claims) < 2:
            return False
        vals = sorted(claims.values(), reverse=True)
        return (vals[0] - vals[1]) < 0.25

    def decay_all(self) -> None:
        for cell_claims in self._claims.values():
            for fid in list(cell_claims):
                cell_claims[fid] = max(0.0, cell_claims[fid] - CLAIM_DECAY)

    def apply_territory_effects(self, agent, faction_registry) -> float:
        """
        Returns an extra conflict pressure modifier based on territorial status.
        Also applies resource/stress bonuses if agent is in own territory.
        """
        x, y = agent.position.x, agent.position.y
        faction = faction_registry.faction_of(agent.id)
        extra_conflict = 0.0

        if self.is_contested(x, y):
            extra_conflict += CONTEST_BONUS_CONFLICT
            agent.state.stress = clamp(agent.state.stress + 0.008)

        if faction:
            controller = self.controller(x, y)
            if controller == faction.id:
                # Home territory: calming
                agent.state.stress = clamp(agent.state.stress - 0.005)
                agent.state.resource_stock = clamp(agent.state.resource_stock + 0.004)
            elif controller is not None and controller != faction.id:
                # Enemy territory
                extra_conflict += 0.08
                agent.state.fear = clamp(agent.state.fear + 0.010)

        return extra_conflict

    def snapshot_controlled(self) -> dict:
        result = {}
        for (x, y), claims in self._claims.items():
            if not claims:
                continue
            top_fid, top_str = max(claims.items(), key=lambda kv: kv[1])
            result[f"{x},{y}"] = {
                "top_faction": top_fid,
                "strength": round(top_str, 4),
                "contested": self.is_contested(x, y),
            }
        return result
