# DEPRECATED (v4.50 kernel migration)
# Runtime logic has moved to kernel/runtime.py
# Use: python run_kernel_exp_E.py --config configs/exp_E.json
# This file is preserved for reference. Do not add new simulation logic here.
# See kernel/kernel_migration_audit.md

"""
Experiment E — Staggered founding + group-specific meme seeds + full spatial agency.

Group A (woodland, NW):  tick 0    — cooperation_norm, collective_memory
Group B (meadow, NE):    tick 200  — resource_sharing, reciprocal_exchange  
Group C (wetland, SW):   tick 400  — collective_memory, territorial_marking
Group D (savanna, SE):   tick 600  — dominance_hierarchy, risk_taking

Full spatial agency layer active. Resource transfer active. 5000 ticks.
"""
import sys, json, random, math
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from agent import Agent
from environment import EnvironmentCycle
from metrics import population_metrics, topology_metrics
from space import SpatialWorld
from resources import ResourceWorld
from factions import FactionRegistry
from territory import TerritoryMap
from institutions import InstitutionRegistry
from culture import CulturePool
from reproduction import ReproductionSystem
from language import WorldNarrative
from experiential import TextureChronicle
import attractor as attractor_mod
import salience as salience_mod
import psychology as psychology_mod
import continuity as continuity_mod
from checkpoint import CheckpointWriter
from death_ledger import DeathLedger, build_death_record
from persistence import PersistenceLedger
from constraints import ConstraintLedger
from generational import GenerationalLedger, apply_tick as apply_generational_tick, assign_child_context, init_agent as init_generational_agent
from apprenticeship import ApprenticeshipLedger, apply_tick as apply_apprenticeship_tick, init_agent as init_apprenticeship_agent
from logistics import LogisticsWorld
import biology as biology_mod
from innovation import InnovationEngine, apply_tick as apply_innovation_tick, init_agent as init_innovation_agent
from harness import EventStream, RollingCounters, RunManifest, safe_agent_tick
from information import InformationLedger, apply_tick as apply_information_tick, init_agent as init_information_agent
from governance import GovernanceLedger, apply_tick as apply_governance_tick, init_agent as init_governance_agent
from subsistence import SubsistenceWorld
from generational_psychology import GenerationalPsychologyLedger, apply_storykeeper_transmission, apply_targeted_care_recovery
from institutional_memory import InstitutionalMemoryLedger, apply_institutional_memory_tick
from social_viability import seed_viable_founder_band, apply_population_viability_tick
from settlements import SettlementLedger
from ecological_context import ecological_health as _eco_health_fn
import life_events as life_events_mod
from epochs import detect_epochs, summarize_epochs
from spatial_zone import ZoneGrid, SPATIAL_ECOLOGY_ENABLED
from spatial_memory import SpatialMemory
from movement_goals import init_agent_movement
from resource_transfer import apply_resource_transfers, transfer_metrics
from schemas import Meme

TICKS       = 5000
SEED        = 23
SNAP_EVERY  = 500
OUTPUT_ROOT = Path("/tmp/hrm_exp_E")
WORLD_W, WORLD_H = 40, 40
MAX_POP     = 140
GROUP_LABELS = ["A", "B", "C", "D"]

# Staggered arrival ticks
ARRIVAL_TICKS = {"A": 0, "B": 200, "C": 400, "D": 600}

# Cluster centers — same as Exp D
CLUSTER_CENTERS = {
    "A": (10, 10),   # woodland NW
    "B": (30, 10),   # meadow NE
    "C": (10, 30),   # wetland SW
    "D": (30, 30),   # savanna SE
}

GROUP_NAMES = {
    "A": ["Alder","Brin","Cara","Dune","Evren","Foss","Gale","Holt","Iris","Jorn","Kael","Lira"],
    "B": ["Marsh","Neva","Orin","Pell","Quinn","Rook","Sera","Tarn","Ulan","Vara","Wren","Xan"],
    "C": ["Yeva","Zale","Asha","Bram","Cove","Dell","Egan","Fern","Grey","Hale","Ilex","Jade"],
    "D": ["Kern","Lane","Mira","Nash","Oval","Pine","Qira","Reed","Sage","Tove","Ursa","Vale"],
}

# Group-specific meme seeds
GROUP_MEMES = {
    "A": {  # Woodland hunters — cooperative, memory-heavy
        "m_coop":   Meme(id="m_coop",   label="cooperation_norm",   valence=+0.80, spread_rate=0.06, strength=0.28),
        "m_colmem": Meme(id="m_colmem", label="collective_memory",  valence=+0.60, spread_rate=0.05, strength=0.25),
    },
    "B": {  # Meadow foragers — sharing, exchange-minded
        "m_share":    Meme(id="m_share",    label="resource_sharing",    valence=+0.70, spread_rate=0.05, strength=0.28),
        "m_reciproc": Meme(id="m_reciproc", label="reciprocal_exchange", valence=+0.70, spread_rate=0.05, strength=0.25),
    },
    "C": {  # Wetland dwellers — place-attached, insular
        "m_colmem": Meme(id="m_colmem", label="collective_memory",   valence=+0.60, spread_rate=0.04, strength=0.28),
        "m_territ": Meme(id="m_territ", label="territorial_marking",  valence=-0.40, spread_rate=0.05, strength=0.25),
    },
    "D": {  # Savanna hunters — prestige, dominance
        "m_dom":  Meme(id="m_dom",  label="dominance_hierarchy", valence=-0.30, spread_rate=0.06, strength=0.28),
        "m_risk": Meme(id="m_risk", label="risk_taking",         valence=-0.20, spread_rate=0.05, strength=0.25),
    },
}

def serialize_event(e):
    return {"tick":e.tick,"phase":e.phase,"actor_id":e.actor_id,
            "event_type":e.event_type,"participants":e.participants,
            "context":e.context,"impact":e.impact,"outcome":e.outcome}

def make_agent(name, seed, g_label, cx, cy, spatial_world, faction_registry,
               culture_pool, group_rng):
    a = Agent(name, seed=seed, spatial_world=spatial_world,
              faction_registry=faction_registry, culture_pool=culture_pool)
    a.position.x = max(0.0, min(float(WORLD_W-1), cx + group_rng.uniform(-2, 2)))
    a.position.y = max(0.0, min(float(WORLD_H-1), cy + group_rng.uniform(-2, 2)))
    init_generational_agent(a, generation=0, household_id=None, parents=[], birth_tick=0)
    init_apprenticeship_agent(a)
    init_governance_agent(a)
    biology_mod.init_agent(a)
    init_innovation_agent(a)
    init_information_agent(a)
    return a

def seed_group_culture(agents, g_label, culture_pool):
    """Give this group their founding meme set."""
    group_memes = GROUP_MEMES[g_label]
    # Merge into culture pool (don't overwrite existing memes from other groups)
    for mid, meme in group_memes.items():
        if mid not in culture_pool.memes:
            culture_pool.memes[mid] = meme
    # Seed agents with their group's memes
    for a in agents:
        group_meme_ids = list(group_memes.keys())
        culture_pool._agent_memes[a.id] = group_meme_ids[:]

def init_spatial_for_agent(a, zone_grid):
    x = getattr(a.position, 'x', 20.0)
    y = getattr(a.position, 'y', 20.0)
    zid = zone_grid.zone_id_for_position(x, y)
    init_agent_movement(a, zid)
    if a.spatial_memory is None:
        a.spatial_memory = SpatialMemory()

def snapshot_report(tick, agents, ledger, culture_pool, faction_registry,
                    innovation_engine, counters, agent_group, event_log, zone_grid):
    living = [a for a in agents if a.alive]
    births = sum(1 for a in agents if a.generation >= 1)
    total_int  = counters.interaction_total
    total_conf = counters.conflict_total
    conf_rate  = 100 * total_conf / max(1, total_int)
    innov_s = innovation_engine.snapshot().get('summary', {})
    max_gen = max((a.generation for a in living), default=0)

    print(f"\n{'='*60}")
    print(f"  TICK {tick} SNAPSHOT")
    print(f"{'='*60}")
    print(f"  Population  : {len(living)} alive / {len(agents)} total  (births: {births})")
    print(f"  Max gen     : Gen{max_gen}")
    print(f"  Deaths      : {len(ledger.deaths)}")
    for gl in GROUP_LABELS:
        arrived = ARRIVAL_TICKS[gl] <= tick
        g_living = sum(1 for a in living if agent_group.get(a.id) == gl)
        status = f"{g_living} alive" if arrived else "not yet arrived"
        print(f"  Group {gl}     : {status}")
    print(f"  Conflict    : {total_conf}/{total_int} ({conf_rate:.1f}%)")
    print(f"  Factions    : {len(faction_registry.factions)}")

    snap = culture_pool.snapshot()
    meme_list = sorted(snap.get('meme_list',[]), key=lambda x: x.get('strength',0), reverse=True)
    print(f"  Memes       : {len(meme_list)} active")
    top = " | ".join(f"{m['label']} ({m['valence']:+.1f},{m.get('strength',0):.2f})"
                     for m in meme_list[:4])
    if top: print(f"  Top memes   : {top}")

    print(f"  Innovation  : {innov_s.get('total_successes',0)} successes, "
          f"registry={innov_s.get('registry_size',0)}")

    tm = transfer_metrics(event_log, since_tick=max(0, tick - SNAP_EVERY))
    print(f"  Transfers   : trade={tm['trades']} (cross-biome={tm['cross_biome_trades']}) | "
          f"theft={tm['theft_successes']}/{tm['thefts']} | "
          f"charity={tm['charities']} (cross-faction={tm['cross_faction_charities']})")

    if zone_grid:
        zsnap = zone_grid.snapshot()
        top_zones = sorted(zsnap.items(), key=lambda kv: kv[1]['local_pop'], reverse=True)[:3]
        zstr = " | ".join(f"{zid}({z['biome'][:3]})={z['local_pop']}ag"
                          for zid, z in top_zones)
        print(f"  Top zones   : {zstr}")

    agents_with_mem = sum(1 for a in living if a.spatial_memory and a.spatial_memory.known_zones())
    avg_zones = sum(len(a.spatial_memory.known_zones()) for a in living
                    if a.spatial_memory) / max(1, len(living))
    print(f"  Spatial mem : {agents_with_mem}/{len(living)} agents, avg {avg_zones:.1f} zones known")

    notable = sorted(living, key=lambda a: a.state.age, reverse=True)[:3]
    for a in notable:
        tags = a.experience.identity_tags[:3] if hasattr(a.experience,'identity_tags') else []
        gl = agent_group.get(a.id, '?')
        role = getattr(getattr(a,'traits',None),'role','?')
        print(f"  {a.name:14s} G{gl} gen={a.generation:2d} age={a.state.age:5d} "
              f"stress={a.state.stress:.2f} tags={tags}")
    print()

def main():
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    output_dir = OUTPUT_ROOT / "run_1"
    output_dir.mkdir(parents=True, exist_ok=True)

    world_rng = random.Random(SEED)
    spatial_world     = SpatialWorld(width=WORLD_W, height=WORLD_H, interaction_radius=3)
    resource_world    = ResourceWorld(width=WORLD_W, height=WORLD_H, n_nodes=120, rng=world_rng)
    faction_registry  = FactionRegistry()
    territory_map     = TerritoryMap(width=WORLD_W, height=WORLD_H)
    institution_registry = InstitutionRegistry()
    culture_pool      = CulturePool()
    # Clear default seed memes — each group seeds their own
    culture_pool.memes = {}
    culture_pool._agent_memes = {}
    reproduction_system = ReproductionSystem(max_population=MAX_POP)
    world_narrative   = WorldNarrative()
    texture_chronicle = TextureChronicle()
    persistence_ledger= PersistenceLedger()
    env               = EnvironmentCycle()
    logistics_world   = LogisticsWorld(WORLD_W, WORLD_H, seed=SEED+44000)
    subsistence_world = SubsistenceWorld(WORLD_W, WORLD_H, seed=SEED+43300)
    genpsych_ledger   = GenerationalPsychologyLedger()
    inst_mem_ledger   = InstitutionalMemoryLedger()
    spatial_world.logistics_world  = logistics_world
    resource_world.logistics_world = logistics_world
    settlement_ledger = SettlementLedger()

    # Spatial agency layer
    zone_grid = ZoneGrid(WORLD_W, WORLD_H, seed=SEED+99000)
    spatial_world._zone_grid    = zone_grid
    subsistence_world._zone_grid = zone_grid
    print(f"ZoneGrid: {len(zone_grid.zones)} zones")

    # Pre-build Group A agents (arrive at tick 0)
    # Other groups stored as pending, spawned at their arrival tick
    agents = []
    agent_group = {}
    pending_groups = {}  # gl -> list of agent snapshots to spawn

    for gl in GROUP_LABELS:
        cx, cy = CLUSTER_CENTERS[gl]
        names  = GROUP_NAMES[gl]
        grp_agents = []
        for i, name in enumerate(names):
            a = make_agent(name, seed=ord(gl)*100+i+1, g_label=gl,
                           cx=cx, cy=cy, spatial_world=spatial_world,
                           faction_registry=faction_registry,
                           culture_pool=culture_pool,
                           group_rng=random.Random(SEED+ord(gl)*1000+i))
            grp_agents.append(a)

        # Sex-balance the group
        seed_viable_founder_band(grp_agents, spatial_world,
                                 random.Random(SEED+ord(gl)*43700))
        # Restore cluster positions after seeding
        for i, a in enumerate(grp_agents):
            rng = random.Random(SEED+ord(gl)*1000+i+500)
            a.position.x = max(0.0, min(float(WORLD_W-1), cx + rng.uniform(-2,2)))
            a.position.y = max(0.0, min(float(WORLD_H-1), cy + rng.uniform(-2,2)))

        if ARRIVAL_TICKS[gl] == 0:
            seed_group_culture(grp_agents, gl, culture_pool)
            for a in grp_agents:
                init_spatial_for_agent(a, zone_grid)
                agent_group[a.id] = gl
            agents.extend(grp_agents)
        else:
            pending_groups[gl] = grp_agents

    life_events_mod.initialize_life_events(agents, max_ticks=TICKS, seed=1, key="run_1")
    settlement_seed_events = settlement_ledger.seed_founder_settlements(
        agents, logistics_world, tick=0)
    (output_dir/"agents_initial.json").write_text(
        json.dumps([a.snapshot() for a in agents], indent=2), encoding="utf-8")

    ckpt     = CheckpointWriter(output_dir, interval=500)
    ledger   = DeathLedger()
    event_log   = []
    metric_log  = []
    _counters   = RollingCounters()
    _stream     = EventStream(output_dir/"events.jsonl")
    RUN_MANIFEST = RunManifest(OUTPUT_ROOT)
    RUN_MANIFEST.start(1, output_dir)

    for st_ev in settlement_seed_events:
        d = serialize_event(st_ev); d["salience"] = 0.58
        persistence_ledger.record_event(d); event_log.append(d)
        _counters.record(d); _stream.write(d)

    constraint_ledger     = ConstraintLedger()
    generational_ledger   = GenerationalLedger()
    apprenticeship_ledger = ApprenticeshipLedger()
    governance_ledger     = GovernanceLedger()
    innovation_engine     = InnovationEngine()
    information_ledger    = InformationLedger()
    death_logged = set()

    print(f"EXPERIMENT E: Staggered founding + group meme seeds + spatial agency")
    print(f"  A (woodland): tick 0    — cooperation_norm, collective_memory")
    print(f"  B (meadow):   tick 200  — resource_sharing, reciprocal_exchange")
    print(f"  C (wetland):  tick 400  — collective_memory, territorial_marking")
    print(f"  D (savanna):  tick 600  — dominance_hierarchy, risk_taking")
    snapshot_report(0, agents, ledger, culture_pool, faction_registry,
                    innovation_engine, _counters, agent_group, event_log, zone_grid)

    for tick in range(1, TICKS+1):

        # ── Spawn pending groups at their arrival tick ────────────────────────
        for gl, grp_agents in list(pending_groups.items()):
            if tick == ARRIVAL_TICKS[gl]:
                print(f"\n  >>> Group {gl} arrives at tick {tick} "
                      f"({len(grp_agents)} agents, {CLUSTER_CENTERS[gl]}) <<<")
                seed_group_culture(grp_agents, gl, culture_pool)
                life_events_mod.initialize_life_events(
                    grp_agents, max_ticks=TICKS, seed=tick+ord(gl), key=f"run_1_{gl}")
                for a in grp_agents:
                    init_spatial_for_agent(a, zone_grid)
                    agent_group[a.id] = gl
                agents.extend(grp_agents)
                del pending_groups[gl]

        phase = env.get_phase(tick)
        phase = subsistence_world.apply_to_phase(phase)

        for sub_ev in subsistence_world.begin_tick(tick):
            d = serialize_event(sub_ev); d["salience"] = 0.50
            subsistence_world.record_event(sub_ev)
            persistence_ledger.record_event(d); event_log.append(d)
            _counters.record(d); _stream.write(d)

        zone_grid.update_local_populations(agents)
        zone_grid.tick(phase.name)

        _eco = _eco_health_fn(subsistence_world, agents,
                              recent_deaths=sum(1 for a in agents if not a.alive))
        life_events_mod.step_disease_layer(agents, tick, key="run_1")
        living = [a for a in agents if a.alive]

        for a in living:
            le = life_events_mod.apply_all_life_effects(a, tick, key="run_1")
            if le["stress"]:  a.state.stress      = max(0., min(1., a.state.stress      + le["stress"]*0.012))
            if le["support"]: a.state.cooperation = max(0., min(1., a.state.cooperation + le["support"]*0.008))
            if le["trust"]:   a.state.stability   = max(0., min(1., a.state.stability   + le["trust"]*0.006))

        # Wire population_ref and eco_health into each agent for lethality system
        for a in living:
            a._population_ref = agents
            a._eco_health = _eco

        for a in list(living):
            if not a.alive: continue
            ev = safe_agent_tick(a, tick, phase, agents,
                spatial_world=spatial_world, resource_world=resource_world,
                faction_registry=faction_registry, territory_map=territory_map,
                institution_registry=institution_registry, culture_pool=culture_pool,
                world_narrative=world_narrative, texture_chronicle=texture_chronicle,
                governance_ledger=governance_ledger, eco_health=_eco)
            if not ev: continue
            d = serialize_event(ev); d["salience"] = salience_mod.score(d)
            persistence_ledger.record_event(d); event_log.append(d)
            _counters.record(d); _stream.write(d)

            if ev.event_type == "birth":
                child_id   = ev.context.get("child_id")
                parent_ids = ev.context.get("parent_ids", [])
                child = next((a for a in agents if a.id == child_id), None)
                if child:
                    parents = [a for a in agents if a.id in parent_ids]
                    assign_child_context(child, parents, tick, generational_ledger)
                    init_innovation_agent(child); init_information_agent(child)
                    init_governance_agent(child)
                    init_spatial_for_agent(child, zone_grid)
                    for pid in parent_ids:
                        if pid in agent_group:
                            agent_group[child.id] = agent_group[pid]; break

            if ev.event_type == "death":
                dead = next((a for a in agents if a.id == ev.actor_id), None)
                if dead and dead.id not in death_logged:
                    death_logged.add(dead.id)
                    ledger.record(build_death_record(dead, tick, agents))
                    psychology_mod.notify_death_to_population(dead, agents, tick)

            # Process aux_events: catch homicide deaths from lethality system
            for aux_ev in getattr(a, "aux_events", []):
                d = serialize_event(aux_ev); d["salience"] = 0.90
                persistence_ledger.record_event(d); event_log.append(d)
                _counters.record(d); _stream.write(d)
                if aux_ev.event_type == "lethal_conflict" and getattr(aux_ev, "outcome", "") == "homicide":
                    victim_id = aux_ev.participants[0] if aux_ev.participants else None
                    if victim_id:
                        victim = next((x for x in agents if x.id == victim_id), None)
                        if victim and victim.id not in death_logged:
                            death_logged.add(victim.id)
                            ledger.record(build_death_record(victim, agents, tick, cause="homicide"))
                            psychology_mod.notify_death_to_population(victim, agents, tick)
            a.aux_events = []

        # Natural mortality: check_death on all living agents after tick
        for a in list(agents):
            if not a.alive: continue
            a.check_death()
            if not a.alive and a.id not in death_logged:
                death_logged.add(a.id)
                ledger.record(build_death_record(a, agents, tick, cause=getattr(a, '_death_cause', 'unknown')))
                psychology_mod.notify_death_to_population(a, agents, tick)

        # Feed — push subsistence events into agent.aux_events for info pipeline
        for a in [x for x in agents if x.alive]:
            for sub_ev in subsistence_world.agent_tick(a, tick, phase.name,
                                                        culture_pool=culture_pool,
                                                        faction_registry=faction_registry):
                d = serialize_event(sub_ev); d["salience"] = 0.52
                subsistence_world.record_event(sub_ev)
                persistence_ledger.record_event(d); event_log.append(d)
                _counters.record(d); _stream.write(d)
                # Wire into agent.aux_events so information.apply_tick can see it
                a.aux_events.append(sub_ev)

        # Resource transfers
        for a in [x for x in agents if x.alive]:
            nearby = spatial_world.nearby_agents(a, agents)
            for tev in apply_resource_transfers(
                    a, tick, phase.name, nearby,
                    random.Random(tick + hash(a.id) & 0xFFFF)):
                d = serialize_event(tev); d["salience"] = 0.72
                persistence_ledger.record_event(d); event_log.append(d)
                _counters.record(d); _stream.write(d)

        # Reproduction
        if tick % 25 == 0:
            newborns = reproduction_system.tick(
                agents, spatial_world, faction_registry,
                culture_pool, random.Random(tick*7),
                genpsych_ledger=genpsych_ledger, tick=tick, eco_health=_eco)
            for child in newborns:
                birth_parents = list(getattr(child, "_birth_parents", []))
                assign_child_context(child, birth_parents, tick, generational_ledger)
                init_innovation_agent(child); init_information_agent(child)
                init_governance_agent(child)
                init_spatial_for_agent(child, zone_grid)
                for p in birth_parents:
                    if p.id in agent_group:
                        agent_group[child.id] = agent_group[p.id]; break
            agents.extend(newborns)

        # Collect cooperation events from this tick for innovation diffusion
        coop_events_this_tick = [
            d for d in event_log[-2000:]
            if d.get("tick") == tick
            and d.get("event_type") == "interaction"
            and d.get("outcome") == "cooperation"
        ]

        apply_generational_tick(agents, tick, phase.name, generational_ledger)
        apply_apprenticeship_tick(agents, tick, phase.name, apprenticeship_ledger)
        apply_governance_tick(agents, tick, phase.name, governance_ledger, faction_registry)
        apply_innovation_tick(agents, tick, phase.name, innovation_engine,
                          cooperation_events=coop_events_this_tick)
        apply_information_tick(agents, tick, information_ledger)
        apply_storykeeper_transmission(agents, tick, phase.name,
                                       random.Random(tick+1), genpsych_ledger)
        apply_targeted_care_recovery(agents, tick, phase.name,
                                     random.Random(tick+2), genpsych_ledger)
        apply_institutional_memory_tick(agents, tick, phase.name,
                                        random.Random(tick+3), inst_mem_ledger,
                                        event_log, faction_registry)
        apply_population_viability_tick(agents, tick, phase.name,
                                        spatial_world, random.Random(tick+SEED))

        if tick % 10 == 0:
            lv = [a for a in agents if a.alive]
            pm = population_metrics(lv)
            tm = topology_metrics(lv, faction_registry, tick)
            metric_log.append({
                "tick": tick, "phase": phase.name,
                "alive_count": len(lv), **pm, **tm,
                "deaths": len(ledger.deaths),
                "births": sum(1 for a in agents if a.generation >= 1),
                "meme_count": len(culture_pool.memes),
                "factions": len(faction_registry.factions),
                "conflict_cumulative": _counters.conflict_total,
                "interaction_cumulative": _counters.interaction_total,
                "max_generation": max((a.generation for a in lv), default=0),
                **{f"alive_{gl}": sum(1 for a in lv if agent_group.get(a.id)==gl)
                   for gl in GROUP_LABELS},
            })

        if ckpt.should_write(tick):
            ckpt.write(tick, phase.name, agents, faction_registry,
                       institution_registry, culture_pool)

        if tick % SNAP_EVERY == 0:
            snapshot_report(tick, agents, ledger, culture_pool, faction_registry,
                            innovation_engine, _counters, agent_group,
                            event_log, zone_grid)

    # Outputs
    living_final = [a for a in agents if a.alive]
    (output_dir/"agents_final.json").write_text(
        json.dumps([a.snapshot() for a in agents], indent=2), encoding="utf-8")
    (output_dir/"deaths.json").write_text(
        json.dumps([__import__("dataclasses").asdict(d) if hasattr(d, "__dataclass_fields__") else d for d in ledger.deaths], indent=2), encoding="utf-8")
    (output_dir/"metrics.json").write_text(
        json.dumps(metric_log, indent=2), encoding="utf-8")
    (output_dir/"culture.json").write_text(
        json.dumps(culture_pool.snapshot(), indent=2), encoding="utf-8")
    (output_dir/"factions.json").write_text(
        json.dumps([{"id":f.id,"name":f.name,"members":f.members,"hostility":f.hostility}
                    for f in faction_registry.factions.values()], indent=2), encoding="utf-8")
    (output_dir/"innovation.json").write_text(
        json.dumps(innovation_engine.snapshot(), indent=2), encoding="utf-8")
    (output_dir/"group_map.json").write_text(
        json.dumps({aid: gl for aid, gl in agent_group.items()}, indent=2),
        encoding="utf-8")

    initial_ids = {a.id for a in agents if a.generation == 0}
    continuity_mod.build_continuity_outputs(
        output_dir, agents, event_log, initial_ids,
        culture_pool, faction_registry, generational_ledger)

    print(f"\n{'='*60}")
    print(f"  FINAL: {len(living_final)} alive after {TICKS} ticks")
    print(f"  Total ever: {len(agents)}")
    print(f"  Births: {sum(1 for a in agents if a.generation>=1)}")
    print(f"  Max gen: Gen{max((a.generation for a in living_final), default=0)}")
    print(f"  Conflict rate: {100*_counters.conflict_total/max(1,_counters.interaction_total):.2f}%")
    print(f"  Innovation: {innovation_engine.snapshot().get('summary',{}).get('total_successes',0)} successes")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
