from dataclasses import dataclass

@dataclass
class Phase:
    name: str
    stress_load: float
    scarcity: float
    conflict_pressure: float
    rest_quality: float
    novelty: float
    social_density: float

class EnvironmentCycle:
    def __init__(self):
        self.phases = [
            Phase('morning',0.08,0.20,0.10,0.20,0.25,0.55),
            Phase('work',0.18,0.32,0.18,0.05,0.35,0.70),
            Phase('evening',0.10,0.22,0.12,0.25,0.18,0.65),
            Phase('night',0.05,0.18,0.08,0.55,0.08,0.30),
        ]
    def get_phase(self, tick:int):
        return self.phases[tick % len(self.phases)]
