"""
context_adaptation.py — DAS v04.20.1 contextual adaptive-value layer.

This layer prevents fixed, civilization-smuggled behavior costs. It does not
say any behavior is inherently good or bad. It estimates how costly/useful a
behavior is under the society's current structure: institutional density,
trust/interdependence, scarcity, specialization, and local memory.
"""
from __future__ import annotations

from typing import Any, Dict, Optional


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(x)))


def _rel(agent, other):
    try:
        return agent.relationships.get(other.id)
    except Exception:
        return None


def compute_context(agent, other=None, phase=None, inst_suppression: float = 0.0) -> Dict[str, float]:
    """Return local adaptive-value context for an agent/action pair.

    Values are normalized 0..1 and intentionally approximate. They are not
    morality labels; they are pressure estimates.
    """
    state = agent.state
    rel = _rel(agent, other) if other is not None else None

    trust = float(getattr(rel, "trust", 0.50)) if rel else 0.50
    attachment = float(getattr(rel, "attachment", 0.00)) if rel else 0.00
    resentment = float(getattr(rel, "resentment", 0.00)) if rel else 0.00

    # System complexity: institutions + language + specialization + stable plans.
    institution_density = clamp(inst_suppression / 0.18)  # typical max suppression ~= 0.12–0.20
    specialization = clamp(getattr(state, "specialization_depth", 0.0))
    language = clamp(getattr(state, "linguistic_complexity", 0.0))
    planning = clamp(getattr(state, "plan_confidence", 0.5))
    system_complexity = clamp(
        institution_density * 0.38
        + specialization * 0.22
        + language * 0.20
        + planning * 0.10
        + trust * 0.10
    )

    # Immediate survival pressure makes short-horizon behaviors more adaptive.
    hunger = clamp(getattr(state, "hunger", 0.0))
    low_stock = clamp(1.0 - getattr(state, "resource_stock", 0.5))
    exhaustion = clamp(getattr(state, "exhaustion", 0.0))
    phase_stress = clamp(getattr(phase, "stress_load", 0.0)) if phase else 0.0
    scarcity_pressure = clamp(hunger * 0.35 + low_stock * 0.30 + exhaustion * 0.15 + phase_stress * 0.20)

    # Interdependence: how much the agent's future depends on stable relations.
    interdependence = clamp(
        trust * 0.30
        + attachment * 0.20
        + institution_density * 0.25
        + specialization * 0.15
        + language * 0.10
    )

    # Low-complexity scarcity can make coercive/competitive behavior locally useful.
    primitive_competition_window = clamp(scarcity_pressure * (1.0 - system_complexity) * (1.0 - interdependence * 0.45))

    # Complex/interdependent systems make destructive behavior more externally costly.
    systemic_fragility = clamp(system_complexity * 0.55 + interdependence * 0.35 + trust * 0.10)

    # Cooperation becomes more useful as interdependence rises; less immediate when survival pressure is acute.
    cooperation_utility = clamp(interdependence * 0.55 + system_complexity * 0.30 - scarcity_pressure * 0.10 + trust * 0.15)

    return {
        "system_complexity": round(system_complexity, 4),
        "institution_density": round(institution_density, 4),
        "scarcity_pressure": round(scarcity_pressure, 4),
        "interdependence": round(interdependence, 4),
        "primitive_competition_window": round(primitive_competition_window, 4),
        "systemic_fragility": round(systemic_fragility, 4),
        "cooperation_utility": round(cooperation_utility, 4),
        "relationship_trust": round(trust, 4),
        "relationship_resentment": round(resentment, 4),
    }


def interaction_pull_adjustments(context: Dict[str, float]) -> Dict[str, float]:
    """How context changes the usefulness of cooperation/conflict pulls."""
    primitive = context["primitive_competition_window"]
    fragility = context["systemic_fragility"]
    coop_utility = context["cooperation_utility"]
    scarcity = context["scarcity_pressure"]

    conflict_add = primitive * 0.16 + scarcity * 0.035
    conflict_subtract = fragility * 0.18
    cooperation_add = coop_utility * 0.14
    cooperation_subtract = primitive * 0.04

    return {
        "conflict_add": round(conflict_add, 4),
        "conflict_subtract": round(conflict_subtract, 4),
        "cooperation_add": round(cooperation_add, 4),
        "cooperation_subtract": round(cooperation_subtract, 4),
    }


def social_cost_multiplier(context: Optional[Dict[str, float]], outcome: str) -> float:
    """Cost multiplier for a social action under current structure.

    Conflict is not made universally expensive. It becomes more expensive as
    interdependence/complexity rise; under low-complexity scarcity its immediate
    social cost can be lower. Cooperation is cheaper in high-interdependence
    contexts and less efficient when survival pressure dominates.
    """
    if not context:
        return 1.0
    primitive = context.get("primitive_competition_window", 0.0)
    fragility = context.get("systemic_fragility", 0.0)
    coop_utility = context.get("cooperation_utility", 0.0)
    scarcity = context.get("scarcity_pressure", 0.0)

    if outcome == "conflict":
        return max(0.55, min(1.75, 0.82 + fragility * 0.75 - primitive * 0.38))
    if outcome == "cooperation":
        return max(0.55, min(1.35, 1.00 - coop_utility * 0.25 + scarcity * 0.18))
    return 1.0
