"""
experiential.py — v04.8 recovery / attractor texture layer
Adds persistent subjective texture without replacing the v04.6 proof metrics.

Core idea:
  Metrics say what happened.
  Experiential traces say what the world remembers.

This module is deterministic/stochastic local Python only. No LLM/API calls.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional
from schemas import new_id


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


@dataclass
class MemoryTrace:
    tick: int
    other_id: Optional[str]
    kind: str
    valence: float
    intensity: float
    phrase: str


@dataclass
class SymbolicArtifact:
    id: str
    tick: int
    label: str
    origin_agent: str
    kind: str
    valence: float
    strength: float = 0.50
    carriers: List[str] = field(default_factory=list)


class ExperientialMemory:
    """Per-agent subjective residue: grudges, attachments, scars, and remembered phrases."""
    def __init__(self) -> None:
        self.traces: List[MemoryTrace] = []
        self.grudges: Dict[str, float] = {}
        self.bonds: Dict[str, float] = {}
        # v04.9: edge birth ticks allow grudge/bond lifespan and half-life auditing.
        self.grudge_started_tick: Dict[str, int] = {}
        self.bond_started_tick: Dict[str, int] = {}
        self.scars: float = 0.0
        self.identity_tags: List[str] = []

    def add_trace(self, tick: int, other_id: Optional[str], kind: str,
                  valence: float, intensity: float, phrase: str) -> None:
        trace = MemoryTrace(tick, other_id, kind, round(valence, 4), round(intensity, 4), phrase)
        self.traces.append(trace)
        if len(self.traces) > 80:
            self.traces = self.traces[-80:]

        if other_id:
            if valence < -0.15:
                prior = self.grudges.get(other_id, 0.0)
                self.grudges[other_id] = clamp(prior + intensity * abs(valence) * 0.22)
                if prior <= 0.0 and self.grudges[other_id] > 0.0:
                    self.grudge_started_tick[other_id] = tick
                self.bonds[other_id] = clamp(self.bonds.get(other_id, 0.0) - intensity * 0.08)
            elif valence > 0.15:
                prior = self.bonds.get(other_id, 0.0)
                self.bonds[other_id] = clamp(prior + intensity * valence * 0.16)
                if prior <= 0.0 and self.bonds[other_id] > 0.0:
                    self.bond_started_tick[other_id] = tick
                self.grudges[other_id] = clamp(self.grudges.get(other_id, 0.0) - intensity * 0.06)

        if kind in ("conflict", "betrayal", "deception_detected"):
            self.scars = clamp(self.scars + intensity * 0.045)
        elif kind in ("cooperation", "negotiation_success", "ritual"):
            self.scars = clamp(self.scars - intensity * 0.018)

    def decay(self) -> None:
        for k in list(self.grudges):
            self.grudges[k] = clamp(self.grudges[k] * 0.994)  # v04.8: faster baseline cooling so recovery is possible
            if self.grudges[k] < 0.01:
                del self.grudges[k]
                self.grudge_started_tick.pop(k, None)
        for k in list(self.bonds):
            self.bonds[k] = clamp(self.bonds[k] * 0.999)
            if self.bonds[k] < 0.01:
                del self.bonds[k]
                self.bond_started_tick.pop(k, None)
        self.scars = clamp(self.scars * 0.9990)  # v04.8: scars still persist, but no longer freeze 500-tick runs

    def top_grudge(self):
        return max(self.grudges.items(), key=lambda kv: kv[1]) if self.grudges else None

    def top_bond(self):
        return max(self.bonds.items(), key=lambda kv: kv[1]) if self.bonds else None

    def snapshot(self) -> dict:
        return {
            "scars": round(self.scars, 4),
            "top_grudges": sorted(self.grudges.items(), key=lambda kv: kv[1], reverse=True)[:5],
            "top_bonds": sorted(self.bonds.items(), key=lambda kv: kv[1], reverse=True)[:5],
            "active_grudge_edges": [
                {"target": k, "strength": round(v, 4), "started_tick": self.grudge_started_tick.get(k)}
                for k, v in sorted(self.grudges.items(), key=lambda kv: kv[1], reverse=True)
            ],
            "active_bond_edges": [
                {"target": k, "strength": round(v, 4), "started_tick": self.bond_started_tick.get(k)}
                for k, v in sorted(self.bonds.items(), key=lambda kv: kv[1], reverse=True)
            ],
            "identity_tags": self.identity_tags[-6:],
            "recent_traces": [vars(t).copy() for t in self.traces[-8:]],
        }


class TextureChronicle:
    """World-level historical texture: episodes, artifacts, rituals, and named turning points."""
    def __init__(self) -> None:
        self.episodes: List[Dict] = []
        self.artifacts: Dict[str, SymbolicArtifact] = {}
        self.rituals: List[Dict] = []
        self.turning_points: List[Dict] = []
        self.reconciliation_events: List[Dict] = []
        self.negative_artifact_spread_events: List[Dict] = []
        # v04.9: prevent duplicate symbolic creation spam from the same origin/kind.
        self._artifact_cooldowns: Dict[tuple, int] = {}

    def record_episode(self, tick: int, kind: str, actors: List[str],
                       title: str, text: str, weight: float = 0.5, data: dict | None = None) -> None:
        ep = {
            "tick": tick,
            "kind": kind,
            "actors": actors,
            "title": title,
            "text": text,
            "weight": round(weight, 4),
            "data": data or {},
        }
        self.episodes.append(ep)
        if len(self.episodes) > 750:
            self.episodes = self.episodes[-750:]
        if weight >= 0.72:
            self.turning_points.append(ep)
            if len(self.turning_points) > 80:
                self.turning_points = self.turning_points[-80:]

    def maybe_create_artifact(self, tick: int, agent, event, rng) -> Optional[SymbolicArtifact]:
        # Artifacts are rare. They emerge from high-intensity conflict, repaired conflict,
        # or repeated cooperation under enough language/culture to symbolize it.
        lc = getattr(agent.state, "linguistic_complexity", 0.0)
        ca = getattr(agent.state, "cultural_alignment", 0.5)
        base = 0.0
        kind = None
        valence = 0.0
        if event.outcome == "conflict" and (agent.state.stress > 0.35 or agent.experience.scars > 0.20):
            base = 0.020 + lc * 0.020
            kind = "scar-marker"
            valence = -0.55
        elif event.context.get("negotiated"):
            base = 0.030 + lc * 0.035
            kind = "settlement-phrase"
            valence = 0.45
        elif event.outcome == "cooperation" and ca > 0.60:
            base = 0.012 + lc * 0.018
            kind = "custom"
            valence = 0.35

        if not kind or rng.random() > base:
            return None

        # v04.9 artifact logging fix: an artifact is a durable symbolic object, not
        # a per-interaction tick effect. Suppress repeated creation by the same
        # origin/kind while an existing artifact from that origin/kind is active.
        cooldown_key = (agent.id, kind)
        if tick < self._artifact_cooldowns.get(cooldown_key, -1):
            return None
        for existing in self.artifacts.values():
            if existing.origin_agent == agent.id and existing.kind == kind and existing.strength > 0.10:
                return None

        labels = {
            "scar-marker": ["the bitter mark", "the remembered slight", "the ash-token"],
            "settlement-phrase": ["the peace phrase", "the hand-sign", "the cooling words"],
            "custom": ["the sharing habit", "the common turn", "the quiet rule"],
        }
        label = rng.choice(labels[kind])
        artifact = SymbolicArtifact(
            id=new_id("artifact"), tick=tick, label=label,
            origin_agent=agent.id, kind=kind, valence=valence,
            strength=clamp(0.35 + lc * 0.35 + ca * 0.15), carriers=[agent.id]
        )
        self.artifacts[artifact.id] = artifact
        self._artifact_cooldowns[cooldown_key] = tick + 75
        self.record_episode(
            tick, "artifact_created", [agent.id],
            f"{agent.name} creates {label}",
            f"A {kind} forms after {event.outcome}; it begins carrying social meaning beyond the original interaction.",
            weight=artifact.strength,
            data={"artifact_id": artifact.id, "artifact_kind": kind, "valence": valence},
        )
        return artifact

    def spread_artifacts(self, tick: int, agents: list, rng) -> None:
        living = [a for a in agents if getattr(a, "alive", False)]
        if not living:
            return
        by_id = {a.id: a for a in living}
        for artifact in list(self.artifacts.values()):
            if artifact.strength < 0.05:
                continue
            artifact.strength = clamp(artifact.strength * 0.999)
            carriers = [by_id[c] for c in artifact.carriers if c in by_id]
            if not carriers:
                continue
            for carrier in carriers[:4]:
                if rng.random() > 0.012 * artifact.strength * (0.5 + carrier.state.social_openness):
                    continue
                target = rng.choice(living)
                if target.id not in artifact.carriers:
                    artifact.carriers.append(target.id)
                    target.experience.identity_tags.append(artifact.label)
                    target.experience.add_trace(tick, carrier.id, "artifact_received", artifact.valence, artifact.strength, artifact.label)
                    if artifact.valence < 0:
                        self.negative_artifact_spread_events.append({
                            "tick": tick,
                            "artifact_id": artifact.id,
                            "label": artifact.label,
                            "from": carrier.id,
                            "to": target.id,
                            "valence": artifact.valence,
                            "strength": round(artifact.strength, 4),
                        })

    def maybe_ritualize(self, tick: int, agents: list, rng) -> None:
        living = [a for a in agents if getattr(a, "alive", False)]
        if tick % 50 != 0 or tick == 0 or len(living) < 3:
            return
        avg_lc = sum(a.state.linguistic_complexity for a in living) / len(living)
        avg_ca = sum(a.state.cultural_alignment for a in living) / len(living)
        avg_scars = sum(a.experience.scars for a in living) / len(living)
        if avg_lc < 0.32 and avg_ca < 0.58:
            return
        if rng.random() > (0.08 + avg_lc * 0.10 + avg_ca * 0.08 + avg_scars * 0.05):
            return
        if avg_scars > 0.18:
            label = "grievance cooling rite"
            valence = 0.25
        elif avg_ca > 0.66:
            label = "sharing rite"
            valence = 0.45
        else:
            label = "naming rite"
            valence = 0.30
        participants = [a.id for a in rng.sample(living, min(len(living), rng.randint(3, 6)))]
        ritual = {"tick": tick, "label": label, "participants": participants, "valence": valence}
        self.rituals.append(ritual)
        # v04.8: rituals now feed back into recovery instead of only adding texture.
        # Grievance rites actively cool grudges and scars for participants; sharing rites
        # consolidate bonds. This is the attractor-recovery mechanism.
        reconciliation_delta = 0.0
        for a in living:
            if a.id in participants:
                a.experience.add_trace(tick, None, "ritual", valence, 0.55, label)
                a.state.stress = clamp(a.state.stress - 0.015)
                a.state.social_openness = clamp(a.state.social_openness + 0.006)
                if label == "grievance cooling rite":
                    before = sum(a.experience.grudges.values()) + a.experience.scars
                    for gid in list(a.experience.grudges):
                        a.experience.grudges[gid] = clamp(a.experience.grudges[gid] * 0.72)
                        if a.experience.grudges[gid] < 0.01:
                            del a.experience.grudges[gid]
                    a.experience.scars = clamp(a.experience.scars * 0.84)
                    a.relationships.cool_resentments(0.78)
                    a.state.cooperation = clamp(a.state.cooperation + 0.018)
                    after = sum(a.experience.grudges.values()) + a.experience.scars
                    reconciliation_delta += max(0.0, before - after)
                elif label == "sharing rite":
                    a.state.cooperation = clamp(a.state.cooperation + 0.012)
                    a.state.cultural_alignment = clamp(a.state.cultural_alignment + 0.008)
        if reconciliation_delta > 0:
            self.reconciliation_events.append({
                "tick": tick,
                "label": label,
                "participants": participants,
                "reconciliation_delta": round(reconciliation_delta, 4),
            })
        self.record_episode(
            tick, "ritual", participants, label,
            f"A repeated social act becomes recognizable as {label}; the group now has behavior that refers to its own history.",
            weight=0.68 + avg_lc * 0.12,
            data={"avg_lc": round(avg_lc, 4), "avg_cultural_alignment": round(avg_ca, 4), "avg_scars": round(avg_scars, 4)},
        )

    def snapshot(self) -> dict:
        return {
            "episodes": len(self.episodes),
            "artifacts": len(self.artifacts),
            "rituals": len(self.rituals),
            "turning_points": self.turning_points[-12:],
            "recent_episodes": self.episodes[-20:],
            "artifact_detail": [vars(a).copy() for a in self.artifacts.values()],
            "ritual_detail": self.rituals[-20:],
            "reconciliation_events": self.reconciliation_events[-40:],
            "negative_artifact_spread_events": self.negative_artifact_spread_events[-80:],
        }


def apply_experience_from_event(agent, other, event, tick: int, chronicle: TextureChronicle | None = None) -> None:
    """Update subjective memory from an interaction event."""
    # Import here to avoid circular imports at module load time
    import development as development_mod

    other_id = other.id if other else (event.participants[0] if event.participants else None)
    negotiated = bool(event.context.get("negotiated"))
    inst_prevented = bool(event.context.get("institution_prevented_conflict"))

    if event.outcome == "conflict":
        phrase = f"conflict with {getattr(other, 'name', other_id)}"
        agent.experience.add_trace(tick, other_id, "conflict", -0.55, 0.65 + agent.state.stress * 0.25, phrase)
        if chronicle and agent.experience.grudges.get(other_id, 0.0) > 0.35:
            chronicle.record_episode(
                tick, "grudge_hardens", [agent.id, other_id],
                f"{agent.name} hardens against {getattr(other, 'name', other_id)}",
                "A repeated negative memory becomes a durable social preference rather than a temporary reaction.",
                weight=agent.experience.grudges.get(other_id, 0.0),
            )
    elif negotiated:
        phrase = f"settled tension with {getattr(other, 'name', other_id)}"
        agent.experience.add_trace(tick, other_id, "negotiation_success", 0.45, 0.60, phrase)
    elif inst_prevented:
        phrase = "the institution absorbed the quarrel"
        agent.experience.add_trace(tick, other_id, "institutional_relief", 0.25, 0.40, phrase)
    elif event.outcome == "cooperation":
        phrase = f"worked with {getattr(other, 'name', other_id)}"
        agent.experience.add_trace(tick, other_id, "cooperation", 0.35, 0.45, phrase)

    # ── v04.31: developmental imprinting ─────────────────────────────────────
    # May permanently rewrite trait layer if agent is in a sensitive period.
    imprint = development_mod.maybe_imprint_from_event(agent, other, event, tick)
    if imprint and chronicle:
        stage = imprint.get("stage", "unknown")
        deltas = imprint.get("trait_deltas", {})
        if deltas:
            is_trauma = imprint.get("event_kind") in ("conflict", "grief", "deception_detected")
            episode_kind = "developmental_trauma" if is_trauma else "developmental_bonding"
            description = (
                f"{agent.name} experiences {'a formative wound' if is_trauma else 'a formative bond'} "
                f"during {stage} stage. Traits shift: "
                + ", ".join(f"{k} {'+' if v > 0 else ''}{v:.4f}" for k, v in deltas.items())
            )
            narrative = (
                "An event during a sensitive developmental window does not merely add stress — "
                "it rewrites the baseline from which all future reactions are measured."
                if is_trauma else
                "A sustained bond during a sensitive developmental window raises the floor "
                "of trust and resilience that the agent carries into adulthood."
            )
            chronicle.record_episode(
                tick, episode_kind, [agent.id] + ([other_id] if other_id else []),
                description, narrative,
                weight=imprint["plasticity"] * imprint["intensity"],
                data=imprint,
            )


def summarize_texture(agents: list, chronicle: TextureChronicle) -> dict:
    living = [a for a in agents if getattr(a, "alive", False)]
    if not living:
        return {"avg_scars": 0.0, "avg_grudges": 0.0, "avg_bonds": 0.0, "artifacts": len(chronicle.artifacts), "rituals": len(chronicle.rituals)}
    return {
        "avg_scars": round(sum(a.experience.scars for a in living) / len(living), 4),
        "avg_grudges": round(sum(sum(a.experience.grudges.values()) for a in living) / len(living), 4),
        "avg_bonds": round(sum(sum(a.experience.bonds.values()) for a in living) / len(living), 4),
        "agents_with_identity_tags": sum(1 for a in living if a.experience.identity_tags),
        "artifacts": len(chronicle.artifacts),
        "negative_artifacts": sum(1 for a in chronicle.artifacts.values() if a.valence < 0),
        "negative_artifact_carriers": sum(len(a.carriers) for a in chronicle.artifacts.values() if a.valence < 0),
        "negative_artifact_spread_events": len(chronicle.negative_artifact_spread_events),
        "rituals": len(chronicle.rituals),
        "reconciliation_events": len(chronicle.reconciliation_events),
        "reconciliation_delta": round(sum(e.get("reconciliation_delta", 0.0) for e in chronicle.reconciliation_events), 4),
        "episodes": len(chronicle.episodes),
        "turning_points": len(chronicle.turning_points),
    }
