from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
import uuid


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


@dataclass
class Event:
    tick: int
    phase: str
    actor_id: str
    event_type: str
    participants: List[str]
    context: Dict[str, Any]
    impact: Dict[str, float]
    outcome: str


@dataclass
class AgentState:
    energy: float = 0.70
    stress: float = 0.20
    curiosity: float = 0.50
    fear: float = 0.20
    cooperation: float = 0.50
    dominance: float = 0.50
    stability: float = 0.60
    social_openness: float = 0.50
    age: int = 0
    collapse_strikes: int = 0
    # Goals
    goal_satisfaction: float = 0.50
    # Resources
    resource_stock: float = 0.50
    # Planning
    plan_confidence: float = 0.50
    # Specialization
    specialization_depth: float = 0.00
    # Culture
    cultural_alignment: float = 0.50
    # Language
    linguistic_complexity: float = 0.10
    # v04.15 substrate pressures (0–1 scalars, observer-visible)
    status_security: float = 0.50    # perceived social standing; low → status threat → conflict pull
    novelty_saturation: float = 0.00 # accumulated novelty exposure; high → diminishing curiosity gain
    ideology_alignment: float = 0.50 # coherence with faction ideology; low → friction; high → cohesion
    # v04.20 constraint/survival state. These are pressure variables, not narrative labels.
    hunger: float = 0.10
    exhaustion: float = 0.10
    injury: float = 0.00
    # v04.30: unified affect scalar (-1.0 = distressed, +1.0 = flourishing)
    valence: float = 0.00
    safety: float = 0.70
    action_budget: float = 1.00
    movement_budget: float = 0.30
    social_budget: float = 0.35
    resource_budget: float = 0.25
    recovery_budget: float = 0.10
    care_burden: float = 0.00


@dataclass
class DevelopmentalTraits:
    stress_limit: float = 1.00
    recovery_speed: float = 0.05
    trust_baseline: float = 0.50
    conflict_sensitivity: float = 0.50
    risk_tolerance: float = 0.50
    attachment_rate: float = 0.05
    avoidance_rate: float = 0.05
    resilience: float = 0.50
    # Specialization capability family (mutates through pressure and practice).
    # Stored as functional domain, not era-specific occupation label.
    role: str = "generalist"          # generalist | subsistence | protection | coordination | diplomacy | craft | care | knowledge | logistics | governance | information
    # Reproduction fitness proxy
    generational_fitness: float = 0.50
    # Language aptitude
    language_aptitude: float = 0.50
    # v04.15: how strongly ideology_alignment shifts cooperation/conflict pull
    ideology_sensitivity: float = 0.50
    # v04.26a biological substrate
    physical_attractiveness: float = 0.50
    sexual_orientation: float = 0.12   # 0=opposite-sex, 1=same-sex, 0.5=bi
    biological_sex: str = "male"        # "male" | "female"


@dataclass
class RelationshipState:
    trust: float = 0.50
    avoidance: float = 0.00
    influence: float = 0.00
    attachment: float = 0.00
    resentment: float = 0.00
    interactions: int = 0
    # Alliance flag
    allied: bool = False


# ── Goal ────────────────────────────────────────────────────────────────────
@dataclass
class Goal:
    label: str              # "acquire_resource" | "dominate" | "bond" | "explore" | "survive"
    priority: float = 0.50  # 0–1 urgency
    progress: float = 0.00
    achieved: bool = False


# ── Resource ─────────────────────────────────────────────────────────────────
@dataclass
class ResourceNode:
    id: str
    x: int
    y: int
    stock: float = 1.00     # depletes on harvest
    regen_rate: float = 0.02


# ── Plan ─────────────────────────────────────────────────────────────────────
@dataclass
class Plan:
    steps: List[str]        # ordered action labels
    target_id: Optional[str] = None
    confidence: float = 0.50
    tick_created: int = 0
    completed: bool = False


# ── Faction ──────────────────────────────────────────────────────────────────
@dataclass
class Faction:
    id: str
    name: str
    members: List[str] = field(default_factory=list)
    resources: float = 0.00
    territory: List[tuple] = field(default_factory=list)   # list of (x,y) cells
    reputation: float = 0.50
    hostility: Dict[str, float] = field(default_factory=dict)  # faction_id -> hostility


# ── Institution ──────────────────────────────────────────────────────────────
@dataclass
class Institution:
    id: str
    name: str                           # "council" | "market" | "militia"
    rule: str                           # natural-language rule enforced
    members: List[str] = field(default_factory=list)
    strength: float = 0.50             # how effectively it enforces
    age: int = 0


# ── Culture meme ─────────────────────────────────────────────────────────────
@dataclass
class Meme:
    id: str
    label: str          # "cooperation_norm" | "distrust_outsiders" | "resource_sharing" …
    valence: float      # +1 prosocial, -1 antisocial
    spread_rate: float = 0.05
    strength: float = 0.50
    origin_tick: int = 0
