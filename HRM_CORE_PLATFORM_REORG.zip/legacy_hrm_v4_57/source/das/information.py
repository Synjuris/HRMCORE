"""
information.py — DAS v04.26b information propagation layer.

Makes information a first-class object that detaches from its source, travels
through the social graph along trust edges, degrades with each hop based on
the receiver's linguistic complexity, goes stale as the world changes, and
causes agents to act on things that are no longer true.

The gap between what is happening and what agents believe is happening is where
rumor, misinformation, delayed response, and eventually narrative emerge.

Core mechanics:
    Message         — discrete packet: content_type, fidelity, age, hop_count
    propagation     — travels along trust edges, blocked by high resentment
    fidelity decay  — each hop: reduced by (1 - avg_lc) * hop_decay_base
    staleness       — fidelity decays passively each tick with age
    belief update   — received messages update BeliefMemory at fidelity-scaled weight
    blocking        — resentment above threshold blocks transmission
    infrastructure  — dense settlement cells amplify propagation rate
    governance      — leader signals travel at full fidelity within radius,
                      degraded beyond
    sex asymmetry   — female agents transmit with lower fidelity loss (higher lc)

Message content types map to existing event categories. No new content invented.
Agents act on the most recent message per content_type, not ground truth.
"""
from __future__ import annotations

import random
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
from adaptive_roles import role_family


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(x)))


def _new_id() -> str:
    return f"msg_{uuid.uuid4().hex[:8]}"


# ── Config ────────────────────────────────────────────────────────────────────

@dataclass
class InformationConfig:
    # Fidelity
    fidelity_floor: float = 0.05
    hop_decay_base: float = 0.18        # fidelity lost per hop at zero language skill
    staleness_decay: float = 0.006      # fidelity lost per tick from age alone
    lc_fidelity_weight: float = 0.72    # how much avg lc reduces hop decay

    # Semantic rumor mutation
    # These do not create new architecture; they make existing payloads drift
    # through the same fidelity / urgency / credibility pathway already used by SRK.
    mutation_enabled: bool = True
    stress_threat_inflation: float = 0.32       # stress/fear inflates threat/scarcity payloads
    ideology_outgroup_amplifier: float = 0.24   # identity pressure amplifies hostile out-group framing
    lc_precision_loss: float = 0.38             # low language complexity coarsens numeric claims
    cross_faction_flip_base: float = 0.045      # hostile cross-faction relays may invert valence
    max_semantic_drift: float = 0.42            # per-hop payload drift cap

    # Propagation
    propagation_rate: float = 0.10      # base prob agent relays a message per tick
    trust_threshold: float = 0.38       # min trust to relay on an edge
    resentment_block: float = 0.62      # resentment above this blocks transmission
    max_hops: int = 8
    max_age_ticks: int = 90

    # Infrastructure amplification (from logistics layer)
    infra_propagation_bonus: float = 0.12

    # Belief update weights
    belief_weight_received: float = 0.30   # × fidelity applied to belief delta

    # Governance leader broadcast
    leader_broadcast_fidelity: float = 0.88
    leader_broadcast_radius_penalty: float = 0.07  # per cell beyond coord radius

    # Ledger
    max_messages_per_agent: int = 10
    max_ledger_events: int = 500


DEFAULT_CONFIG = InformationConfig()


# ── Message content types ─────────────────────────────────────────────────────
# Map directly to existing event/belief categories.
MESSAGE_TYPES = (
    "threat_near",        # conflict observed nearby
    "resource_available", # good harvest / surplus
    "resource_scarce",    # failed harvest / strain
    "safe_zone",          # sustained cooperation
    "leader_signal",      # governance coordination
    "specialist_present", # high-depth agent nearby
)


# ── Data structures ───────────────────────────────────────────────────────────

@dataclass
class Message:
    msg_id: str
    content_type: str
    source_id: str
    origin_tick: int
    fidelity: float         # [0,1] — accuracy remaining
    hop_count: int = 0
    last_sender_id: str = ""
    payload: Dict[str, float] = field(default_factory=dict)

    def is_viable(self, current_tick: int, cfg: InformationConfig) -> bool:
        age = current_tick - self.origin_tick
        return (self.fidelity >= cfg.fidelity_floor
                and self.hop_count <= cfg.max_hops
                and age <= cfg.max_age_ticks)

    def degrade(self, sender_lc: float, receiver_lc: float,
                cfg: InformationConfig) -> "Message":
        import copy
        avg_lc = (sender_lc + receiver_lc) / 2.0
        decay = cfg.hop_decay_base * (1.0 - avg_lc * cfg.lc_fidelity_weight)
        m = copy.copy(m := self)
        m = copy.copy(self)
        m.fidelity = clamp(self.fidelity - decay)
        m.hop_count = self.hop_count + 1
        return m

    def age_tick(self, cfg: InformationConfig) -> "Message":
        import copy
        m = copy.copy(self)
        m.fidelity = clamp(self.fidelity - cfg.staleness_decay)
        return m


class AgentInbox:
    """Per-agent inbox: one slot per content_type, plus relay buffer."""

    def __init__(self) -> None:
        self._latest: Dict[str, Message] = {}
        self._relay_buffer: List[Message] = []

    def receive(self, msg: Message, current_tick: int,
                cfg: InformationConfig) -> bool:
        if not msg.is_viable(current_tick, cfg):
            return False
        existing = self._latest.get(msg.content_type)
        # Accept if no existing or new has higher fidelity
        if existing is None or msg.fidelity > existing.fidelity * 0.85:
            self._latest[msg.content_type] = msg
            self._relay_buffer.append(msg)
            if len(self._relay_buffer) > cfg.max_messages_per_agent:
                self._relay_buffer = self._relay_buffer[-cfg.max_messages_per_agent:]
            return True
        return False

    def drain_relay(self) -> List[Message]:
        msgs = list(self._relay_buffer)
        self._relay_buffer = []
        return msgs

    def age_all(self, current_tick: int, cfg: InformationConfig) -> None:
        drop = []
        for ct, msg in self._latest.items():
            aged = msg.age_tick(cfg)
            if not aged.is_viable(current_tick, cfg):
                drop.append(ct)
            else:
                self._latest[ct] = aged
        for ct in drop:
            del self._latest[ct]

    def get(self, content_type: str) -> Optional[Message]:
        return self._latest.get(content_type)

    def snapshot(self) -> List[dict]:
        return [
            {
                "content_type": ct,
                "source_id": msg.source_id,
                "fidelity": round(msg.fidelity, 4),
                "hop_count": msg.hop_count,
                "origin_tick": msg.origin_tick,
            }
            for ct, msg in self._latest.items()
        ]


class InformationLedger:
    def __init__(self, cfg: InformationConfig = DEFAULT_CONFIG) -> None:
        self.cfg = cfg
        self.total_created: int = 0
        self.total_relayed: int = 0
        self.total_dropped: int = 0
        self.total_belief_updates: int = 0
        self.total_blocked: int = 0
        self.events: List[dict] = []

    def record(self, tick: int, event_type: str, actor_id: str,
               context: dict, outcome: str) -> None:
        self.events.append({
            "tick": tick, "event_type": event_type,
            "actor_id": actor_id, "context": context, "outcome": outcome,
        })
        if len(self.events) > self.cfg.max_ledger_events:
            self.events = self.events[-self.cfg.max_ledger_events:]

    def snapshot(self, agents: Optional[List[Any]] = None) -> dict:
        living = [a for a in agents if getattr(a, "alive", False)] if agents else []
        source_agents = living or (agents or [])
        inbox_sizes, fidelities = [], []
        for a in source_agents:
            inbox = getattr(a, "inbox", None)
            if inbox:
                msgs = list(inbox._latest.values())
                inbox_sizes.append(len(msgs))
                fidelities.extend(m.fidelity for m in msgs)
        if not fidelities and living and agents:
            inbox_sizes, fidelities = [], []
            for a in agents:
                inbox = getattr(a, "inbox", None)
                if inbox:
                    msgs = list(inbox._latest.values())
                    inbox_sizes.append(len(msgs))
                    fidelities.extend(m.fidelity for m in msgs)
        return {
            "summary": {
                "total_created": self.total_created,
                "total_relayed": self.total_relayed,
                "total_dropped": self.total_dropped,
                "total_blocked": self.total_blocked,
                "total_belief_updates": self.total_belief_updates,
                "avg_inbox_size": round(
                    sum(inbox_sizes) / len(inbox_sizes), 4) if inbox_sizes else 0.0,
                "avg_message_fidelity": round(
                    sum(fidelities) / len(fidelities), 4) if fidelities else 0.0,
            },
            "recent_events": self.events[-20:],
        }


# ── Message generation from events ───────────────────────────────────────────

def _source_credibility(agent: Any) -> float:
    """
    How credible is this agent as an information source?
    Specialist in domain > generalist. High lc > low lc. High legitimacy
    (if leader) adds authority multiplier.
    """
    lc     = agent.state.linguistic_complexity
    depth  = agent.state.specialization_depth
    trust_avg = 0.5
    rels = agent.relationships.snapshot()
    if rels:
        trust_avg = sum(r.get("trust", 0.5) for r in rels.values()) / len(rels)
    return clamp(lc * 0.45 + depth * 0.30 + trust_avg * 0.25)


def _urgency_weight(content_type: str) -> float:
    """
    Urgency multiplier for propagation rate and initial fidelity bonus.
    Threat travels fastest. Good news travels slowest.
    Matches biological reality: negative information has higher survival value.
    """
    return {
        "threat_near":        1.40,
        "resource_scarce":    1.20,
        "leader_signal":      1.10,
        "resource_available": 0.90,
        "specialist_present": 0.85,
        "safe_zone":          0.80,
    }.get(content_type, 1.00)


def messages_from_event(agent: Any, event: Any, tick: int,
                         cfg: InformationConfig) -> List[Message]:
    """
    Derive messages from an agent's event this tick.

    Fidelity is now a function of:
      - linguistic_complexity (expression ceiling)
      - source_credibility (specialist in domain gets bonus)
      - urgency (threat encodes with higher initial fidelity)

    Payload carries source_credibility so receivers can weight it.
    """
    lc = agent.state.linguistic_complexity
    if lc < 0.08:
        return []

    msgs    = []
    outcome = getattr(event, "outcome", "")
    ev_outcome = outcome  # alias for clarity below
    etype   = getattr(event, "event_type", "")
    cred    = _source_credibility(agent)
    sex     = getattr(agent, "biological_sex", "male")

    # Female agents encode social/relational signals with higher fidelity
    # due to higher social_openness and language aptitude
    social_bonus = 0.06 if sex == "female" else 0.0

    # Base fidelity: lc-driven + credibility contribution
    fid_base = clamp(lc * 0.72 + cred * 0.18 + 0.06)

    def make(ct: str, fid_mult: float, payload: dict) -> Message:
        urgency = _urgency_weight(ct)
        return Message(
            msg_id=_new_id(), content_type=ct,
            source_id=agent.id, origin_tick=tick,
            fidelity=clamp(fid_base * fid_mult * urgency),
            payload={**payload, "source_credibility": round(cred, 4)},
        )

    if outcome == "conflict":
        # Defenders encode threat with higher fidelity (domain expertise)
        role_bonus = 1.12 if role_family(agent.traits.role) == "protection" else 1.0
        msgs.append(make("threat_near", role_bonus,
                         {"threat_level": clamp(agent.state.stress * 0.6 + 0.35)}))

    elif outcome == "cooperation":
        # Diplomats encode safe_zone more accurately
        role_bonus = 1.10 if role_family(agent.traits.role) == "diplomacy" else 1.0
        msgs.append(make("safe_zone", role_bonus * (1.0 + social_bonus),
                         {"safety_level": clamp(agent.state.cooperation * 0.7 + 0.2)}))

    if etype in ("resource_action_cost", "gathering"):
        gained = (event.impact.get("resource_gain", 0.0)
                  if hasattr(event, "impact") else 0.0)
        # For gathering events, read food from impact dict
        if etype == "gathering" and gained == 0.0:
            gained = event.impact.get("food", 0.0) if hasattr(event, "impact") else 0.0
        # Gatherers encode resource signals with higher fidelity
        role_bonus = 1.15 if role_family(agent.traits.role) == "subsistence" else 1.0
        if gained > 0.04:
            msgs.append(make("resource_available", role_bonus * 0.88,
                             {"amount": clamp(gained)}))
        elif agent.state.resource_stock < 0.28:
            msgs.append(make("resource_scarce", role_bonus * 0.85,
                             {"scarcity": clamp(1.0 - agent.state.resource_stock)}))

    if (etype == "apprenticeship_formed"
            and agent.state.specialization_depth > 0.18):
        msgs.append(make("specialist_present", 0.90 + social_bonus,
                         {"depth": round(agent.state.specialization_depth, 4)}))

    # Hunt success: high-skill hunters emit specialist_present
    if etype == "hunt" and ev_outcome == "hunt_success":
        if agent.state.specialization_depth > 0.12:
            role_bonus = 1.10 if role_family(agent.traits.role) == "subsistence" else 1.0
            msgs.append(make("specialist_present", role_bonus * 0.75 + social_bonus,
                             {"depth": round(agent.state.specialization_depth, 4)}))

    return msgs


def leader_broadcast_messages(leader: Any, signal_type: str,
                               tick: int, followers: List[Any],
                               cfg: InformationConfig) -> List[Tuple[Any, Message]]:
    """
    Leader emits a coordination message to each follower.
    Fidelity degrades with distance beyond coordination_radius.
    """
    try:
        from governance import DEFAULT_CONFIG as GOV_CFG
        coord_radius = GOV_CFG.coordination_radius
    except Exception:
        coord_radius = 4

    lc = leader.state.linguistic_complexity
    base_fid = cfg.leader_broadcast_fidelity * (0.5 + lc * 0.5)
    pairs = []
    for follower in followers:
        dist = ((leader.position.x - follower.position.x) ** 2
                + (leader.position.y - follower.position.y) ** 2) ** 0.5
        penalty = max(0.0, dist - coord_radius) * cfg.leader_broadcast_radius_penalty
        fidelity = clamp(base_fid - penalty)
        if fidelity < cfg.fidelity_floor:
            continue
        msg = Message(
            msg_id=_new_id(), content_type="leader_signal",
            source_id=leader.id, origin_tick=tick,
            fidelity=fidelity,
            payload={"signal_type": 1.0},
        )
        pairs.append((follower, msg))
    return pairs



# ── Rumor mutation during retransmission ──────────────────────────────────────

def _state_float(agent: Any, names: Tuple[str, ...], default: float = 0.0) -> float:
    """Safely read an agent/state scalar without assuming one fixed schema."""
    state = getattr(agent, "state", None)
    for name in names:
        if state is not None and hasattr(state, name):
            try:
                return clamp(float(getattr(state, name)))
            except Exception:
                pass
        if hasattr(agent, name):
            try:
                return clamp(float(getattr(agent, name)))
            except Exception:
                pass
    return clamp(default)


def _ideology_strength(agent: Any) -> float:
    """Best-effort ideology / identity rigidity scalar. Missing fields resolve to 0."""
    return _state_float(agent, (
        "ideology_strength", "ideological_strength", "identity_rigidity",
        "identity_strength", "group_identity", "tribalism", "conviction",
    ), 0.0)


def _agent_faction_id(agent: Any, faction_registry: Any = None) -> Optional[str]:
    """Return a stable faction id if the current build exposes one."""
    if agent is None:
        return None
    for attr in ("faction_id", "group_id", "tribe_id", "clan_id"):
        val = getattr(agent, attr, None)
        if val is not None:
            return str(val)
    state = getattr(agent, "state", None)
    if state is not None:
        for attr in ("faction_id", "group_id", "tribe_id", "clan_id"):
            val = getattr(state, attr, None)
            if val is not None:
                return str(val)
    if faction_registry is not None:
        try:
            fac = faction_registry.faction_of(agent.id)
            if fac is not None:
                return str(getattr(fac, "id", fac))
        except Exception:
            pass
    return None


def _faction_hostility(a_id: Optional[str], b_id: Optional[str], faction_registry: Any = None) -> float:
    """Best-effort hostility lookup across several likely registry shapes."""
    if not a_id or not b_id or a_id == b_id or faction_registry is None:
        return 0.0
    for meth in ("hostility", "get_hostility", "relation_hostility", "get_relation"):
        fn = getattr(faction_registry, meth, None)
        if callable(fn):
            try:
                val = fn(a_id, b_id)
                if isinstance(val, dict):
                    val = val.get("hostility", val.get("resentment", 0.0))
                return clamp(float(val))
            except Exception:
                pass
    for attr in ("hostility", "hostilities", "relations", "faction_relations"):
        table = getattr(faction_registry, attr, None)
        if isinstance(table, dict):
            for key in ((a_id, b_id), (b_id, a_id), f"{a_id}:{b_id}", f"{b_id}:{a_id}"):
                if key in table:
                    val = table[key]
                    if isinstance(val, dict):
                        val = val.get("hostility", val.get("resentment", 0.0))
                    try:
                        return clamp(float(val))
                    except Exception:
                        pass
    return 0.0


def _coarsen_value(value: float, precision_loss: float) -> float:
    """
    Low linguistic complexity does not only reduce confidence; it reduces payload
    precision. Numeric claims become category-like approximations.
    """
    v = clamp(value)
    if precision_loss <= 0.12:
        return v
    if precision_loss < 0.32:
        step = 0.10
    elif precision_loss < 0.58:
        step = 0.20
    else:
        step = 0.34
    return clamp(round(v / step) * step)


def mutate_payload_for_relay(
    msg: Message,
    sender: Any,
    receiver: Any,
    cfg: InformationConfig,
    faction_registry: Any = None,
    rng: Optional[random.Random] = None,
) -> Message:
    """
    Mutate message payload at retransmission time.

    This is the surgical SRK divergence step: fidelity still degrades as before,
    but the actual semantic payload now drifts through transmitter state.
    """
    if not cfg.mutation_enabled:
        return msg
    if rng is None:
        rng = random

    import copy
    m = copy.copy(msg)
    payload = dict(msg.payload or {})

    stress = _state_float(sender, ("stress",), 0.0)
    fear = _state_float(sender, ("fear",), 0.0)
    urgency = _urgency_weight(msg.content_type) - 1.0
    ideology = _ideology_strength(sender)
    sender_lc = _state_float(sender, ("linguistic_complexity",), 0.5)
    precision_loss = clamp((1.0 - sender_lc) * cfg.lc_precision_loss)

    sender_faction = _agent_faction_id(sender, faction_registry)
    receiver_faction = _agent_faction_id(receiver, faction_registry)
    source_faction = None
    if faction_registry is not None:
        try:
            src_fac = faction_registry.faction_of(msg.source_id)
            if src_fac is not None:
                source_faction = str(getattr(src_fac, "id", src_fac))
        except Exception:
            pass
    cross_hostility = max(
        _faction_hostility(sender_faction, receiver_faction, faction_registry),
        _faction_hostility(sender_faction, source_faction, faction_registry),
    )
    outgroup_pressure = ideology * cross_hostility

    # Per-hop semantic drift is bounded so rumors mutate progressively rather
    # than exploding in one relay.
    drift = clamp(
        stress * cfg.stress_threat_inflation
        + fear * (cfg.stress_threat_inflation * 0.65)
        + max(0.0, urgency) * 0.10
        + outgroup_pressure * cfg.ideology_outgroup_amplifier,
        0.0,
        cfg.max_semantic_drift,
    )

    ct = msg.content_type

    if ct == "threat_near":
        base = payload.get("threat_level", 0.5)
        payload["threat_level"] = clamp(_coarsen_value(base * (1.0 + drift), precision_loss))

    elif ct == "resource_scarce":
        base = payload.get("scarcity", 0.5)
        payload["scarcity"] = clamp(_coarsen_value(base * (1.0 + drift * 0.85), precision_loss))

    elif ct == "resource_available":
        base = payload.get("amount", 0.5)
        # Anxiety compresses abundance claims; weak language coarsens the amount.
        payload["amount"] = clamp(_coarsen_value(base * (1.0 - drift * 0.55), precision_loss))

    elif ct == "safe_zone":
        base = payload.get("safety_level", 0.5)
        payload["safety_level"] = clamp(_coarsen_value(base * (1.0 - drift * 0.70), precision_loss))

    elif ct == "specialist_present":
        base = payload.get("depth", 0.5)
        payload["depth"] = clamp(_coarsen_value(base * (1.0 - precision_loss * 0.45), precision_loss))

    # Hostile cross-faction retransmission can invert valence, but only when the
    # transmitter is stressed/ideologically rigid enough for reinterpretation.
    flip_prob = clamp(
        cfg.cross_faction_flip_base
        * (0.35 + stress + fear + ideology)
        * (0.25 + cross_hostility),
        0.0,
        0.18,
    )
    if flip_prob > 0.0 and rng.random() < flip_prob:
        if ct == "safe_zone":
            m.content_type = "threat_near"
            payload = {
                "threat_level": clamp(0.35 + stress * 0.35 + cross_hostility * 0.30),
                "source_credibility": payload.get("source_credibility", 0.5),
            }
        elif ct == "resource_available":
            m.content_type = "resource_scarce"
            payload = {
                "scarcity": clamp(0.30 + fear * 0.30 + cross_hostility * 0.25),
                "source_credibility": payload.get("source_credibility", 0.5),
            }
        elif ct == "threat_near" and cross_hostility < 0.18 and stress < 0.25:
            # Rare calming reinterpretation among low-hostility contacts.
            m.content_type = "safe_zone"
            payload = {
                "safety_level": clamp(0.40 + sender_lc * 0.25 - fear * 0.15),
                "source_credibility": payload.get("source_credibility", 0.5),
            }

    mutation_count = int(payload.get("mutation_count", 0)) + 1
    payload["mutation_count"] = mutation_count
    payload["semantic_drift"] = round(clamp(payload.get("semantic_drift", 0.0) + drift), 4)
    payload["precision_loss"] = round(max(float(payload.get("precision_loss", 0.0)), precision_loss), 4)
    if cross_hostility > 0.0:
        payload["cross_faction_pressure"] = round(cross_hostility, 4)

    m.payload = payload
    return m


# ── Belief update from received message ───────────────────────────────────────

def _confirmation_bias(agent: Any, msg: Message) -> float:
    """
    Agents weight messages that confirm existing beliefs more heavily.
    Contradictory information is partially discounted.
    Returns a multiplier [0.4, 1.5].
    """
    b = agent.beliefs
    s = agent.state
    ct = msg.content_type

    if ct == "threat_near":
        # High-fear agent amplifies threat messages
        existing_threat = b.get_threat(msg.source_id)
        return clamp(0.7 + s.fear * 0.6 + existing_threat * 0.4, 0.4, 1.5)

    elif ct == "safe_zone":
        # Low-fear, high-cooperation agent amplifies safety messages
        existing_safety = b.get_safety(msg.source_id)
        return clamp(0.7 + (1.0 - s.fear) * 0.4 + existing_safety * 0.3, 0.4, 1.5)

    elif ct == "resource_scarce":
        # Hungry agent amplifies scarcity signals
        hunger = getattr(s, "hunger", 0.0)
        return clamp(0.7 + hunger * 0.7 + (1.0 - s.resource_stock) * 0.3, 0.4, 1.5)

    elif ct == "resource_available":
        # Well-fed agent discounts abundance signals; starving agent amplifies
        hunger = getattr(s, "hunger", 0.0)
        return clamp(0.5 + hunger * 0.8, 0.4, 1.3)

    elif ct == "leader_signal":
        # Cooperative, low-stress agents amplify leader signals
        return clamp(0.6 + s.cooperation * 0.5 + (1.0 - s.stress) * 0.3, 0.4, 1.4)

    return 1.0


def _sex_processing_bonus(agent: Any, content_type: str) -> float:
    """
    Sex-differentiated information processing.
    Female: better at social/relational signals (safe_zone, leader, specialist).
    Male: stronger response to threat signals (higher dominance amplifies threat).
    Returns additive multiplier.
    """
    sex = getattr(agent, "biological_sex", "male")
    if sex == "female":
        return 0.15 if content_type in ("safe_zone", "leader_signal",
                                         "specialist_present") else 0.0
    else:  # male
        return 0.12 if content_type == "threat_near" else 0.0


def _institutional_backing(agent: Any, msg: Message,
                             governance_ledger: Any = None,
                             faction_registry: Any = None) -> float:
    """
    Messages from current faction leaders get an institutional authority bonus.
    Scales with leader's legitimacy. Unaffiliated or low-legitimacy source = 1.0.
    """
    if governance_ledger is None or faction_registry is None:
        return 1.0
    try:
        faction = faction_registry.faction_of(msg.source_id)
        if faction is None:
            return 1.0
        rec = governance_ledger.leaders.get(faction.id)
        if rec is None or rec.in_governance_gap:
            return 1.0
        if rec.leader_id != msg.source_id:
            return 1.0
        # Source is an active leader — authority multiplier scales with legitimacy
        return clamp(1.0 + rec.legitimacy * 0.35, 1.0, 1.35)
    except Exception:
        return 1.0


def update_beliefs_from_message(agent: Any, msg: Message,
                                 cfg: InformationConfig,
                                 governance_ledger: Any = None,
                                 faction_registry: Any = None) -> None:
    """
    Apply a received message to agent's BeliefMemory.

    Effect weight is now a product of four factors:
      1. base belief weight × fidelity  (as before)
      2. source_credibility from payload (specialist > generalist)
      3. confirmation_bias  (amplifies confirming, discounts contradicting)
      4. sex_processing_bonus  (female better at social, male at threat)
      5. institutional_backing  (leader messages carry authority multiplier)

    Urgency is baked into fidelity at creation time — threat messages
    arrive with higher fidelity, so they naturally update beliefs more.
    """
    base_weight  = cfg.belief_weight_received * msg.fidelity
    cred         = msg.payload.get("source_credibility", 0.5)
    cred_mult    = clamp(0.7 + cred * 0.6)   # [0.7, 1.3]
    bias         = _confirmation_bias(agent, msg)
    sex_bonus    = _sex_processing_bonus(agent, msg.content_type)
    authority    = _institutional_backing(agent, msg, governance_ledger, faction_registry)

    weight = clamp(base_weight * cred_mult * bias * authority * (1.0 + sex_bonus), 0.0, 0.8)

    b = agent.beliefs
    s = agent.state

    if msg.content_type == "threat_near":
        threat = msg.payload.get("threat_level", 0.5)
        b.agent_threat[msg.source_id] = clamp(
            b.get_threat(msg.source_id) + threat * weight * 0.14)
        for pk in list(b.phase_risk.keys()):
            b.phase_risk[pk] = clamp(b.phase_risk[pk] + 0.007 * weight)
        s.stress = clamp(s.stress + 0.005 * weight)
        s.fear   = clamp(s.fear   + 0.004 * weight)

    elif msg.content_type == "safe_zone":
        safety = msg.payload.get("safety_level", 0.5)
        b.agent_safety[msg.source_id] = clamp(
            b.get_safety(msg.source_id) + safety * weight * 0.11)
        s.fear        = clamp(s.fear        - 0.004 * weight)
        s.cooperation = clamp(s.cooperation + 0.003 * weight)

    elif msg.content_type == "resource_available":
        s.stress = clamp(s.stress - 0.004 * weight)
        if hasattr(s, "hunger"):
            s.hunger = clamp(s.hunger - 0.003 * weight)

    elif msg.content_type == "resource_scarce":
        scarcity = msg.payload.get("scarcity", 0.5)
        s.stress = clamp(s.stress + 0.005 * weight * scarcity)
        if hasattr(s, "hunger"):
            s.hunger = clamp(s.hunger + 0.003 * weight * scarcity)

    elif msg.content_type == "leader_signal":
        s.cooperation = clamp(s.cooperation + 0.003 * weight)
        s.stability   = clamp(s.stability   + 0.002 * weight)

    elif msg.content_type == "specialist_present":
        s.social_openness = clamp(s.social_openness + 0.003 * weight)
        s.curiosity       = clamp(s.curiosity       + 0.002 * weight)


# ── Agent-level init ──────────────────────────────────────────────────────────

def init_agent(agent: Any) -> None:
    """Attach inbox. Idempotent."""
    if not hasattr(agent, "inbox"):
        agent.inbox = AgentInbox()
    if not hasattr(agent, "messages_received"):
        agent.messages_received = 0
    if not hasattr(agent, "messages_relayed"):
        agent.messages_relayed = 0


# ── Main per-tick world update ────────────────────────────────────────────────

def apply_tick(
    agents: List[Any],
    tick: int,
    ledger: InformationLedger,
    cfg: InformationConfig = DEFAULT_CONFIG,
    governance_ledger: Any = None,
    faction_registry: Any = None,
    logistics_world: Any = None,
    rng: Optional[random.Random] = None,
) -> List[Any]:
    """
    World-level information propagation update.
    Call after agent ticks so aux_events are populated.
    Returns list of notable Event objects.
    """
    from schemas import Event

    if rng is None:
        rng = random.Random(tick)

    events: List[Any] = []
    living = [a for a in agents if getattr(a, "alive", False)]

    # ── Step 1: age existing messages in all inboxes ──────────────────────────
    for agent in living:
        init_agent(agent)
        agent.inbox.age_all(tick, cfg)

    # ── Step 2: generate new messages from this tick's events ─────────────────
    for agent in living:
        main_event = None
        # Primary interaction event is the last non-aux event — look in aux_events
        # for the main interaction (event_type == "interaction")
        for ev in getattr(agent, "aux_events", []):
            if ev.event_type == "interaction":
                main_event = ev
                break
        if main_event is None and hasattr(agent, "_last_event"):
            main_event = agent._last_event

        if main_event is not None:
            new_msgs = messages_from_event(agent, main_event, tick, cfg)
            for msg in new_msgs:
                agent.inbox.receive(msg, tick, cfg)
                ledger.total_created += 1

        # Also scan aux_events for resource and specialist signals
        RESOURCE_EVENT_TYPES = (
            "resource_action_cost", "apprenticeship_formed",
            "gathering", "hunt",   # our subsistence event types
        )
        for ev in getattr(agent, "aux_events", []):
            if ev.event_type in RESOURCE_EVENT_TYPES:
                for msg in messages_from_event(agent, ev, tick, cfg):
                    agent.inbox.receive(msg, tick, cfg)
                    ledger.total_created += 1

    # ── Step 3: leader broadcasts ─────────────────────────────────────────────
    if governance_ledger and faction_registry:
        for faction_id, rec in governance_ledger.leaders.items():
            if rec.in_governance_gap:
                continue
            leader = next((a for a in living if a.id == rec.leader_id), None)
            if leader is None:
                continue
            # Get recent signal type from coordination events
            signal_type = "hold_position"
            for ev in getattr(leader, "aux_events", []):
                if ev.event_type == "coordination":
                    signal_type = ev.context.get("signal_type", "hold_position")
                    break
            faction = faction_registry.factions.get(faction_id)
            if not faction:
                continue
            followers = [a for a in living
                         if a.id in faction.members and a.id != leader.id]
            pairs = leader_broadcast_messages(leader, signal_type, tick,
                                              followers, cfg)
            for follower, msg in pairs:
                if follower.inbox.receive(msg, tick, cfg):
                    update_beliefs_from_message(follower, msg, cfg,
                        governance_ledger=governance_ledger,
                        faction_registry=faction_registry)
                    ledger.total_relayed += 1
                    ledger.total_belief_updates += 1

    # ── Step 4: peer-to-peer propagation ─────────────────────────────────────
    # Each agent considers relaying messages in their relay buffer to
    # nearby trusted agents.
    for agent in living:
        relay_msgs = agent.inbox.drain_relay()
        if not relay_msgs:
            continue

        sender_lc = agent.state.linguistic_complexity

        # Infrastructure bonus: denser cells propagate faster
        infra_bonus = 0.0
        if logistics_world is not None:
            try:
                cell = logistics_world.cell(agent.position)
                infra_bonus = cell.infrastructure * cfg.infra_propagation_bonus
            except Exception:
                pass

        # Find candidates: nearby agents with trust above threshold
        candidates = []
        for other in living:
            if other.id == agent.id:
                continue
            dist = ((agent.position.x - other.position.x) ** 2
                    + (agent.position.y - other.position.y) ** 2) ** 0.5
            if dist > 4.0:   # propagation radius — slightly wider than interaction
                continue
            rel = agent.relationships.snapshot().get(other.id, {})
            trust = rel.get("trust", 0.5)
            resentment = rel.get("resentment", 0.0)
            if trust < cfg.trust_threshold:
                continue
            if resentment >= cfg.resentment_block:
                ledger.total_blocked += 1
                continue
            candidates.append((trust, other))

        if not candidates:
            continue

        for msg in relay_msgs:
            if not msg.is_viable(tick, cfg):
                ledger.total_dropped += 1
                continue

            # Urgency-weighted relay gate: threat travels faster than good news
            urgency = _urgency_weight(msg.content_type)
            relay_prob = cfg.propagation_rate * urgency + infra_bonus
            if rng.random() > relay_prob:
                continue

            for trust, other in candidates:
                receiver_lc = other.state.linguistic_complexity
                degraded = msg.degrade(sender_lc, receiver_lc, cfg)
                degraded = mutate_payload_for_relay(
                    degraded, agent, other, cfg,
                    faction_registry=faction_registry, rng=rng,
                )
                degraded.last_sender_id = agent.id

                if not degraded.is_viable(tick, cfg):
                    ledger.total_dropped += 1
                    continue

                if other.inbox.receive(degraded, tick, cfg):
                    update_beliefs_from_message(other, degraded, cfg,
                        governance_ledger=governance_ledger,
                        faction_registry=faction_registry)
                    other.messages_received += 1
                    agent.messages_relayed  += 1
                    ledger.total_relayed    += 1
                    ledger.total_belief_updates += 1

                    # Record notable propagation: high-fidelity threat spreading
                    if (degraded.content_type == "threat_near"
                            and degraded.fidelity > 0.55
                            and degraded.hop_count >= 2):
                        events.append(Event(
                            tick=tick, phase="information",
                            actor_id=agent.id,
                            event_type="rumor_propagation",
                            participants=[other.id],
                            context={
                                "content_type": degraded.content_type,
                                "fidelity": round(degraded.fidelity, 4),
                                "hop_count": degraded.hop_count,
                                "origin": degraded.source_id,
                                "semantic_drift": degraded.payload.get("semantic_drift", 0.0),
                                "mutation_count": degraded.payload.get("mutation_count", 0),
                            },
                            impact={"belief_shift": round(
                                cfg.belief_weight_received * degraded.fidelity, 4)},
                            outcome="rumor_spread",
                        ))

    return events


# ── Benchmark metrics ─────────────────────────────────────────────────────────

def benchmark_metrics(ledger: InformationLedger,
                       agents: List[Any]) -> Dict[str, Any]:
    living = [a for a in agents if getattr(a, "alive", False)]
    source_agents = living or agents
    inbox_sizes = [len(getattr(a, "inbox", AgentInbox())._latest) for a in source_agents]
    fidelities = [
        msg.fidelity
        for a in source_agents
        for msg in getattr(a, "inbox", AgentInbox())._latest.values()
    ]
    # v04.39: if survivors have empty inboxes after active information exchange,
    # fall back to any remaining inbox state in the population so reporting does
    # not show a misleading 0.000 after hundreds of created/relayed messages.
    if not fidelities and living:
        source_agents = agents
        inbox_sizes = [len(getattr(a, "inbox", AgentInbox())._latest) for a in source_agents]
        fidelities = [
            msg.fidelity
            for a in source_agents
            for msg in getattr(a, "inbox", AgentInbox())._latest.values()
        ]
    return {
        "information_total_created": ledger.total_created,
        "information_total_relayed": ledger.total_relayed,
        "information_total_dropped": ledger.total_dropped,
        "information_total_blocked": ledger.total_blocked,
        "information_total_belief_updates": ledger.total_belief_updates,
        "information_avg_inbox_size": round(
            sum(inbox_sizes) / len(inbox_sizes), 4) if inbox_sizes else 0.0,
        "information_avg_fidelity": round(
            sum(fidelities) / len(fidelities), 4) if fidelities else 0.0,
        "information_rumor_events": sum(
            1 for e in ledger.events if e.get("event_type") == "rumor_propagation"),
    }
