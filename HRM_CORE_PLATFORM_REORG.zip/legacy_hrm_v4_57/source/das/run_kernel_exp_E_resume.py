"""
run_kernel_exp_E_resume.py — Experiment E resume through the kernel runtime.

K2-3A: Checkpoint loading is now kernel-native.
The kernel owns load, restore, tick loop, and all runtime logic.

Usage:
    python run_kernel_exp_E_resume.py
    python run_kernel_exp_E_resume.py --config configs/exp_E.json
    python run_kernel_exp_E_resume.py --from-tick 1500  (force start tick)
    python run_kernel_exp_E_resume.py --output /tmp/my_run
"""

import sys, argparse
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from kernel import (
    HRMRuntime, KernelConfig,
    register_standard_subsystems, setup_groups,
)
from kernel.checkpoint import KernelCheckpoint


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config",    default="configs/exp_E.json")
    parser.add_argument("--from-tick", type=int, default=None,
                        help="Force resume from this tick (default: auto from checkpoint)")
    parser.add_argument("--output",    default=None)
    args = parser.parse_args()

    cfg = KernelConfig.from_json(args.config)
    if args.output:
        cfg.output_root = args.output

    output_dir = cfg.output_path / "run_1"

    print(f"EXPERIMENT E RESUME (kernel) — {cfg.output_root}")

    rt = HRMRuntime(cfg)
    rt.build_world()
    register_standard_subsystems(rt)

    # ── Find and restore checkpoint ───────────────────────────────────────────
    cp_path = KernelCheckpoint.find_latest(output_dir)

    if cp_path and not args.from_tick:
        print(f"\nRestoring from: {cp_path.name}")
        start_tick = KernelCheckpoint.restore(cp_path, rt)
    elif args.from_tick:
        # Force a specific start tick — fresh agents, tick offset only
        print(f"\nForced start tick {args.from_tick} — running fresh agents from offset.")
        setup_groups(rt)
        start_tick = args.from_tick
    else:
        print("\nNo checkpoint found — starting fresh.")
        setup_groups(rt)
        start_tick = 1

    rt.registry.freeze()
    print(f"\nSystem registry:\n{rt.registry.summary()}\n")
    print(f"Resuming from tick {start_tick}...")
    rt.run(start_tick=start_tick)

    living = [a for a in rt.agents if a.alive]
    n_int  = max(rt._counters.interaction_total, 1)
    print(f"\n{'='*60}")
    print(f"  FINAL: {len(living)} alive")
    print(f"  Total ever: {len(rt.agents)}")
    print(f"  Deaths: {len(rt.ledger.deaths)}")
    print(f"  Conflict rate: {100*rt._counters.conflict_total/n_int:.2f}%")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
