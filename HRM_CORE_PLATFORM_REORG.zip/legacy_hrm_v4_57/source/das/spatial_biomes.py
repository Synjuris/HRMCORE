"""
Spatial biome layer for HRM civilization runs.
Maps grid positions to biome profiles that modify subsistence yields.
Each biome gives one group a resource advantage and a corresponding weakness.

Biome zones on a 40x40 grid:
  NW (0-19, 0-19): woodland  — good hunting, poor gathering
  NE (20-39, 0-19): meadow   — good gathering, poor hunting
  SW (0-19, 20-39): wetland  — excellent gathering, slow hunting
  SE (20-39, 20-39): savanna — excellent hunting (aurochs), poor gathering

Groups placed at:
  A=NW (10,10), B=NE (30,10), C=SW (10,30), D=SE (30,30)
"""

from dataclasses import dataclass
from typing import Tuple

@dataclass
class BiomeProfile:
    name: str
    gather_multiplier: float    # scales gather_chance and gained
    hunt_multiplier: float      # scales hunt_drive and success_p
    dominant_prey: str          # preferred fauna species
    fauna_density: float        # local fauna availability 0-1
    description: str

BIOMES = {
    "woodland": BiomeProfile(
        name="woodland",
        gather_multiplier=0.55,   # sparse plant food
        hunt_multiplier=1.45,     # excellent deer/boar
        dominant_prey="deer",
        fauna_density=1.35,
        description="Dense forest — hunters thrive, foragers struggle"
    ),
    "meadow": BiomeProfile(
        name="meadow",
        gather_multiplier=1.55,   # rich plant growth
        hunt_multiplier=0.60,     # open ground, prey flees easily
        dominant_prey="rabbits",
        fauna_density=0.75,
        description="Open meadow — foragers thrive, hunters struggle"
    ),
    "wetland": BiomeProfile(
        name="wetland",
        gather_multiplier=1.80,   # exceptional tubers, reeds, berries
        hunt_multiplier=0.50,     # boggy ground impedes hunting
        dominant_prey="rabbits",
        fauna_density=0.60,
        description="Wetland — exceptional foraging, poor hunting ground"
    ),
    "savanna": BiomeProfile(
        name="savanna",
        gather_multiplier=0.45,   # dry, sparse vegetation
        hunt_multiplier=1.65,     # aurochs herds, open sight lines
        dominant_prey="aurochs",
        fauna_density=1.50,
        description="Open savanna — elite hunters, foragers go hungry"
    ),
}

# Zone boundaries on 40x40 grid
ZONE_MAP = {
    "woodland": (0,  19, 0,  19),   # NW: x 0-19, y 0-19
    "meadow":   (20, 39, 0,  19),   # NE: x 20-39, y 0-19
    "wetland":  (0,  19, 20, 39),   # SW: x 0-19, y 20-39
    "savanna":  (20, 39, 20, 39),   # SE: x 20-39, y 20-39
}

def get_biome(x: int, y: int) -> BiomeProfile:
    """Return the biome profile for grid position (x, y)."""
    for biome_name, (x0, x1, y0, y1) in ZONE_MAP.items():
        if x0 <= x <= x1 and y0 <= y <= y1:
            return BIOMES[biome_name]
    return BIOMES["meadow"]  # default fallback

def apply_biome_to_subsistence(agent, gather_chance: float, hunt_drive: float,
                                gained: float, success_p: float
                                ) -> Tuple[float, float, float, float]:
    """
    Scale subsistence yields by the agent's current biome.
    Returns modified (gather_chance, hunt_drive, gained, success_p).
    """
    x = getattr(getattr(agent, 'position', None), 'x', 20)
    y = getattr(getattr(agent, 'position', None), 'y', 20)
    biome = get_biome(int(x), int(y))
    
    return (
        min(0.95, gather_chance * biome.gather_multiplier),
        min(0.95, hunt_drive   * biome.hunt_multiplier),
        gained    * biome.gather_multiplier,
        min(0.90, success_p   * biome.hunt_multiplier),
    )

def biome_summary(agents: list) -> dict:
    """Count living agents per biome."""
    counts = {b: 0 for b in BIOMES}
    for a in agents:
        if getattr(a, 'alive', False):
            x = getattr(getattr(a, 'position', None), 'x', 20)
            y = getattr(getattr(a, 'position', None), 'y', 20)
            biome = get_biome(int(x), int(y))
            counts[biome.name] = counts.get(biome.name, 0) + 1
    return counts


# ── Zone config backbone ───────────────────────────────────────────────────────
# Used by spatial_zone.py to determine biome per zone cell.
# get_biome(x, y) is the primary interface — returns BiomeProfile for any
# grid coordinate. spatial_zone.py samples zone center coordinates.

def zone_biome_label(cx: float, cy: float) -> str:
    """Return biome name string for zone center coordinate."""
    return get_biome(int(cx), int(cy)).name
