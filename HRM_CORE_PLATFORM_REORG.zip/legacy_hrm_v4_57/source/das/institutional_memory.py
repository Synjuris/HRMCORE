"""
institutional_memory.py — v04.36 institutional memory + cultural persistence

This layer closes the loop between recorded history and future behavior.
It does not hardcode era labels or fixed governments.  It observes repeated
social pressures, compresses them into collective memory anchors, lets
knowledge/information/care/governance role families preserve or distort those
anchors, and feeds the resulting cultural priors back into agents.

Design rules:
  - memories bend probabilities; they do not script destiny
  - institutions emerge from repeated social functions, not date/era labels
  - cultural divergence is faction/local-profile based, not racial/ethnic preset
  - knowledge can be preserved, distorted, or lost
"""
from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Any, Dict, Iterable, List, Optional, Tuple
import random

from schemas import Event, new_id
from adaptive_roles import role_family


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    try:
        return max(lo, min(hi, float(x)))
    except Exception:
        return lo


def _mean(xs: Iterable[float], default: float = 0.0) -> float:
    vals = list(xs)
    return sum(vals) / len(vals) if vals else default


def _agent_id(a: Any) -> str:
    return str(getattr(a, "id", "unknown"))


def _faction_id(faction_registry: Any, agent_id: str) -> str:
    if faction_registry is None:
        return "unaffiliated"
    try:
        f = faction_registry.faction_of(agent_id)
        return str(getattr(f, "id", None) or getattr(f, "name", None) or "unaffiliated")
    except Exception:
        return "unaffiliated"


def _event_dict(event: Event) -> Dict[str, Any]:
    return {
        "tick": event.tick,
        "phase": event.phase,
        "actor_id": event.actor_id,
        "event_type": event.event_type,
        "participants": list(event.participants),
        "context": dict(event.context),
        "impact": dict(event.impact),
        "outcome": event.outcome,
    }


def classify_memory_domain(ev: Dict[str, Any]) -> Optional[Tuple[str, float, str]]:
    """Map raw events into functional collective-memory domains.

    Returns (domain, valence, label).  Domains are behavioral pressures, not
    era-specific institutions.
    """
    et = str(ev.get("event_type", ""))
    outcome = str(ev.get("outcome", ""))
    ctx = ev.get("context", {}) if isinstance(ev.get("context"), dict) else {}
    impact = ev.get("impact", {}) if isinstance(ev.get("impact"), dict) else {}

    if et == "agent_death" or "death" in outcome:
        return ("mortality", -0.75, "remembered_loss")
    if outcome == "conflict" or et in ("conflict", "raid", "resource_conflict") or "conflict" in et:
        return ("threat", -0.55, "remembered_conflict")
    if et in ("oral_tradition_transmission", "cultural_memory_transmission"):
        if ctx.get("negative_memory") or ctx.get("memory_valence", 0.0) < 0:
            return ("warning", -0.35, "repeated_warning")
        return ("instruction", 0.30, "repeated_instruction")
    if et in ("targeted_care_recovery", "care_recovery", "healing") or "recovery" in et:
        return ("care", 0.45, "remembered_repair")
    if "birth" in et or "reproduction" in et:
        return ("continuity", 0.30, "remembered_continuity")
    if "hunt" in et or "subsistence" in et or "food" in outcome:
        hunger = float(impact.get("hunger", 0.0) or 0.0)
        if hunger > 0:
            return ("scarcity", -0.42, "remembered_scarcity")
        return ("subsistence", 0.25, "remembered_provision")
    if "institution" in et or "governance" in et or "leader" in et:
        return ("coordination", 0.25, "remembered_coordination")
    if "innovation" in et or "apprenticeship" in et or "knowledge" in et:
        return ("knowledge", 0.35, "remembered_skill")
    if "migration" in et or "territory" in et:
        return ("place", -0.10, "remembered_movement")
    return None


@dataclass
class CulturalMemoryAnchor:
    id: str
    domain: str
    label: str
    faction_id: str
    origin_tick: int
    last_reinforced_tick: int
    valence: float
    strength: float = 0.25
    preservation: float = 0.30
    distortion: float = 0.05
    transmissions: int = 0
    institutionalized: bool = False
    source_event_count: int = 1

    def reinforce(self, tick: int, valence: float, amount: float) -> None:
        self.last_reinforced_tick = tick
        self.valence = clamp((self.valence * self.source_event_count + valence) / (self.source_event_count + 1), -1.0, 1.0)
        self.source_event_count += 1
        self.strength = clamp(self.strength + amount, 0.0, 1.0)
        # Repeated reinforcement preserves a memory, but high negative load can distort it.
        self.preservation = clamp(self.preservation + amount * 0.35, 0.0, 1.0)
        if valence < -0.40:
            self.distortion = clamp(self.distortion + amount * 0.10, 0.0, 1.0)


@dataclass
class CulturalProfile:
    faction_id: str
    trust_prior: float = 0.50
    threat_prior: float = 0.20
    scarcity_prior: float = 0.20
    care_norm: float = 0.25
    knowledge_preservation: float = 0.20
    authority_tolerance: float = 0.25
    divergence_index: float = 0.00

    def as_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        for k, v in list(d.items()):
            if isinstance(v, float):
                d[k] = round(v, 4)
        return d


@dataclass
class ProtoInstitution:
    id: str
    function: str
    faction_id: str
    origin_tick: int
    strength: float = 0.20
    age: int = 0
    supporting_memory_ids: List[str] = field(default_factory=list)
    members_seen: List[str] = field(default_factory=list)

    def as_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["strength"] = round(self.strength, 4)
        return d


class InstitutionalMemoryLedger:
    def __init__(self) -> None:
        self.anchors: Dict[str, CulturalMemoryAnchor] = {}
        self.profiles: Dict[str, CulturalProfile] = {}
        self.proto_institutions: Dict[str, ProtoInstitution] = {}
        self.transmission_events: List[Dict[str, Any]] = []
        self.institution_events: List[Dict[str, Any]] = []
        self.regression_events: List[Dict[str, Any]] = []
        self._seen_event_keys: set = set()
        self._last_observed_tick: int = -1
        self.observed_events: int = 0
        self.memory_transmissions: int = 0
        self.institutions_stabilized: int = 0
        self.knowledge_loss_events: int = 0

    def profile(self, faction_id: str) -> CulturalProfile:
        fid = faction_id or "unaffiliated"
        if fid not in self.profiles:
            self.profiles[fid] = CulturalProfile(faction_id=fid)
        return self.profiles[fid]

    def observe_event(self, ev: Dict[str, Any], faction_id: str) -> None:
        tick = int(ev.get("tick", 0) or 0)
        key = (tick, ev.get("event_type"), ev.get("actor_id"), tuple(ev.get("participants") or []), ev.get("outcome"))
        if key in self._seen_event_keys:
            return
        self._seen_event_keys.add(key)
        classified = classify_memory_domain(ev)
        if not classified:
            return
        domain, valence, label = classified
        self.observed_events += 1
        anchor_key = f"{faction_id}:{domain}:{label}"
        if anchor_key not in self.anchors:
            self.anchors[anchor_key] = CulturalMemoryAnchor(
                id=new_id("mem"), domain=domain, label=label, faction_id=faction_id,
                origin_tick=tick, last_reinforced_tick=tick, valence=valence,
                strength=0.18 + min(0.20, abs(valence) * 0.18),
            )
        else:
            self.anchors[anchor_key].reinforce(tick, valence, amount=0.035 + abs(valence) * 0.025)
        self._update_profile_from_anchor(self.anchors[anchor_key])

    def observe_recent_events(self, event_log: List[Dict[str, Any]], faction_registry: Any) -> None:
        if not event_log:
            return
        for ev in event_log[-300:]:
            tick = int(ev.get("tick", 0) or 0)
            if tick < self._last_observed_tick - 1:
                continue
            actor = str(ev.get("actor_id") or "")
            fid = _faction_id(faction_registry, actor)
            self.observe_event(ev, fid)
        self._last_observed_tick = max(self._last_observed_tick, max(int(e.get("tick", 0) or 0) for e in event_log[-300:]))

    def _update_profile_from_anchor(self, anchor: CulturalMemoryAnchor) -> None:
        p = self.profile(anchor.faction_id)
        # Mean-reversion toward anchor signal: profiles move toward a target, never accumulate
        # Prevents saturation to 1.0 over long runs
        weight = clamp(anchor.strength * 0.08)
        if anchor.domain in ("threat", "warning", "mortality"):
            target_threat = clamp(0.20 + abs(anchor.valence) * 0.65)
            target_trust  = clamp(0.50 - abs(anchor.valence) * 0.35)
            p.threat_prior = clamp(p.threat_prior + (target_threat - p.threat_prior) * weight)
            p.trust_prior  = clamp(p.trust_prior  + (target_trust  - p.trust_prior)  * weight)
        elif anchor.domain in ("scarcity", "subsistence"):
            target = clamp(0.20 + (0.40 if anchor.valence < 0 else 0.10))
            p.scarcity_prior = clamp(p.scarcity_prior + (target - p.scarcity_prior) * weight)
        elif anchor.domain == "care":
            # Target care_norm based on how many care events this faction has actually
            # accumulated, not just anchor strength (which saturates quickly).
            # source_event_count reflects genuine care investment; cap target at 0.65.
            care_intensity = clamp(anchor.source_event_count / 800.0)  # 800 care events → max
            target_care  = clamp(0.25 + care_intensity * 0.40)
            target_trust = clamp(0.50 + care_intensity * 0.20)
            p.care_norm   = clamp(p.care_norm  + (target_care  - p.care_norm)  * weight)
            p.trust_prior = clamp(p.trust_prior + (target_trust - p.trust_prior) * weight * 0.5)
        elif anchor.domain in ("knowledge", "instruction"):
            target = clamp(0.20 + anchor.strength * 0.55)
            p.knowledge_preservation = clamp(p.knowledge_preservation + (target - p.knowledge_preservation) * weight)
        elif anchor.domain == "coordination":
            target = clamp(0.25 + anchor.strength * 0.40)
            p.authority_tolerance = clamp(p.authority_tolerance + (target - p.authority_tolerance) * weight)
        p.divergence_index = clamp(abs(p.trust_prior - 0.50) * 0.45 + p.threat_prior * 0.25 + p.scarcity_prior * 0.15 + p.knowledge_preservation * 0.15)

    def decay_and_loss(self, agents: List[Any], tick: int, rng: random.Random) -> List[Event]:
        events: List[Event] = []
        living = [a for a in agents if getattr(a, "alive", False)]
        knowledge_carriers = [a for a in living if role_family(getattr(getattr(a, "traits", None), "role", "")) in ("knowledge", "information")]
        carrier_factor = clamp(len(knowledge_carriers) / max(1, len(living)))
        for anchor in list(self.anchors.values()):
            age_gap = max(0, tick - anchor.last_reinforced_tick)
            if age_gap <= 0:
                continue
            preservation = clamp(anchor.preservation + carrier_factor * 0.35)
            decay = 0.0015 * (1.0 - preservation) + 0.0008 * anchor.distortion
            anchor.strength = clamp(anchor.strength - decay)
            if anchor.strength < 0.045 and rng.random() < 0.03:
                self.knowledge_loss_events += 1
                ev = Event(
                    tick=tick, phase="memory", actor_id="collective",
                    event_type="cultural_memory_loss",
                    participants=[],
                    context={"memory_id": anchor.id, "domain": anchor.domain, "faction_id": anchor.faction_id},
                    impact={"knowledge_preservation": -0.01, "memory_strength": -anchor.strength},
                    outcome="memory_regressed",
                )
                self.regression_events.append(_event_dict(ev))
                events.append(ev)
                del self.anchors[f"{anchor.faction_id}:{anchor.domain}:{anchor.label}"]
        return events

    def candidate_anchors(self, faction_id: str, limit: int = 4) -> List[CulturalMemoryAnchor]:
        anchors = [a for a in self.anchors.values() if a.faction_id in (faction_id, "unaffiliated") and a.strength > 0.10]
        anchors.sort(key=lambda a: (a.strength + a.preservation * 0.35 + a.source_event_count * 0.01), reverse=True)
        return anchors[:limit]

    def record_transmission(self, event: Event, anchor: CulturalMemoryAnchor) -> None:
        self.memory_transmissions += 1
        anchor.transmissions += 1
        anchor.preservation = clamp(anchor.preservation + 0.025)
        self.transmission_events.append(_event_dict(event))

    def stabilize_proto_institution(self, function: str, faction_id: str, anchor_ids: List[str], members: List[str], tick: int) -> Optional[ProtoInstitution]:
        key = f"{faction_id}:{function}"
        if key not in self.proto_institutions:
            inst = ProtoInstitution(id=new_id("pinst"), function=function, faction_id=faction_id, origin_tick=tick, supporting_memory_ids=anchor_ids[:6], members_seen=members[:24])
            self.proto_institutions[key] = inst
            self.institutions_stabilized += 1
            return inst
        inst = self.proto_institutions[key]
        inst.age += 1
        inst.strength = clamp(inst.strength + 0.018)
        for mid in members:
            if mid not in inst.members_seen and len(inst.members_seen) < 48:
                inst.members_seen.append(mid)
        for aid in anchor_ids:
            if aid not in inst.supporting_memory_ids:
                inst.supporting_memory_ids.append(aid)
        return None

    def snapshot(self) -> Dict[str, Any]:
        anchors = sorted(self.anchors.values(), key=lambda a: a.strength, reverse=True)
        return {
            "summary": {
                "observed_memory_events": self.observed_events,
                "active_memory_anchors": len(self.anchors),
                "memory_transmissions": self.memory_transmissions,
                "proto_institutions": len(self.proto_institutions),
                "institutions_stabilized": self.institutions_stabilized,
                "knowledge_loss_events": self.knowledge_loss_events,
                "avg_cultural_divergence": round(_mean(p.divergence_index for p in self.profiles.values()), 4) if self.profiles else 0.0,
            },
            "cultural_profiles": [p.as_dict() for p in self.profiles.values()],
            "memory_anchors": [asdict(a) for a in anchors[:250]],
            "proto_institutions": [i.as_dict() for i in self.proto_institutions.values()],
            "transmission_events": self.transmission_events[-250:],
            "institution_events": self.institution_events[-250:],
            "regression_events": self.regression_events[-250:],
        }


def _apply_profile_prior(agent: Any, profile: CulturalProfile, intensity: float) -> Dict[str, float]:
    before = {
        "fear": getattr(agent.state, "fear", 0.2),
        "trust_baseline": getattr(agent.traits, "trust_baseline", 0.5),
        "cooperation": getattr(agent.state, "cooperation", 0.5),
        "ideology_sensitivity": getattr(agent.traits, "ideology_sensitivity", 0.5),
        "resource_stock": getattr(agent.state, "resource_stock", 0.5),
    }
    agent.state.fear = clamp(agent.state.fear + (profile.threat_prior - 0.20) * 0.010 * intensity)
    agent.traits.trust_baseline = clamp(agent.traits.trust_baseline + (profile.trust_prior - 0.50) * 0.010 * intensity, 0.05, 0.95)
    agent.state.cooperation = clamp(agent.state.cooperation + (profile.care_norm - 0.25) * 0.007 * intensity)
    agent.traits.ideology_sensitivity = clamp(agent.traits.ideology_sensitivity + profile.divergence_index * 0.006 * intensity, 0.05, 0.95)
    # Scarcity memory causes mild storage orientation, not free resources.
    agent.state.resource_stock = clamp(agent.state.resource_stock + profile.scarcity_prior * 0.002 * intensity)
    after = {
        "fear": agent.state.fear,
        "trust_baseline": agent.traits.trust_baseline,
        "cooperation": agent.state.cooperation,
        "ideology_sensitivity": agent.traits.ideology_sensitivity,
        "resource_stock": agent.state.resource_stock,
    }
    return {k: round(after[k] - before[k], 5) for k in before if abs(after[k] - before[k]) > 0.00001}


def transmit_cultural_memory(agents: List[Any], tick: int, phase_name: str, rng: random.Random, ledger: InstitutionalMemoryLedger, faction_registry: Any = None) -> List[Event]:
    if tick % 18 != 0:
        return []
    living = [a for a in agents if getattr(a, "alive", False)]
    speakers = [a for a in living if role_family(getattr(getattr(a, "traits", None), "role", "")) in ("knowledge", "information", "governance", "care")]
    # In low-complexity societies, elders with language/scars can act as oral memory carriers.
    speakers.extend([a for a in living if getattr(getattr(a, "state", None), "age", 0) > 150 and getattr(getattr(a, "state", None), "linguistic_complexity", 0.0) > 0.35])
    seen = set()
    speakers = [a for a in speakers if not (_agent_id(a) in seen or seen.add(_agent_id(a)))]
    events: List[Event] = []
    for speaker in speakers[:8]:
        fid = _faction_id(faction_registry, speaker.id)
        anchors = ledger.candidate_anchors(fid, limit=3)
        if not anchors or rng.random() > 0.36:
            continue
        anchor = anchors[0]
        role = role_family(getattr(speaker.traits, "role", ""))
        skill = clamp(getattr(speaker.state, "linguistic_complexity", 0.1) * 0.35 + getattr(speaker.traits, "language_aptitude", 0.5) * 0.25 + getattr(speaker.state, "social_openness", 0.5) * 0.15 + (0.20 if role in ("knowledge", "information") else 0.08))
        intensity = clamp(anchor.strength * (0.45 + skill) * rng.uniform(0.65, 1.15))
        if intensity < 0.08:
            continue
        recipients = [a for a in living if a.id != speaker.id and abs(a.position.x - speaker.position.x) <= 2 and abs(a.position.y - speaker.position.y) <= 2]
        rng.shuffle(recipients)
        recipients = recipients[:5]
        if not recipients:
            continue
        profile = ledger.profile(fid)
        aggregate: Dict[str, float] = {}
        for r in recipients:
            susceptibility = clamp(getattr(r.state, "social_openness", 0.5) * 0.30 + getattr(r.traits, "ideology_sensitivity", 0.5) * 0.30 + getattr(r.traits, "language_aptitude", 0.5) * 0.20 + (1.0 - getattr(r.state, "stress", 0.2)) * 0.20)
            deltas = _apply_profile_prior(r, profile, intensity * susceptibility)
            for k, v in deltas.items():
                aggregate[k] = aggregate.get(k, 0.0) + v
            if hasattr(r, "experience"):
                r.experience.add_trace(tick, speaker.id, "cultural_memory", valence=anchor.valence, intensity=intensity * susceptibility, phrase=f"received {anchor.domain} memory")
        ev = Event(
            tick=tick,
            phase=phase_name,
            actor_id=speaker.id,
            event_type="cultural_memory_transmission",
            participants=[r.id for r in recipients],
            context={
                "memory_id": anchor.id,
                "domain": anchor.domain,
                "label": anchor.label,
                "faction_id": fid,
                "memory_valence": round(anchor.valence, 4),
                "strength": round(anchor.strength, 4),
                "speaker_role_family": role,
            },
            impact={k: round(v, 5) for k, v in aggregate.items()},
            outcome="collective_memory_operationalized",
        )
        events.append(ev)
        ledger.record_transmission(ev, anchor)
    return events


def stabilize_institutions_from_memory(agents: List[Any], tick: int, phase_name: str, rng: random.Random, ledger: InstitutionalMemoryLedger, faction_registry: Any = None) -> List[Event]:
    if tick % 30 != 0:
        return []
    living = [a for a in agents if getattr(a, "alive", False)]
    by_faction: Dict[str, List[Any]] = {}
    for a in living:
        by_faction.setdefault(_faction_id(faction_registry, a.id), []).append(a)
    events: List[Event] = []
    function_map = {
        "threat": "collective_defense",
        "warning": "risk_instruction",
        "mortality": "mortuary_ritual",
        "scarcity": "food_storage_norm",
        "subsistence": "subsistence_coordination",
        "care": "care_repair_practice",
        "knowledge": "teaching_lineage",
        "instruction": "teaching_lineage",
        "coordination": "dispute_coordination",
    }
    for fid, members in by_faction.items():
        if len(members) < 3:
            continue
        anchors = ledger.candidate_anchors(fid, limit=8)
        strong = [a for a in anchors if a.strength > 0.28 and a.source_event_count >= 2]
        if not strong:
            continue
        domains = {}
        for a in strong:
            domains.setdefault(a.domain, []).append(a)
        for domain, ds in domains.items():
            function = function_map.get(domain)
            if not function:
                continue
            # Repeated function + available role capacity = proto-institution.
            relevant_roles = {
                "collective_defense": ("protection", "governance", "coordination"),
                "risk_instruction": ("knowledge", "information", "governance"),
                "mortuary_ritual": ("care", "knowledge", "governance"),
                "food_storage_norm": ("subsistence", "logistics", "coordination"),
                "subsistence_coordination": ("subsistence", "coordination", "logistics"),
                "care_repair_practice": ("care", "diplomacy", "knowledge"),
                "teaching_lineage": ("knowledge", "information", "care"),
                "dispute_coordination": ("governance", "diplomacy", "coordination"),
            }.get(function, ("generalist",))
            capacity = [m for m in members if role_family(getattr(getattr(m, "traits", None), "role", "")) in relevant_roles]
            if len(capacity) < 1 or rng.random() > 0.45:
                continue
            inst = ledger.stabilize_proto_institution(function, fid, [a.id for a in ds], [m.id for m in capacity], tick)
            if inst is None:
                # Existing institution strengthens slowly through practice.
                continue
            # New proto-institution feeds back through behavior.
            for m in capacity:
                m.state.cooperation = clamp(m.state.cooperation + 0.012 * inst.strength)
                m.state.plan_confidence = clamp(m.state.plan_confidence + 0.010 * inst.strength)
                m.state.stability = clamp(m.state.stability + 0.008 * inst.strength)
            ev = Event(
                tick=tick,
                phase=phase_name,
                actor_id="collective",
                event_type="proto_institution_stabilized",
                participants=[m.id for m in capacity[:8]],
                context={"function": function, "faction_id": fid, "supporting_domains": [d.domain for d in ds], "proto_institution_id": inst.id},
                impact={"cooperation": round(0.012 * inst.strength, 5), "plan_confidence": round(0.010 * inst.strength, 5), "stability": round(0.008 * inst.strength, 5)},
                outcome="repeated_memory_became_social_function",
            )
            events.append(ev)
            ledger.institution_events.append(_event_dict(ev))
    return events


def apply_institutional_memory_tick(
    agents: List[Any],
    tick: int,
    phase_name: str,
    rng: random.Random,
    ledger: InstitutionalMemoryLedger,
    event_log: Optional[List[Dict[str, Any]]] = None,
    faction_registry: Any = None,
) -> List[Event]:
    """Single v04.36 tick integration point."""
    if event_log is not None:
        ledger.observe_recent_events(event_log, faction_registry)
    events: List[Event] = []
    events.extend(transmit_cultural_memory(agents, tick, phase_name, rng, ledger, faction_registry=faction_registry))
    events.extend(stabilize_institutions_from_memory(agents, tick, phase_name, rng, ledger, faction_registry=faction_registry))
    events.extend(ledger.decay_and_loss(agents, tick, rng))
    return events


def benchmark_metrics(ledger: Optional[InstitutionalMemoryLedger], agents: Optional[List[Any]] = None) -> Dict[str, Any]:
    if ledger is None:
        return {
            "institutional_memory_anchors": 0,
            "institutional_memory_transmissions": 0,
            "institutional_memory_proto_institutions": 0,
            "institutional_memory_loss_events": 0,
        }
    snap = ledger.snapshot()["summary"]
    out = {
        "institutional_memory_observed_events": snap["observed_memory_events"],
        "institutional_memory_anchors": snap["active_memory_anchors"],
        "institutional_memory_transmissions": snap["memory_transmissions"],
        "institutional_memory_proto_institutions": snap["proto_institutions"],
        "institutional_memory_loss_events": snap["knowledge_loss_events"],
        "institutional_memory_avg_divergence": snap["avg_cultural_divergence"],
    }
    if agents is not None:
        living = [a for a in agents if getattr(a, "alive", False)]
        out["institutional_memory_knowledge_carriers"] = sum(1 for a in living if role_family(getattr(getattr(a, "traits", None), "role", "")) in ("knowledge", "information"))
    return out
