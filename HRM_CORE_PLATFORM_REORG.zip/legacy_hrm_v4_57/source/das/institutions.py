"""
Institutions — Layer 8
Institutions emerge when enough agents within a faction converge on a norm.
Each institution has a rule label and enforcement strength.
Institutions suppress conflict within member groups, incentivize cooperation,
and tax member resources to fund collective action.
"""
from typing import Dict, List, Optional
from schemas import Institution, new_id


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


INSTITUTION_TYPES = {
    "council":  {"rule": "disputes_resolved_by_vote",     "cooperation_bonus": 0.04, "tax": 0.005},
    "market":   {"rule": "resource_exchange_standardized", "cooperation_bonus": 0.02, "tax": 0.008},
    "militia":  {"rule": "collective_defense_mandatory",   "cooperation_bonus": 0.01, "tax": 0.010},
}

FORM_THRESHOLD = 2     # v04.39: dyads can stabilize into proto-institutions
DISSOLVE_THRESHOLD = 0.12  # v04.39: small founder institutions persist through normal stress
MAX_INSTITUTIONS_PER_FACTION = 3  # v04.8 cap: prevents runaway institution stacks


class InstitutionRegistry:
    def __init__(self) -> None:
        self.institutions: Dict[str, Institution] = {}
        self._agent_institutions: Dict[str, List[str]] = {}  # agent_id -> [inst_id]

    def try_form(self, agents: list, faction_registry, tick: int, persistence_ledger=None) -> Optional[Institution]:
        """Scan factions; if cohesion is high enough, form an institution.

        v04.18: dissolved institution residue may reduce formation friction.
        This does not restore prior institutions; it only lowers member stress/energy cost.
        """
        for faction in faction_registry.factions.values():
            members = [a for a in agents if a.id in faction.members and a.alive]
            if len(members) < FORM_THRESHOLD:
                continue
            # Check average intra-faction trust
            trust_vals = []
            for a in members:
                for b in members:
                    if a.id == b.id:
                        continue
                    trust_vals.append(a.relationships.get(b.id).trust)
            if not trust_vals:
                continue
            avg_trust = sum(trust_vals) / len(trust_vals)
            formation_floor = 0.42 if len(members) <= 3 else 0.48
            # v04.39: institutions are no longer blocked until mature high-trust society exists.
            # Repeated coordination can crystallize earlier, then fail later if it cannot sustain itself.
            if avg_trust < formation_floor:
                continue
            # v04.8: cap institution stacking by faction, while still preventing exact duplicates.
            existing = [i for i in self.institutions.values() if set(i.members) == set(faction.members)]
            existing_for_faction = [i for i in self.institutions.values() if i.name.startswith(f"{faction.name}_")]
            if existing or len(existing_for_faction) >= MAX_INSTITUTIONS_PER_FACTION:
                continue
            # Pick institution type based on faction profile
            avg_dominance = sum(a.state.dominance for a in members) / len(members)
            avg_cooperation = sum(a.state.cooperation for a in members) / len(members)
            if avg_dominance > 0.60:
                itype = "militia"
            elif avg_cooperation > 0.55:
                itype = "council"
            else:
                itype = "market"
            cfg = INSTITUTION_TYPES[itype]
            # v04.18 functional legacy: strongest aligned dissolved residue near
            # the founder cell reduces the formation stress/energy cost.
            founder = members[0]
            cell = (founder.position.x, founder.position.y) if hasattr(founder, "position") else None
            legacy = persistence_ledger.get_reactivation_bonus(founder, cell, tick) if persistence_ledger else {"matched": False, "cost_multiplier": 1.0}
            cost_mult = float(legacy.get("cost_multiplier", 1.0))
            for m in members:
                m.state.energy = clamp(m.state.energy - 0.030 * cost_mult)
                m.state.stress = clamp(m.state.stress + 0.020 * cost_mult)
            inst = Institution(
                id=new_id("inst"),
                name=f"{faction.name}_{itype}",
                rule=cfg["rule"],
                members=[a.id for a in members],
                strength=0.30 + max(0.0, (avg_trust - formation_floor) * 0.35) + (0.04 if legacy.get("matched") else 0.0),
                age=0,
            )
            self.institutions[inst.id] = inst
            for a in members:
                self._agent_institutions.setdefault(a.id, []).append(inst.id)
            return inst
        return None

    def tick(self, agents: list) -> None:
        """Apply institution effects and handle dissolution."""
        agent_map = {a.id: a for a in agents}
        for iid, inst in list(self.institutions.items()):
            inst.age += 1
            members = [agent_map[mid] for mid in inst.members if mid in agent_map and agent_map[mid].alive]
            if not members:
                del self.institutions[iid]
                continue
            # Check cohesion
            trust_vals = []
            for a in members:
                for b in members:
                    if a.id != b.id:
                        trust_vals.append(a.relationships.get(b.id).trust)
            avg_trust = sum(trust_vals) / len(trust_vals) if trust_vals else (0.50 if inst.age >= 8 else 0.18)
            if avg_trust < DISSOLVE_THRESHOLD:
                # Dissolve
                for mid in inst.members:
                    if mid in self._agent_institutions:
                        self._agent_institutions[mid] = [
                            x for x in self._agent_institutions[mid] if x != iid
                        ]
                del self.institutions[iid]
                continue
            # Grow strength with trust
            inst.strength = clamp(inst.strength + (avg_trust - 0.46) * 0.012 + min(0.006, inst.age * 0.00003))
            # Apply effects
            itype_key = inst.name.split("_")[-1]
            cfg = INSTITUTION_TYPES.get(itype_key, INSTITUTION_TYPES["council"])
            for a in members:
                a.state.cooperation = clamp(a.state.cooperation + cfg["cooperation_bonus"] * inst.strength)
                a.state.resource_stock = clamp(a.state.resource_stock - cfg["tax"])

    def inst_conflict_suppression(self, agent_id: str,
                                    governance_ledger=None,
                                    faction_registry=None) -> float:
        """Returns conflict pressure reduction for institutional members.
        Scaled by backing leader legitimacy (v04.24): institutions without
        a legitimate leader are advisory only — strength still counts but
        at a reduced multiplier.
        """
        inst_ids = self._agent_institutions.get(agent_id, [])
        if not inst_ids:
            return 0.0
        total = sum(self.institutions[iid].strength
                    for iid in inst_ids if iid in self.institutions)
        base = clamp(total * 0.12)
        if governance_ledger is None or faction_registry is None:
            return base
        try:
            from governance import institution_legitimacy_multiplier
            faction = faction_registry.faction_of(agent_id)
            if faction is None:
                return base * 0.40
            mult = institution_legitimacy_multiplier(faction.id, governance_ledger)
            return clamp(base * mult)
        except Exception:
            return base

    def snapshot(self) -> list:
        return [
            {"id": i.id, "name": i.name, "rule": i.rule,
             "members": i.members, "strength": round(i.strength, 4), "age": i.age}
            for i in self.institutions.values()
        ]
