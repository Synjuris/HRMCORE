from schemas import RelationshipState


def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, float(x)))


class RelationshipBook:
    def __init__(self):
        self._rels = {}

    def get(self, other_id: str) -> RelationshipState:
        if other_id not in self._rels:
            self._rels[other_id] = RelationshipState()
        return self._rels[other_id]

    def update_after_interaction(self, other_id: str, trust_delta=0.0,
                                 resentment_delta=0.0,
                                 attachment_delta=0.0,
                                 influence_delta=0.0,
                                 avoidance_delta=0.0):
        """v04.37 compatibility repair.

        Agent.interact() has expected this method since earlier DAS builds, but
        the recovered v4.36 full package only contained the minimal get/snapshot
        RelationshipBook. Missing this method caused safe_agent_tick() to mark
        agents dead on their first real interaction, which produced the apparent
        population collapse. This method restores relationship mutation as a
        bounded causal update.
        """
        r = self.get(other_id)
        r.trust = clamp(getattr(r, 'trust', 0.5) + trust_delta)
        r.resentment = clamp(getattr(r, 'resentment', 0.0) + resentment_delta)
        r.attachment = clamp(getattr(r, 'attachment', 0.0) + attachment_delta)
        r.influence = clamp(getattr(r, 'influence', 0.0) + influence_delta)
        if hasattr(r, 'avoidance'):
            r.avoidance = clamp(getattr(r, 'avoidance', 0.0) + avoidance_delta)
        if hasattr(r, 'interactions'):
            r.interactions = int(getattr(r, 'interactions', 0)) + 1
        if hasattr(r, 'allied'):
            r.allied = bool(r.trust >= 0.62 and r.resentment <= 0.25 and r.attachment >= 0.10)
        return r


    def cool_resentments(self, factor: float = 0.9):
        """Decay resentment/avoidance across all relationships.

        Used by ritual/reconciliation systems. Restored in v04.37 because the
        recovered relationship book was too minimal for experiential systems.
        """
        for r in self._rels.values():
            r.resentment = clamp(getattr(r, 'resentment', 0.0) * factor)
            if hasattr(r, 'avoidance'):
                r.avoidance = clamp(getattr(r, 'avoidance', 0.0) * factor)
        return len(self._rels)

    def warm_trust(self, delta: float = 0.01):
        for r in self._rels.values():
            r.trust = clamp(getattr(r, 'trust', 0.5) + delta)
        return len(self._rels)

    def snapshot(self):
        return {k: vars(v).copy() for k, v in self._rels.items()}
