"""Stub for epochs module (v04.48 not present in this build)."""

def detect_epochs(metric_log, death_records=None):
    return []

def summarize_epochs(epochs):
    return {"epochs": [], "count": 0}
