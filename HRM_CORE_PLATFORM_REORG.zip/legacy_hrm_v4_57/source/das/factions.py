"""
Alliances / Factions — Layer 4
A FactionRegistry manages a set of Faction objects.
Agents join factions based on relationship trust.
Factions pool resources, share territory claims, and develop
inter-faction hostility that modulates conflict_pull during interactions.
"""
from typing import Dict, List, Optional
from schemas import Faction, new_id


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


FACTION_NAMES = ["Ravens", "Wolves", "Foxes", "Bears", "Owls"]
JOIN_TRUST_THRESHOLD = 0.68
SPLIT_RESENTMENT_THRESHOLD = 0.75


class FactionRegistry:
    def __init__(self) -> None:
        self.factions: Dict[str, Faction] = {}
        self._agent_faction: Dict[str, str] = {}   # agent_id -> faction_id

    def _name_iter(self):
        i = 0
        while True:
            yield FACTION_NAMES[i % len(FACTION_NAMES)] + (f"_{i // len(FACTION_NAMES)}" if i >= len(FACTION_NAMES) else "")
            i += 1

    def create_faction(self, founder_id: str) -> Faction:
        fid = new_id("faction")
        name = f"Faction_{len(self.factions) + 1}"
        f = Faction(id=fid, name=name, members=[founder_id])
        self.factions[fid] = f
        self._agent_faction[founder_id] = fid
        return f

    def faction_of(self, agent_id: str) -> Optional[Faction]:
        fid = self._agent_faction.get(agent_id)
        return self.factions.get(fid) if fid else None

    def same_faction(self, a_id: str, b_id: str) -> bool:
        fa = self._agent_faction.get(a_id)
        fb = self._agent_faction.get(b_id)
        return fa is not None and fa == fb

    def try_join(self, agent, other_agent) -> bool:
        """Agent considers joining other_agent's faction."""
        rel = agent.relationships.get(other_agent.id)
        if rel.trust < JOIN_TRUST_THRESHOLD:
            return False
        if agent.id in self._agent_faction:
            return False  # already in a faction
        target_faction = self.faction_of(other_agent.id)
        if target_faction is None:
            target_faction = self.create_faction(other_agent.id)
        target_faction.members.append(agent.id)
        self._agent_faction[agent.id] = target_faction.id
        # Mark alliance in relationship
        rel.allied = True
        return True

    def try_split(self, agent) -> bool:
        """Agent leaves faction when resentment with members is high."""
        faction = self.faction_of(agent.id)
        if faction is None or len(faction.members) <= 1:
            return False
        member_resentment = []
        for mid in faction.members:
            if mid != agent.id:
                r = agent.relationships.get(mid)
                member_resentment.append(r.resentment)
        if not member_resentment:
            return False
        avg_res = sum(member_resentment) / len(member_resentment)
        if avg_res >= SPLIT_RESENTMENT_THRESHOLD:
            faction.members.remove(agent.id)
            del self._agent_faction[agent.id]
            return True
        return False

    def inter_faction_hostility(self, a_id: str, b_id: str) -> float:
        """Returns [0,1] hostility modifier for cross-faction interactions."""
        fa = self.faction_of(a_id)
        fb = self.faction_of(b_id)
        if fa is None or fb is None or fa.id == fb.id:
            return 0.0
        return fa.hostility.get(fb.id, 0.15)

    def update_hostility(self, a_id: str, b_id: str, delta: float) -> None:
        fa = self.faction_of(a_id)
        fb = self.faction_of(b_id)
        if fa and fb and fa.id != fb.id:
            current = fa.hostility.get(fb.id, 0.15)
            fa.hostility[fb.id] = clamp(current + delta)

    def pool_resources(self, agents: list) -> None:
        """Each faction redistributes resources toward weakest member."""
        for faction in self.factions.values():
            members = [a for a in agents if a.id in faction.members and a.alive]
            if len(members) < 2:
                continue
            avg = sum(a.state.resource_stock for a in members) / len(members)
            for a in members:
                a.state.resource_stock = clamp(
                    a.state.resource_stock + (avg - a.state.resource_stock) * 0.10
                )

    def snapshot(self) -> list:
        return [
            {
                "id": f.id,
                "name": f.name,
                "members": f.members,
                "resources": round(f.resources, 4),
                "hostility": {k: round(v, 4) for k, v in f.hostility.items()},
            }
            for f in self.factions.values()
        ]

    def update_reputation(self, agents: list) -> None:
        """Update each faction's reputation from intra-faction conflict/coop rates this tick.
        Called once per tick by the runner after agent ticks complete.
        reputation drifts toward 1.0 when members cooperate, toward 0.0 when they conflict.
        """
        for faction in self.factions.values():
            members = {a.id: a for a in agents if a.id in faction.members and getattr(a, "alive", True)}
            if len(members) < 2:
                continue
            coop = 0; conflict = 0
            for a in members.values():
                for ev in getattr(a, "aux_events", []):
                    if not ev.participants:
                        continue
                    if ev.participants[0] not in members:
                        continue
                    if ev.event_type in ("interaction",):
                        if ev.outcome == "cooperation":
                            coop += 1
                        elif ev.outcome == "conflict":
                            conflict += 1
            total = coop + conflict
            if total == 0:
                continue
            target = coop / total  # 1.0 = all coop, 0.0 = all conflict
            faction.reputation = clamp(faction.reputation + (target - faction.reputation) * 0.05)
