"""
social_viability.py — v04.37 Social Viability + Population Stability Pass

This module repairs a runtime-level bottleneck exposed in v04.36: agents could
survive as isolated bodies long enough to log subsistence pressure, but social
contact, pair bonding, reproduction, and cultural systems rarely activated.

The fix is not a scripted civilization outcome. It supplies viability substrate:
settlement clustering, sex-balance safeguards, kin-band familiarity, cooperative
food sharing, low-population rendezvous behavior, and mortality buffers for
fragile founding populations. Advanced systems still have to emerge through
normal interactions and existing ledgers.
"""
from __future__ import annotations

import random
from typing import Any, Iterable, List

from schemas import Event


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(x)))


def _living(agents: Iterable[Any]) -> List[Any]:
    return [a for a in agents if getattr(a, 'alive', False)]


def seed_viable_founder_band(agents: List[Any], spatial_world=None, rng: random.Random | None = None) -> dict:
    """Prepare the initial population as a small founder band, not scattered dots.

    This preserves individual randomness but prevents the sim from starting with
    contact topology too sparse for relationships, care, birth, or institutions.
    """
    rng = rng or random.Random(43700)
    living = _living(agents)
    if not living:
        return {"seeded": 0, "male_count": 0, "female_count": 0}

    # Cluster founders in a loose camp so encounter topology exists from tick 1.
    if spatial_world is not None:
        cx = max(0, min(spatial_world.width - 1, spatial_world.width // 2))
        cy = max(0, min(spatial_world.height - 1, spatial_world.height // 2))
        offsets = [(0,0),(1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,-1),(1,-1),(-1,1),(2,0),(-2,0)]
        for i, a in enumerate(living):
            dx, dy = offsets[i % len(offsets)]
            a.position.x = max(0, min(spatial_world.width - 1, cx + dx))
            a.position.y = max(0, min(spatial_world.height - 1, cy + dy))

    # Founder viability: high enough resources/energy to allow social systems to
    # activate before winter/scarcity can wipe out the run.
    for a in living:
        s = a.state
        s.energy = clamp(max(getattr(s, 'energy', 0.0), 0.72))
        s.resource_stock = clamp(max(getattr(s, 'resource_stock', 0.0), 0.62))
        s.stress = clamp(min(getattr(s, 'stress', 0.0), 0.22))
        s.hunger = clamp(min(getattr(s, 'hunger', 0.0), 0.08))
        s.exhaustion = clamp(min(getattr(s, 'exhaustion', 0.0), 0.06))
        s.safety = clamp(max(getattr(s, 'safety', 0.0), 0.74))
        s.social_openness = clamp(max(getattr(s, 'social_openness', 0.0), 0.62))
        s.cooperation = clamp(max(getattr(s, 'cooperation', 0.0), 0.66))
        s.fear = clamp(min(getattr(s, 'fear', 0.0), 0.24))
        s.stability = clamp(max(getattr(s, 'stability', 0.0), 0.62))
        # Founders are reproductive-age adults; newborns remain age 0 through assign_child_context().
        s.age = max(getattr(s, 'age', 0), 220)
        setattr(a, 'social_viability_drive', 0.22)

    # Ensure founding population has at least one viable male/female pair.
    # This does not determine attraction or reproduction; it prevents random
    # initialization from making reproduction impossible before the run starts.
    males = [a for a in living if getattr(a, 'biological_sex', None) == 'male']
    females = [a for a in living if getattr(a, 'biological_sex', None) == 'female']
    if living and not males:
        living[0].biological_sex = 'male'
    if len(living) > 1 and not females:
        living[1].biological_sex = 'female'
    # With >=6 founders, keep a rough sex balance so stochastic collapse is less
    # dominated by the first roll of the biology module.
    if len(living) >= 6:
        for i, a in enumerate(living):
            a.biological_sex = 'male' if i % 2 == 0 else 'female'

    # Low-intensity familiarity between nearby founders. This is not forced pair
    # bonding; it gives first interactions enough prior trust to become causal.
    for i, a in enumerate(living):
        for b in living[i+1:]:
            if spatial_world is not None and spatial_world.distance(a.position, b.position) > max(2, getattr(spatial_world, 'interaction_radius', 2)):
                continue
            ar = a.relationships.get(b.id)
            br = b.relationships.get(a.id)
            ar.trust = clamp(max(ar.trust, 0.68))
            br.trust = clamp(max(br.trust, 0.68))
            ar.attachment = clamp(max(ar.attachment, 0.20))
            br.attachment = clamp(max(br.attachment, 0.20))
            ar.resentment = clamp(min(ar.resentment, 0.08))
            br.resentment = clamp(min(br.resentment, 0.08))

    males = [a for a in living if getattr(a, 'biological_sex', None) == 'male']
    females = [a for a in living if getattr(a, 'biological_sex', None) == 'female']
    return {"seeded": len(living), "male_count": len(males), "female_count": len(females)}


def apply_population_viability_tick(agents: List[Any], tick: int, phase_name: str, spatial_world=None, rng: random.Random | None = None) -> List[Event]:
    """Maintain enough social/ecological viability for civilization systems.

    Outputs normal inspectable events and modifies state only through generic
    survival/social support pressures: food sharing, rendezvous, infant/founder
    protection, and early pair-bond scaffolding.
    """
    rng = rng or random.Random(43700 + tick)
    living = _living(agents)
    events: List[Event] = []
    if not living:
        return events

    # When survivors are sparse, drift them toward a camp center to recover
    # encounter topology instead of letting isolated agents die silently.
    if spatial_world is not None and len(living) <= 6:
        cx = round(sum(a.position.x for a in living) / len(living))
        cy = round(sum(a.position.y for a in living) / len(living))
        for a in living:
            old = (a.position.x, a.position.y)
            if a.position.x < cx: a.position.x += 1
            elif a.position.x > cx: a.position.x -= 1
            if a.position.y < cy: a.position.y += 1
            elif a.position.y > cy: a.position.y -= 1
            if old != (a.position.x, a.position.y):
                setattr(a, 'social_viability_drive', clamp(getattr(a, 'social_viability_drive', 0.0) + 0.03, 0.0, 0.35))
                events.append(Event(tick, phase_name, a.id, 'rendezvous_movement', [], {'from': {'x': old[0], 'y': old[1]}, 'to': {'x': a.position.x, 'y': a.position.y}, 'living_count': len(living)}, {'social_contact_drive': 0.03}, 'moved_toward_band'))

    # Cooperative food buffering: surplus holders share tiny amounts with hungry
    # nearby agents. This does not create food; it redistributes within the band.
    donors = sorted([a for a in living if getattr(a.state, 'resource_stock', 0.0) > 0.58], key=lambda a: a.state.resource_stock, reverse=True)
    needy = [a for a in living if getattr(a.state, 'hunger', 0.0) > 0.26 or getattr(a.state, 'resource_stock', 0.0) < 0.20]
    for target in needy:
        donor = next((d for d in donors if d.id != target.id and (spatial_world is None or spatial_world.distance(d.position, target.position) <= max(3, getattr(spatial_world, 'interaction_radius', 2) + 1))), None)
        if not donor:
            continue
        amount = min(0.055, donor.state.resource_stock - 0.50)
        if amount <= 0:
            continue
        donor.state.resource_stock = clamp(donor.state.resource_stock - amount)
        target.state.resource_stock = clamp(target.state.resource_stock + amount)
        target.state.hunger = clamp(target.state.hunger - amount * 0.85)
        target.state.stress = clamp(target.state.stress - 0.008)
        donor.relationships.get(target.id).attachment = clamp(donor.relationships.get(target.id).attachment + 0.012)
        target.relationships.get(donor.id).trust = clamp(target.relationships.get(donor.id).trust + 0.018)
        events.append(Event(tick, phase_name, donor.id, 'cooperative_food_share', [target.id], {'amount': round(amount, 4)}, {'food': round(amount, 4), 'trust': 0.018}, 'shared_food'))

    # Mortality buffer for early founders/children. It does not prevent death in
    # severe collapse; it reduces runaway deaths from one overloaded pressure.
    for a in living:
        is_founder_window = tick < 180 and getattr(a, 'generation', 0) == 0
        is_child = getattr(a.state, 'age', 9999) < 260 or getattr(a, 'generation', 0) > 0
        if is_founder_window or is_child:
            a.state.exhaustion = clamp(a.state.exhaustion - 0.024)
            a.state.stress = clamp(a.state.stress - 0.009)
            a.state.energy = clamp(a.state.energy + 0.007)
            a.state.hunger = clamp(a.state.hunger - 0.006)
            # Emergency stabilization for fragile founder/child populations.
            # It prevents a single grief/stress cascade from deleting the social substrate.
            if len(living) <= 7 or tick < 320:
                if a.state.stress > 0.78:
                    a.state.stress = clamp(a.state.stress - 0.035)
                if a.state.energy < 0.28 and a.state.resource_stock > 0.08:
                    a.state.energy = clamp(a.state.energy + 0.018)
                    a.state.resource_stock = clamp(a.state.resource_stock - 0.010)
            # v04.38: if food exists, convert a small amount into energy so
            # survivors do not end every benchmark at 0 energy/0 libido while
            # hunger is already solved.
            if a.state.energy < 0.30 and a.state.resource_stock > 0.025:
                draw = min(0.030, a.state.resource_stock)
                a.state.resource_stock = clamp(a.state.resource_stock - draw)
                a.state.energy = clamp(a.state.energy + draw * 2.2)
            if a.state.hunger < 0.10 and a.state.energy < 0.16:
                a.state.energy = clamp(a.state.energy + 0.010)
            if getattr(a.state, 'collapse_strikes', 0) > 0 and a.state.stress < getattr(a.traits, 'stress_limit', 1.0):
                a.state.collapse_strikes = max(0, a.state.collapse_strikes - 1)

    # Create weak pair-bond runway for repeated high-trust opposite-sex nearby
    # pairs so reproduction can become possible through normal ReproductionSystem.
    if tick % 8 == 0:
        for i, a in enumerate(living):
            for b in living[i+1:]:
                if getattr(a, 'biological_sex', None) == getattr(b, 'biological_sex', None):
                    continue
                if spatial_world is not None and spatial_world.distance(a.position, b.position) > max(2, getattr(spatial_world, 'interaction_radius', 2)):
                    continue
                ar = a.relationships.get(b.id); br = b.relationships.get(a.id)
                if ar.trust > 0.36 and br.trust > 0.36:
                    ar.attachment = clamp(ar.attachment + 0.024)
                    br.attachment = clamp(br.attachment + 0.024)
                    a.state.social_openness = clamp(a.state.social_openness + 0.004)
                    b.state.social_openness = clamp(b.state.social_openness + 0.004)
                    events.append(Event(tick, phase_name, a.id, 'pair_bond_runway', [b.id], {'trust_a': round(ar.trust, 4), 'trust_b': round(br.trust, 4)}, {'attachment': 0.018}, 'attachment_increased'))
                    break
    return events


def viability_metrics(agents: List[Any]) -> dict:
    living = _living(agents)
    if not living:
        return {
            'viability_living_count': 0,
            'viability_male_count': 0,
            'viability_female_count': 0,
            'viability_avg_social_drive': 0.0,
            'viability_reproductive_pairs': 0,
        }
    males = [a for a in living if getattr(a, 'biological_sex', None) == 'male']
    females = [a for a in living if getattr(a, 'biological_sex', None) == 'female']
    pairs = 0
    for a in males:
        for b in females:
            ar = a.relationships.get(b.id); br = b.relationships.get(a.id)
            if ar.trust > 0.45 and br.trust > 0.45 and ar.attachment > 0.08 and br.attachment > 0.08:
                pairs += 1
    return {
        'viability_living_count': len(living),
        'viability_male_count': len(males),
        'viability_female_count': len(females),
        'viability_avg_social_drive': round(sum(getattr(a, 'social_viability_drive', 0.0) for a in living) / len(living), 4),
        'viability_reproductive_pairs': pairs,
    }
