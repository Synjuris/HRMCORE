"""
salience.py — v04.12 event salience filter

Defines what counts as worth storing in the full event log.
Scores every event at write time. Low-salience events are dropped
from the persistent log but still processed behaviorally.

Salience is not a behavioral mechanic — agents always process all events.
This only controls what hits disk.

Salience tiers:
  HIGH   (>= 0.7)  — always kept: conflict, deception, death, reconciliation,
                      first-conflict in a dyad, ritual, artifact creation
  MEDIUM (0.3–0.7) — kept in FULL mode, sampled in COMPACT mode
  LOW    (< 0.3)   — dropped in COMPACT mode: routine cooperation, solo events

Retention modes:
  full    — all events kept (debug / baseline)
  compact — only HIGH + sampled MEDIUM (production runs)
  audit   — only HIGH (post-hoc analysis)
"""

from typing import Dict, Optional

# Per-event-type base salience
_BASE: Dict[str, float] = {
    "interaction":                  0.20,   # routine; overridden by outcome below
    "deception":                    0.80,
    "negotiation":                  0.35,
    "artifact":                     0.50,
    "agent_death":                  1.00,
    "post_deception_conflict_check": 0.40,
    "solo":                         0.05,
}

# Outcome modifiers applied on top of base
_OUTCOME_MOD: Dict[str, float] = {
    "conflict":                     +0.50,
    "cooperation":                  -0.10,
    "deception_detected":           +0.20,
    "deception_success":            +0.10,
    "negotiation_success":          +0.15,
    "negotiation_failed":           +0.05,
    "artifact_created":             +0.00,
    "recover":                      -0.05,
    "explore":                      -0.05,
    "endure":                       -0.05,
}

SAMPLE_RATE_MEDIUM = 0.25   # fraction of MEDIUM events kept in compact mode


def score(event: dict, dyad_first_conflicts: Optional[set] = None) -> float:
    """
    Compute salience score for a serialized event dict.
    dyad_first_conflicts: set of dyad_keys that have already had their first conflict.
    If the event is the first conflict in a dyad, salience is forced HIGH.
    """
    etype = event.get("event_type", "")
    outcome = event.get("outcome", "")

    base = _BASE.get(etype, 0.20)
    mod = _OUTCOME_MOD.get(outcome, 0.0)
    s = min(1.0, base + mod)

    # First conflict in a dyad → HIGH regardless
    if etype == "interaction" and outcome == "conflict" and dyad_first_conflicts is not None:
        a = event.get("actor_id", "")
        parts = event.get("participants", [])
        b = parts[0] if parts else ""
        key = frozenset({a, b})
        if key not in dyad_first_conflicts:
            dyad_first_conflicts.add(key)
            s = 1.0

    # Institution-prevented conflict is noteworthy
    if etype == "interaction" and event.get("context", {}).get("institution_prevented_conflict"):
        s = max(s, 0.70)

    return round(s, 3)


def should_keep(salience: float, mode: str, rng=None) -> bool:
    """
    Decide whether to write the event to disk.
    mode: 'full' | 'compact' | 'audit'
    rng: random.Random instance (required for compact sampling)
    """
    if mode == "full":
        return True
    if mode == "audit":
        return salience >= 0.70
    # compact
    if salience >= 0.70:
        return True
    if salience >= 0.30:
        return rng is not None and rng.random() < SAMPLE_RATE_MEDIUM
    return False


def label(salience: float) -> str:
    if salience >= 0.70:
        return "HIGH"
    if salience >= 0.30:
        return "MEDIUM"
    return "LOW"
