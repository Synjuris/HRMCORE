"""
pressures.py — v04.15 substrate pressure modifiers

Three lightweight decision multipliers. Each adds a small scalar to the
existing cooperation_pull / raw_conflict_pull computation in agent.interact().

Design constraints:
  - Each modifier is capped so a ±10% parameter change produces < 3pp
    shift in conflict_per_100 (v04.12 sensitivity threshold).
  - All three combined at max effect must not exceed the faction_hostility
    contribution (~0.20 avg in conflict runs) to avoid dominating the signal.
  - Per-tick state updates are in apply_pressure_updates() called from
    adaptation.py's irreversible_update path.
  - All new fields (status_security, novelty_saturation, ideology_alignment)
    are observable scalars. They appear in metric snapshots and agent snapshots.
  - No new agent goals. No new trait mutations. No hardcoded reactions.

Calibration target:
  Peaceful runs: < 1pp shift in conflict_per_100
  Conflict runs: 1–3pp shift maximum
  Combined max pressure contribution to raw_conflict_pull: ~0.08
  (faction_hostility in conflict runs averages 0.20 — this is 40% of that)

Three pressures:

1. STATUS SECURITY
   state.status_security decays when an agent loses interactions (cooperation
   deficit) or when dominated in conflicts. Low status_security adds a small
   amount to raw_conflict_pull — the agent pushes back to restore standing.
   High status_security adds a small bonus to cooperation_pull.

   Decay: -0.008 per conflict received, +0.004 per cooperation initiated
   Contribution to conflict_pull: max 0.06 when status_security < 0.25
   Contribution to coop_pull: max 0.04 when status_security > 0.75

2. NOVELTY DECAY (saturation)
   state.novelty_saturation accumulates during novelty-phase ticks and from
   high-novelty interactions. High saturation reduces the curiosity boost from
   the novelty phase and slightly reduces social_openness (been-there effect).
   This is a diminishing-returns mechanic on exploration, not a punishment.

   Accumulation: +0.015 per novelty-phase tick, decays 0.3%/tick
   Effect: reduces env.novelty contribution to curiosity by saturation * 0.4
   No direct conflict_pull effect — operates through curiosity → goal weights

3. IDEOLOGY ALIGNMENT
   state.ideology_alignment tracks how coherent an agent's behavior is with
   its faction's dominant cooperation norm. Updated from cultural_alignment
   and faction membership. High alignment boosts cooperation_pull with
   faction-mates; low alignment adds friction to cross-faction cooperation.

   Update: nudged toward faction avg cultural_alignment each tick (±0.002)
   Effect on conflict_pull: misalignment with other faction adds
     traits.ideology_sensitivity * (1 - ideology_alignment) * 0.05
   Effect on coop_pull: alignment with same faction adds
     traits.ideology_sensitivity * ideology_alignment * 0.03

All effects are logged in event context under 'pressure_contributions'.
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from agent import Agent

# ── Constants ─────────────────────────────────────────────────────────────────

# Status security
STATUS_CONFLICT_DECAY   = 0.008   # lost per conflict received
STATUS_COOP_GAIN        = 0.004   # gained per cooperation initiated
STATUS_PASSIVE_RECOVERY = 0.001   # small per-tick drift toward 0.5
STATUS_MAX_CONFLICT_ADD = 0.06    # max contribution to raw_conflict_pull
STATUS_MAX_COOP_ADD     = 0.04    # max contribution to cooperation_pull

# Novelty saturation
NOVELTY_ACCUMULATE_RATE = 0.015   # per novelty-phase tick
NOVELTY_DECAY_RATE      = 0.003   # per tick (exponential)
NOVELTY_EFFECT_SCALE    = 0.40    # how much saturation reduces novelty gain

# Ideology alignment
IDEOLOGY_NUDGE_RATE     = 0.002   # per-tick pull toward faction mean
IDEOLOGY_CROSS_SCALE    = 0.05    # cross-faction friction multiplier
IDEOLOGY_INTRA_SCALE    = 0.03    # intra-faction cohesion multiplier


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


# ── Per-tick state updates ────────────────────────────────────────────────────

def update_status_security(agent: "Agent", last_outcome: str) -> None:
    """
    Called after each interaction event.
    last_outcome: 'conflict' | 'cooperation' | other
    """
    s = agent.state
    if last_outcome == "conflict":
        # Agent was in a conflict — perceived standing drops
        s.status_security = clamp(s.status_security - STATUS_CONFLICT_DECAY)
    elif last_outcome == "cooperation":
        # Successful cooperation — standing improves slightly
        s.status_security = clamp(s.status_security + STATUS_COOP_GAIN)
    # Passive drift toward neutral (0.5)
    s.status_security = clamp(
        s.status_security + STATUS_PASSIVE_RECOVERY * (0.5 - s.status_security)
    )


def update_novelty_saturation(agent: "Agent", phase_novelty: float) -> None:
    """
    Called each tick from adaptation path.
    phase_novelty: env.novelty value from current EnvironmentPhase (0–1).
    """
    s = agent.state
    # Accumulate during high-novelty phases
    if phase_novelty > 0.60:
        s.novelty_saturation = clamp(
            s.novelty_saturation + NOVELTY_ACCUMULATE_RATE * phase_novelty
        )
    # Always decay
    s.novelty_saturation = clamp(s.novelty_saturation * (1.0 - NOVELTY_DECAY_RATE))


def update_ideology_alignment(agent: "Agent", faction_registry) -> None:
    """
    Called each tick. Nudges ideology_alignment toward faction's avg cultural_alignment.
    """
    s = agent.state
    if not faction_registry:
        return
    faction = faction_registry.faction_of(agent.id)
    if not faction:
        # Factionless: drift toward neutral
        s.ideology_alignment = clamp(
            s.ideology_alignment + IDEOLOGY_NUDGE_RATE * (0.5 - s.ideology_alignment)
        )
        return
    # Use faction reputation as proxy for ideological coherence
    # (reputation is already updated by faction mechanics)
    target = clamp(faction.reputation)
    s.ideology_alignment = clamp(
        s.ideology_alignment + IDEOLOGY_NUDGE_RATE * (target - s.ideology_alignment)
    )


def apply_novelty_to_curiosity(agent: "Agent", phase_novelty: float) -> float:
    """
    Returns the effective novelty value after saturation dampening.
    Called in adaptation.apply_environment_to_state() path.
    """
    saturation = agent.state.novelty_saturation
    return phase_novelty * (1.0 - saturation * NOVELTY_EFFECT_SCALE)


# ── Interaction pull contributions ────────────────────────────────────────────

def status_conflict_contribution(agent: "Agent") -> float:
    """
    Low status_security → small addition to raw_conflict_pull.
    High status_security → small addition to cooperation_pull (returned as negative).
    Returns a signed float: positive = adds to conflict, negative = adds to coop.
    """
    ss = agent.state.status_security
    if ss < 0.40:
        # Status threat — pushes toward conflict
        threat_ratio = (0.40 - ss) / 0.40   # 0 at ss=0.40, 1 at ss=0.0
        return STATUS_MAX_CONFLICT_ADD * threat_ratio
    elif ss > 0.70:
        # Secure — cooperative pull bonus (returned as negative conflict contribution)
        secure_ratio = (ss - 0.70) / 0.30   # 0 at ss=0.70, 1 at ss=1.0
        return -(STATUS_MAX_COOP_ADD * secure_ratio)
    return 0.0


def ideology_pull_contributions(
    agent: "Agent",
    other: "Agent",
    same_faction: bool,
) -> tuple[float, float]:
    """
    Returns (conflict_add, coop_add) for this interaction based on ideology.
    conflict_add: added to raw_conflict_pull
    coop_add: added to cooperation_pull
    """
    agent_align  = agent.state.ideology_alignment
    other_align  = other.state.ideology_alignment
    sensitivity  = agent.traits.ideology_sensitivity

    if same_faction:
        # High alignment with faction-mate → cooperation pull bonus
        shared_align = (agent_align + other_align) / 2.0
        coop_add = sensitivity * shared_align * IDEOLOGY_INTRA_SCALE
        return 0.0, round(coop_add, 5)
    else:
        # Misalignment with other-faction agent → friction
        divergence = abs(agent_align - other_align)
        conflict_add = sensitivity * divergence * IDEOLOGY_CROSS_SCALE
        return round(conflict_add, 5), 0.0


def compute_pressure_contributions(
    agent: "Agent",
    other: "Agent",
    same_faction: bool,
) -> dict:
    """
    Compute all three pressure contributions for one interaction.
    Returns a dict with named components for event logging.
    """
    status_signed = status_conflict_contribution(agent)
    status_conflict = max(0.0, status_signed)
    status_coop     = max(0.0, -status_signed)

    ideol_conflict, ideol_coop = ideology_pull_contributions(agent, other, same_faction)

    # Novelty saturation has no direct pull contribution — it operates through
    # curiosity → goal weights → social_openness → choose_social_target.
    # Logged here for observability.

    return {
        "status_conflict_add":  round(status_conflict, 5),
        "status_coop_add":      round(status_coop, 5),
        "ideology_conflict_add": ideol_conflict,
        "ideology_coop_add":    ideol_coop,
        "novelty_saturation":   round(agent.state.novelty_saturation, 4),
        "status_security":      round(agent.state.status_security, 4),
        "ideology_alignment":   round(agent.state.ideology_alignment, 4),
        "total_conflict_add":   round(status_conflict + ideol_conflict, 5),
        "total_coop_add":       round(status_coop + ideol_coop, 5),
    }
