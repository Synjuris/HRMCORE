"""
run_sim.py — v04.20.1 contextual constraint/survival runner

v04.12 fixes (no behavioral changes):
  - Deception dedupe: bidirectional frozenset key replaces ordered tuple;
    tick registry injected into DeceptionModule before each tick loop
  - Event salience: all events scored at emit time; log filtered by retention mode
  - Attractor classification: rule-based via attractor.py, config-driven,
    adds 'collapse' state; thresholds calibrated to v04.10 baseline gaps
  - Interaction balance: sensitivity audit tool (interaction_balance.py)
  - Memory compression: agents retain first-contact + peak + recent N + HIGH salience;
    unbounded raw lists eliminated
  - Run manifest: manifest.json written at run start with full config snapshot
  - Baseline lock: benchmark_v04_12.json is the frozen comparison target

Previous version history preserved in CHANGELOG files.
"""
import argparse
import json
import os
import random
from pathlib import Path
from collections import defaultdict

from agent import Agent
from environment import EnvironmentCycle
from metrics import population_metrics, topology_metrics
from space import SpatialWorld

from resources import ResourceWorld
from factions import FactionRegistry
from territory import TerritoryMap
from institutions import InstitutionRegistry
from culture import CulturePool
from reproduction import ReproductionSystem
from language import WorldNarrative
from deception import DECEIVE_THRESHOLD
from experiential import TextureChronicle, summarize_texture
import attractor as attractor_mod
import salience as salience_mod
import manifest as manifest_mod
import psychology as psychology_mod
import continuity as continuity_mod
from checkpoint import CheckpointWriter
from death_ledger import DeathLedger, build_death_record
from observer_router import run_observer_pipeline
from persistence import PersistenceLedger
from scenario_profiles import load_scenario, apply_population_profile, scenario_agent_names, summarize_scenario_agents
from constraints import ConstraintLedger, snapshot_agents as constraint_snapshot
from generational import GenerationalLedger, apply_tick as apply_generational_tick, assign_child_context, summarize_generational_state, init_agent as init_generational_agent
from apprenticeship import ApprenticeshipLedger, apply_tick as apply_apprenticeship_tick, benchmark_metrics as apprenticeship_benchmark_metrics, init_agent as init_apprenticeship_agent
from logistics import LogisticsWorld
import biology as biology_mod
from biology import benchmark_metrics as biology_benchmark_metrics
from innovation import InnovationEngine, apply_tick as apply_innovation_tick, benchmark_metrics as innovation_benchmark_metrics, init_agent as init_innovation_agent
from harness import EventStream, RollingCounters, RunManifest, safe_agent_tick
RUN_MANIFEST: RunManifest = None  # initialized in main()
from information import InformationLedger, apply_tick as apply_information_tick, benchmark_metrics as information_benchmark_metrics, init_agent as init_information_agent
from governance import GovernanceLedger, apply_tick as apply_governance_tick, benchmark_metrics as governance_benchmark_metrics, init_agent as init_governance_agent
from subsistence import SubsistenceWorld, benchmark_metrics as subsistence_benchmark_metrics
from generational_psychology import GenerationalPsychologyLedger, apply_storykeeper_transmission, apply_targeted_care_recovery, benchmark_metrics as genpsych_benchmark_metrics
from institutional_memory import InstitutionalMemoryLedger, apply_institutional_memory_tick, benchmark_metrics as instmem_benchmark_metrics
from social_viability import seed_viable_founder_band, apply_population_viability_tick, viability_metrics
from settlements import SettlementLedger
import life_events as life_events_mod
from epochs import detect_epochs, summarize_epochs


def serialize_event(event):
    return {
        "tick": event.tick,
        "phase": event.phase,
        "actor_id": event.actor_id,
        "event_type": event.event_type,
        "participants": event.participants,
        "context": event.context,
        "impact": event.impact,
        "outcome": event.outcome,
    }


RUNS = int(os.environ.get("DAS_RUNS", "10"))
TICKS = int(os.environ.get("DAS_TICKS", "500"))
SCENARIO = os.environ.get("DAS_SCENARIO", "default")
SCENARIO_PROFILE = load_scenario(SCENARIO)
INITIAL_AGENTS = int(os.environ.get("DAS_INITIAL_AGENTS", str(SCENARIO_PROFILE.population.initial_agents)))
OUTPUT_ROOT = Path(os.environ.get("DAS_OUTPUT_ROOT", "runs_v04_41"))
BENCHMARK_FILE = Path(os.environ.get("DAS_BENCHMARK_FILE", "benchmark_v04_41.json"))
RETENTION_MODE = os.environ.get("DAS_RETENTION", "full")   # full | compact | audit
CHECKPOINT_INTERVAL = int(os.environ.get("DAS_CHECKPOINT_INTERVAL", "50"))

AGENT_NAMES = ["Ada", "Bruno", "Cleo", "Dax", "Eli",
               "Faye", "Gio", "Hana", "Ira", "Juno"]


# Attractor classification delegated to attractor.py (v04.12)
def classify_attractor(conflict_per_100):
    return attractor_mod.classify(conflict_per_100)

def attractor_switches(metric_log):
    return attractor_mod.switches(metric_log)



def conflict_localization_metrics(event_log, window_start: int, window_end: int) -> dict:
    conflicts = [
        e for e in event_log
        if e.get("event_type") == "interaction"
        and e.get("outcome") == "conflict"
        and window_start <= e.get("tick", -1) <= window_end
        and e.get("participants")
    ]
    if not conflicts:
        return {
            "conflict_localization_index_50": 0.0,
            "window_conflict_events_50": 0,
            "window_unique_conflict_dyads_50": 0,
        }
    dyads = defaultdict(int)
    for e in conflicts:
        dyad = tuple(sorted([e.get("actor_id"), e.get("participants", [None])[0]]))
        dyads[dyad] += 1
    top = max(dyads.values()) if dyads else 0
    return {
        "conflict_localization_index_50": round(top / len(conflicts), 4),
        "window_conflict_events_50": len(conflicts),
        "window_unique_conflict_dyads_50": len(dyads),
    }


def negative_artifact_clustering(texture_chronicle, agents, faction_registry) -> dict:
    living_by_id = {a.id: a for a in agents if a.alive}
    carrier_records = []
    cross_faction_artifacts = 0
    single_faction_artifacts = 0
    for artifact in texture_chronicle.artifacts.values():
        if artifact.valence >= 0:
            continue
        factions = set()
        carriers = []
        for cid in artifact.carriers:
            if cid not in living_by_id:
                continue
            f = faction_registry.faction_of(cid) if faction_registry else None
            fname = f.name if f else None
            factions.add(fname)
            carriers.append({"agent_id": cid, "faction": fname})
        live_factions = {f for f in factions if f is not None}
        if len(live_factions) > 1:
            cross_faction_artifacts += 1
        elif len(live_factions) == 1:
            single_faction_artifacts += 1
        carrier_records.append({
            "artifact_id": artifact.id,
            "label": artifact.label,
            "origin_agent": artifact.origin_agent,
            "carrier_count": len(carriers),
            "carrier_faction_count": len(live_factions),
            "cross_faction": len(live_factions) > 1,
            "carriers": carriers,
        })
    return {
        "negative_artifacts_cross_faction": cross_faction_artifacts,
        "negative_artifacts_single_faction": single_faction_artifacts,
        "negative_artifact_carrier_clusters": carrier_records,
    }

def _faction_name(faction_registry, agent_id):
    if not faction_registry:
        return None
    f = faction_registry.faction_of(agent_id)
    return f.name if f else None


def _dyad_key(a, b):
    return tuple(sorted([a, b]))


def dyad_persistence_metrics(event_log, agents, faction_registry, window_start=0, window_end=None, min_conflicts=3):
    """v04.10 dyad-level persistence instrumentation.

    Tracks cross-faction dyads as the unit of unresolved memory reinforcement.
    This is intentionally computed from the event stream so it is an audit layer,
    not a behavioral mechanic.
    """
    if window_end is None:
        window_end = 10**9
    by_id = {a.id: a for a in agents}
    stats = {}

    for e in event_log:
        if e.get("event_type") != "interaction" or not e.get("participants"):
            continue
        tick = e.get("tick", -1)
        if tick < window_start or tick > window_end:
            continue
        a_id = e.get("actor_id")
        b_id = e.get("participants", [None])[0]
        if a_id not in by_id or b_id not in by_id:
            continue
        fa = _faction_name(faction_registry, a_id)
        fb = _faction_name(faction_registry, b_id)
        if not fa or not fb or fa == fb:
            continue
        key = _dyad_key(a_id, b_id)
        rec = stats.setdefault(key, {
            "dyad": key,
            "factions": sorted([fa, fb]),
            "first_conflict_tick": None,
            "last_conflict_tick": None,
            "conflict_count": 0,
            "cooperation_count": 0,
            "distances": [],
        })
        d = e.get("context", {}).get("distance")
        if isinstance(d, (int, float)):
            rec["distances"].append(float(d))
        if e.get("outcome") == "conflict":
            rec["conflict_count"] += 1
            rec["first_conflict_tick"] = tick if rec["first_conflict_tick"] is None else min(rec["first_conflict_tick"], tick)
            rec["last_conflict_tick"] = tick if rec["last_conflict_tick"] is None else max(rec["last_conflict_tick"], tick)
        elif e.get("outcome") == "cooperation":
            rec["cooperation_count"] += 1

    dyads = []
    for key, rec in stats.items():
        if rec["conflict_count"] < min_conflicts or rec["first_conflict_tick"] is None:
            continue
        ids = list(key)
        a = by_id.get(ids[0]); b = by_id.get(ids[1])
        lifespan = max(1, rec["last_conflict_tick"] - rec["first_conflict_tick"])
        total = rec["conflict_count"] + rec["cooperation_count"]
        # Current grudge peak proxy: max current directed grudge strength between the pair.
        g1 = getattr(getattr(a, "experience", None), "grudges", {}).get(ids[1], 0.0) if a else 0.0
        g2 = getattr(getattr(b, "experience", None), "grudges", {}).get(ids[0], 0.0) if b else 0.0
        dyads.append({
            "dyad_id": f"{ids[0]}::{ids[1]}",
            "agents": ids,
            "agent_names": [getattr(a, "name", ids[0]) if a else ids[0], getattr(b, "name", ids[1]) if b else ids[1]],
            "faction_pair": rec["factions"],
            "first_conflict_tick": rec["first_conflict_tick"],
            "last_conflict_tick": rec["last_conflict_tick"],
            "lifespan_ticks": lifespan,
            "conflict_count": rec["conflict_count"],
            "cooperation_count": rec["cooperation_count"],
            "conflict_density": round(rec["conflict_count"] / lifespan, 4),
            "net_conflict_ratio": round(rec["conflict_count"] / total, 4) if total else None,
            "avg_resilience": round(((a.traits.resilience if a else 0.0) + (b.traits.resilience if b else 0.0)) / 2, 4),
            "spatial_proximity_mean": round(sum(rec["distances"]) / len(rec["distances"]), 4) if rec["distances"] else None,
            "grudge_at_peak": round(max(g1, g2), 4),
            "still_active_at_t250": bool(rec["first_conflict_tick"] <= 250 <= rec["last_conflict_tick"]),
        })

    dyads.sort(key=lambda d: (d["conflict_count"], d["lifespan_ticks"]), reverse=True)
    persistent = [d for d in dyads if d["conflict_density"] > 0.1 and d["lifespan_ticks"] > 50]
    seed_candidates = [d for d in dyads if d["lifespan_ticks"] > 100]
    seed = min(seed_candidates, key=lambda d: d["first_conflict_tick"]) if seed_candidates else None
    return {
        "top_conflict_dyads": dyads[:3],
        "attractor_seed_dyad": seed,
        "persistent_xf_dyad_count": len(persistent),
        "all_qualifying_xf_dyads": dyads,
    }


def dyad_snapshot_metrics(event_log, agents, faction_registry, window_start: int, window_end: int) -> dict:
    """Rolling/cumulative dyad metrics for per-10-tick snapshots."""
    window_conflicts = []
    by_id = {a.id: a for a in agents}
    for e in event_log:
        if e.get("event_type") != "interaction" or e.get("outcome") != "conflict" or not e.get("participants"):
            continue
        tick = e.get("tick", -1)
        if tick < window_start or tick > window_end:
            continue
        a_id = e.get("actor_id"); b_id = e.get("participants", [None])[0]
        if a_id not in by_id or b_id not in by_id:
            continue
        fa = _faction_name(faction_registry, a_id); fb = _faction_name(faction_registry, b_id)
        if fa and fb and fa != fb:
            window_conflicts.append(_dyad_key(a_id, b_id))
    dominant_share = 0.0
    if window_conflicts:
        counts = defaultdict(int)
        for d in window_conflicts:
            counts[d] += 1
        dominant_share = max(counts.values()) / len(window_conflicts)

    cumulative = dyad_persistence_metrics(event_log, agents, faction_registry, window_start=0, window_end=window_end, min_conflicts=3)
    return {
        "persistent_xf_dyad_count": cumulative["persistent_xf_dyad_count"],
        "dominant_dyad_share_50": round(dominant_share, 4),
        "window_xf_conflict_events_50": len(window_conflicts),
    }

def make_world_systems(seed: int):
    world_rng = random.Random(seed)
    scenario = SCENARIO_PROFILE
    env_cfg = scenario.environment
    spatial_world = SpatialWorld(width=env_cfg.world_width, height=env_cfg.world_height, interaction_radius=env_cfg.interaction_radius)
    resource_world = ResourceWorld(width=env_cfg.world_width, height=env_cfg.world_height, n_nodes=env_cfg.resource_nodes, rng=world_rng)
    faction_registry = FactionRegistry()
    territory_map = TerritoryMap(width=env_cfg.world_width, height=env_cfg.world_height)
    institution_registry = InstitutionRegistry()
    culture_pool = CulturePool()
    reproduction_system = ReproductionSystem(max_population=env_cfg.max_population)
    world_narrative = WorldNarrative()
    texture_chronicle = TextureChronicle()
    persistence_ledger = PersistenceLedger()
    env = EnvironmentCycle()
    # Scenario pressure biases alter phase parameters globally but do not script outcomes.
    for phase in env.phases:
        for attr, delta in env_cfg.phase_bias.items():
            if hasattr(phase, attr):
                setattr(phase, attr, max(0.0, min(1.0, getattr(phase, attr) + float(delta))))
    logistics_world = LogisticsWorld(spatial_world.width, spatial_world.height, seed=seed + 44000)
    subsistence_world = SubsistenceWorld(spatial_world.width, spatial_world.height, seed=seed + 43300)
    genpsych_ledger = GenerationalPsychologyLedger()
    institutional_memory_ledger = InstitutionalMemoryLedger()
    spatial_world.logistics_world = logistics_world
    resource_world.logistics_world = logistics_world
    settlement_ledger = SettlementLedger()
    return (spatial_world, resource_world, faction_registry,
            territory_map, institution_registry, culture_pool,
            reproduction_system, world_narrative, texture_chronicle, persistence_ledger, env, logistics_world, subsistence_world, genpsych_ledger, institutional_memory_ledger, settlement_ledger)


def make_agents(run_id: int, spatial_world, faction_registry, culture_pool):
    names = scenario_agent_names(SCENARIO_PROFILE.population)
    if INITIAL_AGENTS != len(names):
        names = [names[i] if i < len(names) else f"Agent_{i+1:02d}" for i in range(INITIAL_AGENTS)]
    agents = []
    for i, name in enumerate(names):
        agent = Agent(name, seed=i + 1 + run_id * 100,
              spatial_world=spatial_world,
              faction_registry=faction_registry,
              culture_pool=culture_pool)
        apply_population_profile(agent, i, len(names), SCENARIO_PROFILE.population, world=spatial_world, seed=run_id * 10000)
        agents.append(agent)
    return agents


def run_single_sim(run_id: int):
    output_dir = OUTPUT_ROOT / f"run_{run_id}"
    output_dir.mkdir(parents=True, exist_ok=True)
    # Write manifest at run start — before any sim logic
    manifest_mod.write(
        output_dir, run_id=run_id, seed=run_id, ticks=TICKS,
        scenario=SCENARIO_PROFILE.name, retention_mode=RETENTION_MODE,
        extra={"scenario_profile": SCENARIO_PROFILE.as_dict()},
    )

    # Checkpoint writer — saves compressed world state every N ticks
    ckpt = CheckpointWriter(output_dir, interval=CHECKPOINT_INTERVAL)

    # Death ledger — accumulates structured death records
    ledger = DeathLedger()

    (spatial_world, resource_world, faction_registry,
     territory_map, institution_registry, culture_pool,
     reproduction_system, world_narrative, texture_chronicle, persistence_ledger, env, logistics_world, subsistence_world, genpsych_ledger, institutional_memory_ledger, settlement_ledger) = make_world_systems(seed=run_id)

    agents = make_agents(run_id, spatial_world, faction_registry, culture_pool)
    for a in agents:
        init_generational_agent(a, generation=0, household_id=None, parents=[], birth_tick=0)
        init_apprenticeship_agent(a)
        init_governance_agent(a)
        biology_mod.init_agent(a)
        init_innovation_agent(a)
        init_information_agent(a)
    viability_seed_summary = seed_viable_founder_band(agents, spatial_world, random.Random(run_id * 43700))
    # v04.48: life event engine — structured external shocks (illness, bereavement,
    # region disasters) applied per-tick. Initialized after agents exist so
    # initial event assignment can read agent age distributions.
    life_events_mod.initialize_life_events(
        agents, max_ticks=TICKS, seed=run_id, key=f"run_{run_id}"
    )
    settlement_seed_events = settlement_ledger.seed_founder_settlements(agents, logistics_world, tick=0)
    initial_agent_ids = {a.id for a in agents}
    scenario_seed_summary = summarize_scenario_agents(agents, prefix="scenario_seed")
    (output_dir / "agents_initial.json").write_text(json.dumps([a.snapshot() for a in agents], indent=2), encoding="utf-8")

    # ── t=0 diagnostics ───────────────────────────────────────────────────────
    initial_eligible = sum(
        1 for a in agents if a.state.dominance * a.traits.risk_tolerance >= DECEIVE_THRESHOLD
    )
    initial_max_score = round(
        max(a.state.dominance * a.traits.risk_tolerance for a in agents), 4
    )
    initial_avg_score = round(
        sum(a.state.dominance * a.traits.risk_tolerance for a in agents) / len(agents), 4
    )

    event_log = []   # legacy compat — kept for functions that still read it
    metric_log = []
    _counters = RollingCounters()
    _stream = EventStream(output_dir / "events.jsonl")
    RUN_MANIFEST.start(run_id, output_dir)
    for st_event in settlement_seed_events:
        st_dict = serialize_event(st_event)
        st_dict["salience"] = 0.58
        persistence_ledger.record_event(st_dict)
        event_log.append(st_dict)
        _counters.record(st_dict)
        _stream.write(st_dict)
    constraint_ledger = ConstraintLedger()
    generational_ledger = GenerationalLedger()
    apprenticeship_ledger = ApprenticeshipLedger()
    governance_ledger = GovernanceLedger()
    innovation_engine = InnovationEngine()
    information_ledger = InformationLedger()
    death_logged = set()

    # Post-deception conflict tracking:
    # When deception is detected, record (actor_id, target_id, tick).
    # Then count conflict events between that dyad in the next 10 ticks.
    pending_postdec_checks: list = []  # (actor_id, target_id, detection_tick, due_tick)
    postdec_conflict_count = 0
    postdec_total_checks = 0

    for tick in range(TICKS):
        phase = env.get_phase(tick)
        phase = subsistence_world.apply_to_phase(phase)
        for sub_event in subsistence_world.begin_tick(tick):
            sub_dict = serialize_event(sub_event)
            sub_dict["salience"] = 0.50
            subsistence_world.record_event(sub_event)
            persistence_ledger.record_event(sub_dict)
            event_log.append(sub_dict)
            _counters.record(sub_dict)
            _stream.write(sub_dict)
        # v04.12: single bidirectional dedup registry injected into every agent's
        # DeceptionModule before the tick loop. Keyed by frozenset({actor, target})
        # so mutual same-tick deception attempts log exactly once.
        deception_tick_registry: set = set()
        for agent in agents:
            agent.deception.set_tick_registry(deception_tick_registry)

        # v04.12: salience tracker for first-conflict-in-dyad detection
        salience_dyad_first_conflicts: set = set()

        # v04.10 compat: keep this but it's now redundant — deception.py owns the dedup
        deception_logged_this_tick = set()

        resource_world.tick_regen()
        territory_map.decay_all()
        culture_pool.decay()
        culture_pool.mutate(random.Random(tick + run_id), tick, agents)

        # v04.43: compute ecological health once per tick — shared signal for
        # reproduction drive and lethality escalation.
        from ecological_context import ecological_health as _eco_health_fn
        _eco_health = _eco_health_fn(
            subsistence_world, agents,
            recent_deaths=len([a for a in agents if not a.alive]),
        )

        # v04.48: life event layer — disease contagion spreads between agents,
        # then each agent's active shocks (illness, bereavement, region disaster)
        # are translated into stress/support/trust deltas applied directly to
        # agent state. These are external pressure inputs, not scripted outcomes.
        life_events_mod.step_disease_layer(agents, tick, key=f"run_{run_id}")
        for agent in [a for a in agents if a.alive]:
            le_delta = life_events_mod.apply_all_life_effects(agent, tick, key=f"run_{run_id}")
            if le_delta["stress"] != 0.0:
                agent.state.stress = max(0.0, min(1.0,
                    agent.state.stress + le_delta["stress"] * 0.012
                ))
            if le_delta["support"] != 0.0:
                agent.state.cooperation = max(0.0, min(1.0,
                    agent.state.cooperation + le_delta["support"] * 0.008
                ))
            if le_delta["trust"] != 0.0:
                agent.state.stability = max(0.0, min(1.0,
                    agent.state.stability + le_delta["trust"] * 0.006
                ))

        # v04.43: decay all agent beliefs toward neutral each tick.
        # Negative beliefs (threat) decay slower than positive (safety).
        for agent in agents:
            if agent.alive:
                agent.beliefs.decay(tick)

        if tick % 10 == 0:
            faction_registry.pool_resources(agents)
        # Update faction reputation from intra-faction interaction outcomes each tick.
        # This gives ideology_alignment an actual gradient to drift toward.
        faction_registry.update_reputation(agents)
        RUN_MANIFEST.tick(run_id, tick)
        for sv_event in apply_population_viability_tick(agents, tick, phase.name, spatial_world, random.Random(tick + run_id * 43737)):
            sv_dict = serialize_event(sv_event)
            sv_dict["salience"] = 0.48
            persistence_ledger.record_event(sv_dict)
            event_log.append(sv_dict)
            _counters.record(sv_dict)
            _stream.write(sv_dict)
        if tick % 10 == 0:
            institution_registry.try_form(agents, faction_registry, tick, persistence_ledger=persistence_ledger)
        institution_registry.tick(agents)
        for log_event in logistics_world.tick(agents, tick):
            log_dict = serialize_event(log_event)
            log_dict["salience"] = 0.45
            persistence_ledger.record_event(log_dict)
            if salience_mod.should_keep(log_dict["salience"], RETENTION_MODE, random.Random(tick + 425)):
                event_log.append(log_dict)
            _counters.record(log_dict)
            _stream.write(log_dict)
        for st_event in settlement_ledger.tick(agents, tick, phase.name, logistics_world, random.Random(tick + run_id * 44040)):
            st_dict = serialize_event(st_event)
            st_dict["salience"] = 0.57
            persistence_ledger.record_event(st_dict)
            event_log.append(st_dict)
            _counters.record(st_dict)
            _stream.write(st_dict)

        texture_chronicle.spread_artifacts(tick, agents, random.Random(tick + run_id * 997))
        texture_chronicle.maybe_ritualize(tick, agents, random.Random(tick + run_id * 991))
        persistence_ledger.decay_locations()
        if tick % 10 == 0:
            persistence_ledger.sync_artifacts(texture_chronicle)
            persistence_ledger.sync_institutions(institution_registry, tick, agents=agents)

        for agent in agents:
            was_alive = agent.alive
            persistence_ledger.apply_location_pressure(agent)
            persistence_ledger.maybe_create_resource_cache(agent, tick, reason="low_stress", rng=random.Random(tick + run_id * 1009 + hash(agent.id)))
            event = safe_agent_tick(
                agent, tick, phase, agents,
                spatial_world=spatial_world,
                resource_world=resource_world,
                faction_registry=faction_registry,
                territory_map=territory_map,
                institution_registry=institution_registry,
                culture_pool=culture_pool,
                world_narrative=world_narrative,
                texture_chronicle=texture_chronicle,
                governance_ledger=governance_ledger,
                eco_health=_eco_health,
            )
            if event:
                ev_dict = serialize_event(event)
                sal = salience_mod.score(ev_dict, salience_dyad_first_conflicts)
                ev_dict["salience"] = sal
                persistence_ledger.record_event(ev_dict)
                if salience_mod.should_keep(sal, RETENTION_MODE, random.Random(tick + agent.id.__hash__())):
                    event_log.append(ev_dict)
                _counters.record(ev_dict)
                _stream.write(ev_dict)

            for sub_event in subsistence_world.agent_tick(agent, tick, phase.name, culture_pool=culture_pool, faction_registry=faction_registry):
                sub_dict = serialize_event(sub_event)
                sub_dict["salience"] = 0.52
                subsistence_world.record_event(sub_event)
                persistence_ledger.record_event(sub_dict)
                if salience_mod.should_keep(sub_dict["salience"], RETENTION_MODE, random.Random(tick + 433 + hash(agent.id))):
                    event_log.append(sub_dict)
                _counters.record(sub_dict)
                _stream.write(sub_dict)

            if was_alive and not agent.alive and agent.id not in death_logged:
                death_logged.add(agent.id)
                f = faction_registry.faction_of(agent.id) if faction_registry else None

                # v04.14: build structured death record
                dr = build_death_record(
                    tick=tick,
                    agent=agent,
                    faction_registry=faction_registry,
                    all_agents=agents,
                    events_so_far=event_log,
                    archetype_label=None,   # archetype not computed mid-run; set post-hoc
                )
                ledger.record(dr)

                death_ev = {
                    "tick": tick,
                    "phase": phase.name,
                    "actor_id": agent.id,
                    "event_type": "agent_death",
                    "participants": [],
                    "context": {
                        "name": agent.name,
                        "faction": f.name if f else None,
                        "position": {"x": agent.position.x, "y": agent.position.y},
                        "cause": agent._death_cause,
                        "age": agent.state.age,
                        "generation": agent.generation,
                        "role": agent.traits.role,
                        "stress": round(agent.state.stress, 4),
                        "energy": round(agent.state.energy, 4),
                        "resource_stock": round(agent.state.resource_stock, 4),
                        "hunger": round(getattr(agent.state, "hunger", 0.0), 4),
                        "exhaustion": round(getattr(agent.state, "exhaustion", 0.0), 4),
                        "injury": round(getattr(agent.state, "injury", 0.0), 4),
                        "safety": round(getattr(agent.state, "safety", 0.0), 4),
                        "scars": round(agent.experience.scars, 4),
                        "collapse_strikes": agent.state.collapse_strikes,
                        "active_grudge_edges": len(agent.experience.grudges),
                        "active_bond_edges": len(agent.experience.bonds),
                        "grudge_strength_total": round(sum(agent.experience.grudges.values()), 4),
                        "bond_strength_total": round(sum(agent.experience.bonds.values()), 4),
                        "n_survivors_with_relationship": len(dr.social_residue),
                        "systemic_impact": dr.systemic_impact,
                        "vacancy_type": dr.vacancy.vacancy_type if dr.vacancy else None,
                    },
                    "impact": {},
                    "outcome": "dead",
                    "salience": 1.0,
                }
                persistence_ledger.maybe_create_resource_cache(agent, tick, reason="death", rng=random.Random(tick + run_id * 2003 + hash(agent.id)))
                persistence_ledger.record_event(death_ev)
                event_log.append(death_ev)

                # ── v04.30: grief propagation to bonded survivors ─────────────
                grief_reports = psychology_mod.notify_death_to_population(
                    agent, agents, tick
                )
                for report in grief_reports:
                    grief_ev = {
                        "tick": tick,
                        "phase": phase.name,
                        "actor_id": report["survivor_id"],
                        "event_type": "grief",
                        "participants": [agent.id],
                        "context": report,
                        "impact": {
                            "stress": report["stress_spike"],
                            "scars": report["scar_added"],
                        },
                        "outcome": "grief",
                        "salience": round(report["bond_strength"], 4),
                    }
                    persistence_ledger.record_event(grief_ev)
                    event_log.append(grief_ev)

            for aux_event in getattr(agent, "aux_events", []):
                # v04.12: dedup is now handled by deception.py's tick registry.
                # The old ordered-tuple dedupe is kept as a fallback safety net only.
                if aux_event.event_type == "deception" and aux_event.participants:
                    dec_key = (aux_event.tick, aux_event.actor_id, aux_event.participants[0])
                    if dec_key in deception_logged_this_tick:
                        continue
                    deception_logged_this_tick.add(dec_key)
                constraint_ledger.record(aux_event)
                ev_dict = serialize_event(aux_event)
                sal = salience_mod.score(ev_dict, salience_dyad_first_conflicts)
                ev_dict["salience"] = sal
                persistence_ledger.record_event(ev_dict)
                # v04.38: aux events (deception/negotiation) must feed the
                # benchmark counters even when salience retention drops them from
                # the compact event log. v04.37 wrote them to persistence only,
                # which made negotiation look permanently dead.
                _counters.record(ev_dict)
                _stream.write(ev_dict)
                if salience_mod.should_keep(sal, RETENTION_MODE, random.Random(tick)):
                    event_log.append(ev_dict)
                    # Register post-deception conflict check on detections
                    if (aux_event.event_type == "deception"
                            and aux_event.outcome == "deception_detected"
                            and aux_event.participants):
                        pending_postdec_checks.append(
                            (aux_event.actor_id, aux_event.participants[0], tick, tick + 10)
                        )
            agent.aux_events = []

        # Collect cooperation events this tick for innovation diffusion
        # (must happen after aux_events processing but before they're needed by diffusion)
        tick_cooperation_events = [
            e for e in event_log
            if e.get("tick") == tick
            and e.get("event_type") == "interaction"
            and e.get("outcome") == "cooperation"
        ]

        # Resolve post-deception conflict checks due this tick
        still_pending = []
        for actor_id, target_id, detection_tick, due_tick in pending_postdec_checks:
            if tick >= due_tick:
                postdec_total_checks += 1
                window_size = due_tick - detection_tick
                window_start = detection_tick + 1
                window_end = due_tick

                # Count conflict events between this dyad in the audit window after detection.
                # The direction is actor -> target because deception detection currently mutates
                # the target's belief about the actor; future versions may add symmetric checks.
                had_conflict = any(
                    e.get("event_type") == "interaction"
                    and e.get("outcome") == "conflict"
                    and e.get("actor_id") == actor_id
                    and target_id in e.get("participants", [])
                    and window_start <= e.get("tick", -1) <= window_end
                    for e in event_log
                )

                if had_conflict:
                    postdec_conflict_count += 1

                event_log.append({
                    "tick": tick,
                    "phase": phase.name,
                    "actor_id": actor_id,
                    "event_type": "post_deception_conflict_check",
                    "participants": [target_id],
                    "context": {
                        "target_id": target_id,
                        "detection_tick": detection_tick,
                        "due_tick": due_tick,
                        "window_start": window_start,
                        "window_end": window_end,
                        "window_size": window_size,
                    },
                    "impact": {
                        "had_conflict": 1.0 if had_conflict else 0.0,
                    },
                    "outcome": "post_deception_conflict_observed" if had_conflict else "post_deception_no_conflict",
                })
            else:
                still_pending.append((actor_id, target_id, detection_tick, due_tick))
        pending_postdec_checks = still_pending

        if tick % 25 == 0:
            parents_before = [a for a in agents if a.alive]
            newborns = reproduction_system.tick(
                agents, spatial_world, faction_registry,
                culture_pool, random.Random(tick + run_id * 7), genpsych_ledger=genpsych_ledger, tick=tick,
                eco_health=_eco_health,
            )
            # v04.17: weak inherited residue from local/factional culture.
            # Parent identity is not returned by v04 reproduction yet, so use
            # same-cell living adults as the inspectable inheritance context.
            for child in newborns:
                birth_parents = list(getattr(child, "_birth_parents", []))
                if not birth_parents:
                    birth_parents = [p for p in parents_before if p.position.x == child.position.x and p.position.y == child.position.y][:2]
                assign_child_context(child, birth_parents, tick, generational_ledger)
                same_cell = [p for p in parents_before if p.position.x == child.position.x and p.position.y == child.position.y]
                persistence_ledger.seed_newborn_residue(child, same_cell[:2], tick)
            agents.extend(newborns)

        # v04.21: dependency/caretaker pressure is applied once per tick, after
        # births and individual action resolution. It changes capacity pressure,
        # not scripted outcomes.
        for gen_event in apply_generational_tick(agents, tick, phase.name, generational_ledger):
            constraint_ledger.record(gen_event)
            ev_dict = serialize_event(gen_event)
            ev_dict["salience"] = salience_mod.score(ev_dict, salience_dyad_first_conflicts)
            persistence_ledger.record_event(ev_dict)
            if salience_mod.should_keep(ev_dict["salience"], RETENTION_MODE, random.Random(tick + 40421)):
                event_log.append(ev_dict)


        # v04.35: generational psychological transmission — oral memory and targeted repair.
        genpsych_events = []
        genpsych_events.extend(apply_storykeeper_transmission(
            agents, tick, phase.name, random.Random(tick + run_id * 2035), genpsych_ledger
        ))
        genpsych_events.extend(apply_targeted_care_recovery(
            agents, tick, phase.name, random.Random(tick + run_id * 2036), genpsych_ledger
        ))
        for gp_ev in genpsych_events:
            gp_dict = serialize_event(gp_ev)
            gp_dict["salience"] = salience_mod.score(gp_dict, salience_dyad_first_conflicts)
            persistence_ledger.record_event(gp_dict)
            if salience_mod.should_keep(gp_dict["salience"], RETENTION_MODE, random.Random(tick + 43500)):
                event_log.append(gp_dict)

        # v04.36: institutional memory — recorded events become cultural priors,
        # proto-institutions, preservation, divergence, or loss.
        instmem_events = apply_institutional_memory_tick(
            agents, tick, phase.name, random.Random(tick + run_id * 2036 + 36),
            institutional_memory_ledger, event_log=event_log, faction_registry=faction_registry
        )
        for im_ev in instmem_events:
            im_dict = serialize_event(im_ev)
            im_dict["salience"] = salience_mod.score(im_dict, salience_dyad_first_conflicts)
            persistence_ledger.record_event(im_dict)
            if salience_mod.should_keep(im_dict["salience"], RETENTION_MODE, random.Random(tick + 43600)):
                event_log.append(im_dict)

        # Layer 12: Apprenticeship — knowledge transfer between agents
        ap_events = apply_apprenticeship_tick(
            agents, tick, phase.name, apprenticeship_ledger,
            faction_registry=faction_registry,
            institution_registry=institution_registry,
            rng=random.Random(tick + run_id * 1013),
        )
        for ap_ev in ap_events:
            ap_dict = serialize_event(ap_ev)
            ap_dict["salience"] = 0.5
            event_log.append(ap_dict)

        # Layer 13: Governance — leadership, legitimacy, coordination, enforcement
        gov_events = apply_governance_tick(
            agents, tick, phase.name, governance_ledger,
            faction_registry=faction_registry,
            rng=random.Random(tick + run_id * 1019),
        )
        for gov_ev in gov_events:
            gov_dict = serialize_event(gov_ev)
            gov_dict["salience"] = 0.6
            event_log.append(gov_dict)
        # Biology: same-sex pair specialization bonus + infidelity check
        bio_rng = random.Random(tick + run_id * 7717)
        for a in agents:
            if not getattr(a, "alive", False):
                continue
            biology_mod.apply_same_sex_pair_bonus(a, agents)
            # Infidelity: bonded agents may attempt deception toward non-partners
            if getattr(a.state, "pair_bond_strength", 0.0) > 0.40:
                partner_id = getattr(a, "_pair_bond_partner_id", None)
                if partner_id and bio_rng.random() < 0.015:  # low base rate check
                    candidates = [
                        o for o in agents
                        if getattr(o, "alive", False)
                        and o.id != a.id
                        and o.id != partner_id
                        and abs(o.position.x - a.position.x) <= 2
                        and abs(o.position.y - a.position.y) <= 2
                    ]
                    for target in candidates[:2]:
                        if biology_mod.check_infidelity_attempt(a, target, bio_rng):
                            # Infidelity fires as a deception event toward the partner
                            infidelity_ev = {
                                "tick": tick,
                                "phase": "biology",
                                "event_type": "deception",
                                "actor_id": a.id,
                                "participants": [partner_id],
                                "context": {
                                    "deception_type": "infidelity_attempt",
                                    "target_id": target.id,
                                    "bond_strength": round(a.state.pair_bond_strength, 3),
                                    "libido": round(getattr(a, "libido", 0.0), 3),
                                },
                                "impact": {"trust": -0.08},
                                "outcome": "infidelity_deception",
                                "salience": 0.85,
                            }
                            _counters.record(infidelity_ev)
                            _stream.write(infidelity_ev)
                            event_log.append(infidelity_ev)
                            # Erode bond slightly — the act itself creates risk
                            a.state.pair_bond_strength = clamp(
                                a.state.pair_bond_strength - 0.04
                            )
                            break
        # Information propagation
        info_events = apply_information_tick(
            agents, tick, information_ledger,
            governance_ledger=governance_ledger,
            faction_registry=faction_registry,
            logistics_world=logistics_world,
            rng=random.Random(tick + run_id * 1031),
        )
        for info_ev in info_events:
            info_dict = serialize_event(info_ev)
            info_dict["salience"] = 0.55
            event_log.append(info_dict)
        # v04.43: wire information propagation into BeliefMemory.
        # Agents update agent-specific safety/threat beliefs from received messages,
        # not just their aggregate state variables (stress, fear, cooperation).
        for agent in [a for a in agents if a.alive and hasattr(a, "inbox")]:
            for msg in agent.inbox._latest.values():
                if msg.content_type in ("threat_near", "safe_zone"):
                    agent.beliefs.update_from_message(
                        source_id=msg.source_id,
                        content_type=msg.content_type,
                        weight=0.30 * msg.fidelity,
                        fidelity=msg.fidelity,
                    )
        # Innovation: recombination, diffusion, institutional adoption
        inn_events = apply_innovation_tick(
            agents, tick, phase.name, innovation_engine,
            institution_registry=institution_registry,
            governance_ledger=governance_ledger,
            rng=random.Random(tick + run_id * 1037),
            cooperation_events=tick_cooperation_events,
        )
        for inn_ev in inn_events:
            inn_dict = serialize_event(inn_ev)
            inn_dict["salience"] = 0.65
            _counters.record(inn_dict)
            _stream.write(inn_dict)
            event_log.append(inn_dict)
        if tick % 10 == 0:
            metric_log.append({
                "tick": tick,
                "phase": phase.name,
                **population_metrics(
                    agents,
                    faction_registry=faction_registry,
                    institution_registry=institution_registry,
                    culture_pool=culture_pool,
                    reproduction_system=reproduction_system,
                ),
                **logistics_world.settlement_metrics(agents),
                **settlement_ledger.metrics(agents),
                **_counters.snapshot(),

                "institution_prevented_conflicts_cumulative": sum(
                    1 for e in event_log
                    if e["event_type"] == "interaction"
                    and e.get("context", {}).get("institution_prevented_conflict")
                ),
                "institution_suppression_total_cumulative": round(sum(
                    e.get("context", {}).get("institution_suppression", 0.0)
                    for e in event_log if e["event_type"] == "interaction"
                ), 4),
                "deception_events_cumulative": sum(
                    1 for e in event_log if e["event_type"] == "deception"
                ),
                "deception_successes_cumulative": sum(
                    1 for e in event_log
                    if e["event_type"] == "deception" and e["outcome"] == "deception_success"
                ),
                "deception_detected_cumulative": sum(
                    1 for e in event_log
                    if e["event_type"] == "deception" and e["outcome"] == "deception_detected"
                ),
                **topology_metrics(agents, faction_registry, tick=tick),
                **conflict_localization_metrics(event_log, max(0, tick - 50), tick),
                **dyad_snapshot_metrics(event_log, agents, faction_registry, max(0, tick - 50), tick),
                **summarize_texture(agents, texture_chronicle),
                "resource_cache_count": len(persistence_ledger.resource_caches),
                "institution_reactivations": persistence_ledger.institution_reactivations,
                "lineage_seed_count": persistence_ledger.lineage_seed_count,
                "trust_pocket_count": len(persistence_ledger._trust_pockets()),
                "institution_residue_count": len(persistence_ledger.institutions),
                "resource_cache_hits": persistence_ledger.cache_hits,
                **constraint_snapshot(agents),
                **summarize_generational_state(agents),
                **{f"constraint_{k}": v for k, v in constraint_ledger.snapshot().items()},
                **subsistence_benchmark_metrics(subsistence_world),
                **genpsych_benchmark_metrics(genpsych_ledger, agents),
                **viability_metrics(agents),
        **instmem_benchmark_metrics(institutional_memory_ledger, agents),
                **instmem_benchmark_metrics(institutional_memory_ledger, agents),
            })

            # v04.13: write checkpoint after metrics are computed (metric row goes in snapshot)
            if ckpt.should_write(tick):
                ckpt.write(
                    tick=tick,
                    phase_name=phase.name,
                    agents=agents,
                    faction_registry=faction_registry,
                    institution_registry=institution_registry,
                    culture_pool=culture_pool,
                    metric_row=metric_log[-1] if metric_log else None,
                )

    ckpt.close()   # write checkpoint index
    ledger.write(output_dir)   # write deaths.json
    persistence_ledger.sync_artifacts(texture_chronicle)
    persistence_ledger.sync_institutions(institution_registry, TICKS, agents=agents)

    # v04.48: epoch segmentation — detect civilization phase boundaries from
    # the completed metric log. Death records with high systemic impact can
    # force epoch boundaries at the tick they occurred.
    _dr_raw = ledger.summary().get("deaths", []) if hasattr(ledger, "summary") else []
    _death_records = _dr_raw if isinstance(_dr_raw, list) else []
    _epochs = detect_epochs(metric_log, death_records=_death_records)
    _epoch_summary = summarize_epochs(_epochs)
    (output_dir / "epochs.json").write_text(
        __import__("json").dumps(_epoch_summary, indent=2), encoding="utf-8"
    )

    final_agents = [a.snapshot() for a in agents]
    living_agents = [a for a in agents if a.alive]
    dead_agents = [a for a in agents if not a.alive]
    original_survivors = [a for a in living_agents if a.id in initial_agent_ids]
    child_survivors = [a for a in living_agents if a.id not in initial_agent_ids]

    _summary_counts = _counters.summary_fields()
    # Legacy vars for code below that still references them
    dec_events      = _summary_counts["deception_events"]
    dec_success     = _summary_counts["deception_success"]
    dec_detected    = _summary_counts["deception_detected"]
    interaction_events   = type("_E", (), {"__len__": lambda s: _summary_counts["interaction_events"]})() 
    conflict_events      = type("_E", (), {"__len__": lambda s: _summary_counts["conflict_events"]})() 
    cooperation_events   = type("_E", (), {"__len__": lambda s: _summary_counts["cooperation_events"]})() 
    negotiation_events   = type("_E", (), {"__len__": lambda s: _summary_counts["negotiation_events"]})() 
    negotiation_successes = type("_E", (), {"__len__": lambda s: _summary_counts["negotiation_successes"]})() 
    negotiation_failures  = type("_E", (), {"__len__": lambda s: _summary_counts["negotiation_failures"]})() 
    institution_prevented = type("_E", (), {"__len__": lambda s: _summary_counts["institution_prevented_conflicts"]})() 
    institution_suppression_total = _summary_counts["institution_suppression_total"]
    attractor_profile = attractor_switches(metric_log)

    summary = {
        "run_id": run_id,
        "version": "v04.41",
        "scenario": SCENARIO_PROFILE.name,
        "scenario_description": SCENARIO_PROFILE.description,
        "scenario_tags": SCENARIO_PROFILE.tags,
        "ticks": TICKS,
        "initial_agents": len(initial_agent_ids),
        **scenario_seed_summary,
        **{f"viability_seed_{k}": v for k, v in viability_seed_summary.items()},
        **summarize_scenario_agents(agents, prefix="scenario_final"),
        "final_total_records": len(agents),
        "alive": len(living_agents),
        "dead": len(dead_agents),
        "births": reproduction_system.total_births,
        "original_survivors": [a.name for a in original_survivors],
        "child_survivors": [a.name for a in child_survivors],
        "dead_agents": [a.name for a in dead_agents],
        # Deception
        "deception_eligible_initial": initial_eligible,
        "deception_max_score_initial": initial_max_score,
        "deception_avg_score_initial": initial_avg_score,
        "deception_events": dec_events,
        "deception_successes": dec_success,
        "deception_detected": dec_detected,
        "deception_success_rate": round(dec_success / dec_events, 4) if dec_events else None,
        "deception_eligible_final": sum(
            1 for a in living_agents if a.state.dominance * a.traits.risk_tolerance >= DECEIVE_THRESHOLD
        ),
        "deception_max_score_final": round(
            max((a.state.dominance * a.traits.risk_tolerance for a in living_agents), default=0.0), 4
        ),
        # Post-deception conflict rate
        "postdec_conflict_rate": round(
            postdec_conflict_count / postdec_total_checks, 4
        ) if postdec_total_checks else None,
        "postdec_checks": postdec_total_checks,
        "postdec_conflicts_observed": postdec_conflict_count,
        "postdec_events_logged": sum(
            1 for e in event_log if e["event_type"] == "post_deception_conflict_check"
        ),
        # Interaction / conflict proof layer
        "interaction_events": len(interaction_events),
        "conflict_events": len(conflict_events),
        "cooperation_events": len(cooperation_events),
        "conflict_per_100_interactions": round(100.0 * len(conflict_events) / len(interaction_events), 4) if interaction_events else None,
        "cooperation_rate": round(len(cooperation_events) / len(interaction_events), 4) if interaction_events else None,
        # v04.8 attractor recovery layer
        **attractor_profile,
        # Negotiation
        "negotiation_events": len(negotiation_events),
        "negotiation_successes": len(negotiation_successes),
        "negotiation_failures": len(negotiation_failures),
        "negotiation_success_rate": round(len(negotiation_successes) / len(negotiation_events), 4) if negotiation_events else None,
        "negotiated_conflict_suppression": len(negotiation_successes),
        # Institution suppression proof layer
        "institution_prevented_conflicts": len(institution_prevented),
        "institution_suppression_total": round(institution_suppression_total, 4),
        "institution_suppression_per_interaction": round(institution_suppression_total / len(interaction_events), 4) if interaction_events else None,
        # Structure
        "factions": len(faction_registry.factions),
        "institutions": len(institution_registry.institutions),
        "memes": len(culture_pool.memes),
        "agent_deaths_logged": sum(1 for e in event_log if e.get("event_type") == "agent_death"),
        "homicides": _summary_counts.get("homicides", 0),
        "lethal_attempts_survived": _summary_counts.get("lethal_attempts_survived", 0),
        # v04.14 death ledger fields
        **{f"death_{k}": v for k, v in ledger.summary().items() if k != "deaths"},
        # v04.9 topology / residue layer
        **topology_metrics(agents, faction_registry, tick=TICKS),
        **conflict_localization_metrics(event_log, max(0, TICKS - 50), TICKS),
        **dyad_snapshot_metrics(event_log, agents, faction_registry, max(0, TICKS - 50), TICKS),
        **negative_artifact_clustering(texture_chronicle, agents, faction_registry),
        **dyad_persistence_metrics(event_log, agents, faction_registry, window_start=0, window_end=TICKS, min_conflicts=3),
        # v04.7 texture / felt-reality layer
        **summarize_texture(agents, texture_chronicle),
        # v04.18 functional legacy proof layer
        "resource_cache_count": len(persistence_ledger.resource_caches),
        "resource_cache_hits": persistence_ledger.cache_hits,
        "institution_reactivations": persistence_ledger.institution_reactivations,
        "lineage_seed_count": persistence_ledger.lineage_seed_count,
        "trust_pocket_count": len(persistence_ledger._trust_pockets()),
        "institution_residue_count": len(persistence_ledger.institutions),
        "trust_pocket_institution_residue_correlation": persistence_ledger.snapshot().get("summary", {}).get("trust_pocket_institution_residue_correlation"),
        # v04.20 constraint/survival proof layer
        **constraint_snapshot(agents),
        **summarize_generational_state(agents),
        "birth_records_logged": len(generational_ledger.birth_records),
        "pair_bond_events": len(generational_ledger.pair_bond_events),
        **{f"apprenticeship_{k}": v for k, v in apprenticeship_benchmark_metrics(apprenticeship_ledger, agents, institution_registry).items()},
        **{f"governance_{k}": v for k, v in governance_benchmark_metrics(governance_ledger, agents).items()},
        **biology_benchmark_metrics(agents),
        **information_benchmark_metrics(information_ledger, agents),
        **{f"innovation_{k}": v for k, v in innovation_benchmark_metrics(innovation_engine, agents).items()},
        **subsistence_benchmark_metrics(subsistence_world),
        **viability_metrics(agents),
        **genpsych_benchmark_metrics(genpsych_ledger, agents),
                **viability_metrics(agents),
        **instmem_benchmark_metrics(institutional_memory_ledger, agents),
        **logistics_world.settlement_metrics(agents),
        **settlement_ledger.metrics(agents),
        "care_events": generational_ledger.care_events,
        "dependency_pressure_events": generational_ledger.dependency_pressure_events,
        **{f"constraint_{k}": v for k, v in constraint_ledger.snapshot().items()},
        # v04.48 life event summary
        "life_events_active": sum(
            len([ev for ev in getattr(a, "life_events", []) if ev.active(TICKS - 1)])
            for a in agents if a.alive
        ),
        "life_events_illness_total": sum(
            len([ev for ev in getattr(a, "life_events", []) if "illness" in ev.type])
            for a in agents
        ),
        "life_events_negative_total": sum(
            len([ev for ev in getattr(a, "life_events", []) if ev.impact < 0])
            for a in agents
        ),
        "life_events_positive_total": sum(
            len([ev for ev in getattr(a, "life_events", []) if ev.impact > 0])
            for a in agents
        ),
        # v04.48 epoch summary
        "epoch_count":      _epoch_summary.get("epoch_count", 0),
        "dominant_epoch":   _epoch_summary.get("dominant_epoch"),
        "unique_epoch_labels": _epoch_summary.get("unique_labels", []),
        "epochs":           _epoch_summary.get("epochs", []),
        # v04.15 pressure state finals (from last metric row)
        **(
            {
                "avg_status_security_final":    metric_log[-1].get("avg_status_security"),
                "avg_novelty_saturation_final": metric_log[-1].get("avg_novelty_saturation"),
                "avg_ideology_alignment_final": metric_log[-1].get("avg_ideology_alignment"),
            }
            if metric_log else {}
        ),
    }

    (output_dir / "events.json").write_text(json.dumps(event_log, separators=(",", ":")), encoding="utf-8")
    (output_dir / "metrics.json").write_text(json.dumps(metric_log, separators=(",", ":")), encoding="utf-8")
    (output_dir / "agents_final.json").write_text(json.dumps(final_agents, separators=(",", ":")), encoding="utf-8")
    (output_dir / "world_narrative.json").write_text(
        json.dumps(world_narrative.snapshot(), indent=2), encoding="utf-8"
    )
    (output_dir / "texture_chronicle.json").write_text(
        json.dumps(texture_chronicle.snapshot(), indent=2), encoding="utf-8"
    )
    (output_dir / "generational_psychology_ledger.json").write_text(
        json.dumps(genpsych_ledger.snapshot(), indent=2), encoding="utf-8"
    )
    (output_dir / "institutional_memory_ledger.json").write_text(
        json.dumps(institutional_memory_ledger.snapshot(), indent=2), encoding="utf-8"
    )
    (output_dir / "factions.json").write_text(
        json.dumps(faction_registry.snapshot(), indent=2), encoding="utf-8"
    )
    (output_dir / "culture.json").write_text(
        json.dumps(culture_pool.snapshot(), indent=2), encoding="utf-8"
    )
    (output_dir / "territory.json").write_text(
        json.dumps(territory_map.snapshot_controlled(), indent=2), encoding="utf-8"
    )
    (output_dir / "institutions.json").write_text(
        json.dumps(institution_registry.snapshot(), indent=2), encoding="utf-8"
    )
    (output_dir / "reproduction.json").write_text(
        json.dumps(reproduction_system.snapshot(), indent=2), encoding="utf-8"
    )
    (output_dir / "persistence.json").write_text(
        json.dumps(persistence_ledger.snapshot(), indent=2), encoding="utf-8"
    )
    (output_dir / "constraints.json").write_text(
        json.dumps({"summary": constraint_ledger.snapshot(), "config": __import__("constraints").DEFAULT_CONFIG.__dict__}, indent=2), encoding="utf-8"
    )
    (output_dir / "generational.json").write_text(
        json.dumps(generational_ledger.snapshot(agents), indent=2), encoding="utf-8"
    )
    (output_dir / "apprenticeship.json").write_text(
        json.dumps(apprenticeship_ledger.snapshot(agents), indent=2), encoding="utf-8"
    )
    (output_dir / "governance.json").write_text(
        json.dumps(governance_ledger.snapshot(agents), indent=2), encoding="utf-8"
    )
    (output_dir / "information.json").write_text(
        json.dumps(information_ledger.snapshot(agents), indent=2), encoding="utf-8"
    )
    (output_dir / "innovation.json").write_text(
        json.dumps(innovation_engine.snapshot(agents), indent=2), encoding="utf-8"
    )
    (output_dir / "logistics.json").write_text(
        json.dumps(logistics_world.snapshot(agents), indent=2), encoding="utf-8"
    )
    (output_dir / "settlements.json").write_text(
        json.dumps(settlement_ledger.snapshot(agents), indent=2), encoding="utf-8"
    )
    (output_dir / "subsistence.json").write_text(
        json.dumps(subsistence_world.snapshot(), indent=2), encoding="utf-8"
    )
    continuity_summary = continuity_mod.build_continuity_outputs(
        output_dir, agents, event_log, initial_agent_ids=initial_agent_ids,
        culture_pool=culture_pool, faction_registry=faction_registry,
        generational_ledger=generational_ledger,
    )
    summary.update(continuity_summary)
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    _stream.close()
    RUN_MANIFEST.complete(run_id)

    # v04.16 observer intelligence layer. This runs only after canonical
    # simulation artifacts have been written. It reads completed outputs and
    # writes observer/ files; it never mutates simulation state.
    observer_bundle = run_observer_pipeline(output_dir)
    summary["observer"] = observer_bundle.get("observer_summary", {})
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print(f"RUN {run_id}")
    print(f"  survivors:  {summary['original_survivors'] + summary['child_survivors']}")
    print(f"  dead:       {summary['dead_agents']}")
    print(f"  births:     {summary['births']}")
    print(f"  deception:  {dec_events} / success={dec_success} detected={dec_detected}"
          f" (eligible_t0={initial_eligible} max_score={initial_max_score})")
    print(f"  postdec_conflict_rate: {summary['postdec_conflict_rate']} (n={postdec_total_checks})")
    print(f"  conflict:   {summary['conflict_events']}/{summary['interaction_events']} interactions ({summary['conflict_per_100_interactions']}/100)")
    print(f"  homicide:   {summary['homicides']} killed / {summary['lethal_attempts_survived']} survived lethal attempt")
    print(f"  negotiate:  {summary['negotiation_events']} success={summary['negotiation_successes']} failed={summary['negotiation_failures']}")
    print(f"  inst proof: {summary['institution_prevented_conflicts']} prevented; suppression/interaction={summary['institution_suppression_per_interaction']}")
    print(f"  factions:   {len(faction_registry.factions)}  insts: {len(institution_registry.institutions)}")
    print(f"  memes:      {len(culture_pool.memes)}")
    print(f"  texture:    artifacts={summary['artifacts']} neg_artifacts={summary.get('negative_artifacts')} rituals={summary['rituals']} recon={summary.get('reconciliation_events')} scars={summary['avg_scars']} grudges={summary['avg_grudges']}")
    print(f"  constraints: hunger={summary.get('avg_hunger')} exhaustion={summary.get('avg_exhaustion')} injury={summary.get('avg_injury')} safety={summary.get('avg_safety')}")
    gov_s = summary
    print(f"  innovation: attempts={summary.get('innovation_innovation_attempts', 0)} successes={summary.get('innovation_innovation_successes', 0)} diffusions={summary.get('innovation_practice_diffusions', 0)} adoptions={summary.get('innovation_institutional_adoptions', 0)} registry={summary.get('innovation_practice_registry_size', 0)}")
    print(f"  information: created={summary.get('information_total_created', 0)} relayed={summary.get('information_total_relayed', 0)} blocked={summary.get('information_total_blocked', 0)} rumors={summary.get('information_rumor_events', 0)} avg_fidelity={summary.get('information_avg_fidelity', 0):.3f}")
    print(f"  biology: males={summary.get('biology_male_count', 0)} females={summary.get('biology_female_count', 0)} homosexual={summary.get('biology_homosexual_agents', 0)} bisexual={summary.get('biology_bisexual_agents', 0)} avg_libido={summary.get('biology_avg_libido', 0):.3f} gestation={summary.get('biology_gestation_active', 0)}")
    print(f"  logistics: occupied_cells={summary.get('logistics_occupied_cells')} concentration={summary.get('logistics_settlement_concentration')} storage={summary.get('logistics_storage_total')} infrastructure={summary.get('logistics_infrastructure_total')} strain={summary.get('logistics_capacity_strain_events')}")
    print(f"  settlements: active={summary.get('settlement_active')} homes={summary.get('settlement_home_cells_living')} continuity={summary.get('settlement_avg_continuity')} support={summary.get('settlement_support_events')} expansions={summary.get('settlement_expansion_events')}")
    print(f"  subsistence: season={summary.get('subsistence_season')} fauna={summary.get('subsistence_total_fauna')} hunts={summary.get('subsistence_hunt_successes')}/{summary.get('subsistence_hunt_failures')} gather={summary.get('subsistence_gather_events')} herd={summary.get('subsistence_herd_wealth')} domestication={summary.get('subsistence_domestication_events')}")
    print(f"  governance: leaders={gov_s.get('governance_factions_with_leaders', 0)} legitimacy={gov_s.get('governance_avg_legitimacy', 0)} compliance={gov_s.get('governance_compliance_rate', 0)} successions={gov_s.get('governance_total_successions', 0)} gap_ticks={gov_s.get('governance_governance_gap_ticks', 0)}")
    print(f"  apprenticeship: pairs={summary.get("apprenticeship_active_pairs", 0)} completions={summary.get("apprenticeship_apprenticeship_count", 0)} retention={summary.get("apprenticeship_knowledge_retention", 0)} complexity={summary.get("apprenticeship_system_complexity_final", 0)}")
    print(f"  generational: households={summary.get('household_count')} dependents={summary.get('dependent_agents')} care_events={summary.get('care_events')} pair_bonds={summary.get('pair_bond_events')}")
    print(f"  gen psych:  births={summary.get('psych_transmission_births', 0)} stories={summary.get('psych_transmission_stories', 0)} recoveries={summary.get('psych_transmission_recoveries', 0)} avg_burden={summary.get('psych_transmission_avg_parental_burden', 0)}")
    print(f"  attractor:  {summary.get('early_attractor')} -> {summary.get('final_attractor')} switches={summary.get('switches')} recovered={summary.get('recovered')}")
    print()



def build_benchmark():
    summaries = []
    metric_runs = []
    for run_id in range(1, RUNS + 1):
        run_dir = OUTPUT_ROOT / f"run_{run_id}"
        summaries.append(json.loads((run_dir / "summary.json").read_text(encoding="utf-8")))
        metric_runs.append(json.loads((run_dir / "metrics.json").read_text(encoding="utf-8")))

    def avg(key):
        vals = [s[key] for s in summaries if s.get(key) is not None]
        return round(sum(vals) / len(vals), 4) if vals else None

    by_tick = {}
    for metrics in metric_runs:
        for row in metrics:
            by_tick.setdefault(row["tick"], []).append(row)

    avg_time_series = []
    for tick in sorted(by_tick):
        rows = by_tick[tick]
        keys = sorted({k for r in rows for k in r.keys() if isinstance(r.get(k), (int, float))})
        out = {"tick": tick}
        for key in keys:
            vals = [r[key] for r in rows if isinstance(r.get(key), (int, float))]
            if vals:
                out[key] = round(sum(vals) / len(vals), 4)
        avg_time_series.append(out)

    benchmark = {
        "version": "v04.41",
        "runs": RUNS,
        "ticks": TICKS,
        "output_root": str(OUTPUT_ROOT),
        "scenario": SCENARIO_PROFILE.name,
        "scenario_profile": SCENARIO_PROFILE.as_dict(),
        "totals": {
            "births": sum(s["births"] for s in summaries),
            "dead": sum(s["dead"] for s in summaries),
            "interaction_events": sum(s["interaction_events"] for s in summaries),
            "conflict_events": sum(s["conflict_events"] for s in summaries),
            "cooperation_events": sum(s["cooperation_events"] for s in summaries),
            "deception_events": sum(s["deception_events"] for s in summaries),
            "deception_successes": sum(s["deception_successes"] for s in summaries),
            "deception_detected": sum(s["deception_detected"] for s in summaries),
            "negotiation_events": sum(s["negotiation_events"] for s in summaries),
            "negotiation_successes": sum(s["negotiation_successes"] for s in summaries),
            "negotiation_failures": sum(s["negotiation_failures"] for s in summaries),
            "institution_prevented_conflicts": sum(s["institution_prevented_conflicts"] for s in summaries),
            "artifacts": sum(s["artifacts"] for s in summaries),
            "negative_artifacts": sum(s.get("negative_artifacts", 0) for s in summaries),
            "negative_artifact_carriers": sum(s.get("negative_artifact_carriers", 0) for s in summaries),
            "negative_artifact_spread_events": sum(s.get("negative_artifact_spread_events", 0) for s in summaries),
            "rituals": sum(s["rituals"] for s in summaries),
            "reconciliation_events": sum(s.get("reconciliation_events", 0) for s in summaries),
            "reconciliation_delta": round(sum(s.get("reconciliation_delta", 0.0) for s in summaries), 4),
            "episodes": sum(s.get("episodes", 0) for s in summaries),
            "turning_points": sum(s.get("turning_points", 0) for s in summaries),
            "attractor_switches": sum(s.get("switches", 0) for s in summaries),
            "recovered_runs": sum(1 for s in summaries if s.get("recovered")),
            "cross_faction_grudge_edges_final": sum(s.get("cross_faction_grudge_edges", 0) for s in summaries),
            "cross_faction_bond_edges_final": sum(s.get("cross_faction_bond_edges", 0) for s in summaries),
            "agent_deaths_logged": sum(s.get("agent_deaths_logged", 0) for s in summaries),
            "death_total_deaths":  sum(s.get("death_total_deaths", 0) for s in summaries),
            "runs_with_deaths":    sum(1 for s in summaries if s.get("death_total_deaths", 0) > 0),
            "persistent_xf_dyad_count_final": sum(s.get("persistent_xf_dyad_count", 0) for s in summaries),
            "resource_cache_count_final": sum(s.get("resource_cache_count", 0) for s in summaries),
            "resource_cache_hits": sum(s.get("resource_cache_hits", 0) for s in summaries),
            "institution_reactivations": sum(s.get("institution_reactivations", 0) for s in summaries),
            "lineage_seed_count": sum(s.get("lineage_seed_count", 0) for s in summaries),
            "scenario_seed_population_size_total": sum(s.get("scenario_seed_population_size", 0) for s in summaries),
            "constraint_injury_events": sum(s.get("constraint_injury_events", 0) for s in summaries),
            "constraint_hunger_events": sum(s.get("constraint_hunger_events", 0) for s in summaries),
            "constraint_exhaustion_events": sum(s.get("constraint_exhaustion_events", 0) for s in summaries),
            "constraint_mobility_cost_events": sum(s.get("constraint_mobility_cost_events", 0) for s in summaries),
            "constraint_resource_actions": sum(s.get("constraint_resource_actions", 0) for s in summaries),
            "constraint_social_actions": sum(s.get("constraint_social_actions", 0) for s in summaries),
            "household_count_final": sum(s.get("household_count", 0) for s in summaries),
            "dependent_agents_final": sum(s.get("dependent_agents", 0) for s in summaries),
            "birth_records_logged": sum(s.get("birth_records_logged", 0) for s in summaries),
            "apprenticeship_completions": sum(s.get("apprenticeship_apprenticeship_count", 0) for s in summaries),
            "innovation_total_attempts": sum(s.get("innovation_innovation_attempts", 0) for s in summaries),
            "innovation_total_successes": sum(s.get("innovation_innovation_successes", 0) for s in summaries),
            "innovation_total_diffusions": sum(s.get("innovation_practice_diffusions", 0) for s in summaries),
            "innovation_total_adoptions": sum(s.get("innovation_institutional_adoptions", 0) for s in summaries),
            "information_total_created": sum(s.get("information_total_created", 0) for s in summaries),
            "information_total_relayed": sum(s.get("information_total_relayed", 0) for s in summaries),
            "information_total_rumors": sum(s.get("information_rumor_events", 0) for s in summaries),
            "biology_total_homosexual": sum(s.get("biology_homosexual_agents", 0) for s in summaries),
            "biology_total_bisexual": sum(s.get("biology_bisexual_agents", 0) for s in summaries),
            "logistics_capacity_strain_events": sum(s.get("logistics_capacity_strain_events", 0) for s in summaries),
            "logistics_settlement_gravity_events": sum(s.get("logistics_settlement_gravity_events", 0) for s in summaries),
            "logistics_travel_events": sum(s.get("logistics_travel_events", 0) for s in summaries),
            "governance_total_compliance": sum(s.get("governance_total_compliance", 0) for s in summaries),
            "governance_total_defiance": sum(s.get("governance_total_defiance", 0) for s in summaries),
            "governance_total_successions": sum(s.get("governance_total_successions", 0) for s in summaries),
            "governance_gap_ticks": sum(s.get("governance_governance_gap_ticks", 0) for s in summaries),
            "apprenticeship_transfer_ticks": sum(s.get("apprenticeship_total_transfer_ticks", 0) for s in summaries),
            "apprenticeship_dissolutions": sum(s.get("apprenticeship_total_dissolutions", 0) for s in summaries),
            "care_events": sum(s.get("care_events", 0) for s in summaries),
            "dependency_pressure_events": sum(s.get("dependency_pressure_events", 0) for s in summaries),
            "pair_bond_events": sum(s.get("pair_bond_events", 0) for s in summaries),
        },
        "means": {
            "births_per_run": avg("births"),
            "dead_per_run": avg("dead"),
            "death_first_tick_mean": avg("death_first_death_tick"),
            "death_avg_systemic_impact_mean": avg("death_avg_systemic_impact"),
            # v04.15 pressure means
            "avg_status_security_final": avg("avg_status_security_final"),
            "avg_novelty_saturation_final": avg("avg_novelty_saturation_final"),
            "avg_ideology_alignment_final": avg("avg_ideology_alignment_final"),
            "conflict_per_100_interactions": avg("conflict_per_100_interactions"),
            "cooperation_rate": avg("cooperation_rate"),
            "deception_per_run": avg("deception_events"),
            "deception_success_rate": avg("deception_success_rate"),
            "postdec_conflict_rate": avg("postdec_conflict_rate"),
            "negotiation_per_run": avg("negotiation_events"),
            "negotiation_success_rate": avg("negotiation_success_rate"),
            "institution_prevented_conflicts_per_run": avg("institution_prevented_conflicts"),
            "institution_suppression_per_interaction": avg("institution_suppression_per_interaction"),
            "avg_scars": avg("avg_scars"),
            "avg_grudges": avg("avg_grudges"),
            "avg_bonds": avg("avg_bonds"),
            "artifacts_per_run": avg("artifacts"),
            "rituals_per_run": avg("rituals"),
            "reconciliation_events_per_run": avg("reconciliation_events"),
            "negative_artifacts_per_run": avg("negative_artifacts"),
            "negative_artifact_spread_events_per_run": avg("negative_artifact_spread_events"),
            "turning_points_per_run": avg("turning_points"),
            "attractor_switches_per_run": avg("switches"),
            "cross_faction_grudge_edges_final": avg("cross_faction_grudge_edges"),
            "cross_faction_bond_edges_final": avg("cross_faction_bond_edges"),
            "avg_grudge_edge_lifespan_final": avg("avg_grudge_edge_lifespan"),
            "avg_cross_faction_grudge_edge_lifespan_final": avg("avg_cross_faction_grudge_edge_lifespan"),
            "trust_pocket_count_final": avg("trust_pocket_count"),
            "institution_residue_count_final": avg("institution_residue_count"),
            "trust_pocket_institution_residue_correlation": avg("trust_pocket_institution_residue_correlation"),
            "resource_cache_count_final": avg("resource_cache_count"),
            "resource_cache_hits_final": avg("resource_cache_hits"),
            "institution_reactivations_final": avg("institution_reactivations"),
            "lineage_seed_count_final": avg("lineage_seed_count"),
            "scenario_seed_age_mean": avg("scenario_seed_age_mean"),
            "scenario_seed_avg_cooperation": avg("scenario_seed_avg_cooperation"),
            "scenario_seed_avg_stress": avg("scenario_seed_avg_stress"),
            "scenario_seed_avg_social_openness": avg("scenario_seed_avg_social_openness"),
            "scenario_final_age_mean": avg("scenario_final_age_mean"),
            "scenario_final_avg_cooperation": avg("scenario_final_avg_cooperation"),
            "scenario_final_avg_stress": avg("scenario_final_avg_stress"),
            "scenario_final_avg_social_openness": avg("scenario_final_avg_social_openness"),
            "avg_hunger_final": avg("avg_hunger"),
            "avg_exhaustion_final": avg("avg_exhaustion"),
            "avg_injury_final": avg("avg_injury"),
            "avg_safety_final": avg("avg_safety"),
            "avg_action_budget_final": avg("avg_action_budget"),
            "injured_agents_final": avg("injured_agents"),
            "hungry_agents_final": avg("hungry_agents"),
            "exhausted_agents_final": avg("exhausted_agents"),
            "conflict_localization_index_50_final": avg("conflict_localization_index_50"),
            "persistent_xf_dyad_count_final": avg("persistent_xf_dyad_count"),
            "dominant_dyad_share_50_final": avg("dominant_dyad_share_50"),
            "household_count_final": avg("household_count"),
            "apprenticeship_count_per_run": avg("apprenticeship_apprenticeship_count"),
            "apprenticeship_active_pairs_final": avg("apprenticeship_active_pairs"),
            "apprenticeship_mentor_links_final": avg("apprenticeship_mentor_links"),
            "apprenticeship_skill_depth_final": avg("apprenticeship_skill_depth"),
            "apprenticeship_knowledge_retention_final": avg("apprenticeship_knowledge_retention"),
            "apprenticeship_system_complexity_final": avg("apprenticeship_system_complexity_final"),
            "innovation_success_rate_final": avg("innovation_innovation_success_rate"),
            "innovation_registry_size_final": avg("innovation_practice_registry_size"),
            "innovation_avg_practices_known_final": avg("innovation_avg_practices_known_per_agent"),
            "information_avg_fidelity_final": avg("information_avg_fidelity"),
            "information_avg_inbox_size_final": avg("information_avg_inbox_size"),
            "information_total_belief_updates_final": avg("information_total_belief_updates"),
            "biology_avg_libido_final": avg("biology_avg_libido"),
            "biology_avg_attractiveness_final": avg("biology_avg_attractiveness"),
            "biology_male_share_final": avg("biology_male_count"),
            "biology_female_share_final": avg("biology_female_count"),
            "biology_homosexual_agents_final": avg("biology_homosexual_agents"),
            "logistics_settlement_concentration_final": avg("logistics_settlement_concentration"),
            "logistics_occupied_cells_final": avg("logistics_occupied_cells"),
            "logistics_avg_cell_fertility_occupied_final": avg("logistics_avg_cell_fertility_occupied"),
            "logistics_avg_cell_friction_occupied_final": avg("logistics_avg_cell_friction_occupied"),
            "logistics_avg_settlement_pull_occupied_final": avg("logistics_avg_settlement_pull_occupied"),
            "logistics_storage_total_final": avg("logistics_storage_total"),
            "logistics_infrastructure_total_final": avg("logistics_infrastructure_total"),
            "settlement_active_final": avg("settlement_active"),
            "settlement_home_cells_living_final": avg("settlement_home_cells_living"),
            "settlement_avg_continuity_final": avg("settlement_avg_continuity"),
            "settlement_total_infrastructure_memory_final": avg("settlement_total_infrastructure_memory"),
            "logistics_total_spoilage_final": avg("logistics_total_spoilage"),
            "governance_avg_legitimacy_final": avg("governance_avg_legitimacy"),
            "governance_compliance_rate_final": avg("governance_compliance_rate"),
            "governance_factions_with_leaders_final": avg("governance_factions_with_leaders"),
            "governance_factions_in_gap_final": avg("governance_factions_in_gap"),
            "dependent_agents_final": avg("dependent_agents"),
            "child_agents_final": avg("child_agents"),
            "juvenile_agents_final": avg("juvenile_agents"),
            "adult_agents_final": avg("adult_agents"),
            "elder_agents_final": avg("elder_agents"),
            "avg_dependency_load_final": avg("avg_dependency_load"),
            "avg_caretaker_load_final": avg("avg_caretaker_load"),
            "avg_pair_bond_strength_final": avg("avg_pair_bond_strength"),
            "avg_household_stability_final": avg("avg_household_stability"),
            "care_events_per_run": avg("care_events"),
            "dependency_pressure_events_per_run": avg("dependency_pressure_events"),
            "pair_bond_events_per_run": avg("pair_bond_events"),
        },
        "attractor_profiles": {
            "peaceful_final": [s["run_id"] for s in summaries if s.get("final_attractor") == "peaceful"],
            "mixed_final": [s["run_id"] for s in summaries if s.get("final_attractor") == "mixed"],
            "conflict_final": [s["run_id"] for s in summaries if s.get("final_attractor") == "conflict"],
            "recovered": [s["run_id"] for s in summaries if s.get("recovered")],
        },
        "runs_detail": summaries,
        "avg_time_series": avg_time_series,
    }
    BENCHMARK_FILE.write_text(json.dumps(benchmark, indent=2), encoding="utf-8")
    print(f"WROTE {BENCHMARK_FILE}")


def parse_cli_args(argv=None):
    parser = argparse.ArgumentParser(description="HRM/DAS simulation runner with configurable validation-friendly runtime.")
    parser.add_argument("--runs", type=int, default=RUNS, help="Number of independent runs to execute.")
    parser.add_argument("--ticks", type=int, default=TICKS, help="Ticks per run.")
    parser.add_argument("--population", type=int, default=INITIAL_AGENTS, help="Initial founder population size.")
    parser.add_argument("--scenario", default=SCENARIO, help="Scenario profile name from das/scenario_profiles.py.")
    parser.add_argument("--output-root", default=str(OUTPUT_ROOT), help="Directory for run outputs.")
    parser.add_argument("--benchmark-file", default=str(BENCHMARK_FILE), help="Benchmark JSON output path.")
    parser.add_argument("--retention", default=RETENTION_MODE, choices=["full", "compact", "audit"], help="Event retention mode.")
    parser.add_argument("--checkpoint-interval", type=int, default=CHECKPOINT_INTERVAL, help="Ticks between checkpoints.")
    parser.add_argument("--seed-offset", type=int, default=0, help="Reserved deterministic seed offset for validation profiles.")
    return parser.parse_args(argv)


def apply_cli_config(args):
    global RUNS, TICKS, SCENARIO, SCENARIO_PROFILE, INITIAL_AGENTS, OUTPUT_ROOT, BENCHMARK_FILE, RETENTION_MODE, CHECKPOINT_INTERVAL
    if args.runs <= 0:
        raise ValueError("--runs must be > 0")
    if args.ticks <= 0:
        raise ValueError("--ticks must be > 0")
    if args.population <= 0:
        raise ValueError("--population must be > 0")
    RUNS = args.runs
    TICKS = args.ticks
    SCENARIO = args.scenario
    SCENARIO_PROFILE = load_scenario(SCENARIO)
    INITIAL_AGENTS = args.population
    OUTPUT_ROOT = Path(args.output_root)
    BENCHMARK_FILE = Path(args.benchmark_file)
    RETENTION_MODE = args.retention
    CHECKPOINT_INTERVAL = args.checkpoint_interval


def main(argv=None):
    global RUN_MANIFEST
    args = parse_cli_args(argv)
    apply_cli_config(args)
    OUTPUT_ROOT.mkdir(exist_ok=True)
    RUN_MANIFEST = RunManifest(OUTPUT_ROOT)
    for run_id in range(1, RUNS + 1):
        try:
            run_single_sim(run_id)
        except Exception as _exc:
            RUN_MANIFEST.fail(run_id, _exc, OUTPUT_ROOT / f"run_{run_id}")
            print(f"  RUN {run_id} FAILED — see manifest.json and traceback file")
            import traceback as _tb; _tb.print_exc()
    build_benchmark()
    print("ALL RUNS COMPLETE")


if __name__ == "__main__":
    main()