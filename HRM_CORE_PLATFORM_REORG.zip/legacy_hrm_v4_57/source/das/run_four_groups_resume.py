# DEPRECATED (v4.50 kernel migration)
# Runtime logic has moved to kernel/runtime.py
# Use: python run_kernel_exp_E.py --config configs/exp_E.json
# This file is preserved for reference. Do not add new simulation logic here.
# See kernel/kernel_migration_audit.md

"""
Resume four-group civilization from tick 2000, run to tick 5000.
Loads agent states, relationships, factions, culture from prior run output.
"""
import sys, json, random
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from agent import Agent
from environment import EnvironmentCycle
from metrics import population_metrics, topology_metrics
from space import SpatialWorld
from resources import ResourceWorld
from factions import FactionRegistry, Faction
from territory import TerritoryMap
from institutions import InstitutionRegistry
from culture import CulturePool
from reproduction import ReproductionSystem
from language import WorldNarrative
from experiential import TextureChronicle
import attractor as attractor_mod
import salience as salience_mod
import psychology as psychology_mod
import continuity as continuity_mod
from checkpoint import CheckpointWriter
from death_ledger import DeathLedger, build_death_record
from persistence import PersistenceLedger
from constraints import ConstraintLedger
from generational import GenerationalLedger, apply_tick as apply_generational_tick, assign_child_context, init_agent as init_generational_agent
from apprenticeship import ApprenticeshipLedger, apply_tick as apply_apprenticeship_tick, init_agent as init_apprenticeship_agent
from logistics import LogisticsWorld
import biology as biology_mod
from innovation import InnovationEngine, apply_tick as apply_innovation_tick, init_agent as init_innovation_agent
from harness import EventStream, RollingCounters, RunManifest, safe_agent_tick
from information import InformationLedger, apply_tick as apply_information_tick, init_agent as init_information_agent
from governance import GovernanceLedger, apply_tick as apply_governance_tick, init_agent as init_governance_agent
from subsistence import SubsistenceWorld
from generational_psychology import GenerationalPsychologyLedger, apply_storykeeper_transmission, apply_targeted_care_recovery
from institutional_memory import InstitutionalMemoryLedger, apply_institutional_memory_tick
from social_viability import apply_population_viability_tick
from settlements import SettlementLedger
from ecological_context import ecological_health as _eco_health_fn
import life_events as life_events_mod
from epochs import detect_epochs, summarize_epochs

PRIOR_DIR   = Path("/tmp/hrm_four_groups_2k/run_1")
OUTPUT_ROOT = Path("/tmp/hrm_four_groups_5k")
START_TICK  = 2001
END_TICK    = 5000
TICKS       = END_TICK - START_TICK + 1
SNAP_EVERY  = 500
SEED        = 17
WORLD_W, WORLD_H = 40, 40
MAX_POP     = 120
GROUP_LABELS = ["A","B","C","D"]

def serialize_event(e):
    return {"tick":e.tick,"phase":e.phase,"actor_id":e.actor_id,
            "event_type":e.event_type,"participants":e.participants,
            "context":e.context,"impact":e.impact,"outcome":e.outcome}

def snapshot_report(tick, agents, ledger, culture_pool, faction_registry,
                    innovation_engine, counters, agent_group):
    living = [a for a in agents if a.alive]
    gen0   = [a for a in living if a.generation == 0]
    gen1p  = [a for a in living if a.generation >= 1]
    births = sum(1 for a in agents if a.generation >= 1)
    total_int  = counters.interaction_total
    total_conf = counters.conflict_total
    conf_rate  = 100 * total_conf / max(1, total_int)
    innov_s = innovation_engine.snapshot().get('summary', {})
    max_gen = max((a.generation for a in living), default=0)

    print(f"\n{'='*60}")
    print(f"  TICK {tick} SNAPSHOT")
    print(f"{'='*60}")
    print(f"  Population  : {len(living)} alive / {len(agents)} total")
    print(f"  Generations : {len(gen0)} founders, {len(gen1p)} born  (total births: {births})")
    print(f"  Max gen     : Gen{max_gen}")
    print(f"  Deaths      : {len(ledger.deaths)}")
    for gi, gl in enumerate(GROUP_LABELS):
        g_living = sum(1 for a in living if agent_group.get(a.id) == gi)
        print(f"  Group {gl}     : {g_living} alive")
    print(f"  Conflict    : {total_conf}/{total_int} ({conf_rate:.1f}%)")
    print(f"  Factions    : {len(faction_registry.factions)}")
    print(f"  Memes       : {len(culture_pool.memes) if hasattr(culture_pool,'memes') else 0} active")
    print(f"  Innovation  : {innov_s.get('total_successes',0)} successes, registry={innov_s.get('registry_size',0)}")
    snap = culture_pool.snapshot()
    top_memes = sorted(snap.get('meme_list',[]), key=lambda x: x.get('strength',0), reverse=True)[:3]
    if top_memes:
        mstr = " | ".join(f"{m['label']} ({m['valence']:+.1f}, {m.get('strength',0):.2f})" for m in top_memes)
        print(f"  Top memes   : {mstr}")
    notable = sorted(living, key=lambda a: a.state.age, reverse=True)[:3]
    for a in notable:
        tags = a.experience.identity_tags[:3] if hasattr(a.experience,'identity_tags') else []
        grp = GROUP_LABELS[agent_group.get(a.id, 0)] if agent_group.get(a.id, -1) >= 0 else '?'
        role = getattr(getattr(a, 'traits', None), 'role', 'unknown')
        print(f"  {a.name:14s} G{grp} gen={a.generation:2d} age={a.state.age:5d} "
              f"stress={a.state.stress:.2f} tags={tags}")
    print()

def restore_agent(snap, spatial_world, faction_registry, culture_pool):
    """Reconstruct an Agent from a snapshot dict."""
    a = Agent(snap['name'], seed=hash(snap['id']) & 0xFFFFFF,
              spatial_world=spatial_world,
              faction_registry=faction_registry,
              culture_pool=culture_pool)
    a.id = snap['id']
    a.alive = snap.get('alive', True)
    a.generation = snap.get('generation', 0)
    a.birth_tick = snap.get('birth_tick', 0)

    # Position
    pos = snap.get('position', {})
    a.position.x = pos.get('x', 10)
    a.position.y = pos.get('y', 10)

    # State
    st = snap.get('state', {})
    for attr in ['stress','energy','age','cooperation','stability','fear',
                 'valence','arousal','dominance','pair_bond_strength','hunger']:
        if attr in st:
            setattr(a.state, attr, st[attr])

    # Biology
    bio = snap.get('biology', {})
    for attr in ['biological_sex','sexual_orientation','physical_attractiveness',
                 'libido','gestation_ticks_remaining']:
        if attr in bio:
            setattr(a, attr, bio[attr])

    # Traits/development
    dev = snap.get('development', {})
    dt = a.development if hasattr(a, 'development') else None
    if dt:
        for attr in ['stage','traits_consolidated','plasticity','trust_baseline',
                     'attachment_rate','avoidance_rate','conflict_sensitivity',
                     'resilience','risk_tolerance','ideology_sensitivity']:
            if attr in dev:
                setattr(dt, attr, dev[attr])
        if 'identity_tags' in dev:
            dt.identity_tags = dev['identity_tags']

    # Psychology
    psy = snap.get('psychology', {})
    if hasattr(a, 'psychology'):
        for attr in ['valence','arousal','dominance','mood_inertia']:
            if attr in psy:
                setattr(a.psychology, attr, psy[attr])

    # Experience/memory
    exp = snap.get('experience', {})
    if hasattr(a, 'experience'):
        for attr in ['identity_tags','scars','top_bonds']:
            if attr in exp:
                setattr(a.experience, attr, exp[attr])

    # Relationships — use RelationshipBook.get() to create entries
    rels = snap.get('relationships', {})
    if hasattr(a, 'relationships'):
        for oid, rdata in rels.items():
            r = a.relationships.get(oid)  # creates if not exists
            for attr in ['trust','avoidance','influence','attachment','resentment','interactions','allied']:
                if attr in rdata:
                    setattr(r, attr, rdata[attr])

    # Init subsystems
    init_generational_agent(a, generation=a.generation,
                             household_id=snap.get('household_id'),
                             parents=snap.get('parent_ids',[]),
                             birth_tick=a.birth_tick)
    init_apprenticeship_agent(a)
    init_governance_agent(a)
    biology_mod.init_agent(a)
    init_innovation_agent(a)
    init_information_agent(a)

    return a

def main():
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    output_dir = OUTPUT_ROOT / "run_1"
    output_dir.mkdir(parents=True, exist_ok=True)

    print(f"RESUMING from tick {START_TICK-1} → running to tick {END_TICK}")

    # Load prior state
    with open(PRIOR_DIR/"agents_final.json") as f:
        agent_snaps = json.load(f)
    with open(PRIOR_DIR/"factions.json") as f:
        faction_data = json.load(f)
    with open(PRIOR_DIR/"culture.json") as f:
        culture_data = json.load(f)
    with open(PRIOR_DIR/"group_map.json") as f:
        group_map_raw = json.load(f)

    GROUP_LABEL_TO_IDX = {"A":0,"B":1,"C":2,"D":3}
    group_map_prior = {aid: GROUP_LABEL_TO_IDX.get(gl, 0) for aid, gl in group_map_raw.items()}

    # Build world
    world_rng = random.Random(SEED)
    spatial_world     = SpatialWorld(width=WORLD_W, height=WORLD_H, interaction_radius=3)
    resource_world    = ResourceWorld(width=WORLD_W, height=WORLD_H, n_nodes=120, rng=world_rng)
    faction_registry  = FactionRegistry()
    territory_map     = TerritoryMap(width=WORLD_W, height=WORLD_H)
    institution_registry = InstitutionRegistry()
    culture_pool      = CulturePool()
    reproduction_system = ReproductionSystem(max_population=MAX_POP)
    world_narrative   = WorldNarrative()
    texture_chronicle = TextureChronicle()
    persistence_ledger= PersistenceLedger()
    env               = EnvironmentCycle()
    logistics_world   = LogisticsWorld(WORLD_W, WORLD_H, seed=SEED+44000)
    subsistence_world = SubsistenceWorld(WORLD_W, WORLD_H, seed=SEED+43300)
    genpsych_ledger   = GenerationalPsychologyLedger()
    inst_mem_ledger   = InstitutionalMemoryLedger()
    spatial_world.logistics_world  = logistics_world
    resource_world.logistics_world = logistics_world
    settlement_ledger = SettlementLedger()

    # Restore agents — only alive ones
    alive_snaps = [s for s in agent_snaps if s.get('alive', False)]
    print(f"Restoring {len(alive_snaps)} living agents from tick 2000...")
    agents = []
    agent_group = {}
    for snap in alive_snaps:
        try:
            a = restore_agent(snap, spatial_world, faction_registry, culture_pool)
            agents.append(a)
            agent_group[a.id] = group_map_prior.get(snap['id'], 0)
        except Exception as ex:
            print(f"  Warning: failed to restore {snap.get('name','?')}: {ex}")

    # Restore factions
    for fd in faction_data:
        members = [a for a in agents if a.id in fd.get('members',[])]
        if not members:
            continue  # skip fully extinct factions
        fac = faction_registry.create_faction(members[0].id)
        # Override the auto-generated id/name with saved ones
        old_fid = fac.id
        fac.id = fd['id']
        fac.name = fd['name']
        fac.members = [a.id for a in members]
        fac.hostility = fd.get('hostility', {})
        # Re-key in registry dict and update agent→faction map
        del faction_registry.factions[old_fid]
        faction_registry.factions[fac.id] = fac
        for a in members:
            faction_registry._agent_faction[a.id] = fac.id

    # Restore culture memes directly into CulturePool
    from schemas import Meme
    culture_pool.memes = {}
    for m in culture_data.get('meme_list', []):
        mid = m.get('id', f"m_{m['label'][:6]}")
        meme_obj = Meme(
            id=mid, label=m['label'], valence=m['valence'],
            spread_rate=m.get('spread_rate', 0.05),
            strength=m.get('strength', 0.3)
        )
        culture_pool.memes[mid] = meme_obj
    # Restore agent→meme assignments
    if 'agent_memes' in culture_data:
        culture_pool._agent_memes = culture_data['agent_memes']
    print(f"  Restored {len(culture_pool.memes)} memes")

    print(f"Restored: {len(agents)} agents, {len(faction_registry.factions)} factions, "
          f"{len(culture_pool.memes) if hasattr(culture_pool,'memes') else 0} memes")

    life_events_mod.initialize_life_events(agents, max_ticks=END_TICK, seed=2, key="resume_1")

    ckpt     = CheckpointWriter(output_dir, interval=500)
    ledger   = DeathLedger()
    event_log   = []
    metric_log  = []
    _counters   = RollingCounters()
    _stream     = EventStream(output_dir/"events.jsonl")
    RUN_MANIFEST = RunManifest(OUTPUT_ROOT)
    RUN_MANIFEST.start(1, output_dir)

    constraint_ledger     = ConstraintLedger()
    generational_ledger   = GenerationalLedger()
    apprenticeship_ledger = ApprenticeshipLedger()
    governance_ledger     = GovernanceLedger()
    innovation_engine     = InnovationEngine()
    information_ledger    = InformationLedger()
    death_logged = set()

    snapshot_report(START_TICK-1, agents, ledger, culture_pool, faction_registry,
                    innovation_engine, _counters, agent_group)

    for tick in range(START_TICK, END_TICK+1):
        phase = env.get_phase(tick)
        phase = subsistence_world.apply_to_phase(phase)

        for sub_ev in subsistence_world.begin_tick(tick):
            d = serialize_event(sub_ev); d["salience"] = 0.50
            subsistence_world.record_event(sub_ev)
            persistence_ledger.record_event(d); event_log.append(d)
            _counters.record(d); _stream.write(d)

        _eco = _eco_health_fn(subsistence_world, agents,
                              recent_deaths=sum(1 for a in agents if not a.alive))
        life_events_mod.step_disease_layer(agents, tick, key="resume_1")
        living = [a for a in agents if a.alive]

        for a in living:
            le = life_events_mod.apply_all_life_effects(a, tick, key="resume_1")
            if le["stress"]:  a.state.stress      = max(0., min(1., a.state.stress      + le["stress"]*0.012))
            if le["support"]: a.state.cooperation = max(0., min(1., a.state.cooperation + le["support"]*0.008))
            if le["trust"]:   a.state.stability   = max(0., min(1., a.state.stability   + le["trust"]*0.006))

        for a in list(living):
            if not a.alive: continue
            ev = safe_agent_tick(a, tick, phase, agents,
                spatial_world=spatial_world, resource_world=resource_world,
                faction_registry=faction_registry, territory_map=territory_map,
                institution_registry=institution_registry, culture_pool=culture_pool,
                world_narrative=world_narrative, texture_chronicle=texture_chronicle,
                governance_ledger=governance_ledger, eco_health=_eco)
            if not ev: continue
            d = serialize_event(ev); d["salience"] = salience_mod.score(d)
            persistence_ledger.record_event(d); event_log.append(d)
            _counters.record(d); _stream.write(d)

            if ev.event_type == "birth":
                child_id   = ev.context.get("child_id")
                parent_ids = ev.context.get("parent_ids", [])
                child = next((a for a in agents if a.id == child_id), None)
                if child:
                    parents = [a for a in agents if a.id in parent_ids]
                    assign_child_context(child, parents, tick, generational_ledger)
                    init_innovation_agent(child); init_information_agent(child); init_governance_agent(child)
                    for pid in parent_ids:
                        if pid in agent_group:
                            agent_group[child.id] = agent_group[pid]; break

            if ev.event_type == "death":
                dead = next((a for a in agents if a.id == ev.actor_id), None)
                if dead and dead.id not in death_logged:
                    death_logged.add(dead.id)
                    ledger.record(build_death_record(dead, tick, agents))
                    psychology_mod.notify_death_to_population(dead, agents)

        # Feed every agent
        for a in [x for x in agents if x.alive]:
            for sub_ev in subsistence_world.agent_tick(a, tick, phase.name,
                                                        culture_pool=culture_pool,
                                                        faction_registry=faction_registry):
                d = serialize_event(sub_ev); d["salience"] = 0.52
                subsistence_world.record_event(sub_ev)
                persistence_ledger.record_event(d); event_log.append(d)
                _counters.record(d); _stream.write(d)

        # Reproduction every 25 ticks
        if tick % 25 == 0:
            newborns = reproduction_system.tick(
                agents, spatial_world, faction_registry,
                culture_pool, random.Random(tick*7), genpsych_ledger=genpsych_ledger,
                tick=tick, eco_health=_eco)
            for child in newborns:
                birth_parents = list(getattr(child, "_birth_parents", []))
                assign_child_context(child, birth_parents, tick, generational_ledger)
                init_innovation_agent(child); init_information_agent(child); init_governance_agent(child)
                for p in birth_parents:
                    if p.id in agent_group:
                        agent_group[child.id] = agent_group[p.id]; break
            agents.extend(newborns)

        apply_generational_tick(agents, tick, phase.name, generational_ledger)
        apply_apprenticeship_tick(agents, tick, phase.name, apprenticeship_ledger)
        apply_governance_tick(agents, tick, phase.name, governance_ledger, faction_registry)
        apply_innovation_tick(agents, tick, phase.name, innovation_engine)
        apply_information_tick(agents, tick, information_ledger)
        apply_storykeeper_transmission(agents, tick, phase.name, random.Random(tick+1), genpsych_ledger)
        apply_targeted_care_recovery(agents, tick, phase.name, random.Random(tick+2), genpsych_ledger)
        apply_institutional_memory_tick(agents, tick, phase.name, random.Random(tick+3),
                                        inst_mem_ledger, event_log, faction_registry)
        apply_population_viability_tick(agents, tick, phase.name, spatial_world, random.Random(tick+SEED))

        if tick % 10 == 0:
            lv = [a for a in agents if a.alive]
            pm = population_metrics(lv)
            tm = topology_metrics(lv, faction_registry, tick)
            metric_log.append({
                "tick": tick, "phase": phase.name, "alive_count": len(lv), **pm, **tm,
                "deaths": len(ledger.deaths),
                "births": sum(1 for a in agents if a.generation >= 1),
                "meme_count": len(culture_pool.memes) if hasattr(culture_pool,'memes') else 0,
                "factions": len(faction_registry.factions),
                "conflict_cumulative": _counters.conflict_total,
                "interaction_cumulative": _counters.interaction_total,
                "max_generation": max((a.generation for a in lv), default=0),
                "alive_A": sum(1 for a in lv if agent_group.get(a.id)==0),
                "alive_B": sum(1 for a in lv if agent_group.get(a.id)==1),
                "alive_C": sum(1 for a in lv if agent_group.get(a.id)==2),
                "alive_D": sum(1 for a in lv if agent_group.get(a.id)==3),
            })

        if ckpt.should_write(tick):
            ckpt.write(tick, phase.name, agents, faction_registry, institution_registry, culture_pool)

        if tick % SNAP_EVERY == 0:
            snapshot_report(tick, agents, ledger, culture_pool, faction_registry,
                            innovation_engine, _counters, agent_group)

    # Final outputs
    living_final = [a for a in agents if a.alive]
    (output_dir/"agents_final.json").write_text(json.dumps([a.snapshot() for a in agents], indent=2), encoding="utf-8")
    (output_dir/"deaths.json").write_text(json.dumps(ledger.deaths, indent=2), encoding="utf-8")
    (output_dir/"metrics.json").write_text(json.dumps(metric_log, indent=2), encoding="utf-8")
    (output_dir/"culture.json").write_text(json.dumps(culture_pool.snapshot(), indent=2), encoding="utf-8")
    (output_dir/"factions.json").write_text(json.dumps(
        [{"id":f.id,"name":f.name,"members":f.members,"hostility":f.hostility}
         for f in faction_registry.factions.values()], indent=2), encoding="utf-8")
    (output_dir/"innovation.json").write_text(json.dumps(innovation_engine.snapshot(), indent=2), encoding="utf-8")
    (output_dir/"group_map.json").write_text(json.dumps(
        {aid: GROUP_LABELS[gi] for aid, gi in agent_group.items()}, indent=2), encoding="utf-8")

    initial_ids = {a.id for a in agents if a.generation == 0}
    continuity_mod.build_continuity_outputs(output_dir, agents, event_log,
                                            initial_ids, culture_pool, faction_registry, generational_ledger)

    print(f"\n{'='*60}")
    print(f"  FINAL: {len(living_final)} alive after tick {END_TICK}")
    print(f"  Total ever: {len(agents)}")
    print(f"  Births this run: {sum(1 for a in agents if a.generation>=1)}")
    print(f"  Max generation: Gen{max((a.generation for a in living_final), default=0)}")
    print(f"  Conflict rate: {100*_counters.conflict_total/max(1,_counters.interaction_total):.2f}%")
    print(f"  Innovation successes: {innovation_engine.snapshot().get('summary',{}).get('total_successes',0)}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
