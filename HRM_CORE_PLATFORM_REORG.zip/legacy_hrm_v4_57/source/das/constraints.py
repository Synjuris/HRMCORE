from schemas import Event

def clamp(x, lo=0.0, hi=1.0): return max(lo, min(hi, x))

def init_agent_constraints(agent):
    s=agent.state
    for k,v in {'hunger':0.1,'exhaustion':0.1,'injury':0.0,'safety':0.7,'action_budget':1.0,'movement_budget':0.3,'social_budget':0.35,'resource_budget':0.25,'recovery_budget':0.1,'care_burden':0.0}.items():
        if not hasattr(s,k): setattr(s,k,v)

def begin_tick(agent, phase, tick):
    s=agent.state
    s.action_budget=clamp(1.0-s.exhaustion*0.4-s.injury*0.3)
    s.movement_budget=clamp(0.30*s.action_budget)
    s.social_budget=clamp(0.35*s.action_budget)
    s.resource_budget=clamp(0.25*s.action_budget)
    s.recovery_budget=clamp(0.10+getattr(phase,'rest_quality',0.0)*0.20)
    s.exhaustion=clamp(s.exhaustion+0.0018-getattr(phase,'rest_quality',0.0)*0.018)

def spend_movement(agent, distance, tick, phase):
    agent.state.exhaustion=clamp(agent.state.exhaustion+0.0022*distance)
    return Event(tick, phase, agent.id, 'movement_cost', [], {'distance':distance}, {'exhaustion':0.005*distance}, 'moved')

def spend_resource_action(agent, tick, phase, gained):
    agent.state.exhaustion=clamp(agent.state.exhaustion+0.004)
    return Event(tick, phase, agent.id, 'resource_action', [], {'gained':gained}, {'resource':gained}, 'resource_gain')

def spend_social_action(agent, other, outcome, tick, phase):
    return Event(tick, phase, agent.id, 'social_action', [other.id], {'outcome':outcome}, {'social_budget':-0.02}, outcome)

def maybe_injure_from_conflict(agent, other, tick, phase, rng):
    if rng.random()<0.025:
        agent.state.injury=clamp(agent.state.injury+0.035); agent.state.safety=clamp(agent.state.safety-0.02)
        return Event(tick, phase, agent.id, 'injury', [other.id], {}, {'injury':0.035}, 'injured')
    return None

def recover(agent, tick, phase):
    s=agent.state
    old=(s.stress,s.exhaustion,s.injury)
    s.stress=clamp(s.stress-0.014*s.recovery_budget); s.exhaustion=clamp(s.exhaustion-0.036*s.recovery_budget); s.injury=clamp(s.injury-0.007*s.recovery_budget)
    if old!=(s.stress,s.exhaustion,s.injury):
        return Event(tick, phase, agent.id, 'recovery', [], {}, {'recovery':s.recovery_budget}, 'recovered')

class ConstraintLedger:
    def __init__(self): self.events=[]
    def record(self, ev): self.events.append(ev)
    def snapshot(self):
        return {'events':len(self.events),'injuries':sum(1 for e in self.events if getattr(e,'event_type',None)=='injury')}

def snapshot_agents(agents):
    living=[a for a in agents if getattr(a,'alive',False)]
    avg=lambda attr: round(sum(getattr(a.state,attr,0) for a in living)/len(living),4) if living else 0
    return {'avg_hunger':avg('hunger'),'avg_exhaustion':avg('exhaustion'),'avg_injury':avg('injury'),'avg_safety':avg('safety')}

class _DefaultConfig:
    hunger_injury_pressure = 0.0
    exhaustion_pressure = 0.0
    notes = 'Recovered default constraint config for v4.32 full package.'
DEFAULT_CONFIG = _DefaultConfig()
