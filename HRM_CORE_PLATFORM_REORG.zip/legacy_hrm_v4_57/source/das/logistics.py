"""DAS v04.25 — Environmental Asymmetry & Logistics Layer.

This module makes geography materially uneven without adding named/demo scenarios.
It provides terrain friction, local carrying capacity, storage/spoilage, settlement
pull, and logistics metrics. It is substrate pressure, not narrative scripting.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
import math
import random
from typing import Dict, Iterable, List, Optional, Tuple

from schemas import Event, new_id


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


TERRAINS = ("plain", "forest", "rough", "water_edge", "scarce")

TERRAIN_FRICTION = {
    "plain": 1.00,
    "forest": 1.18,
    "rough": 1.42,
    "water_edge": 1.08,
    "scarce": 1.28,
}

TERRAIN_RESOURCE_BIAS = {
    "plain": 0.52,
    "forest": 0.74,
    "rough": 0.36,
    "water_edge": 0.68,
    "scarce": 0.18,
}

TERRAIN_CAPACITY_BIAS = {
    "plain": 0.62,
    "forest": 0.52,
    "rough": 0.34,
    "water_edge": 0.70,
    "scarce": 0.20,
}


@dataclass
class CellLogistics:
    x: int
    y: int
    terrain: str
    friction: float
    fertility: float
    carrying_capacity: float
    storage: float = 0.0
    infrastructure: float = 0.0
    visits: int = 0
    harvest_pressure: float = 0.0
    settlement_pull: float = 0.0

    def snapshot(self) -> dict:
        out = asdict(self)
        for k, v in list(out.items()):
            if isinstance(v, float):
                out[k] = round(v, 4)
        return out


class LogisticsWorld:
    def __init__(self, width: int, height: int, seed: int = 0) -> None:
        self.width = width
        self.height = height
        self.rng = random.Random(seed + 42500)
        self.cells: Dict[Tuple[int, int], CellLogistics] = {}
        self.events: List[dict] = []
        self.total_spoilage = 0.0
        self.total_storage_deposits = 0.0
        self.total_storage_withdrawals = 0.0
        self.total_travel_friction = 0.0
        self.travel_events = 0
        self.capacity_strain_events = 0
        self.settlement_gravity_events = 0
        self._init_cells()

    def _terrain_for(self, x: int, y: int) -> str:
        # Deterministic, seed-perturbed smooth-ish terrain. No named scenarios.
        edge = min(x, y, self.width - 1 - x, self.height - 1 - y)
        noise = self.rng.random()
        ridge = (math.sin((x + 1) * 0.71) + math.cos((y + 3) * 0.53)) / 2.0
        if edge <= 1 and noise < 0.33:
            return "water_edge"
        if ridge > 0.55:
            return "forest"
        if ridge < -0.55:
            return "rough"
        if noise < 0.10:
            return "scarce"
        return "plain"

    def _init_cells(self) -> None:
        for x in range(self.width):
            for y in range(self.height):
                terrain = self._terrain_for(x, y)
                fertility = clamp(TERRAIN_RESOURCE_BIAS[terrain] + self.rng.uniform(-0.08, 0.08))
                cap = clamp(TERRAIN_CAPACITY_BIAS[terrain] + self.rng.uniform(-0.07, 0.07))
                friction = max(0.75, TERRAIN_FRICTION[terrain] + self.rng.uniform(-0.06, 0.06))
                self.cells[(x, y)] = CellLogistics(
                    x=x, y=y, terrain=terrain, friction=friction,
                    fertility=fertility, carrying_capacity=cap,
                )

    def cell(self, pos_or_x, y: Optional[int] = None) -> CellLogistics:
        if y is None:
            x = int(getattr(pos_or_x, "x")); y = int(getattr(pos_or_x, "y"))
        else:
            x = int(pos_or_x); y = int(y)
        return self.cells[(max(0, min(self.width - 1, x)), max(0, min(self.height - 1, y)))]

    def local_friction(self, pos) -> float:
        return self.cell(pos).friction

    def local_fertility(self, pos) -> float:
        return self.cell(pos).fertility

    def local_capacity(self, pos) -> float:
        return self.cell(pos).carrying_capacity

    def tick(self, agents: Iterable, tick: int) -> List[Event]:
        out: List[Event] = []
        occupancy: Dict[Tuple[int, int], int] = {}
        for a in agents:
            if getattr(a, "alive", False):
                occupancy[(a.position.x, a.position.y)] = occupancy.get((a.position.x, a.position.y), 0) + 1

        for key, cell in self.cells.items():
            occ = occupancy.get(key, 0)
            # storage spoils slower where infrastructure exists
            spoil_rate = 0.006 * (1.0 - min(0.55, cell.infrastructure * 0.45))
            spoiled = min(cell.storage, cell.storage * spoil_rate)
            if spoiled > 0:
                cell.storage = max(0.0, cell.storage - spoiled)
                self.total_spoilage += spoiled
            # visits and repeated occupation build low-amplitude infrastructure
            if occ:
                cell.visits += occ
                cell.infrastructure = clamp(cell.infrastructure + 0.0008 * occ + 0.0004 * min(3, occ))
                cell.settlement_pull = clamp(
                    cell.infrastructure * 0.45 + cell.storage * 0.30 + cell.fertility * 0.20 - cell.friction * 0.05
                )
                if cell.settlement_pull > 0.45 and tick % 25 == 0:
                    self.settlement_gravity_events += 1
                    out.append(Event(
                        tick=tick, phase="logistics", actor_id="world",
                        event_type="settlement_gravity",
                        participants=[],
                        context={"cell": [cell.x, cell.y], "settlement_pull": round(cell.settlement_pull, 4), "occupancy": occ},
                        impact={"settlement_pull": round(cell.settlement_pull, 4)},
                        outcome="settlement_pressure_detected",
                    ))
                # over capacity raises local strain
                if occ / max(1.0, cell.carrying_capacity * 8.0) > 1.0:
                    self.capacity_strain_events += 1
                    out.append(Event(
                        tick=tick, phase="logistics", actor_id="world",
                        event_type="capacity_strain",
                        participants=[],
                        context={"cell": [cell.x, cell.y], "occupancy": occ, "carrying_capacity": round(cell.carrying_capacity, 4)},
                        impact={"strain": round(occ / max(1.0, cell.carrying_capacity * 8.0), 4)},
                        outcome="local_capacity_exceeded",
                    ))
            else:
                cell.settlement_pull = clamp(cell.settlement_pull * 0.995 + cell.infrastructure * 0.002)
                cell.infrastructure = clamp(cell.infrastructure * 0.9995)
            cell.harvest_pressure = clamp(cell.harvest_pressure * 0.965)
        return out

    def record_travel(self, distance: float, pos) -> dict:
        friction = self.local_friction(pos)
        cost = float(distance) * friction
        self.total_travel_friction += cost
        self.travel_events += 1
        return {"terrain_friction": round(friction, 4), "travel_cost": round(cost, 4)}

    def modulate_harvest(self, agent, gained: float) -> float:
        cell = self.cell(agent.position)
        if gained <= 0:
            # sparse/scarce terrain slightly increases hunger/stress pressure
            if cell.fertility < 0.25:
                agent.state.hunger = clamp(getattr(agent.state, "hunger", 0.0) + 0.006)
                agent.state.stress = clamp(agent.state.stress + 0.003)
            return 0.0
        # fertile/infrastructure cells improve harvest usefulness; strain suppresses it.
        multiplier = 0.72 + cell.fertility * 0.42 + cell.infrastructure * 0.18
        adjusted = max(0.0, gained * multiplier)
        delta = adjusted - gained
        agent.state.resource_stock = clamp(agent.state.resource_stock + delta)
        cell.harvest_pressure = clamp(cell.harvest_pressure + adjusted * 0.08)
        # low-stress/non-starving agents deposit tiny surplus into local storage.
        surplus_condition = agent.state.resource_stock > 0.42 and agent.state.stress < 0.72 and getattr(agent.state, "hunger", 0.0) < 0.62
        # v04.39: make surplus visible before agriculture. Small groups cache excess food/hides
        # opportunistically; this creates a real storage gradient for later economy/institutions.
        if surplus_condition and agent.rng.random() < 0.34:
            deposit = min(agent.state.resource_stock - 0.34, max(0.004, adjusted * agent.rng.uniform(0.10, 0.28)))
            if deposit > 0:
                agent.state.resource_stock = clamp(agent.state.resource_stock - deposit)
                cell.storage = clamp(cell.storage + deposit, 0.0, 5.0)
                self.total_storage_deposits += deposit
        return adjusted

    def attempt_storage_withdrawal(self, agent, tick: int, phase: str) -> Optional[Event]:
        cell = self.cell(agent.position)
        need = max(getattr(agent.state, "hunger", 0.0), 1.0 - agent.state.resource_stock)
        if cell.storage <= 0.02 or need < 0.35:
            return None
        pull = min(cell.storage, 0.035 + need * 0.045)
        cell.storage = max(0.0, cell.storage - pull)
        agent.state.resource_stock = clamp(agent.state.resource_stock + pull)
        agent.state.hunger = clamp(getattr(agent.state, "hunger", 0.0) - pull * 0.55)
        agent.state.energy = clamp(agent.state.energy + pull * 0.25)
        self.total_storage_withdrawals += pull
        return Event(
            tick=tick, phase=phase, actor_id=agent.id,
            event_type="logistics_storage_withdrawal",
            participants=[],
            context={"cell": [cell.x, cell.y], "amount": round(pull, 4), "storage_remaining": round(cell.storage, 4)},
            impact={"resource_gain": round(pull, 4), "hunger_reduction": round(pull * 0.55, 4)},
            outcome="stored_resource_used",
        )

    def settlement_metrics(self, agents: Iterable) -> dict:
        living = [a for a in agents if getattr(a, "alive", False)]
        if not living:
            return {
                "logistics_settlement_concentration": 0.0,
                "logistics_avg_cell_fertility_occupied": 0.0,
                "logistics_avg_cell_friction_occupied": 0.0,
                "logistics_storage_total": round(sum(c.storage for c in self.cells.values()), 4),
                "logistics_infrastructure_total": round(sum(c.infrastructure for c in self.cells.values()), 4),
            }
        occ: Dict[Tuple[int, int], int] = {}
        fert = []
        fric = []
        pulls = []
        for a in living:
            key = (a.position.x, a.position.y)
            occ[key] = occ.get(key, 0) + 1
            c = self.cells[key]
            fert.append(c.fertility)
            fric.append(c.friction)
            pulls.append(c.settlement_pull)
        max_occ = max(occ.values()) if occ else 0
        return {
            "logistics_settlement_concentration": round(max_occ / max(1, len(living)), 4),
            "logistics_occupied_cells": len(occ),
            "logistics_avg_cell_fertility_occupied": round(sum(fert) / len(fert), 4),
            "logistics_avg_cell_friction_occupied": round(sum(fric) / len(fric), 4),
            "logistics_avg_settlement_pull_occupied": round(sum(pulls) / len(pulls), 4),
            "logistics_storage_total": round(sum(c.storage for c in self.cells.values()), 4),
            "logistics_infrastructure_total": round(sum(c.infrastructure for c in self.cells.values()), 4),
            "logistics_total_spoilage": round(self.total_spoilage, 4),
            "logistics_storage_deposits": round(self.total_storage_deposits, 4),
            "logistics_storage_withdrawals": round(self.total_storage_withdrawals, 4),
            "logistics_travel_events": self.travel_events,
            "logistics_total_travel_friction": round(self.total_travel_friction, 4),
            "logistics_capacity_strain_events": self.capacity_strain_events,
            "logistics_settlement_gravity_events": self.settlement_gravity_events,
        }

    def snapshot(self, agents: Iterable = ()) -> dict:
        cells = [c.snapshot() for c in self.cells.values()]
        # keep output bounded/readable: top strategic cells only, full aggregate retained
        top = sorted(cells, key=lambda c: (c.get("settlement_pull", 0), c.get("storage", 0), c.get("infrastructure", 0)), reverse=True)[:25]
        terrain_counts: Dict[str, int] = {}
        for c in self.cells.values():
            terrain_counts[c.terrain] = terrain_counts.get(c.terrain, 0) + 1
        return {
            "version": "v04.25",
            "summary": self.settlement_metrics(agents),
            "terrain_counts": terrain_counts,
            "top_cells": top,
        }
