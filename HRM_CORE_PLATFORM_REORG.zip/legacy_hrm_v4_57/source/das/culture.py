"""
Culture Propagation — Layer 9
A CulturePool holds the active meme set.
Memes spread between agents on cooperative contact; die when spread_rate decays;
mutate slightly each generation.  High-valence memes reinforce prosocial behavior;
negative memes amplify conflict and resentment.
Each agent carries a cultural_alignment score (average valence of absorbed memes).
"""
import random
from typing import Dict, List
from schemas import Meme, new_id


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


SEED_MEMES = [
    Meme(id="m_coop",     label="cooperation_norm",    valence=+0.80, spread_rate=0.06, strength=0.35),
    Meme(id="m_distrust", label="distrust_outsiders",  valence=-0.60, spread_rate=0.05, strength=0.35),
    Meme(id="m_share",    label="resource_sharing",    valence=+0.70, spread_rate=0.04, strength=0.20),
    Meme(id="m_dom",      label="dominance_hierarchy",  valence=-0.30, spread_rate=0.05, strength=0.25),
]

SPREAD_CHANCE_BASE = 0.12
MEME_DECAY = 0.0012
MUTATION_CHANCE = 0.035
MUTATION_INITIAL_STRENGTH = 0.70
MUTATION_CARRIER_COUNT = 2


class CulturePool:
    def __init__(self) -> None:
        self.memes: Dict[str, Meme] = {m.id: m for m in SEED_MEMES}
        self._agent_memes: Dict[str, List[str]] = {}   # agent_id -> [meme_id]

    def seed_agent(self, agent_id: str, rng: random.Random) -> None:
        # Give each agent 1–2 random memes at birth
        sample = rng.sample(list(self.memes.keys()), k=min(2, len(self.memes)))
        self._agent_memes[agent_id] = sample

    def try_spread(self, sender_id: str, receiver_id: str, rng: random.Random,
                   receiver_openness: float) -> None:
        sender_memes = self._agent_memes.get(sender_id, [])
        if not sender_memes:
            return
        meme_id = rng.choice(sender_memes)
        meme = self.memes.get(meme_id)
        if meme is None:
            return
        receiver_list = self._agent_memes.setdefault(receiver_id, [])
        if meme_id in receiver_list:
            return   # already has it
        spread_prob = meme.spread_rate * receiver_openness * SPREAD_CHANCE_BASE / SPREAD_CHANCE_BASE
        if rng.random() < spread_prob:
            receiver_list.append(meme_id)
            meme.strength = min(1.0, meme.strength + 0.008)  # strength grows with successful spread

    def mutate(self, rng: random.Random, tick: int, agents: list = None) -> None:
        """Occasionally spawn a mutated child meme and seed it into carriers.

        In v04.2 mutated memes entered the global pool but usually had no living
        carrier, so they decayed before they could spread. v04.3 gives each new
        meme one or two initial carriers selected from living agents.
        """
        if rng.random() > MUTATION_CHANCE:
            return
        parent = rng.choice(list(self.memes.values()))
        child_id = new_id("meme")
        child = Meme(
            id=child_id,
            label=parent.label + "_v" + str(tick),
            valence=clamp(parent.valence + rng.uniform(-0.20, 0.20), -1.0, 1.0),
            spread_rate=clamp(parent.spread_rate + rng.uniform(-0.005, 0.02), 0.02, 0.12),
            strength=max(MUTATION_INITIAL_STRENGTH, parent.strength * 0.80),
            origin_tick=tick,
        )
        self.memes[child_id] = child

        living = [a for a in (agents or []) if getattr(a, "alive", False)]
        if living:
            carriers = rng.sample(living, k=min(MUTATION_CARRIER_COUNT, len(living)))
            for carrier in carriers:
                self._agent_memes.setdefault(carrier.id, [])
                if child_id not in self._agent_memes[carrier.id]:
                    self._agent_memes[carrier.id].append(child_id)

    def decay(self) -> None:
        for meme in list(self.memes.values()):
            meme.strength = max(0.0, meme.strength - MEME_DECAY)
        # Prune dead memes
        dead = [mid for mid, m in self.memes.items() if m.strength <= 0.0 and mid not in ("m_coop", "m_distrust", "m_share", "m_dom")]
        for mid in dead:
            del self.memes[mid]
            for agent_list in self._agent_memes.values():
                if mid in agent_list:
                    agent_list.remove(mid)

    def update_agent_alignment(self, agent) -> None:
        meme_ids = self._agent_memes.get(agent.id, [])
        if not meme_ids:
            agent.state.cultural_alignment = 0.50
            return
        valences = [self.memes[mid].valence for mid in meme_ids if mid in self.memes]
        if valences:
            avg = sum(valences) / len(valences)
            # Normalize -1…1 to 0…1
            agent.state.cultural_alignment = clamp((avg + 1.0) / 2.0)

    def apply_alignment_effects(self, agent) -> None:
        ca = agent.state.cultural_alignment
        # High cultural alignment (prosocial) → cooperation bonus, stress reduction
        # Low alignment (antisocial) → dominance bonus, cooperation penalty
        agent.state.cooperation = clamp(agent.state.cooperation + (ca - 0.50) * 0.015)
        agent.state.stress = clamp(agent.state.stress - (ca - 0.50) * 0.005)

    def snapshot(self, agent_id: str = None) -> dict:
        result = {
            "active_memes": len(self.memes),
            "meme_list": [
                {"id": m.id, "label": m.label, "valence": round(m.valence, 3),
                 "strength": round(m.strength, 4), "origin_tick": m.origin_tick,
                 "carriers": sum(1 for mids in self._agent_memes.values() if m.id in mids)}
                for m in self.memes.values()
            ],
        }
        if agent_id:
            result["agent_memes"] = self._agent_memes.get(agent_id, [])
        return result
