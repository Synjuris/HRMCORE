"""
archetypes.py — v04.13 primitive archetype detection

Observer-only. Assigns behavioral archetype labels to agents based on
their recorded event history and final relationship state.

Archetypes are NOT identity or personality. They are observable behavioral
patterns over the run window. An agent can shift archetypes across epochs.

Six primitive archetypes (mutually exclusive per window, ranked by score):

  mediator     High negotiation success rate + cross-faction cooperation
               + low resentment received
  isolate      Low interaction count + high avoidance + few bonds
  aggressor    High conflict initiation rate + high resentment imparted
               + low negotiation attempts
  connector    High cross-faction cooperation + many distinct partners
               + high attachment scores
  opportunist  High deception rate + high resource stock + high dominance
               + inconsistent cooperation (cooperates when strong)
  stabilizer   High institution membership + conflict-prevention events
               + low stress variance + mediates without initiating conflict

Each archetype has a score function. The highest-scoring archetype is
assigned. Scores are returned for all six so drift can be tracked.

This module only reads from the event ledger and agent snapshot.
It does not modify any agent state.
"""

from dataclasses import dataclass, field
from pathlib import Path
import gzip
import json
from typing import Dict, List, Optional, Tuple


ARCHETYPES = ["mediator", "isolate", "aggressor", "connector", "opportunist", "stabilizer"]


@dataclass
class AgentArchetype:
    agent_id:   str
    agent_name: str
    archetype:  str
    scores:     Dict[str, float] = field(default_factory=dict)
    evidence:   Dict[str, float] = field(default_factory=dict)   # raw signals

    def to_dict(self) -> dict:
        return {
            "agent_id":  self.agent_id,
            "agent_name": self.agent_name,
            "archetype": self.archetype,
            "scores":    {k: round(v, 4) for k, v in self.scores.items()},
            "evidence":  {k: round(v, 4) if isinstance(v, float) else v
                          for k, v in self.evidence.items()},
        }


# ── Signal extraction from event ledger ───────────────────────────────────────

def _extract_signals(agent_id: str, events: List[dict],
                     agent_snap: Optional[dict] = None) -> dict:
    """
    Compute raw behavioral signals for one agent over the event window.
    """
    interactions_as_actor   = [e for e in events if e.get("actor_id") == agent_id
                                and e.get("event_type") == "interaction"]
    interactions_as_target  = [e for e in events if agent_id in e.get("participants", [])
                                and e.get("event_type") == "interaction"]
    all_interactions        = interactions_as_actor + interactions_as_target

    n_interact = len(all_interactions)
    n_conflict_initiated  = sum(1 for e in interactions_as_actor if e.get("outcome") == "conflict")
    n_conflict_received   = sum(1 for e in interactions_as_target if e.get("outcome") == "conflict")
    n_coop_initiated      = sum(1 for e in interactions_as_actor if e.get("outcome") == "cooperation")

    negotiation_events    = [e for e in events if e.get("actor_id") == agent_id
                              and e.get("event_type") == "negotiation"]
    n_neg_attempts = len(negotiation_events)
    n_neg_success  = sum(1 for e in negotiation_events if e.get("outcome") == "negotiation_success")

    deception_events      = [e for e in events if e.get("actor_id") == agent_id
                              and e.get("event_type") == "deception"]
    n_deception = len(deception_events)

    institution_prevention = [e for e in interactions_as_actor
                               if e.get("context", {}).get("institution_prevented_conflict")]
    n_inst_prevented = len(institution_prevention)

    # Distinct partners
    partner_ids = set()
    for e in all_interactions:
        if e.get("actor_id") == agent_id:
            for p in e.get("participants", []):
                partner_ids.add(p)
        else:
            partner_ids.add(e.get("actor_id"))
    n_partners = len(partner_ids)

    # Cross-faction interactions
    xf_coop = sum(
        1 for e in interactions_as_actor
        if e.get("outcome") == "cooperation"
        and e.get("context", {}).get("faction_hostility", 0) > 0
    )

    # From final snapshot
    snap_rel = agent_snap.get("relationships", {}) if agent_snap else {}
    avg_resentment_given = 0.0   # resentment this agent has imparted (check others' snapshots — approximate)
    avg_trust_received   = 0.0
    avg_avoidance        = 0.0
    avg_attachment       = 0.0
    n_bonds = 0
    if snap_rel:
        resentments = [v.get("resentment", 0.0) for v in snap_rel.values()]
        trusts      = [v.get("trust", 0.5) for v in snap_rel.values()]
        avoidances  = [v.get("avoidance", 0.0) for v in snap_rel.values()]
        attachments = [v.get("attachment", 0.0) for v in snap_rel.values()]
        n_bonds = sum(1 for v in snap_rel.values() if v.get("attachment", 0) > 0.40)
        avg_resentment_given = sum(resentments) / len(resentments) if resentments else 0.0
        avg_trust_received   = sum(trusts) / len(trusts) if trusts else 0.5
        avg_avoidance        = sum(avoidances) / len(avoidances) if avoidances else 0.0
        avg_attachment       = sum(attachments) / len(attachments) if attachments else 0.0

    state = agent_snap.get("state", {}) if agent_snap else {}
    dominance     = state.get("dominance", 0.5)
    resource_stock = state.get("resource_stock", 0.5)
    stress        = state.get("stress", 0.3)

    exp = agent_snap.get("experience", {}) if agent_snap else {}
    scars  = exp.get("scars", 0.0)
    grudge_val = exp.get("active_grudge_edges", 0)
    n_grudge_edges = len(grudge_val) if isinstance(grudge_val, list) else int(grudge_val)

    return {
        "n_interact":           n_interact,
        "n_conflict_initiated": n_conflict_initiated,
        "n_conflict_received":  n_conflict_received,
        "n_coop_initiated":     n_coop_initiated,
        "n_neg_attempts":       n_neg_attempts,
        "n_neg_success":        n_neg_success,
        "n_deception":          n_deception,
        "n_inst_prevented":     n_inst_prevented,
        "n_partners":           n_partners,
        "xf_coop":              xf_coop,
        "n_bonds":              n_bonds,
        "avg_resentment_given": avg_resentment_given,
        "avg_trust_received":   avg_trust_received,
        "avg_avoidance":        avg_avoidance,
        "avg_attachment":       avg_attachment,
        "dominance":            dominance,
        "resource_stock":       resource_stock,
        "stress":               stress,
        "scars":                scars,
        "n_grudge_edges":       n_grudge_edges,
    }


def _clamp01(x: float) -> float:
    return max(0.0, min(1.0, x))


# ── Archetype score functions ──────────────────────────────────────────────────

def _score_mediator(s: dict) -> float:
    n = max(s["n_interact"], 1)
    neg_rate   = s["n_neg_attempts"] / n
    neg_succ   = (s["n_neg_success"] / s["n_neg_attempts"]) if s["n_neg_attempts"] > 0 else 0.0
    xf_rate    = s["xf_coop"] / n
    low_resent = 1.0 - s["avg_resentment_given"]
    return _clamp01(neg_rate * 2.0 + neg_succ * 1.5 + xf_rate * 1.0 + low_resent * 0.5) / 5.0


def _score_isolate(s: dict) -> float:
    n = s["n_interact"]
    low_interact = _clamp01(1.0 - n / 50.0)   # 0 interactions → 1.0
    avoidance    = s["avg_avoidance"]
    few_bonds    = _clamp01(1.0 - s["n_bonds"] / 5.0)
    low_partners = _clamp01(1.0 - s["n_partners"] / 8.0)
    return _clamp01(low_interact * 1.5 + avoidance * 1.2 + few_bonds * 0.8 + low_partners * 0.5) / 4.0


def _score_aggressor(s: dict) -> float:
    n = max(s["n_interact"], 1)
    conflict_rate = s["n_conflict_initiated"] / n
    resentment    = s["avg_resentment_given"]
    low_neg       = 1.0 - (s["n_neg_attempts"] / n)
    scars_proxy   = _clamp01(s["scars"] * 3.0)
    grudges       = _clamp01(s["n_grudge_edges"] / 5.0)
    return _clamp01(conflict_rate * 2.0 + resentment * 1.5 + low_neg * 0.5 + scars_proxy * 0.5 + grudges * 0.5) / 5.0


def _score_connector(s: dict) -> float:
    n = max(s["n_interact"], 1)
    partner_rate  = _clamp01(s["n_partners"] / 8.0)
    xf_rate       = s["xf_coop"] / n
    attachment    = s["avg_attachment"]
    bonds         = _clamp01(s["n_bonds"] / 5.0)
    trust         = s["avg_trust_received"] - 0.5   # above baseline
    return _clamp01(partner_rate * 1.5 + xf_rate * 1.5 + attachment * 1.0 + bonds * 0.8 + trust * 0.2) / 5.0


def _score_opportunist(s: dict) -> float:
    n = max(s["n_interact"], 1)
    dec_rate      = _clamp01(s["n_deception"] / (n * 0.1 + 1))
    dominance     = s["dominance"]
    resource      = s["resource_stock"]
    inconsistency = abs(s["n_coop_initiated"] / n - 0.5)   # peak at 0.5 (mixed)
    return _clamp01(dec_rate * 2.5 + dominance * 0.8 + resource * 0.5 + inconsistency * 0.7) / 4.5


def _score_stabilizer(s: dict) -> float:
    n = max(s["n_interact"], 1)
    inst_rate     = s["n_inst_prevented"] / n
    low_conflict  = _clamp01(1.0 - s["n_conflict_initiated"] / n)
    low_stress    = _clamp01(1.0 - s["stress"])
    trust         = s["avg_trust_received"] - 0.5
    attachment    = s["avg_attachment"]
    return _clamp01(inst_rate * 3.0 + low_conflict * 1.0 + low_stress * 0.8 + trust * 0.5 + attachment * 0.7) / 6.0


_SCORERS = {
    "mediator":    _score_mediator,
    "isolate":     _score_isolate,
    "aggressor":   _score_aggressor,
    "connector":   _score_connector,
    "opportunist": _score_opportunist,
    "stabilizer":  _score_stabilizer,
}


# ── Public API ────────────────────────────────────────────────────────────────

def classify_agents(
    agents: List[dict],
    events: List[dict],
    t_start: int = 0,
    t_end: int = 999999,
) -> List[AgentArchetype]:
    """
    Classify all agents over event window [t_start, t_end].
    agents: list of agent snapshot dicts (from checkpoint or agents_final.json)
    events: full event ledger
    Returns: list of AgentArchetype, one per agent.
    """
    window_events = [
        e for e in events
        if t_start <= e.get("tick", -1) <= t_end
    ]
    snap_by_id = {a["id"]: a for a in agents}

    results = []
    for agent in agents:
        aid  = agent["id"]
        snap = snap_by_id.get(aid)
        sigs = _extract_signals(aid, window_events, snap)
        scores = {name: scorer(sigs) for name, scorer in _SCORERS.items()}
        best  = max(scores, key=lambda k: scores[k])
        results.append(AgentArchetype(
            agent_id=aid,
            agent_name=agent.get("name", aid),
            archetype=best,
            scores=scores,
            evidence=sigs,
        ))

    return results



def _load_checkpoint_agents(run_dir: Optional[Path], tick: int) -> Optional[List[dict]]:
    """Load nearest checkpoint agent snapshot at or before tick.

    This prevents archetype windows from using end-of-run relationship/state
    values for early epochs. If checkpoints are unavailable, callers fall back
    to final agents but should mark the result as lower confidence.
    """
    if run_dir is None:
        return None
    ck_dir = Path(run_dir) / "checkpoints"
    idx_path = ck_dir / "index.json"
    if not idx_path.exists():
        return None
    try:
        index = json.loads(idx_path.read_text(encoding="utf-8"))
        candidates = [row for row in index if int(row.get("tick", -1)) <= int(tick)]
        if not candidates:
            candidates = index[:1]
        if not candidates:
            return None
        row = max(candidates, key=lambda r: int(r.get("tick", -1)))
        raw = (ck_dir / row["file"]).read_bytes()
        checkpoint = json.loads(gzip.decompress(raw).decode("utf-8"))
        return checkpoint.get("agents") or None
    except Exception:
        return None


def classify_by_epoch(
    agents: List[dict],
    events: List[dict],
    epochs,   # List[Epoch] from epochs.py
    run_dir: Optional[Path] = None,
) -> List[dict]:
    """
    Classify agents per epoch, returning a list of epoch archetype snapshots.
    Useful for tracking archetype drift across run phases.
    """
    from epochs import Epoch
    out = []
    for ep in epochs:
        epoch_agents = _load_checkpoint_agents(run_dir, ep.end_tick)
        snapshot_source = "checkpoint" if epoch_agents else "agents_final_fallback"
        if not epoch_agents:
            epoch_agents = agents
        classifications = classify_agents(epoch_agents, events, ep.start_tick, ep.end_tick)
        out.append({
            "epoch_label":  ep.label,
            "start_tick":   ep.start_tick,
            "end_tick":     ep.end_tick,
            "snapshot_source": snapshot_source,
            "archetypes":   [c.to_dict() for c in classifications],
            "distribution": _distribution(classifications),
        })
    return out


def _distribution(classifications: List[AgentArchetype]) -> Dict[str, int]:
    dist: Dict[str, int] = {a: 0 for a in ARCHETYPES}
    for c in classifications:
        dist[c.archetype] = dist.get(c.archetype, 0) + 1
    return dist
