import json
from pathlib import Path
class CheckpointWriter:
    def __init__(self, output_dir, interval=50): self.output_dir=Path(output_dir); self.interval=interval; self.index=[]
    def should_write(self,tick): return self.interval>0 and tick%self.interval==0
    def write(self, tick, phase_name, agents, faction_registry=None, institution_registry=None, culture_pool=None, metric_row=None):
        p=self.output_dir/f'checkpoint_{tick:05d}.json'
        p.write_text(json.dumps({'tick':tick,'phase':phase_name,'agents':[a.snapshot() for a in agents],'metric_row':metric_row}, indent=2, default=str), encoding='utf-8')
        self.index.append(str(p.name))
    def close(self): (self.output_dir/'checkpoints_index.json').write_text(json.dumps(self.index, indent=2), encoding='utf-8')
