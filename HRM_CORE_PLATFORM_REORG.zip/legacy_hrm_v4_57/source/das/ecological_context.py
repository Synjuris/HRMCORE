"""
ecological_context.py — DAS v04.43

Shared environmental health signal used by both reproduction goal priority
and lethality escalation. Computed once per tick, passed to both systems.

Real organisms respond to environmental conditions at a species level —
not just personal physiology. This module exposes that signal.

ecological_health()  →  float [0, 1]
    0.0 = collapse conditions (famine, winter, population crash)
    1.0 = ideal conditions (spring, abundance, stable population)

Components:
    - Season quality        (spring/summer upregulate, winter suppresses)
    - Fauna health          (prey population relative to historical max)
    - Resource availability (average agent resource stock)
    - Population viability  (current living count relative to MAX_POPULATION)
    - Recent death rate     (deaths this window as fraction of population)

Used by:
    goals.py        — reproduce goal priority
    lethality.py    — desperation and extinction-pressure escalation
    reproduction.py — modulate base reproduction chance
"""

from __future__ import annotations
from typing import Any, List, Optional


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(x)))


# Season quality scores — spring is best, winter worst
SEASON_QUALITY = {
    "spring": 0.85,
    "summer": 0.70,
    "autumn": 0.45,
    "winter": 0.15,
}

# Fauna health: if total fauna is above this fraction of max, conditions are good
FAUNA_HEALTHY_FRACTION = 0.65
FAUNA_MAX_ESTIMATE     = 1200.0   # rough expected max across all species

# Population viability
POP_CRISIS_FLOOR       = 4        # below this, extinction pressure fires
POP_COMFORTABLE        = 10       # above this, density suppression begins


def ecological_health(
    subsistence_world: Any,
    agents: List[Any],
    recent_deaths: int = 0,
    window_ticks: int = 50,
) -> float:
    """
    Compute environmental health index [0, 1] from available world signals.
    Higher = better conditions for reproduction, lower = desperation/lethality pressure.
    """
    # 1. Season quality
    try:
        season_name = subsistence_world.current_season().name.lower()
        season_score = SEASON_QUALITY.get(season_name, 0.50)
    except Exception:
        season_score = 0.50

    # 2. Fauna health (prey availability as ecosystem proxy)
    try:
        total_fauna = sum(
            f.population for f in subsistence_world.fauna.values()
            if getattr(f, "species", "") != "wolves"
        )
        fauna_score = clamp(total_fauna / FAUNA_MAX_ESTIMATE)
    except Exception:
        fauna_score = 0.50

    # 3. Drought / harsh winter modifiers
    try:
        drought      = getattr(subsistence_world, "drought", 0.0)
        harsh_winter = getattr(subsistence_world, "harsh_winter", 0.0)
        weather_penalty = drought * 0.25 + harsh_winter * 0.20
    except Exception:
        weather_penalty = 0.0

    # 4. Population viability
    living = [a for a in agents if getattr(a, "alive", False)]
    n_living = len(living)
    if n_living <= POP_CRISIS_FLOOR:
        pop_score = 0.10   # extinction pressure
    elif n_living >= POP_COMFORTABLE:
        pop_score = 0.70   # comfortable density
    else:
        pop_score = clamp(0.10 + (n_living - POP_CRISIS_FLOOR) /
                          max(1, POP_COMFORTABLE - POP_CRISIS_FLOOR) * 0.60)

    # 5. Recent death rate (deaths per agent per window)
    if n_living > 0 and window_ticks > 0:
        death_rate = recent_deaths / max(1, n_living + recent_deaths)
        death_penalty = clamp(death_rate * 2.0)  # 50% death rate → full penalty
    else:
        death_penalty = 0.0

    # 6. Average resource stock across living agents
    if living:
        avg_resource = sum(
            getattr(a.state, "resource_stock", 0.5) for a in living
        ) / len(living)
    else:
        avg_resource = 0.0

    # Weighted composite
    raw = (
        season_score   * 0.28
        + fauna_score  * 0.22
        + pop_score    * 0.20
        + avg_resource * 0.18
        - weather_penalty * 0.12
        - death_penalty   * 0.12
    )
    return clamp(raw)


def reproduction_drive(
    agent: Any,
    eco_health: float,
) -> float:
    """
    Agent-level reproductive drive [0, 1].
    Combines individual biology with environmental signal.

    High eco_health + high libido + good personal state = strong drive.
    Low eco_health suppresses even high-libido agents.
    But: critically low population triggers desperation override.
    """
    libido   = clamp(getattr(agent, "libido", 0.0))
    energy   = clamp(getattr(agent.state, "energy", 0.5))
    stress   = clamp(getattr(agent.state, "stress", 0.5))
    pair_bond = clamp(getattr(agent.state, "pair_bond_strength", 0.0))

    # Individual fitness for reproduction
    individual = (
        libido   * 0.40
        + energy * 0.25
        + (1.0 - stress) * 0.20
        + pair_bond * 0.15
    )

    # Environmental modulation — good conditions amplify, bad suppress
    env_mult = clamp(0.30 + eco_health * 0.70)  # floor at 0.30 so drive never zeros

    drive = individual * env_mult
    return clamp(drive)


def lethality_eco_modifier(eco_health: float, n_living: int) -> float:
    """
    Environmental modifier for lethality escalation.

    Two opposing forces:
    1. ABUNDANCE SUPPRESSION: good conditions reduce need for lethal competition.
       Agents don't need to kill for resources when resources are plentiful.
    2. EXTINCTION DESPERATION: critically low population triggers panic escalation.
       Small bands facing extinction fight harder for what's left.

    Returns additive modifier to lethality chance. Negative = suppresses, positive = escalates.
    """
    # Abundance suppression — good environment, less reason to kill
    abundance_suppression = -(eco_health * 0.025)

    # Extinction desperation — tiny population, existential stakes
    if n_living <= POP_CRISIS_FLOOR:
        desperation_add = 0.035   # critical — fight or die
    elif n_living <= 6:
        desperation_add = 0.015   # stressed
    else:
        desperation_add = 0.0

    return abundance_suppression + desperation_add
