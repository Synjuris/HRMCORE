"""
innovation.py — DAS v04.27 primitive innovation and recombination layer.

Agents combine two beliefs they hold into a novel inference that neither
contained alone. The inference is weighted by the fidelity of both source
beliefs and the agent's specialization depth and plan_confidence. The output
may be wrong. The civilization acts on it anyway.

Core mechanics:
    PracticeRecord      — a named strategy/method with utility score and tags
    PracticeMemory      — per-agent record of tried/succeeded/failed practices
    InnovationEngine    — world-level recombination registry and diffusion tracker
    recombine()         — combine two inbox beliefs into a novel PracticeRecord
    diffuse()           — spread an innovation through the information layer
    institutional_adopt() — faction institutions absorb high-utility innovations

Recombination sources: agent's BeliefMemory + inbox messages.
Compatible pairs are domain-crossed:
    threat_near × specialist_present → defensive_deployment practice
    resource_available × safe_zone   → surplus_exchange practice
    leader_signal × specialist_present → directed_specialization practice
    resource_scarce × threat_near   → scarcity_defense practice
    safe_zone × resource_available  → settlement_anchor practice

Innovation fidelity = avg(source_a_fidelity, source_b_fidelity) × agent_aptitude.
Below fidelity floor: attempt fails silently. Agent learns from failure.
Successful innovations enter information layer as specialist_present messages
with innovation payload. Diffusion = when another agent receives and acts on one.
Institutional adoption = when a faction institution's strength rises from it.

No scripted outputs. The recombination pairs are fixed; what emerges from them
depends entirely on the agent's current belief state and world conditions.
"""
from __future__ import annotations

import random
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple
from adaptive_roles import role_family


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(x)))


def _new_id() -> str:
    return f"inn_{uuid.uuid4().hex[:8]}"


# ── Practice definitions ───────────────────────────────────────────────────────

# Compatible recombination pairs: (belief_type_a, belief_type_b) → practice_domain
# Each pair produces a different class of practice.
RECOMBINATION_PAIRS: Dict[Tuple[str, str], str] = {
    ("threat_near",        "specialist_present"):  "defensive_deployment",
    ("resource_available", "safe_zone"):           "surplus_exchange",
    ("leader_signal",      "specialist_present"):  "directed_specialization",
    ("resource_scarce",    "threat_near"):         "scarcity_defense",
    ("safe_zone",          "resource_available"):  "settlement_anchor",
    ("specialist_present", "resource_available"):  "knowledge_harvest",
    ("leader_signal",      "resource_scarce"):     "rationing_protocol",
    ("safe_zone",          "specialist_present"):  "mentor_network",
    ("threat_near",        "resource_scarce"):     "crisis_response",
    # Pairs that fire in cooperative/peaceful sims
    ("safe_zone",          "leader_signal"):       "cooperative_governance",
    ("leader_signal",      "safe_zone"):           "cooperative_governance",
    ("leader_signal",      "resource_available"):  "abundance_protocol",
    ("resource_available", "specialist_present"):  "specialized_harvest",
    ("safe_zone",          "resource_available"):  "settlement_anchor",
}

# Capability-family aptitude for recombination.  These are not fixed occupations.
ROLE_APTITUDE: Dict[str, Dict[str, float]] = {
    "defensive_deployment":   {"protection": 0.20, "coordination": 0.12},
    "surplus_exchange":       {"diplomacy": 0.18, "subsistence": 0.10, "logistics": 0.12},
    "directed_specialization":{"coordination": 0.20, "diplomacy": 0.12, "knowledge": 0.10},
    "scarcity_defense":       {"protection": 0.15, "subsistence": 0.15},
    "settlement_anchor":      {"coordination": 0.18, "subsistence": 0.10, "craft": 0.08},
    "knowledge_harvest":      {"knowledge": 0.18, "subsistence": 0.10, "coordination": 0.08},
    "rationing_protocol":     {"coordination": 0.20, "diplomacy": 0.08, "logistics": 0.12},
    "mentor_network":         {"diplomacy": 0.18, "coordination": 0.10, "knowledge": 0.10},
    "crisis_response":        {"protection": 0.18, "coordination": 0.12, "care": 0.08},
    "cooperative_governance": {"diplomacy": 0.22, "coordination": 0.16, "governance": 0.18},
    "abundance_protocol":     {"subsistence": 0.18, "coordination": 0.14, "logistics": 0.10},
    "specialized_harvest":    {"subsistence": 0.20, "coordination": 0.10, "craft": 0.08},
}

# Behavioral effect of a successfully adopted practice (applied to agent state)
PRACTICE_EFFECTS: Dict[str, Dict[str, float]] = {
    "defensive_deployment":    {"fear": -0.03, "stress": -0.02, "stability": +0.04},
    "surplus_exchange":        {"resource_stock": +0.04, "cooperation": +0.03},
    "directed_specialization": {"specialization_depth": +0.008, "plan_confidence": +0.02},
    "scarcity_defense":        {"stress": -0.03, "fear": -0.02},
    "settlement_anchor":       {"stability": +0.05, "social_openness": +0.02},
    "knowledge_harvest":       {"curiosity": +0.03, "specialization_depth": +0.005},
    "rationing_protocol":      {"resource_stock": +0.02, "stress": -0.02},
    "mentor_network":          {"social_openness": +0.03, "linguistic_complexity": +0.004},
    "crisis_response":         {"stress": -0.04, "fear": -0.03, "stability": +0.02},
    "cooperative_governance":  {"cooperation": +0.04, "stability": +0.03, "plan_confidence": +0.02},
    "abundance_protocol":      {"resource_stock": +0.03, "cooperation": +0.02, "stability": +0.02},
    "specialized_harvest":     {"specialization_depth": +0.006, "resource_stock": +0.02},
}


# ── Data structures ───────────────────────────────────────────────────────────

@dataclass
class PracticeRecord:
    name: str
    domain: str
    utility_score: float = 0.0
    fidelity: float = 0.5          # inherited from source belief fidelities
    origin_agent_id: str = ""
    origin_tick: int = 0
    attempts: int = 0
    successes: int = 0
    diffusion_count: int = 0       # how many agents adopted this practice
    institutional_adoptions: int = 0
    tags: List[str] = field(default_factory=list)

    @property
    def success_rate(self) -> float:
        return self.successes / max(1, self.attempts)


class PracticeMemory:
    """Per-agent record of practices tried, succeeded, and failed."""

    def __init__(self) -> None:
        self.known: Dict[str, PracticeRecord] = {}   # domain → best practice
        self.failed: List[str] = []                   # practice names
        self.successful: List[str] = []

    def remember_failure(self, name: str) -> None:
        if name not in self.failed:
            self.failed.append(name)
        if len(self.failed) > 20:
            self.failed = self.failed[-20:]

    def remember_success(self, name: str, record: PracticeRecord) -> None:
        if name not in self.successful:
            self.successful.append(name)
        # Keep best practice per domain
        existing = self.known.get(record.domain)
        if existing is None or record.utility_score > existing.utility_score:
            self.known[record.domain] = record

    def knows_domain(self, domain: str) -> bool:
        return domain in self.known

    def best_practice(self, domain: str) -> Optional[PracticeRecord]:
        return self.known.get(domain)

    def snapshot(self) -> dict:
        return {
            "known_domains": list(self.known.keys()),
            "failed_count": len(self.failed),
            "success_count": len(self.successful),
        }


@dataclass
class InnovationConfig:
    # Recombination
    fidelity_floor: float = 0.12        # min avg source fidelity to attempt
    attempt_rate: float = 0.04          # prob eligible agent attempts per tick
    utility_noise: float = 0.18         # random component in utility score
    success_utility_threshold: float = 0.38  # utility above which = success

    # Aptitude
    depth_weight: float = 0.30          # specialization_depth contribution
    plan_weight: float = 0.25           # plan_confidence contribution
    lc_weight: float = 0.20             # linguistic_complexity contribution
    base_aptitude: float = 0.30         # floor aptitude for any agent

    # Diffusion
    diffusion_rate: float = 0.06        # prob practice spreads per coop interaction
    diffusion_fidelity_decay: float = 0.08  # fidelity lost per diffusion hop

    # Institutional adoption
    inst_adoption_utility_floor: float = 0.60
    inst_strength_bonus: float = 0.04

    # Behavioral effects
    effect_scale: float = 0.85          # scalar on PRACTICE_EFFECTS

    # Ledger
    max_practices: int = 300
    max_events: int = 400


DEFAULT_CONFIG = InnovationConfig()


class InnovationEngine:
    def __init__(self, cfg: InnovationConfig = DEFAULT_CONFIG) -> None:
        self.cfg = cfg
        self.practice_registry: Dict[str, PracticeRecord] = {}
        self.total_attempts: int = 0
        self.total_successes: int = 0
        self.total_diffusions: int = 0
        self.total_institutional_adoptions: int = 0
        self.events: List[dict] = []

    def register_practice(self, record: PracticeRecord) -> None:
        self.practice_registry[record.name] = record
        if len(self.practice_registry) > self.cfg.max_practices:
            # Drop lowest-utility practices
            sorted_p = sorted(self.practice_registry.values(),
                              key=lambda p: p.utility_score)
            for p in sorted_p[:20]:
                del self.practice_registry[p.name]

    def recombine(self, name_a: str, name_b: str) -> Optional[PracticeRecord]:
        """Legacy compat — wraps direct registry lookup."""
        pa = self.practice_registry.get(name_a)
        pb = self.practice_registry.get(name_b)
        if pa is None or pb is None:
            return None
        combined = f"{name_a}_{name_b}_hybrid"
        utility = (pa.utility_score + pb.utility_score
                   + random.uniform(-0.2, 0.5)) / 2
        record = PracticeRecord(
            name=combined, domain="hybrid",
            utility_score=clamp(utility),
            fidelity=(pa.fidelity + pb.fidelity) / 2,
            attempts=1,
            successes=1 if utility > 0.5 else 0,
            tags=list(set(pa.tags + pb.tags)),
        )
        self.register_practice(record)
        return record

    def snapshot(self, agents: Optional[List[Any]] = None) -> dict:
        top = sorted(self.practice_registry.values(),
                     key=lambda p: p.utility_score, reverse=True)[:10]
        return {
            "summary": {
                "total_attempts": self.total_attempts,
                "total_successes": self.total_successes,
                "total_diffusions": self.total_diffusions,
                "total_institutional_adoptions": self.total_institutional_adoptions,
                "registry_size": len(self.practice_registry),
            },
            "top_practices": [
                {
                    "name": p.name,
                    "domain": p.domain,
                    "utility_score": round(p.utility_score, 4),
                    "fidelity": round(p.fidelity, 4),
                    "diffusion_count": p.diffusion_count,
                    "institutional_adoptions": p.institutional_adoptions,
                }
                for p in top
            ],
            "recent_events": self.events[-15:],
        }


# ── Agent init ────────────────────────────────────────────────────────────────

def init_agent(agent: Any) -> None:
    if not hasattr(agent, "practice_memory"):
        agent.practice_memory = PracticeMemory()
    if not hasattr(agent, "innovation_attempts"):
        agent.innovation_attempts = 0
    if not hasattr(agent, "innovation_successes"):
        agent.innovation_successes = 0


# ── Aptitude computation ──────────────────────────────────────────────────────

def _agent_aptitude(agent: Any, domain: str,
                    cfg: InnovationConfig = DEFAULT_CONFIG) -> float:
    """How capable is this agent of generating a useful practice in this domain."""
    s = agent.state
    t = agent.traits
    role_bonus = ROLE_APTITUDE.get(domain, {}).get(role_family(getattr(t, "role", "generalist")), 0.0)
    return clamp(
        cfg.base_aptitude
        + s.specialization_depth * cfg.depth_weight
        + s.plan_confidence     * cfg.plan_weight
        + s.linguistic_complexity * cfg.lc_weight
        + role_bonus
    )


# ── Recombination attempt ─────────────────────────────────────────────────────

def attempt_recombination(
    agent: Any,
    tick: int,
    engine: InnovationEngine,
    cfg: InnovationConfig = DEFAULT_CONFIG,
    rng: Optional[random.Random] = None,
) -> Optional[PracticeRecord]:
    """
    Agent tries to recombine two inbox beliefs into a novel practice.
    Returns PracticeRecord on success, None on failure or skip.
    """
    if rng is None:
        rng = random.Random(tick)

    init_agent(agent)
    inbox = getattr(agent, "inbox", None)
    if inbox is None:
        return None

    # Gather viable inbox messages
    held = {ct: msg for ct, msg in inbox._latest.items()
            if msg.fidelity >= cfg.fidelity_floor}
    if len(held) < 2:
        return None

    # Find a compatible recombination pair
    held_types = set(held.keys())
    candidates = []
    for (ta, tb), domain in RECOMBINATION_PAIRS.items():
        if ta in held_types and tb in held_types:
            fid_avg = (held[ta].fidelity + held[tb].fidelity) / 2.0
            if fid_avg >= cfg.fidelity_floor:
                candidates.append((fid_avg, ta, tb, domain))

    if not candidates:
        return None

    # Pick the highest-fidelity pair
    candidates.sort(reverse=True)
    fid_avg, ta, tb, domain = candidates[0]

    engine.total_attempts += 1
    agent.innovation_attempts += 1

    # Compute utility: fidelity × aptitude + noise
    aptitude = _agent_aptitude(agent, domain, cfg)
    noise = rng.uniform(-cfg.utility_noise * 0.6, cfg.utility_noise)  # can go negative, making failure real
    utility = clamp(fid_avg * 0.45 + aptitude * 0.45 + noise)

    practice_name = f"{domain}_{agent.id[:6]}_{tick}"
    record = PracticeRecord(
        name=practice_name,
        domain=domain,
        utility_score=utility,
        fidelity=fid_avg,
        origin_agent_id=agent.id,
        origin_tick=tick,
        attempts=1,
        successes=1 if utility >= cfg.success_utility_threshold else 0,
        tags=[ta, tb, domain, agent.traits.role],
    )

    if utility >= cfg.success_utility_threshold:
        engine.total_successes += 1
        agent.innovation_successes += 1
        engine.register_practice(record)
        agent.practice_memory.remember_success(practice_name, record)

        # Apply behavioral effect to innovating agent immediately
        _apply_practice_effect(agent, domain, utility, cfg)

        engine.events.append({
            "tick": tick, "event_type": "innovation_success",
            "actor_id": agent.id,
            "context": {
                "domain": domain, "utility": round(utility, 4),
                "fidelity": round(fid_avg, 4), "aptitude": round(aptitude, 4),
                "source_beliefs": [ta, tb],
            },
            "outcome": "innovation_success",
        })
        if len(engine.events) > cfg.max_events:
            engine.events = engine.events[-cfg.max_events:]
        return record
    else:
        agent.practice_memory.remember_failure(practice_name)
        return None


# ── Behavioral effect ─────────────────────────────────────────────────────────

def _apply_practice_effect(agent: Any, domain: str, utility: float,
                            cfg: InnovationConfig) -> None:
    """Apply domain-specific state nudges scaled by utility and effect_scale."""
    effects = PRACTICE_EFFECTS.get(domain, {})
    scale = utility * cfg.effect_scale
    s = agent.state
    for attr, delta in effects.items():
        current = getattr(s, attr, None)
        if current is not None:
            setattr(s, attr, clamp(current + delta * scale))


# ── Diffusion ─────────────────────────────────────────────────────────────────

def diffuse_practices(
    agents: List[Any],
    tick: int,
    engine: InnovationEngine,
    cfg: InnovationConfig = DEFAULT_CONFIG,
    rng: Optional[random.Random] = None,
    cooperation_events: Optional[List[dict]] = None,
) -> List[dict]:
    """
    Spread practices through cooperative interactions.
    cooperation_events: list of event dicts with event_type='interaction' and outcome='cooperation'
    collected during the current tick before aux_events are cleared.
    Returns list of diffusion event dicts.
    """
    if rng is None:
        rng = random.Random(tick)

    living = [a for a in agents if getattr(a, "alive", False)]
    living_by_id = {a.id: a for a in living}
    events = []

    # Build cooperation pairs from passed-in events (avoids cleared aux_events)
    coop_pairs: List[tuple] = []
    if cooperation_events:
        for ev in cooperation_events:
            if ev.get("event_type") == "interaction" and ev.get("outcome") == "cooperation":
                actor_id = ev.get("actor_id", "")
                parts = ev.get("participants", [])
                if actor_id and parts:
                    coop_pairs.append((actor_id, parts[0]))
    else:
        # Fallback: read aux_events (may already be cleared)
        for agent in living:
            for ev in getattr(agent, "aux_events", []):
                if ev.event_type == "interaction" and ev.outcome == "cooperation" and ev.participants:
                    coop_pairs.append((agent.id, ev.participants[0]))

    for actor_id, other_id in coop_pairs:
        agent = living_by_id.get(actor_id)
        other = living_by_id.get(other_id)
        if agent is None or other is None:
            continue

        pm = getattr(agent, "practice_memory", None)
        if pm is None or not pm.known:
            continue

        init_agent(other)

        for domain, practice in pm.known.items():
            if other.practice_memory.knows_domain(domain):
                continue
            if rng.random() > cfg.diffusion_rate:
                continue

            new_fidelity = clamp(practice.fidelity - cfg.diffusion_fidelity_decay)
            if new_fidelity < cfg.fidelity_floor:
                continue

            diffused = PracticeRecord(
                name=f"{practice.name}_d{practice.diffusion_count + 1}",
                domain=domain,
                utility_score=clamp(practice.utility_score * new_fidelity),
                fidelity=new_fidelity,
                origin_agent_id=practice.origin_agent_id,
                origin_tick=practice.origin_tick,
                attempts=1,
                successes=1,
                diffusion_count=practice.diffusion_count + 1,
                tags=practice.tags[:],
            )
            other.practice_memory.remember_success(diffused.name, diffused)
            engine.register_practice(diffused)
            practice.diffusion_count += 1
            engine.total_diffusions += 1

            _apply_practice_effect(other, domain, diffused.utility_score * 0.6, cfg)

            events.append({
                "tick": tick, "event_type": "innovation_diffusion",
                "actor_id": actor_id,
                "context": {
                    "receiver": other_id,
                    "domain": domain,
                    "practice_name": diffused.name,
                    "fidelity": round(new_fidelity, 4),
                    "utility": round(diffused.utility_score, 4),
                    "hop": diffused.diffusion_count,
                },
                "outcome": "practice_diffused",
            })
    return events


# ── Institutional adoption ────────────────────────────────────────────────────

def institutional_adoption(
    agents: List[Any],
    tick: int,
    engine: InnovationEngine,
    institution_registry: Any,
    governance_ledger: Any = None,
    cfg: InnovationConfig = DEFAULT_CONFIG,
) -> List[dict]:
    """
    High-utility practices adopted by institutions raise their strength
    and give governance a small legitimacy bonus.
    Called every 20 ticks (same cadence as institution tick).
    """
    events = []
    living = [a for a in agents if getattr(a, "alive", False)]

    # Collect all high-utility known practices across population
    candidate_practices: Dict[str, PracticeRecord] = {}
    for agent in living:
        pm = getattr(agent, "practice_memory", None)
        if pm is None:
            continue
        for domain, practice in pm.known.items():
            if practice.utility_score >= cfg.inst_adoption_utility_floor:
                existing = candidate_practices.get(domain)
                if existing is None or practice.utility_score > existing.utility_score:
                    candidate_practices[domain] = practice

    if not candidate_practices:
        return events

    for inst_id, inst in list(institution_registry.institutions.items()):
        # Match institution rule label to practice domain
        matched = None
        for domain, practice in candidate_practices.items():
            if domain in inst.rule or inst.rule in domain:
                matched = practice
                break
            # Loose match: check tags
            if any(tag in inst.rule for tag in practice.tags):
                matched = practice
                break

        if matched is None:
            # Any high-utility practice can strengthen any institution weakly
            top = max(candidate_practices.values(),
                      key=lambda p: p.utility_score, default=None)
            if top and top.utility_score >= cfg.inst_adoption_utility_floor + 0.10:
                matched = top

        if matched is None:
            continue

        # Strengthen institution
        old_strength = inst.strength
        inst.strength = clamp(inst.strength + cfg.inst_strength_bonus)
        matched.institutional_adoptions += 1
        engine.total_institutional_adoptions += 1

        # Governance legitimacy bonus
        if governance_ledger:
            for fid, rec in governance_ledger.leaders.items():
                if not rec.in_governance_gap and fid in [
                    m for m in inst.members
                    if any(a.id == m for a in living)
                ]:
                    rec.legitimacy = clamp(rec.legitimacy + 0.008)
                    break

        events.append({
            "tick": tick, "event_type": "institutional_adoption",
            "actor_id": matched.origin_agent_id,
            "context": {
                "institution": inst_id,
                "practice": matched.name,
                "domain": matched.domain,
                "utility": round(matched.utility_score, 4),
                "strength_before": round(old_strength, 4),
                "strength_after": round(inst.strength, 4),
            },
            "outcome": "practice_adopted",
        })
        engine.events.append(events[-1])

    return events


# ── Information layer hook ────────────────────────────────────────────────────

def innovation_to_message(record: PracticeRecord, agent: Any,
                           tick: int) -> Any:
    """
    Convert a successful innovation into an information Message for propagation.
    Enters the information layer as specialist_present with innovation payload.
    """
    from information import Message, _new_id
    return Message(
        msg_id=_new_id(),
        content_type="specialist_present",
        source_id=agent.id,
        origin_tick=tick,
        fidelity=record.fidelity,
        payload={
            "depth": round(agent.state.specialization_depth, 4),
            "source_credibility": round(record.utility_score, 4),
            "innovation_domain": record.domain,
            "innovation_name": record.name,
        },
    )


# ── Main per-tick update ──────────────────────────────────────────────────────

def apply_tick(
    agents: List[Any],
    tick: int,
    phase_name: str,
    engine: InnovationEngine,
    cfg: InnovationConfig = DEFAULT_CONFIG,
    institution_registry: Any = None,
    governance_ledger: Any = None,
    rng: Optional[random.Random] = None,
    cooperation_events: Optional[List[dict]] = None,
) -> List[Any]:
    """
    World-level innovation update. Call after agent ticks.
    Returns list of Event objects.
    """
    from schemas import Event

    if rng is None:
        rng = random.Random(tick)

    events: List[Any] = []
    living = [a for a in agents if getattr(a, "alive", False)]

    # ── Recombination attempts ────────────────────────────────────────────────
    for agent in living:
        # Per-agent seed so each agent gets an independent roll
        agent_rng = random.Random(tick * 9973 + hash(agent.id) % 99991)
        if agent_rng.random() > cfg.attempt_rate:
            continue
        record = attempt_recombination(agent, tick, engine, cfg, agent_rng)
        if record is not None:
            # Push innovation into information layer
            msg = innovation_to_message(record, agent, tick)
            inbox = getattr(agent, "inbox", None)
            if inbox:
                from information import DEFAULT_CONFIG as INFO_CFG
                inbox.receive(msg, tick, INFO_CFG)

            events.append(Event(
                tick=tick, phase=phase_name,
                actor_id=agent.id,
                event_type="innovation",
                participants=[],
                context={
                    "domain": record.domain,
                    "utility": round(record.utility_score, 4),
                    "fidelity": round(record.fidelity, 4),
                    "practice_name": record.name,
                },
                impact={"utility": round(record.utility_score, 4)},
                outcome="innovation_success",
            ))

    # ── Diffusion ─────────────────────────────────────────────────────────────
    diff_events = diffuse_practices(agents, tick, engine, cfg, rng,
                                    cooperation_events=cooperation_events)
    for dev in diff_events:
        events.append(Event(
            tick=tick, phase=phase_name,
            actor_id=dev["actor_id"],
            event_type="innovation_diffusion",
            participants=[dev["context"].get("receiver", "")],
            context=dev["context"],
            impact={},
            outcome="practice_diffused",
        ))

    # ── Institutional adoption every 20 ticks ─────────────────────────────────
    if institution_registry and tick % 20 == 0:
        adopt_events = institutional_adoption(
            agents, tick, engine, institution_registry,
            governance_ledger=governance_ledger, cfg=cfg,
        )
        for aev in adopt_events:
            events.append(Event(
                tick=tick, phase=phase_name,
                actor_id=aev["actor_id"],
                event_type="institutional_adoption",
                participants=[],
                context=aev["context"],
                impact={"strength_delta": round(
                    aev["context"]["strength_after"]
                    - aev["context"]["strength_before"], 4)},
                outcome="practice_adopted",
            ))

    return events


# ── Benchmark metrics ─────────────────────────────────────────────────────────

def benchmark_metrics(engine: InnovationEngine,
                       agents: List[Any]) -> Dict[str, Any]:
    living = [a for a in agents if getattr(a, "alive", False)]
    known_counts = [len(getattr(a, "practice_memory", PracticeMemory()).known)
                    for a in living]
    avg_known = sum(known_counts) / len(known_counts) if known_counts else 0.0
    return {
        "innovation_attempts": engine.total_attempts,
        "innovation_successes": engine.total_successes,
        "innovation_success_rate": round(
            engine.total_successes / max(1, engine.total_attempts), 4),
        "practice_diffusions": engine.total_diffusions,
        "institutional_adoptions": engine.total_institutional_adoptions,
        "practice_registry_size": len(engine.practice_registry),
        "avg_practices_known_per_agent": round(avg_known, 4),
    }
