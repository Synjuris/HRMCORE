"""
persistence.py — v04.18 Functional Legacy substrate

v04.18 upgrades v04.17 passive historical residue into functional legacy:
- dissolved institution traces can lower future institution formation friction
- subsistence specialists can leave tangible resource caches in cells
- specialist lineages can seed newborn specialization baselines
- high-impact institution residues decay more slowly than weak traces

The layer remains probabilistic, degradable, and inspectable. It does not script
outcomes or restore old institutions wholesale.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Tuple
import math
import random
from adaptive_roles import role_family


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


Cell = Tuple[int, int]


def _cell_from_agent(agent) -> Optional[Cell]:
    pos = getattr(agent, "position", None)
    if pos is None:
        return None
    return (int(pos.x), int(pos.y))


def _nearby_cells(cell: Cell, radius: int = 1) -> List[Cell]:
    x, y = cell
    return [(x + dx, y + dy) for dx in range(-radius, radius + 1) for dy in range(-radius, radius + 1)]


def _ideology_signature_from_agents(agents: List[object]) -> dict:
    vals = [float(getattr(getattr(a, "state", None), "ideology_alignment", 0.5)) for a in agents if a is not None]
    if not vals:
        return {"alignment_mean": 0.5, "alignment_min": 0.5, "alignment_max": 0.5}
    return {"alignment_mean": round(sum(vals) / len(vals), 4), "alignment_min": round(min(vals), 4), "alignment_max": round(max(vals), 4)}


def ideology_match(agent_alignment: float, signature: dict) -> float:
    """1.0 means agent alignment matches residue mean exactly."""
    target = float(signature.get("alignment_mean", 0.5)) if isinstance(signature, dict) else 0.5
    return clamp(1.0 - abs(float(agent_alignment) - target) * 2.0)


@dataclass
class ResourceCache:
    cache_id: str
    x: int
    y: int
    amount: float
    origin_agent: str
    origin_role: str
    created_tick: int
    last_tick: int
    decay_rate: float = 0.997
    discoveries: int = 0

    @property
    def cell(self) -> Cell:
        return (self.x, self.y)

    def decay(self) -> None:
        self.amount *= self.decay_rate

    def pull(self, requested: float) -> float:
        taken = max(0.0, min(self.amount, requested))
        self.amount -= taken
        if taken > 0:
            self.discoveries += 1
        return taken

    def to_dict(self) -> dict:
        d = asdict(self)
        d["amount"] = round(self.amount, 4)
        return d


@dataclass
class LocationResidue:
    x: int
    y: int
    conflict_residue: float = 0.0
    cooperation_residue: float = 0.0
    death_residue: float = 0.0
    artifact_residue: float = 0.0
    resource_cache_total: float = 0.0
    visits: int = 0
    last_tick: int = 0

    @property
    def net_valence(self) -> float:
        return round(self.cooperation_residue + self.artifact_residue - self.conflict_residue - self.death_residue, 4)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["net_valence"] = self.net_valence
        d["salience"] = round(
            self.conflict_residue + self.cooperation_residue + self.death_residue + self.artifact_residue + min(1.0, self.resource_cache_total),
            4,
        )
        return d


@dataclass
class ArtifactResidue:
    artifact_id: str
    label: str
    kind: str
    origin_agent: str
    origin_tick: int
    valence: float
    peak_strength: float
    last_strength: float
    carrier_count: int
    persistence_class: str

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class InstitutionResidue:
    institution_id: str
    name: str
    first_seen_tick: int
    last_seen_tick: int
    max_strength: float
    member_peak: int
    status: str = "active"
    ideology_signature: dict = field(default_factory=lambda: {"alignment_mean": 0.5})
    location_cells: List[Cell] = field(default_factory=list)
    historical_weight: float = 0.0
    half_life: float = 120.0
    reuse_value: float = 0.0
    decay_rate: float = 0.996
    reactivation_count: int = 0
    last_reactivated_tick: Optional[int] = None

    @property
    def duration(self) -> int:
        return max(0, self.last_seen_tick - self.first_seen_tick)

    @property
    def persistence_class(self) -> str:
        return "tradition" if self.max_strength >= 0.70 or self.historical_weight >= 0.65 else "trace"

    def update_decay_profile(self) -> None:
        # Strong institutions decay slowly; weak traces fade quickly.
        self.historical_weight = clamp((self.max_strength * 0.55) + min(1.0, self.duration / 600.0) * 0.25 + min(1.0, self.member_peak / 10.0) * 0.20)
        self.half_life = 120.0 + 780.0 * self.historical_weight
        self.decay_rate = math.pow(0.5, 1.0 / max(1.0, self.half_life))
        self.reuse_value = clamp(0.20 + self.historical_weight * 0.80)

    def tick_decay(self) -> None:
        if self.status == "dissolved":
            self.reuse_value *= self.decay_rate

    def to_dict(self) -> dict:
        d = asdict(self)
        d["duration"] = self.duration
        d["persistence_class"] = self.persistence_class
        d["historical_weight"] = round(self.historical_weight, 4)
        d["half_life"] = round(self.half_life, 2)
        d["reuse_value"] = round(self.reuse_value, 4)
        d["decay_rate"] = round(self.decay_rate, 6)
        d["location_cells"] = [list(c) for c in self.location_cells[:12]]
        return d


class PersistenceLedger:
    """Runtime ledger for durable historical residue and functional legacy."""

    def __init__(self, decay: float = 0.996) -> None:
        self.decay = decay
        self.locations: Dict[Cell, LocationResidue] = {}
        self.artifacts: Dict[str, ArtifactResidue] = {}
        self.institutions: Dict[str, InstitutionResidue] = {}
        self.resource_caches: Dict[str, ResourceCache] = {}
        self.inheritance_events: List[dict] = []
        self.functional_events: List[dict] = []
        self.pressure_applications: int = 0
        self.cache_hits: int = 0
        self.institution_reactivations: int = 0
        self.lineage_seed_count: int = 0

    # ── Runtime pressure / utility ─────────────────────────────────────────
    def apply_location_pressure(self, agent) -> dict:
        pos = getattr(agent, "position", None)
        if pos is None:
            return {}
        cell = (int(pos.x), int(pos.y))
        rec = self.locations.get(cell)
        result = {}
        if rec is not None:
            threat = clamp(rec.conflict_residue * 0.030 + rec.death_residue * 0.055)
            safety = clamp(rec.cooperation_residue * 0.020 + rec.artifact_residue * 0.012)
            if threat > 0.0001 or safety > 0.0001:
                agent.state.fear = clamp(agent.state.fear + threat * 0.20 - safety * 0.06)
                agent.state.stress = clamp(agent.state.stress + threat * 0.12 - safety * 0.05)
                agent.state.social_openness = clamp(agent.state.social_openness + safety * 0.03 - threat * 0.04)
                self.pressure_applications += 1
                result.update({"location_threat": round(threat, 4), "location_safety": round(safety, 4)})
        cache_result = self.harvest_resource_cache(agent)
        if cache_result:
            result.update(cache_result)
        return result

    def harvest_resource_cache(self, agent, max_pull: float = 0.08) -> dict:
        cell = _cell_from_agent(agent)
        if cell is None:
            return {}
        caches = [c for c in self.resource_caches.values() if c.cell == cell and c.amount > 0.002]
        if not caches:
            return {}
        caches.sort(key=lambda c: c.amount, reverse=True)
        cache = caches[0]
        need = max(0.0, 0.78 - float(getattr(agent.state, "resource_stock", 0.5)))
        if need <= 0.0 and getattr(agent, "traits", None) and role_family(getattr(agent.traits, "role", "")) != "subsistence":
            return {}
        pull = cache.pull(min(max_pull, max(0.015, need * 0.35)))
        if pull <= 0:
            return {}
        agent.state.resource_stock = clamp(agent.state.resource_stock + pull)
        agent.state.energy = clamp(agent.state.energy + pull * 0.55)
        self.cache_hits += 1
        if cell in self.locations:
            self.locations[cell].resource_cache_total = max(0.0, self.locations[cell].resource_cache_total - pull)
        self.functional_events.append({
            "tick": cache.last_tick,
            "event": "resource_cache_discovered",
            "agent_id": getattr(agent, "id", "unknown"),
            "cell": list(cell),
            "yield": round(pull, 4),
            "cache_id": cache.cache_id,
        })
        return {"resource_cache_yield": round(pull, 4)}

    # ── Resource cache creation ────────────────────────────────────────────
    def maybe_create_resource_cache(self, agent, tick: int, reason: str, rng: Optional[random.Random] = None) -> Optional[dict]:
        rng = rng or random.Random(tick + hash(getattr(agent, "id", "")))
        role = getattr(getattr(agent, "traits", None), "role", "generalist")
        depth = float(getattr(getattr(agent, "state", None), "specialization_depth", 0.0))
        resources = float(getattr(getattr(agent, "state", None), "resource_stock", 0.0))
        stress = float(getattr(getattr(agent, "state", None), "stress", 1.0))
        if role_family(role) != "subsistence" and depth < 0.35:
            return None
        if resources < 0.18:
            return None
        if reason == "low_stress":
            if stress > 0.22:
                return None
            prob = 0.018 + min(0.04, depth * 0.025)
        elif reason == "death":
            prob = 0.22 + min(0.20, depth * 0.20)
        else:
            prob = 0.02
        if rng.random() > prob:
            return None
        cell = _cell_from_agent(agent)
        if cell is None:
            return None
        amount = resources * rng.uniform(0.12, 0.35)
        if amount <= 0.01:
            return None
        agent.state.resource_stock = clamp(agent.state.resource_stock - amount * 0.35)
        cache_id = f"cache_{tick}_{getattr(agent, 'id', 'unknown')[-4:]}_{len(self.resource_caches)}"
        cache = ResourceCache(
            cache_id=cache_id, x=cell[0], y=cell[1], amount=round(amount, 4),
            origin_agent=getattr(agent, "id", "unknown"), origin_role=role,
            created_tick=tick, last_tick=tick,
            decay_rate=0.9985 if reason == "death" else 0.997,
        )
        self.resource_caches[cache_id] = cache
        rec = self.locations.setdefault(cell, LocationResidue(x=cell[0], y=cell[1]))
        rec.resource_cache_total += amount
        rec.last_tick = max(rec.last_tick, tick)
        event = {"tick": tick, "event": "resource_cache_created", "reason": reason, "cell": list(cell), "amount": round(amount, 4), "origin_agent": cache.origin_agent}
        self.functional_events.append(event)
        return event

    # ── Event capture ──────────────────────────────────────────────────────
    def record_event(self, event: dict) -> None:
        ctx = event.get("context", {}) or {}
        pos = ctx.get("position") or ctx.get("other_position")
        if not isinstance(pos, dict) or "x" not in pos or "y" not in pos:
            return
        cell = (int(pos["x"]), int(pos["y"]))
        rec = self.locations.setdefault(cell, LocationResidue(x=cell[0], y=cell[1]))
        rec.visits += 1
        rec.last_tick = max(rec.last_tick, int(event.get("tick", 0)))
        etype = event.get("event_type")
        outcome = event.get("outcome")
        if etype == "interaction" and outcome == "conflict":
            rec.conflict_residue = clamp(rec.conflict_residue + 0.035)
        elif etype == "interaction" and outcome == "cooperation":
            rec.cooperation_residue = clamp(rec.cooperation_residue + 0.020)
        elif etype == "agent_death":
            rec.death_residue = clamp(rec.death_residue + 0.20)
        elif etype == "artifact":
            rec.artifact_residue = clamp(rec.artifact_residue + float(event.get("impact", {}).get("symbolic_strength", 0.05)) * 0.06)

    def decay_locations(self) -> None:
        for cell, rec in list(self.locations.items()):
            rec.conflict_residue *= self.decay
            rec.cooperation_residue *= self.decay
            rec.death_residue *= self.decay
            rec.artifact_residue *= self.decay
            rec.resource_cache_total = sum(c.amount for c in self.resource_caches.values() if c.cell == cell)
            if (rec.conflict_residue + rec.cooperation_residue + rec.death_residue + rec.artifact_residue + rec.resource_cache_total < 0.002 and rec.visits < 2):
                del self.locations[cell]
        for cid, cache in list(self.resource_caches.items()):
            cache.decay()
            if cache.amount < 0.002:
                del self.resource_caches[cid]
        for iid, inst in list(self.institutions.items()):
            inst.tick_decay()
            if inst.status == "dissolved" and inst.reuse_value < 0.015 and inst.historical_weight < 0.15:
                del self.institutions[iid]

    # ── Institution functional legacy ──────────────────────────────────────
    def sync_artifacts(self, texture_chronicle) -> None:
        if not texture_chronicle:
            return
        for aid, art in texture_chronicle.artifacts.items():
            strength = float(getattr(art, "strength", 0.0))
            carriers = list(getattr(art, "carriers", []) or [])
            pclass = "trace"
            if strength >= 0.55 and len(carriers) >= 3:
                pclass = "tradition"
            elif strength >= 0.35 and len(carriers) >= 2:
                pclass = "custom"
            elif strength >= 0.20:
                pclass = "marker"
            prior = self.artifacts.get(aid)
            peak = max(prior.peak_strength if prior else 0.0, strength)
            self.artifacts[aid] = ArtifactResidue(
                artifact_id=aid, label=getattr(art, "label", aid), kind=getattr(art, "kind", "unknown"),
                origin_agent=getattr(art, "origin_agent", "unknown"), origin_tick=int(getattr(art, "tick", 0)),
                valence=float(getattr(art, "valence", 0.0)), peak_strength=round(peak, 4), last_strength=round(strength, 4),
                carrier_count=len(carriers), persistence_class=pclass,
            )

    def sync_institutions(self, institution_registry, tick: int, agents: Optional[List[object]] = None) -> None:
        current = set()
        agent_map = {getattr(a, "id", None): a for a in (agents or [])}
        if institution_registry:
            for inst in getattr(institution_registry, "institutions", {}).values():
                iid = inst.id
                current.add(iid)
                members = [agent_map[mid] for mid in getattr(inst, "members", []) if mid in agent_map]
                cells = []
                for m in members:
                    c = _cell_from_agent(m)
                    if c is not None and c not in cells:
                        cells.append(c)
                signature = _ideology_signature_from_agents(members)
                prior = self.institutions.get(iid)
                if prior is None:
                    prior = InstitutionResidue(
                        institution_id=iid, name=inst.name, first_seen_tick=tick, last_seen_tick=tick,
                        max_strength=round(float(inst.strength), 4), member_peak=len(inst.members),
                        ideology_signature=signature, location_cells=cells,
                    )
                    self.institutions[iid] = prior
                else:
                    prior.last_seen_tick = tick
                    prior.max_strength = round(max(prior.max_strength, float(inst.strength)), 4)
                    prior.member_peak = max(prior.member_peak, len(inst.members))
                    prior.status = "active"
                    prior.ideology_signature = signature
                    for c in cells:
                        if c not in prior.location_cells:
                            prior.location_cells.append(c)
                    prior.location_cells = prior.location_cells[-16:]
                prior.update_decay_profile()
        for iid, rec in list(self.institutions.items()):
            if iid not in current and rec.status == "active" and tick > rec.last_seen_tick:
                rec.status = "dissolved"
                rec.update_decay_profile()

    def get_reactivation_bonus(self, agent, cell: Optional[Cell], tick: int) -> dict:
        if cell is None:
            return {"matched": False, "cost_multiplier": 1.0}
        alignment_value = float(getattr(getattr(agent, "state", None), "ideology_alignment", 0.5))
        candidates = []
        nearby = set(_nearby_cells(cell, radius=1))
        for rec in self.institutions.values():
            if rec.status != "dissolved" or rec.reuse_value <= 0.02:
                continue
            if rec.location_cells and not any(tuple(c) in nearby for c in rec.location_cells):
                continue
            match = ideology_match(alignment_value, rec.ideology_signature)
            if match >= 0.72:
                candidates.append((match * rec.reuse_value, match, rec))
        if not candidates:
            return {"matched": False, "cost_multiplier": 1.0}
        _, match, rec = max(candidates, key=lambda x: x[0])
        # 40–50% cost reduction; stronger traditions approach the high end.
        cost_multiplier = 0.60 - min(0.10, rec.historical_weight * 0.10)
        rec.reactivation_count += 1
        rec.last_reactivated_tick = tick
        self.institution_reactivations += 1
        event = {
            "tick": tick, "event": "institution_reactivated", "cell": list(cell),
            "alignment": round(match, 4), "legacy_source": rec.name,
            "cost_multiplier": round(cost_multiplier, 4), "residue_class": rec.persistence_class,
        }
        self.functional_events.append(event)
        return {"matched": True, "cost_multiplier": cost_multiplier, "residue": rec, "event": event}

    # ── Generational inheritance ───────────────────────────────────────────
    def seed_newborn_residue(self, child, parents: List[object], tick: int) -> None:
        tags = []
        parent_ids = [getattr(p, "id", None) for p in parents if p is not None]
        lineage_sources = []
        best_depth = 0.0
        best_role = None
        for p in parents:
            tags.extend(getattr(getattr(p, "experience", None), "identity_tags", [])[-3:])
            depth = float(getattr(getattr(p, "state", None), "specialization_depth", 0.0))
            role = getattr(getattr(p, "traits", None), "role", None)
            if depth > best_depth and role:
                best_depth, best_role = depth, role
        # Cell lineage residue from previous specialist births/deaths.
        cell = _cell_from_agent(child)
        cell_lineage_depth = 0.0
        cell_lineage_role = None
        if cell is not None:
            for ev in reversed(self.inheritance_events[-200:]):
                if ev.get("event") == "lineage_specialization_detected" and tuple(ev.get("cell", [])) == cell:
                    if ev.get("continuity_strength", 0.0) > cell_lineage_depth:
                        cell_lineage_depth = float(ev.get("continuity_strength", 0.0))
                        cell_lineage_role = ev.get("specialization")
        inherited_depth = 0.0
        inherited_role = best_role
        if best_depth >= 0.65:
            inherited_depth = max(inherited_depth, best_depth * 0.18)
        if cell_lineage_depth >= 0.35:
            inherited_depth = max(inherited_depth, cell_lineage_depth * 0.12)
            inherited_role = inherited_role or cell_lineage_role
        if inherited_depth > 0.0:
            child.state.specialization_depth = clamp(child.state.specialization_depth + inherited_depth, 0.0, 0.28)
            if inherited_role and getattr(child.traits, "role", "generalist") == "generalist":
                child.traits.role = inherited_role
            lineage_sources.append({"role": inherited_role, "depth_seed": round(inherited_depth, 4)})
            self.lineage_seed_count += 1
            if cell is not None:
                self.inheritance_events.append({
                    "tick": tick, "event": "lineage_specialization_detected", "cell": list(cell),
                    "specialization": inherited_role, "continuity_strength": round(max(best_depth, cell_lineage_depth), 4),
                    "child_id": getattr(child, "id", None),
                })
        for art in sorted(self.artifacts.values(), key=lambda a: a.peak_strength, reverse=True)[:3]:
            if art.persistence_class in ("custom", "tradition"):
                tags.append(art.label)
        unique = []
        for t in tags:
            if t and t not in unique:
                unique.append(t)
        inherited = unique[:4]
        if inherited:
            child.experience.identity_tags.extend(inherited)
            child.experience.scars = clamp(child.experience.scars + 0.01 * sum(1 for t in inherited if "bitter" in t or "ash" in t))
        self.inheritance_events.append({
            "tick": tick, "event": "newborn_residue_seeded", "child_id": child.id,
            "parent_ids": parent_ids, "inherited_tags": inherited, "lineage_sources": lineage_sources,
        })

    # ── Export / compression ───────────────────────────────────────────────
    def _trust_pockets(self) -> List[dict]:
        pockets = []
        for rec in self.locations.values():
            if rec.cooperation_residue >= 0.10 and rec.net_valence > 0.05:
                pockets.append({"cell": [rec.x, rec.y], "cooperation_residue": round(rec.cooperation_residue, 4), "net_valence": rec.net_valence})
        pockets.sort(key=lambda x: (x["cooperation_residue"], x["net_valence"]), reverse=True)
        return pockets[:40]

    def _institution_residue_cells(self) -> set:
        cells = set()
        for rec in self.institutions.values():
            if rec.reuse_value > 0.02:
                for c in rec.location_cells:
                    cells.add(tuple(c))
        return cells

    def snapshot(self) -> dict:
        salient_locations = sorted([r.to_dict() for r in self.locations.values()], key=lambda r: (r["salience"], abs(r["net_valence"])), reverse=True)[:80]
        trust_pockets = self._trust_pockets()
        institution_cells = self._institution_residue_cells()
        pocket_cells = {tuple(p["cell"]) for p in trust_pockets}
        overlap = len(pocket_cells & institution_cells)
        correlation = round(overlap / max(1, len(pocket_cells | institution_cells)), 4)
        resource_clusters = sorted([c.to_dict() for c in self.resource_caches.values()], key=lambda x: x["amount"], reverse=True)[:80]
        return {
            "version": "v04.18",
            "location_memory": salient_locations,
            "resource_caches": resource_clusters,
            "artifact_residue": [a.to_dict() for a in sorted(self.artifacts.values(), key=lambda x: x.peak_strength, reverse=True)],
            "institution_residue": [i.to_dict() for i in sorted(self.institutions.values(), key=lambda x: (x.historical_weight, x.duration), reverse=True)],
            "inheritance_events": self.inheritance_events[-150:],
            "functional_legacy_events": self.functional_events[-200:],
            "trust_pockets": trust_pockets,
            "summary": {
                "salient_location_count": len(salient_locations),
                "resource_cache_count": len(self.resource_caches),
                "resource_cache_total": round(sum(c.amount for c in self.resource_caches.values()), 4),
                "resource_cache_hits": self.cache_hits,
                "artifact_residue_count": len(self.artifacts),
                "institution_residue_count": len(self.institutions),
                "dissolved_institution_traces": sum(1 for i in self.institutions.values() if i.status == "dissolved"),
                "tradition_count": sum(1 for i in self.institutions.values() if i.persistence_class == "tradition"),
                "institution_reactivations": self.institution_reactivations,
                "inheritance_event_count": len(self.inheritance_events),
                "lineage_seed_count": self.lineage_seed_count,
                "trust_pocket_count": len(trust_pockets),
                "trust_pocket_institution_residue_overlap": overlap,
                "trust_pocket_institution_residue_correlation": correlation,
                "pressure_applications": self.pressure_applications,
            },
        }
