from schemas import Event

def init_agent(agent):
    if not hasattr(agent,'apprenticeship_skill'): agent.apprenticeship_skill=0.0
class ApprenticeshipLedger:
    def __init__(self): self.events=[]; self.active_pairs=set()
    def record(self,e): self.events.append(e)
    def snapshot(self, agents=None):
        return {"events":[getattr(e,"__dict__",str(e)) for e in self.events], "active_pairs":[list(p) for p in self.active_pairs]}

def apply_tick(agents, tick, phase, ledger, faction_registry=None, institution_registry=None, rng=None):
    rng=rng or __import__('random').Random(tick)
    living=[a for a in agents if getattr(a,'alive',False)]
    out=[]
    if len(living)>=2 and tick%30==0:
        mentor=max(living,key=lambda a:getattr(a.state,'linguistic_complexity',0)+getattr(a.state,'specialization_depth',0))
        learner=rng.choice([a for a in living if a.id!=mentor.id])
        learner.apprenticeship_skill=getattr(learner,'apprenticeship_skill',0)+0.03
        ev=Event(tick, phase, mentor.id, 'apprenticeship', [learner.id], {}, {'skill_transfer':0.03}, 'knowledge_transferred')
        ledger.events.append(ev); ledger.active_pairs.add((mentor.id, learner.id)); out.append(ev)
    return out

def benchmark_metrics(ledger, agents, institution_registry=None):
    return {'active_pairs':len(ledger.active_pairs),'apprenticeship_count':len(ledger.events),'knowledge_retention':round(sum(getattr(a,'apprenticeship_skill',0) for a in agents),4),'system_complexity_final':round(len(ledger.events)/10,4)}
