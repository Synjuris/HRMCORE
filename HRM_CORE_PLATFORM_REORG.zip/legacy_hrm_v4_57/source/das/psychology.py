"""
psychology.py — v04.30 agent psychological depth layer

Four mechanisms that were previously missing or stub-only:

1. VALENCE STATE
   A unified positive/negative affect scalar (state.valence, -1.0 to +1.0)
   integrating stress, fear, goal satisfaction, bond strength, and scar load.
   Updated once per tick. Feeds back into cooperation_pull and exploration
   tendency without replacing any existing state variables.

2. GRIEF RESPONSE
   When a bonded agent dies, survivors receive a grief impulse proportional
   to bond strength. Grief temporarily elevates stress and fear, suppresses
   social openness, and leaves a permanent scar trace. Resolves over ~80 ticks
   via natural recovery, ritual, or renewed bonding. High-grief agents may
   pursue "bond" goal elevation as a compensatory drive.

3. IDENTITY CONSOLIDATION
   identity_tags on ExperientialMemory were populated only by artifact spread.
   This module also populates them from: role crystallization (after 100 ticks
   in a role), faction membership, scar threshold crossing, and top grudge/bond
   relationships. Tags are narrative labels, not behavior scalars — they inform
   snapshot readability and chronicle episodes.

4. COGNITIVE DISSONANCE
   When an agent's ideology_alignment diverges sharply from their cultural
   alignment (i.e., what they do vs. what their faction says to do), a small
   stress load accumulates. Resolution paths: faction exit (faction split),
   cultural drift toward faction norm, or scar-based cynicism (dropping
   ideology sensitivity). This is deliberately weak — it's friction, not
   a forced outcome.

Design constraints (matching v04.15 pressure calibration):
  - Combined max effect on raw_conflict_pull: < 0.06 (below ideology pressure)
  - Grief stress spike: bounded at +0.08 per event, decays at recovery_speed
  - Valence contribution to cooperation_pull: ±0.04 max
  - No new goals. No new trait mutations from psychology.py alone.
  - All state variables are already declared in AgentState / DevelopmentalTraits.
    This module only writes to existing fields plus experience.scars,
    experience.identity_tags, experience.bonds, experience.grudges.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from agent import Agent


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


# ── Constants ──────────────────────────────────────────────────────────────────

# Valence
VALENCE_STRESS_WEIGHT       = 0.35   # stress pulls valence negative
VALENCE_FEAR_WEIGHT         = 0.20   # fear pulls valence negative
VALENCE_SCAR_WEIGHT         = 0.20   # scar load pulls valence negative
VALENCE_GOAL_SAT_WEIGHT     = 0.15   # goal satisfaction pulls valence positive
VALENCE_BOND_WEIGHT         = 0.10   # mean bond strength pulls valence positive
VALENCE_COOP_PULL_ADD       = 0.04   # max contribution to cooperation_pull

# Grief
GRIEF_BOND_THRESHOLD        = 0.18   # bonds below this don't trigger grief
GRIEF_STRESS_SPIKE_MAX      = 0.025   # max stress added per grief event
GRIEF_FEAR_SPIKE_MAX        = 0.014
GRIEF_SOCIAL_OPEN_PENALTY   = 0.020   # openness suppression
GRIEF_SCAR_LOAD             = 0.018  # permanent scar contribution
GRIEF_GOAL_BOND_BOOST       = 0.18   # grief pushes bond goal priority up temporarily

# Identity
ROLE_CRYSTALLIZATION_TICKS  = 100    # ticks before role becomes an identity tag
SCAR_IDENTITY_THRESHOLD     = 0.35   # scars above this → "the scarred" tag
GRUDGE_IDENTITY_THRESHOLD   = 0.40   # top grudge above this → "the aggrieved" tag
BOND_IDENTITY_THRESHOLD     = 0.45   # top bond above this → "the bonded" tag

# Cognitive dissonance
DISSONANCE_THRESHOLD        = 0.28   # |ideology_alignment - cultural_alignment| triggers
DISSONANCE_STRESS_RATE      = 0.0015  # stress per tick while dissonant
DISSONANCE_IDEOLOGY_DRIFT   = 0.003  # ideology_alignment nudges toward cultural_alignment
DISSONANCE_SENSITIVITY_ERODE = 0.0005  # ideology_sensitivity decays under chronic dissonance


# ── 1. Valence ─────────────────────────────────────────────────────────────────

def compute_valence(agent: "Agent") -> float:
    """
    Unified affect scalar. -1.0 = deeply distressed, +1.0 = flourishing.
    Integrated from existing state variables — does not replace them.
    """
    neg = (
        agent.state.stress    * VALENCE_STRESS_WEIGHT
        + agent.state.fear    * VALENCE_FEAR_WEIGHT
        + agent.experience.scars * VALENCE_SCAR_WEIGHT
    )
    avg_bond = (
        sum(agent.experience.bonds.values()) / len(agent.experience.bonds)
        if agent.experience.bonds else 0.0
    )
    pos = (
        agent.state.goal_satisfaction * VALENCE_GOAL_SAT_WEIGHT
        + avg_bond                    * VALENCE_BOND_WEIGHT
    )
    return clamp(pos - neg, -1.0, 1.0)


def update_valence(agent: "Agent") -> None:
    """Called once per tick from agent.tick(). Updates state.valence."""
    agent.state.valence = compute_valence(agent)


def valence_cooperation_add(agent: "Agent") -> float:
    """
    Positive valence contributes a small pull toward cooperation.
    Negative valence contributes nothing (stress/fear already do the work).
    """
    v = agent.state.valence
    if v <= 0.0:
        return 0.0
    return v * VALENCE_COOP_PULL_ADD


# ── 2. Grief ───────────────────────────────────────────────────────────────────

def apply_grief(survivor: "Agent", dead_agent_id: str, dead_agent_name: str,
                tick: int, bond_strength: float) -> Optional[dict]:
    """
    Called by run_sim.py immediately after a death is logged, for each
    living agent that held a bond with the deceased.

    Returns a grief summary dict for event logging, or None if bond was
    below threshold.
    """
    if bond_strength < GRIEF_BOND_THRESHOLD:
        return None

    # Scale intensity to bond strength (0.18–1.0 → 0.0–1.0)
    intensity = clamp((bond_strength - GRIEF_BOND_THRESHOLD) / (1.0 - GRIEF_BOND_THRESHOLD))

    # Stress and fear spike
    stress_spike = GRIEF_STRESS_SPIKE_MAX * intensity * (1.0 - survivor.traits.resilience * 0.40)
    fear_spike   = GRIEF_FEAR_SPIKE_MAX   * intensity * (1.0 - survivor.traits.resilience * 0.30)
    survivor.state.stress       = clamp(survivor.state.stress + stress_spike)
    survivor.state.fear         = clamp(survivor.state.fear   + fear_spike)
    survivor.state.social_openness = clamp(
        survivor.state.social_openness - GRIEF_SOCIAL_OPEN_PENALTY * intensity
    )

    # Scar load — loss leaves a mark that doesn't fully heal
    survivor.experience.scars = clamp(survivor.experience.scars + GRIEF_SCAR_LOAD * intensity)

    # Remove the bond (the person is gone) but record the trace
    survivor.experience.bonds.pop(dead_agent_id, None)
    survivor.experience.bond_started_tick.pop(dead_agent_id, None)
    phrase = f"loss of {dead_agent_name}"
    survivor.experience.add_trace(
        tick, dead_agent_id, "grief",
        valence=-0.70 * intensity,
        intensity=0.75 * intensity,
        phrase=phrase,
    )

    # Goal: push bond priority up as compensatory drive
    for g in survivor.goals.goals:
        if g.label == "bond":
            g.priority = clamp(g.priority + GRIEF_GOAL_BOND_BOOST * intensity)
            break

    return {
        "survivor_id": survivor.id,
        "dead_id": dead_agent_id,
        "bond_strength": round(bond_strength, 4),
        "intensity": round(intensity, 4),
        "stress_spike": round(stress_spike, 4),
        "fear_spike": round(fear_spike, 4),
        "scar_added": round(GRIEF_SCAR_LOAD * intensity, 4),
    }


def notify_death_to_population(dead_agent: "Agent", population: List["Agent"],
                                tick: int) -> List[dict]:
    """
    Called once per death event. Iterates living agents, applies grief to
    those with a bond above threshold. Returns list of grief summary dicts
    for event logging.
    """
    dead_id   = dead_agent.id
    dead_name = dead_agent.name
    reports   = []
    for agent in population:
        if not agent.alive or agent.id == dead_id:
            continue
        bond_strength = agent.experience.bonds.get(dead_id, 0.0)
        result = apply_grief(agent, dead_id, dead_name, tick, bond_strength)
        if result:
            reports.append(result)
    return reports


# ── 3. Identity consolidation ──────────────────────────────────────────────────

def _has_tag(agent: "Agent", tag: str) -> bool:
    return tag in agent.experience.identity_tags


def _add_tag(agent: "Agent", tag: str) -> None:
    if not _has_tag(agent, tag):
        agent.experience.identity_tags.append(tag)


def _remove_tag(agent: "Agent", tag: str) -> None:
    try:
        agent.experience.identity_tags.remove(tag)
    except ValueError:
        pass


def update_identity(agent: "Agent", tick: int,
                    faction_registry=None) -> None:
    """
    Refreshes identity_tags from current state. Called once per tick.
    Tags are additive; stale tags are pruned when their condition is no longer met.
    """
    # Role crystallization
    role_tag = f"the {agent.traits.role}"
    if agent.state.age >= ROLE_CRYSTALLIZATION_TICKS:
        _add_tag(agent, role_tag)
    else:
        _remove_tag(agent, role_tag)

    # Scar identity
    if agent.experience.scars >= SCAR_IDENTITY_THRESHOLD:
        _add_tag(agent, "the scarred")
    else:
        _remove_tag(agent, "the scarred")

    # Grudge identity
    top_grudge = agent.experience.top_grudge()
    if top_grudge and top_grudge[1] >= GRUDGE_IDENTITY_THRESHOLD:
        _add_tag(agent, "the aggrieved")
    else:
        _remove_tag(agent, "the aggrieved")

    # Bond identity
    top_bond = agent.experience.top_bond()
    if top_bond and top_bond[1] >= BOND_IDENTITY_THRESHOLD:
        _add_tag(agent, "the bonded")
    else:
        _remove_tag(agent, "the bonded")

    # Faction membership tag
    if faction_registry:
        faction = faction_registry.faction_of(agent.id)
        if faction:
            faction_tag = f"member of {faction.name}"
            _add_tag(agent, faction_tag)
            # Prune stale faction tags (agent may have switched)
            stale = [t for t in agent.experience.identity_tags
                     if t.startswith("member of ") and t != faction_tag]
            for t in stale:
                _remove_tag(agent, t)

    # High-grief tag (transient; resolves when scars drop)
    if agent.experience.scars >= 0.55 and agent.state.stress >= 0.65:
        _add_tag(agent, "grieving")
    else:
        _remove_tag(agent, "grieving")


# ── 4. Cognitive dissonance ────────────────────────────────────────────────────

def update_cognitive_dissonance(agent: "Agent") -> float:
    """
    Computes gap between agent's ideology_alignment and cultural_alignment.
    When gap exceeds threshold:
      - adds small stress load
      - nudges ideology_alignment toward cultural_alignment (drift)
      - slowly erodes ideology_sensitivity under chronic dissonance

    Returns dissonance magnitude (0.0 if below threshold).
    """
    gap = abs(agent.state.ideology_alignment - agent.state.cultural_alignment)
    if gap < DISSONANCE_THRESHOLD:
        return 0.0

    # Stress friction
    agent.state.stress = clamp(agent.state.stress + DISSONANCE_STRESS_RATE)

    # Ideology drifts toward actual behavior (cultural alignment wins long-term)
    if agent.state.ideology_alignment > agent.state.cultural_alignment:
        agent.state.ideology_alignment = clamp(
            agent.state.ideology_alignment - DISSONANCE_IDEOLOGY_DRIFT
        )
    else:
        agent.state.ideology_alignment = clamp(
            agent.state.ideology_alignment + DISSONANCE_IDEOLOGY_DRIFT
        )

    # Chronic dissonance erodes sensitivity (cynicism / disengagement)
    agent.traits.ideology_sensitivity = clamp(
        agent.traits.ideology_sensitivity - DISSONANCE_SENSITIVITY_ERODE
    )

    return round(gap, 4)


# ── Per-tick entry point (called from agent.tick) ──────────────────────────────

def tick_psychology(agent: "Agent", tick: int, faction_registry=None) -> dict:
    """
    Single call point for agent.tick(). Runs all four mechanisms.
    Returns a summary dict included in agent snapshot / event context.
    """
    update_valence(agent)
    update_identity(agent, tick, faction_registry)
    dissonance = update_cognitive_dissonance(agent)

    return {
        "valence": round(agent.state.valence, 4),
        "dissonance": dissonance,
        "identity_tags": list(agent.experience.identity_tags),
    }
