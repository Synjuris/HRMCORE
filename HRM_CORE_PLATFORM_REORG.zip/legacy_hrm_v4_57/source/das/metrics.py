def _avg(vals): return round(sum(vals)/len(vals),4) if vals else 0.0

def population_metrics(agents, faction_registry=None, institution_registry=None, culture_pool=None, reproduction_system=None):
    living=[a for a in agents if getattr(a,'alive',False)]
    return {
        'alive_count':len(living),'avg_energy':_avg([a.state.energy for a in living]),'avg_stress':_avg([a.state.stress for a in living]),
        'avg_fear':_avg([a.state.fear for a in living]),'avg_cooperation':_avg([a.state.cooperation for a in living]),
        'avg_resource_stock':_avg([a.state.resource_stock for a in living]),'avg_status_security':_avg([getattr(a.state,'status_security',0.5) for a in living]),
        'avg_novelty_saturation':_avg([getattr(a.state,'novelty_saturation',0.0) for a in living]),'avg_ideology_alignment':_avg([getattr(a.state,'ideology_alignment',0.5) for a in living]),
        'faction_count':len(getattr(faction_registry,'factions',{})) if faction_registry else 0,
        'institution_count':len(getattr(institution_registry,'institutions',{})) if institution_registry else 0,
        'meme_count':len(getattr(culture_pool,'memes',{})) if culture_pool else 0,
        'births':getattr(reproduction_system,'total_births',0) if reproduction_system else 0,
    }

def topology_metrics(agents, faction_registry=None, tick=None):
    living=[a for a in agents if getattr(a,'alive',False)]
    rel_edges=sum(len(getattr(a.relationships,'_rels',{})) for a in living if hasattr(a,'relationships'))
    return {'relationship_edges':rel_edges,'avg_relationship_edges':round(rel_edges/len(living),4) if living else 0.0,'topology_tick':tick}
