"""
subsistence.py — v04.33 World Pressure + Subsistence Engine

Adds environment-driven seasonal pressure, wild fauna ecology, hunting/gathering,
and proto-domestication without replacing existing DAS resource or behavior systems.
The world changes first; agents adapt or fail through ordinary hunger, safety,
resource_stock, exhaustion, culture, and event logs.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Dict, List, Any
import math
import random

from schemas import Event
from adaptive_roles import role_family
try:
    from spatial_biomes import get_biome
    SPATIAL_BIOMES = True
except ImportError:
    SPATIAL_BIOMES = False


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(x)))


@dataclass
class SeasonProfile:
    name: str
    temperature: float
    rainfall: float
    plant_growth: float
    travel_difficulty: float
    disease_ecology: float
    daylight: float
    animal_migration_pull: float
    scarcity_pressure: float


@dataclass
class FaunaPopulation:
    species: str
    biome: str
    population: float
    max_population: float
    reproduction_rate: float
    hunt_difficulty: float
    calories: float
    hide_value: float
    tamability: float
    migration_sensitivity: float
    domesticated: float = 0.0
    tolerance: float = 0.0
    herd_wealth: float = 0.0
    disease_load: float = 0.02

    def snapshot(self) -> Dict[str, Any]:
        d = asdict(self)
        for k, v in list(d.items()):
            if isinstance(v, float):
                d[k] = round(v, 4)
        return d


class SubsistenceWorld:
    """World-level subsistence pressure model.

    This does not assign fixed cultural types to agents. It exposes seasonal and
    ecological constraints; repeated success/failure creates adaptation signals.
    """

    def __init__(self, width: int = 20, height: int = 20, seed: int = 0):
        self.width = width
        self.height = height
        self.rng = random.Random(seed)
        self.seasons: List[SeasonProfile] = [
            SeasonProfile("spring", temperature=0.58, rainfall=0.70, plant_growth=0.82, travel_difficulty=0.22, disease_ecology=0.34, daylight=0.58, animal_migration_pull=0.56, scarcity_pressure=0.18),
            SeasonProfile("summer", temperature=0.82, rainfall=0.46, plant_growth=0.72, travel_difficulty=0.16, disease_ecology=0.48, daylight=0.80, animal_migration_pull=0.34, scarcity_pressure=0.22),
            SeasonProfile("autumn", temperature=0.52, rainfall=0.42, plant_growth=0.48, travel_difficulty=0.24, disease_ecology=0.24, daylight=0.50, animal_migration_pull=0.68, scarcity_pressure=0.34),
            SeasonProfile("winter", temperature=0.18, rainfall=0.28, plant_growth=0.12, travel_difficulty=0.58, disease_ecology=0.18, daylight=0.28, animal_migration_pull=0.74, scarcity_pressure=0.72),
        ]
        self.fauna: Dict[str, FaunaPopulation] = {
            "deer": FaunaPopulation("deer", "woodland", 160.0, 240.0, 0.042, 0.42, 0.095, 0.030, 0.28, 0.45),
            "rabbits": FaunaPopulation("rabbits", "edge", 420.0, 650.0, 0.110, 0.22, 0.030, 0.005, 0.12, 0.18),
            "boar": FaunaPopulation("boar", "woodland", 95.0, 140.0, 0.036, 0.56, 0.120, 0.020, 0.12, 0.28),
            "goats": FaunaPopulation("goats", "scrub", 130.0, 210.0, 0.058, 0.38, 0.075, 0.018, 0.66, 0.34),
            "aurochs": FaunaPopulation("aurochs", "grassland", 70.0, 120.0, 0.025, 0.78, 0.180, 0.050, 0.48, 0.50),
            "wolves": FaunaPopulation("wolves", "woodland", 34.0, 60.0, 0.015, 0.88, 0.020, 0.010, 0.08, 0.56),
        }
        self.tick_count = 0
        self.season_index = 0
        self.year = 0
        self.drought = 0.0
        self.harsh_winter = 0.0
        self.overhunting_pressure = 0.0
        self.food_storage_total = 0.0
        self.events: List[Dict[str, Any]] = []
        self.hunt_successes = 0
        self.hunt_failures = 0
        self.hunting_injuries = 0
        self.gather_events = 0
        self._zone_grid = None  # set externally if spatial ecology enabled
        self.domestication_events = 0
        self.herd_births = 0.0
        self.herd_deaths = 0.0
        self.season_event_counts: Dict[str, int] = {}

    def current_season(self) -> SeasonProfile:
        return self.seasons[self.season_index]

    def seasonal_phase_modifiers(self) -> Dict[str, float]:
        s = self.current_season()
        return {
            "scarcity": s.scarcity_pressure + self.drought * 0.30 + self.harsh_winter * 0.16,
            "travel_difficulty": s.travel_difficulty,
            "rest_quality_delta": -0.08 * s.scarcity_pressure - 0.05 * self.harsh_winter,
            "disease_ecology": s.disease_ecology,
            "plant_growth": s.plant_growth * (1.0 - self.drought * 0.55),
        }

    def begin_tick(self, tick: int) -> List[Event]:
        self.tick_count = tick
        old_season = self.season_index
        # 100 ticks/year, four 25-tick seasons. Kept deterministic for replay.
        self.year = tick // 100
        self.season_index = (tick // 25) % 4
        events: List[Event] = []
        if tick == 0 or self.season_index != old_season:
            season = self.current_season()
            # Slow climate variation; pressure belongs to world, not agents.
            self.drought = clamp(self.drought * 0.78 + self.rng.random() * 0.08 - season.rainfall * 0.035)
            self.harsh_winter = clamp((self.harsh_winter * 0.65 + self.rng.random() * 0.18) if season.name == "winter" else self.harsh_winter * 0.35)
            ev = Event(
                tick=tick, phase=season.name, actor_id="world",
                event_type="season_transition", participants=[],
                context={"season": season.name, "year": self.year, "temperature": season.temperature, "rainfall": season.rainfall, "drought": round(self.drought, 4), "harsh_winter": round(self.harsh_winter, 4)},
                impact={"scarcity_pressure": round(self.seasonal_phase_modifiers()["scarcity"], 4), "plant_growth": round(self.seasonal_phase_modifiers()["plant_growth"], 4)},
                outcome="world_pressure_changed",
            )
            events.append(ev)
        self._tick_fauna()
        self._tick_herds()
        return events

    def _tick_fauna(self) -> None:
        season = self.current_season()
        plant = self.seasonal_phase_modifiers()["plant_growth"]
        total_before = sum(f.population for f in self.fauna.values())
        for f in self.fauna.values():
            carrying = f.max_population * (0.45 + plant * 0.65)
            growth = f.population * f.reproduction_rate * plant * (1.0 - f.population / max(1.0, carrying))
            migration_loss = f.population * season.animal_migration_pull * f.migration_sensitivity * 0.006
            winter_loss = f.population * self.harsh_winter * 0.003
            f.population = max(0.0, f.population + growth - migration_loss - winter_loss)
            f.disease_load = clamp(f.disease_load * 0.98 + season.disease_ecology * 0.004 + f.domesticated * 0.003)
        total_after = sum(f.population for f in self.fauna.values())
        self.overhunting_pressure = clamp(1.0 - total_after / max(1.0, total_before + 1e-9)) if total_before else 0.0

    def _tick_herds(self) -> None:
        season = self.current_season()
        for f in self.fauna.values():
            if f.domesticated <= 0.01:
                continue
            births = f.herd_wealth * f.reproduction_rate * (0.16 + season.plant_growth * 0.46)
            grazing_capacity = f.max_population * (0.28 + season.plant_growth * 0.52 + f.tolerance * 0.18) * (1.0 - self.drought * 0.35)
            crowding = max(0.0, f.herd_wealth - grazing_capacity) / max(1.0, grazing_capacity)
            deaths = f.herd_wealth * (0.008 + self.harsh_winter * 0.018 + f.disease_load * 0.013 + crowding * 0.045)
            f.herd_wealth = min(f.max_population * 1.18, max(0.0, f.herd_wealth + births - deaths))
            self.herd_births += min(births, f.max_population * 0.05)
            self.herd_deaths += deaths

    def apply_to_phase(self, phase):
        mods = self.seasonal_phase_modifiers()
        phase.scarcity = clamp(getattr(phase, "scarcity", 0.0) + mods["scarcity"] * 0.25)
        phase.rest_quality = clamp(getattr(phase, "rest_quality", 0.0) + mods["rest_quality_delta"])
        phase.novelty = clamp(getattr(phase, "novelty", 0.0) + (0.04 if self.current_season().name in ("spring", "autumn") else 0.0))
        return phase

    def agent_tick(self, agent, tick: int, phase_name: str, culture_pool=None, faction_registry=None) -> List[Event]:
        if not getattr(agent, "alive", False):
            return []
        events: List[Event] = []
        state = agent.state
        season = self.current_season()
        scarcity = self.seasonal_phase_modifiers()["scarcity"]
        # World-driven consumption pressure. Existing ResourceWorld still works;
        # this adds seasonal calories and storage dependency.
        calorie_need = 0.0038 + scarcity * 0.0058 + max(0.0, 0.35 - season.temperature) * 0.0035
        if getattr(state, "resource_stock", 0.0) > calorie_need:
            state.resource_stock = clamp(state.resource_stock - calorie_need)
            state.hunger = clamp(state.hunger - 0.010)
            state.energy = clamp(state.energy + 0.006 + (1.0 - state.hunger) * 0.002)
        elif self.food_storage_total > calorie_need:
            self.food_storage_total = max(0.0, self.food_storage_total - calorie_need)
            state.hunger = clamp(state.hunger - 0.004)
            state.energy = clamp(state.energy + 0.003)
        else:
            state.hunger = clamp(state.hunger + calorie_need * 1.25)
            state.stress = clamp(state.stress + scarcity * 0.0018)
            state.energy = clamp(state.energy - calorie_need * 0.26)

        # Gather first when plants are available; hunt pressure rises under hunger/scarcity.
        gather_chance = max(0.12, (season.plant_growth * (1.0 - self.drought * 0.55)) * (0.28 + getattr(state, "curiosity", 0.4) * 0.14))
        gained_base = 0.035 + season.plant_growth * 0.065
        if SPATIAL_BIOMES:
            _x = getattr(getattr(agent, 'position', None), 'x', 20)
            _y = getattr(getattr(agent, 'position', None), 'y', 20)
            _biome = get_biome(int(_x), int(_y))
            gather_chance = min(0.95, gather_chance * _biome.gather_multiplier)
            gained_base = gained_base * _biome.gather_multiplier
        if self.rng.random() < gather_chance:
            gained = gained_base
            state.resource_stock = clamp(state.resource_stock + gained)
            state.energy = clamp(state.energy + gained * 0.18)
            self.food_storage_total += max(0.0, gained - 0.030) * 0.25
            self.gather_events += 1
            # Update spatial memory with observed gather yield
            if hasattr(agent, 'spatial_memory') and agent.spatial_memory and self._zone_grid:
                _gx = getattr(getattr(agent, 'position', None), 'x', 20.0)
                _gy = getattr(getattr(agent, 'position', None), 'y', 20.0)
                _gzid = self._zone_grid.zone_id_for_position(_gx, _gy)
                _gz = self._zone_grid.zones.get(_gzid)
                if _gz:
                    _gyield = _gz.effective_gather_yield(season.name) * gather_chance
                    agent.spatial_memory.update(_gzid, _gyield, tick)
                    from movement_goals import update_home_zone
                    update_home_zone(agent, self._zone_grid, tick, _gyield)
            events.append(Event(tick, phase_name, agent.id, "gathering", [], {"season": season.name, "plant_growth": round(season.plant_growth, 4)}, {"food": round(gained, 4)}, "gathered_food"))

        hunt_drive = clamp(state.hunger * 0.46 + scarcity * 0.30 + getattr(agent.traits, "risk_tolerance", 0.5) * 0.16 + (0.10 if role_family(getattr(agent.traits, "role", "")) in ("subsistence", "protection") else 0.0))
        if SPATIAL_BIOMES:
            _x = getattr(getattr(agent, 'position', None), 'x', 20)
            _y = getattr(getattr(agent, 'position', None), 'y', 20)
            _biome = get_biome(int(_x), int(_y))
            hunt_drive = clamp(hunt_drive * _biome.hunt_multiplier)
        if self.rng.random() < hunt_drive * 0.18:
            events.append(self._hunt(agent, tick, phase_name, season))

        # Repeated proximity/use-value creates proto-domestication. It is not scripted culture.
        if tick % 3 == 0:
            dom_event = self._maybe_domesticate(agent, tick, phase_name, season, culture_pool=culture_pool)
            if dom_event:
                events.append(dom_event)
        return events

    def _choose_prey(self) -> FaunaPopulation:
        candidates = [f for f in self.fauna.values() if f.population > 1.0 and f.species != "wolves"]
        if not candidates:
            return list(self.fauna.values())[0]
        weights = [(f.population / max(1.0, f.max_population)) * (1.15 - f.hunt_difficulty) for f in candidates]
        total = sum(max(0.01, w) for w in weights)
        r = self.rng.random() * total
        acc = 0.0
        for f, w in zip(candidates, weights):
            acc += max(0.01, w)
            if r <= acc:
                return f
        return candidates[-1]

    def _hunt(self, agent, tick: int, phase_name: str, season: SeasonProfile) -> Event:
        prey = self._choose_prey()
        skill = clamp(getattr(agent.state, "curiosity", 0.5) * 0.20 + getattr(agent.traits, "risk_tolerance", 0.5) * 0.30 + getattr(agent.state, "energy", 0.5) * 0.22 + getattr(agent.state, "specialization_depth", 0.0) * 0.18)
        penalty = prey.hunt_difficulty * 0.38 + season.travel_difficulty * 0.20 + getattr(agent.state, "injury", 0.0) * 0.28
        success_p = clamp(0.15 + skill - penalty, 0.03, 0.82)
        if SPATIAL_BIOMES:
            _hx = getattr(getattr(agent, 'position', None), 'x', 20)
            _hy = getattr(getattr(agent, 'position', None), 'y', 20)
            _hbiome = get_biome(int(_hx), int(_hy))
            success_p = clamp(success_p * _hbiome.hunt_multiplier, 0.03, 0.90)
        if self.rng.random() < success_p:
            kill = min(prey.population, 1.0 + self.rng.random() * 1.8)
            prey.population = max(0.0, prey.population - kill)
            # Spatial ecology: also deplete local zone
            if SPATIAL_BIOMES and hasattr(self, '_zone_grid') and self._zone_grid is not None:
                _ax = getattr(getattr(agent, 'position', None), 'x', 20.0)
                _ay = getattr(getattr(agent, 'position', None), 'y', 20.0)
                self._zone_grid.deplete_fauna(_ax, _ay, prey.species, kill * 0.6)
            calories = prey.calories * kill
            agent.state.resource_stock = clamp(agent.state.resource_stock + calories)
            agent.state.hunger = clamp(agent.state.hunger - calories * 0.90)
            agent.state.energy = clamp(agent.state.energy + calories * 0.28)
            agent.state.exhaustion = clamp(agent.state.exhaustion + 0.010 + season.travel_difficulty * 0.012)
            self.food_storage_total += calories * 0.18
            self.hunt_successes += 1
            return Event(tick, phase_name, agent.id, "hunt", [], {"season": season.name, "species": prey.species, "success_probability": round(success_p, 4), "remaining_population": round(prey.population, 3)}, {"food": round(calories, 4), "hide": round(prey.hide_value * kill, 4)}, "hunt_success")
        else:
            agent.state.hunger = clamp(agent.state.hunger + 0.012)
            agent.state.exhaustion = clamp(agent.state.exhaustion + 0.014 + season.travel_difficulty * 0.014)
            injury = 0.0
            if self.rng.random() < (0.025 + prey.hunt_difficulty * 0.055):
                injury = 0.045 + prey.hunt_difficulty * 0.045
                agent.state.injury = clamp(agent.state.injury + injury)
                agent.state.safety = clamp(agent.state.safety - injury)
                self.hunting_injuries += 1
            self.hunt_failures += 1
            return Event(tick, phase_name, agent.id, "hunt", [], {"season": season.name, "species": prey.species, "success_probability": round(success_p, 4)}, {"hunger": 0.012, "injury": round(injury, 4)}, "hunt_failed")

    def _maybe_domesticate(self, agent, tick: int, phase_name: str, season: SeasonProfile, culture_pool=None):
        candidates = [f for f in self.fauna.values() if f.tamability > 0.30 and f.population > 5.0]
        if not candidates:
            return None
        # Hunger and scarcity encourage capture/feeding attempts; openness and stability help tolerance.
        attempt_p = clamp(0.010 + (agent.state.hunger * 0.10 + season.scarcity_pressure * 0.07 + agent.state.social_openness * 0.04 + agent.state.stability * 0.04 + (0.05 if role_family(getattr(agent.traits, "role", "")) in ("subsistence", "care", "logistics") else 0.0)) * 0.18)
        if self.rng.random() >= attempt_p:
            return None
        animal = max(candidates, key=lambda f: f.tamability * (0.8 + f.tolerance))
        animal.tolerance = clamp(animal.tolerance + animal.tamability * 0.045 + agent.state.stability * 0.014)
        if animal.tolerance > 0.14:
            delta = animal.tamability * 0.024
            animal.domesticated = clamp(animal.domesticated + delta)
            starter = 0.045 + animal.domesticated * self.rng.uniform(0.025, 0.075)
            animal.herd_wealth = min(animal.max_population * 1.18, animal.herd_wealth + starter)
            self.domestication_events += 1
            agent.state.resource_stock = clamp(agent.state.resource_stock - 0.004)
            if culture_pool and self.rng.random() < animal.domesticated * 0.10:
                try:
                    culture_pool.seed_agent(agent.id, self.rng)
                except Exception:
                    pass
            return Event(tick, phase_name, agent.id, "proto_domestication", [], {"species": animal.species, "tolerance": round(animal.tolerance, 4), "domesticated": round(animal.domesticated, 4)}, {"herd_wealth": round(animal.herd_wealth, 4)}, "animal_tolerance_increased")
        return Event(tick, phase_name, agent.id, "animal_contact", [], {"species": animal.species, "tolerance": round(animal.tolerance, 4)}, {"tolerance_delta": round(animal.tamability * 0.018, 4)}, "contact_without_husbandry")

    def record_event(self, event: Event) -> None:
        self.events.append({
            "tick": event.tick,
            "event_type": event.event_type,
            "outcome": event.outcome,
            "actor_id": event.actor_id,
            "context": event.context,
            "impact": event.impact,
        })
        self.season_event_counts[self.current_season().name] = self.season_event_counts.get(self.current_season().name, 0) + 1

    def metrics(self) -> Dict[str, Any]:
        total_fauna = sum(f.population for f in self.fauna.values())
        herd = sum(f.herd_wealth for f in self.fauna.values())
        dom_species = sum(1 for f in self.fauna.values() if f.domesticated > 0.05)
        return {
            "subsistence_season": self.current_season().name,
            "subsistence_year": self.year,
            "subsistence_drought": round(self.drought, 4),
            "subsistence_harsh_winter": round(self.harsh_winter, 4),
            "subsistence_total_fauna": round(total_fauna, 4),
            "subsistence_food_storage": round(self.food_storage_total, 4),
            "subsistence_hunt_successes": self.hunt_successes,
            "subsistence_hunt_failures": self.hunt_failures,
            "subsistence_hunting_injuries": self.hunting_injuries,
            "subsistence_gather_events": self.gather_events,
            "subsistence_domestication_events": self.domestication_events,
            "subsistence_domesticated_species": dom_species,
            "subsistence_herd_wealth": round(herd, 4),
            "subsistence_herd_births": round(self.herd_births, 4),
            "subsistence_herd_deaths": round(self.herd_deaths, 4),
            "subsistence_overhunting_pressure": round(self.overhunting_pressure, 4),
        }

    def snapshot(self) -> Dict[str, Any]:
        return {
            "version": "v04.33",
            "description": "Environment-driven seasons, wild fauna, hunting/gathering, proto-domestication, and herd pressure.",
            "current": self.metrics(),
            "seasons": [asdict(s) for s in self.seasons],
            "fauna": {k: v.snapshot() for k, v in self.fauna.items()},
            "season_event_counts": dict(self.season_event_counts),
        }


def benchmark_metrics(world: SubsistenceWorld) -> Dict[str, Any]:
    return world.metrics()
