"""
Deception / Asymmetric Information — Layer 6
Agents can signal false states (fake cooperation, fake low-threat) to
manipulate others' beliefs.  Deception success depends on dominance and
risk_tolerance; detection depends on the observer's curiosity and past
experience with the actor.  Successful deception shifts observed beliefs
toward the false signal; detected deception sharply raises threat perception.
"""
import random
from typing import Optional


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


# v04.2 balance patch: the former threshold/goal/random triple gate made
# deception nearly invisible after early trust formation.  Deception is still
# trait-gated and relationship-gated, but no longer goal-label gated.
DECEIVE_THRESHOLD = 0.46    # dominance * risk_tolerance above this → can attempt
DECEIVE_RANDOM_GATE = 0.18  # stochastic attempt gate after deterministic gates pass
DETECT_BASE = 0.25          # base detection probability


class DeceptionModule:
    def __init__(self, rng: random.Random) -> None:
        self._rng = rng
        self.times_deceived: int = 0
        self.times_caught: int = 0
        self.times_deceived_by: dict = {}   # actor_id -> count
        # v04.12: world-level dedup registry injected by runner each tick.
        # Keyed by frozenset({actor_id, target_id}) so bidirectional same-tick
        # mutual deception attempts log only once.
        self._logged_this_tick: Optional[set] = None

    def set_tick_registry(self, registry: set) -> None:
        """Runner calls this once per tick before any agent ticks."""
        self._logged_this_tick = registry

    def _already_logged(self, actor_id: str, target_id: str) -> bool:
        """Check whether this dyad already had a deception attempt this tick (does NOT register)."""
        if self._logged_this_tick is None:
            return False
        return frozenset({actor_id, target_id}) in self._logged_this_tick

    def _register_attempt(self, actor_id: str, target_id: str) -> None:
        """Register a dyad after an attempt actually fires — prevents double-counting."""
        if self._logged_this_tick is not None:
            self._logged_this_tick.add(frozenset({actor_id, target_id}))

    def should_attempt_deception(self, agent, other) -> bool:
        """
        Agent considers deceiving `other` when:
        - dominance × risk_tolerance clears the attempt threshold
        - the target trusts the actor enough for deception to have cover
        - the target is not in the actor's own faction
        - this dyad has not already logged a deception event this tick
          (prevents bidirectional mutual-deception double-counting)
        """
        # Bidirectional dedup: if the other agent already attempted on self this tick, skip.
        if self._already_logged(agent.id, other.id):
            return False
        score = agent.state.dominance * agent.traits.risk_tolerance
        if score < DECEIVE_THRESHOLD:
            return False
        # Don't deceive faction-mates
        if getattr(agent, "faction_registry", None):
            if agent.faction_registry.same_faction(agent.id, other.id):
                return False
        rel_other_to_self = other.relationships.get(agent.id)
        if rel_other_to_self.trust < 0.45:
            return False   # target is already suspicious
        return self._rng.random() < DECEIVE_RANDOM_GATE   # stochastic gate

    def execute_deception(self, actor, target, tick: int) -> dict:
        """
        Actor sends a false "cooperative" signal.
        Returns a result dict indicating success/failure and belief shifts.
        """
        # Register this dyad so the other agent can't also attempt this tick.
        self._register_attempt(actor.id, target.id)

        # Detection probability: base + target curiosity − actor dominance modifier
        detect_prob = clamp(
            DETECT_BASE
            + target.state.curiosity * 0.35
            - actor.state.dominance * 0.20
            + self.times_deceived_by.get(actor.id, 0) * 0.08
        )
        detected = self._rng.random() < detect_prob

        if detected:
            self.times_caught += 1
            # Target sharply raises threat perception of actor
            target.beliefs.agent_threat[actor.id] = clamp(
                target.beliefs.get_threat(actor.id) + 0.20
            )
            target.beliefs.agent_safety[actor.id] = clamp(
                target.beliefs.get_safety(actor.id) - 0.15
            )
            target.relationships.update_after_interaction(
                actor.id,
                trust_delta=-0.15,
                resentment_delta=0.20,
                attachment_delta=-0.05,
                influence_delta=-0.05,
            )
            self.times_deceived_by[actor.id] = self.times_deceived_by.get(actor.id, 0) + 1
            return {"outcome": "deception_detected", "actor": actor.id, "target": target.id, "tick": tick}
        else:
            self.times_deceived += 1
            # Target softens threat perception — believes the false signal
            target.beliefs.agent_threat[actor.id] = clamp(
                target.beliefs.get_threat(actor.id) - 0.10
            )
            target.beliefs.agent_safety[actor.id] = clamp(
                target.beliefs.get_safety(actor.id) + 0.08
            )
            # Actor gains a small dominance/resource advantage.
            # v04.8: dominance soft-cap prevents deception from becoming an unlimited ratchet.
            if actor.state.dominance <= 0.65:
                dom_gain = 0.015
            else:
                dom_gain = max(0.002, 0.015 * (1.0 - ((actor.state.dominance - 0.65) / 0.35)))
            actor.state.dominance = clamp(actor.state.dominance + dom_gain, hi=0.90)
            actor.state.resource_stock = clamp(actor.state.resource_stock + 0.05)
            actor.deception_last_dominance_gain = dom_gain
            return {"outcome": "deception_success", "actor": actor.id, "target": target.id, "tick": tick}

    def snapshot(self) -> dict:
        return {
            "times_deceived": self.times_deceived,
            "times_caught": self.times_caught,
        }
