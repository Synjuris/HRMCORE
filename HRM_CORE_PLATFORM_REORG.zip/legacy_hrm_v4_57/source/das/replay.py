"""
replay.py — v04.16 replay loader

Reconstructs the full observable state of a run at any tick from:
  manifest.json      — config, seed, version
  checkpoints/       — compressed world snapshots every N ticks
  events.json        — full event ledger (or salience-filtered subset)

Replay does NOT re-run simulation logic. It reassembles what the
observer can know from the recorded artifacts. This is an inspection
tool, not a behavioral re-execution engine.

Usage:
  from replay import RunReplay
  r = RunReplay("runs_v04_13/run_4")
  state = r.at(tick=250)          # world state at tick 250
  window = r.events_between(200, 300)
  timeline = r.timeline()         # major events ordered by tick
"""

import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from checkpoint import CheckpointReader


class RunReplay:
    """
    Read-only view into a completed run.
    Loads lazily — checkpoint is only decompressed when requested.
    """

    def __init__(self, run_dir: str | Path):
        self.run_dir = Path(run_dir)

        # Manifest
        m_path = self.run_dir / "manifest.json"
        if not m_path.exists():
            raise FileNotFoundError(f"No manifest at {m_path}")
        self.manifest = json.loads(m_path.read_text(encoding="utf-8"))

        # Summary
        s_path = self.run_dir / "summary.json"
        self.summary = json.loads(s_path.read_text(encoding="utf-8")) if s_path.exists() else {}

        # Metric log
        ml_path = self.run_dir / "metrics.json"
        self._metric_rows: List[dict] = json.loads(ml_path.read_text(encoding="utf-8")) if ml_path.exists() else []
        self._metric_by_tick: Dict[int, dict] = {r["tick"]: r for r in self._metric_rows}

        # Event ledger
        ev_path = self.run_dir / "events.json"
        self._events: List[dict] = json.loads(ev_path.read_text(encoding="utf-8")) if ev_path.exists() else []

        # Death ledger (v04.14)
        deaths_path = self.run_dir / "deaths.json"
        if deaths_path.exists():
            d = json.loads(deaths_path.read_text(encoding="utf-8"))
            self._death_records: List[dict] = d.get("deaths", [])
            self._death_summary: dict = {k: v for k, v in d.items() if k != "deaths"}
        else:
            self._death_records = []
            self._death_summary = {}

        # Observer annotations (v04.16)
        ann_path = self.run_dir / "observer" / "replay_annotations.json"
        self._observer_annotations: List[dict] = json.loads(ann_path.read_text(encoding="utf-8")) if ann_path.exists() else []

        # Checkpoint reader
        self._ck = CheckpointReader(self.run_dir)

        # Run bounds
        self.ticks = self.manifest.get("ticks", 500)
        self.seed  = self.manifest.get("seed")
        self.version = self.manifest.get("version", "unknown")

    # ── State access ──────────────────────────────────────────────────────────

    def at(self, tick: int) -> dict:
        """
        Return the world state at `tick`.
        Uses the nearest checkpoint at or before tick, then patches with
        metric row if available.
        """
        ck_tick = self._ck.nearest_before(tick)
        if ck_tick is None:
            raise ValueError(f"No checkpoint available at or before tick {tick}")

        ck = self._ck.load(ck_tick)
        metric = self._metric_by_tick.get(tick) or self._metric_by_tick.get(ck_tick)

        return {
            "requested_tick":   tick,
            "checkpoint_tick":  ck_tick,
            "phase":            ck.get("phase"),
            "agents":           ck.get("agents", []),
            "factions":         ck.get("factions", []),
            "institutions":     ck.get("institutions", []),
            "culture":          ck.get("culture", {}),
            "metrics":          metric,
            "staleness_ticks":  tick - ck_tick,
        }

    def checkpoint_ticks(self) -> List[int]:
        return self._ck.available_ticks

    # ── Event access ──────────────────────────────────────────────────────────

    def events_between(self, t_start: int, t_end: int,
                       event_types: Optional[List[str]] = None,
                       min_salience: float = 0.0) -> List[dict]:
        """Return events in [t_start, t_end], filtered by type and salience."""
        out = []
        for e in self._events:
            t = e.get("tick", -1)
            if t < t_start or t > t_end:
                continue
            if event_types and e.get("event_type") not in event_types:
                continue
            if e.get("salience", 1.0) < min_salience:
                continue
            out.append(e)
        return out

    def high_salience_events(self, min_salience: float = 0.70) -> List[dict]:
        return [e for e in self._events if e.get("salience", 0.0) >= min_salience]

    @property
    def death_records(self) -> List[dict]:
        """Structured death records from deaths.json (v04.14+). Empty list for older runs."""
        return self._death_records

    @property
    def death_summary(self) -> dict:
        return self._death_summary

    @property
    def observer_annotations(self) -> List[dict]:
        """Replay overlay annotations from observer/replay_annotations.json (v04.16)."""
        return self._observer_annotations

    def agent_events(self, agent_id: str,
                     t_start: int = 0, t_end: int = 999999) -> List[dict]:
        """All events where agent_id is actor or participant."""
        return [
            e for e in self._events
            if t_start <= e.get("tick", -1) <= t_end
            and (e.get("actor_id") == agent_id
                 or agent_id in e.get("participants", []))
        ]

    # ── Metric access ─────────────────────────────────────────────────────────

    def metric_at(self, tick: int) -> Optional[dict]:
        """Metric row at tick (sampled every 10 ticks). Returns None if not recorded."""
        return self._metric_by_tick.get(tick)

    def metric_series(self, key: str) -> List[Tuple[int, Any]]:
        """Extract a single metric across all recorded ticks."""
        return [(r["tick"], r.get(key)) for r in self._metric_rows if key in r]

    # ── Timeline ──────────────────────────────────────────────────────────────

    def timeline(self) -> List[dict]:
        """
        Ordered list of major observable events:
          - Attractor state changes
          - Agent deaths and births
          - First conflict in each cross-faction dyad
          - Institution formations/dissolutions (from metric steps)
          - Deception events (HIGH salience)
          - Reconciliation events
        """
        events = []

        # Attractor transitions from metric log
        prev_attr = None
        for row in self._metric_rows:
            attr = row.get("attractor_window") or _infer_attractor(
                row.get("conflict_per_100_interactions"),
                self.manifest.get("config", {}).get("attractor", {})
            )
            if attr and attr != prev_attr and prev_attr is not None:
                events.append({
                    "tick":  row["tick"],
                    "kind":  "attractor_transition",
                    "from":  prev_attr,
                    "to":    attr,
                    "c100":  row.get("conflict_per_100_interactions"),
                })
            prev_attr = attr

        # Institution count changes from metric log
        prev_inst = None
        for row in self._metric_rows:
            ic = row.get("institution_count")
            if ic is not None and prev_inst is not None and ic != prev_inst:
                events.append({
                    "tick": row["tick"],
                    "kind": "institution_count_change",
                    "from": prev_inst,
                    "to":   ic,
                })
            if ic is not None:
                prev_inst = ic

        # High-salience events from ledger
        # Build name map from agents_final (most complete source) + death events
        agent_name_map = {}
        # Try to load agents_final from the same run_dir
        try:
            import json as _json
            _af_path = self.run_dir / "agents_final.json"
            if _af_path.exists():
                for _a in _json.loads(_af_path.read_text()):
                    agent_name_map[_a["id"]] = _a.get("name", _a["id"])
        except Exception:
            pass
        # Also pull from death event contexts as fallback
        for e in self._events:
            ctx = e.get("context", {})
            if ctx.get("name") and e.get("actor_id") and e.get("actor_id") not in agent_name_map:
                agent_name_map[e["actor_id"]] = ctx["name"]

        def _name(aid: str) -> str:
            return agent_name_map.get(aid, aid[-8:])

        seen_dyads: set = set()
        for e in self.high_salience_events(min_salience=0.70):
            etype = e.get("event_type")
            outcome = e.get("outcome")
            if etype == "agent_death":
                # Use enriched data from death ledger if available
                ctx = e.get("context", {})
                dr = next((d for d in self._death_records
                           if d["agent_id"] == e.get("actor_id")), None)
                events.append({
                    "tick":            e["tick"],
                    "kind":            "agent_death",
                    "agent":           ctx.get("name", e.get("actor_id")),
                    "faction":         ctx.get("faction"),
                    "cause":           ctx.get("cause", "unknown"),
                    "role":            ctx.get("role"),
                    "systemic_impact": ctx.get("systemic_impact", 0.0),
                    "vacancy_type":    ctx.get("vacancy_type"),
                    "n_survivors_connected": ctx.get("n_survivors_with_relationship", 0),
                })
            elif etype == "interaction" and outcome == "conflict" and e.get("salience", 0) >= 1.0:
                # Only first-conflict-in-dyad (salience==1.0)
                actor  = e.get("actor_id", "")
                target = (e.get("participants") or [""])[0]
                dyad   = frozenset({actor, target})
                if dyad in seen_dyads:
                    continue
                seen_dyads.add(dyad)
                actor_name  = _name(actor)
                target_name = _name(target)
                events.append({
                    "tick":       e["tick"],
                    "kind":       "conflict",
                    "actor":      actor,
                    "actor_name": actor_name,
                    "target":     target,
                    "target_name": target_name,
                    "salience":   e.get("salience"),
                    "first_in_dyad": True,
                })
            elif etype == "deception":
                actor  = e.get("actor_id", "")
                target = (e.get("participants") or [""])[0]
                events.append({
                    "tick":    e["tick"],
                    "kind":    "deception",
                    "actor":   _name(actor),
                    "target":  _name(target),
                    "outcome": outcome,
                })

        # v04.16 observer overlay annotations. Keep them separate by kind so
        # viewers can filter without confusing them with substrate events.
        for ann in self._observer_annotations:
            if ann.get("salience", 0.0) < 0.45:
                continue
            events.append({
                "tick": ann.get("tick", 0),
                "kind": "observer_annotation",
                "annotation_type": ann.get("annotation_type"),
                "text": ann.get("text"),
                "salience": ann.get("salience"),
                "source": ann.get("source"),
                "evidence": ann.get("evidence", {}),
            })

        events.sort(key=lambda x: x["tick"])
        return events

    def __repr__(self) -> str:
        return (f"RunReplay(run_dir={self.run_dir}, "
                f"version={self.version}, seed={self.seed}, ticks={self.ticks}, "
                f"checkpoints={len(self._ck.available_ticks)}, "
                f"events={len(self._events)})")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _infer_attractor(c100, attractor_cfg: dict) -> Optional[str]:
    if c100 is None:
        return None
    p_max = attractor_cfg.get("peaceful_max", 7.0)
    c_min = attractor_cfg.get("conflict_min", 12.0)
    if c100 < p_max:
        return "peaceful"
    if c100 > c_min:
        return "conflict"
    return "mixed"
