"""
Language / LLM Cognition — Layer 11
Agents develop linguistic complexity over time.
Language enables:
  - Richer intent signaling before interactions (reduces surprise outcomes)
  - Collective memory encoding (shared narrative snippets stored in a WorldNarrative)
  - Negotiation: high-language agents can resolve disputes before they escalate
Language aptitude is an inherited trait; complexity grows with age and cooperation.
A WorldNarrative accumulates cross-agent event summaries (no API calls required —
this is a lightweight symbolic model; an optional LLM hook is provided but not required).
"""
import random
from typing import List, Dict
from schemas import AgentState, DevelopmentalTraits


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


# v04.2 balance patch: language previously decayed from ~0.10 to ~0.067
# across 500 ticks and never reached negotiation.  Cooperation now compounds
# meaningfully, while isolation decay remains mild.
LANG_GROW_RATE = 0.0060
LANG_DECAY_ISOLATION = 0.0002
NEGOTIATE_THRESHOLD = 0.14    # v04.38: proto-negotiation activates before advanced language
NEGOTIATE_CONFLICT_REDUCTION = 0.18


class LanguageModule:
    """Per-agent language tracker."""
    def __init__(self) -> None:
        self.utterances: List[str] = []    # recent symbolic utterances

    def tick(self, agent, had_cooperation: bool, had_conflict: bool) -> None:
        state = agent.state
        traits = agent.traits
        # Grow with social success and aptitude
        if had_cooperation:
            state.linguistic_complexity = clamp(
                state.linguistic_complexity + LANG_GROW_RATE * (0.5 + traits.language_aptitude)
            )
        elif had_conflict:
            state.linguistic_complexity = clamp(
                state.linguistic_complexity + LANG_GROW_RATE * 0.2
            )
        else:
            # Isolation decays language slightly
            state.linguistic_complexity = clamp(
                state.linguistic_complexity - LANG_DECAY_ISOLATION
            )

    def can_negotiate(self, agent) -> bool:
        return agent.state.linguistic_complexity >= NEGOTIATE_THRESHOLD

    def try_negotiate(self, agent, other, rng: random.Random) -> bool:
        """
        Before a conflict resolves, attempt linguistic negotiation.
        Returns True if conflict is averted (converted to cooperation outcome).
        """
        if not self.can_negotiate(agent):
            return False
        # Combined language skill determines success probability
        combined = (agent.state.linguistic_complexity + other.state.linguistic_complexity) / 2.0
        success = rng.random() < clamp(0.10 + combined * 0.65)
        if success:
            # Reduce both parties' stress slightly
            agent.state.stress = clamp(agent.state.stress - NEGOTIATE_CONFLICT_REDUCTION * 0.5)
            other.state.stress = clamp(other.state.stress - NEGOTIATE_CONFLICT_REDUCTION * 0.3)
            self.utterances.append(f"negotiated_peace_with_{other.id[:12]}")
        return success

    def emit_utterance(self, agent, event_outcome: str) -> str:
        lc = agent.state.linguistic_complexity
        if lc < 0.20:
            u = f"[signal:{event_outcome[:3]}]"
        elif lc < 0.50:
            u = f"[proto:{event_outcome}]"
        else:
            u = f"[lang:{event_outcome}:agent={agent.name}]"
        self.utterances.append(u)
        if len(self.utterances) > 50:
            self.utterances = self.utterances[-50:]
        return u

    def snapshot(self) -> dict:
        return {
            "linguistic_complexity": None,   # filled by agent snapshot
            "recent_utterances": self.utterances[-5:],
        }


class WorldNarrative:
    """
    Shared collective memory — agents contribute symbolic event summaries.
    An optional LLM hook can be attached (set llm_hook = async callable)
    to generate natural-language summaries of notable events.
    """
    def __init__(self) -> None:
        self.entries: List[Dict] = []
        self.llm_hook = None   # optional: async fn(entries) -> str

    def record(self, tick: int, actor_name: str, outcome: str,
               participants: List[str], extra: dict = None) -> None:
        self.entries.append({
            "tick": tick,
            "actor": actor_name,
            "outcome": outcome,
            "participants": participants,
            **(extra or {}),
        })
        if len(self.entries) > 500:
            self.entries = self.entries[-500:]

    def recent_summary(self, n: int = 10) -> List[Dict]:
        return self.entries[-n:]

    def snapshot(self) -> dict:
        return {
            "total_entries": len(self.entries),
            "recent": self.recent_summary(5),
        }
