"""
adaptive_roles.py — v04.34 anti-hardcoding role ontology

Roles are capability domains, not fixed historical occupations.  A society may
call the same functional niche different things as language, tools, storage,
governance, and infrastructure mature.  Mechanics should key off role_family()
and capability pressure, not literal labels like "farmer" or "programmer".
"""
from __future__ import annotations
from typing import Any, Dict, Tuple


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    try:
        return max(lo, min(hi, float(x)))
    except Exception:
        return lo


ROLE_FAMILIES = (
    "generalist", "subsistence", "protection", "coordination", "diplomacy",
    "craft", "care", "knowledge", "logistics", "governance", "information"
)

# Legacy aliases are kept only for compatibility with earlier saves/reports.
LEGACY_ROLE_FAMILY = {
    "generalist": "generalist",
    "gatherer": "subsistence",
    "hunter": "subsistence",
    "forager": "subsistence",
    "farmer": "subsistence",
    "herder": "subsistence",
    "defender": "protection",
    "guard": "protection",
    "warrior": "protection",
    "planner": "coordination",
    "coordinator": "coordination",
    "diplomat": "diplomacy",
    "mediator": "diplomacy",
    "toolmaker": "craft",
    "builder": "craft",
    "healer": "care",
    "caregiver": "care",
    "storykeeper": "knowledge",
    "scribe": "knowledge",
    "teacher": "knowledge",
    "trader": "logistics",
    "carrier": "logistics",
    "leader": "governance",
    "judge": "governance",
    "messenger": "information",
    "analyst": "information",
}


def role_family(role: str | None) -> str:
    if not role:
        return "generalist"
    r = str(role).strip().lower()
    if r in ROLE_FAMILIES:
        return r
    return LEGACY_ROLE_FAMILY.get(r, "generalist")


def civilization_context(agent: Any) -> Dict[str, float]:
    """Infer local capability context from observable state, not date labels."""
    s = getattr(agent, "state", None)
    if s is None:
        return {"complexity": 0.0, "scarcity": 0.5, "language": 0.0, "storage": 0.0, "governance": 0.0, "information": 0.0}
    language = clamp(getattr(s, "linguistic_complexity", 0.0))
    specialization = clamp(getattr(s, "specialization_depth", 0.0))
    planning = clamp(getattr(s, "plan_confidence", 0.0))
    storage = clamp(getattr(s, "resource_stock", 0.0))
    stress = clamp(getattr(s, "stress", 0.0))
    hunger = clamp(getattr(s, "hunger", 0.0))
    scarcity = clamp((1.0 - storage) * 0.45 + hunger * 0.35 + stress * 0.20)
    innovation = clamp(getattr(agent, "innovation_successes", 0) / 12.0)
    governance = clamp((1.0 if getattr(agent, "is_leader", False) else 0.0) * 0.35 + planning * 0.35 + specialization * 0.30)
    information = clamp(language * 0.45 + innovation * 0.30 + planning * 0.25)
    infrastructure = clamp(storage * 0.30 + innovation * 0.35 + planning * 0.20 + specialization * 0.15)
    complexity = clamp(language * 0.24 + specialization * 0.20 + planning * 0.18 + innovation * 0.20 + infrastructure * 0.18)
    return {
        "complexity": complexity,
        "scarcity": scarcity,
        "language": language,
        "storage": storage,
        "governance": governance,
        "information": information,
        "infrastructure": infrastructure,
        "innovation": innovation,
    }


def capability_scores(agent: Any, outcome: str = "") -> Dict[str, float]:
    s = getattr(agent, "state", None)
    t = getattr(agent, "traits", None)
    if s is None or t is None:
        return {"generalist": 0.35}
    ctx = civilization_context(agent)
    current = role_family(getattr(t, "role", "generalist"))
    depth = clamp(getattr(s, "specialization_depth", 0.0))
    # Continuity bonus scales with specialization depth — deeper roles resist displacement
    continuity_bonus = 0.10 + depth * 0.18
    continuity = {fam: (continuity_bonus if fam == current else 0.0) for fam in ROLE_FAMILIES}
    scores = {
        "generalist": 0.34 + (0.06 if ctx["complexity"] < 0.20 else 0.0),
        "subsistence": clamp(getattr(s, "curiosity", 0.5) * 0.22 + (1.0 - getattr(s, "fear", 0.2)) * 0.14 + ctx["scarcity"] * 0.34 + getattr(s, "energy", 0.5) * 0.12 + (0.10 if outcome in ("explore", "gathered_food", "successful_hunt") else 0.0)),
        "protection": clamp(getattr(s, "dominance", 0.5) * 0.30 + getattr(t, "resilience", 0.5) * 0.22 + getattr(t, "risk_tolerance", 0.5) * 0.18 + (0.16 if outcome == "conflict" else 0.0) + getattr(s, "fear", 0.2) * 0.08),
        "coordination": clamp(getattr(s, "plan_confidence", 0.5) * 0.36 + ctx["infrastructure"] * 0.22 + getattr(s, "stability", 0.5) * 0.12 + getattr(s, "specialization_depth", 0.0) * 0.16),
        # Diplomacy ceiling reduced: cooperation is universal, not a strong differentiator
        "diplomacy": clamp(getattr(s, "cooperation", 0.5) * 0.20 + getattr(s, "social_openness", 0.5) * 0.18 + (1.0 - getattr(s, "dominance", 0.5)) * 0.10 + (0.04 if outcome == "cooperation" else 0.0)),
        "craft": clamp(ctx["innovation"] * 0.30 + getattr(s, "curiosity", 0.5) * 0.18 + getattr(s, "plan_confidence", 0.5) * 0.18 + ctx["infrastructure"] * 0.20),
        # Care boosted via attachment_rate (a stable trait)
        "care": clamp((1.0 - getattr(s, "dominance", 0.5)) * 0.14 + getattr(s, "cooperation", 0.5) * 0.16 + getattr(s, "social_openness", 0.5) * 0.14 + getattr(t, "attachment_rate", 0.05) * 2.5 + getattr(s, "care_burden", 0.0) * 0.30 + (1.0 - getattr(s, "stress", 0.2)) * 0.08),
        # Knowledge boosted: language_aptitude is a stable trait-level differentiator
        "knowledge": clamp(ctx["language"] * 0.26 + getattr(s, "curiosity", 0.5) * 0.20 + getattr(t, "language_aptitude", 0.5) * 0.26 + ctx["innovation"] * 0.12 + 0.04),
        "logistics": clamp(ctx["storage"] * 0.26 + ctx["infrastructure"] * 0.24 + getattr(s, "plan_confidence", 0.5) * 0.18 + getattr(s, "resource_stock", 0.5) * 0.12),
        "governance": clamp(ctx["governance"] * 0.34 + getattr(s, "dominance", 0.5) * 0.16 + getattr(s, "plan_confidence", 0.5) * 0.20 + getattr(s, "cultural_alignment", 0.5) * 0.10),
        "information": clamp(ctx["information"] * 0.34 + getattr(t, "language_aptitude", 0.5) * 0.22 + getattr(s, "curiosity", 0.5) * 0.16 + getattr(s, "plan_confidence", 0.5) * 0.10 + 0.03),
    }
    for fam, bonus in continuity.items():
        scores[fam] = clamp(scores.get(fam, 0.0) + bonus)
    return scores


def infer_role_family(agent: Any, outcome: str = "") -> str:
    scores = capability_scores(agent, outcome)
    return max(scores, key=scores.__getitem__)


def role_label(family: str, context: Dict[str, float]) -> str:
    """Timeline-appropriate display label derived from capability maturity."""
    fam = role_family(family)
    c = context.get("complexity", 0.0)
    info = context.get("information", 0.0)
    infra = context.get("infrastructure", 0.0)
    if fam == "generalist":
        return "generalist"
    bands = {
        "subsistence": [(0.25, "forager"), (0.45, "food producer"), (0.70, "agricultural specialist"), (1.01, "resource systems worker")],
        "protection": [(0.25, "watcher"), (0.45, "guard"), (0.70, "soldier"), (1.01, "security specialist")],
        "coordination": [(0.25, "camp organizer"), (0.45, "work coordinator"), (0.70, "administrator"), (1.01, "operations specialist")],
        "diplomacy": [(0.25, "peace broker"), (0.45, "mediator"), (0.70, "envoy"), (1.01, "negotiation specialist")],
        "craft": [(0.25, "tool maker"), (0.45, "craft worker"), (0.70, "artisan/technician"), (1.01, "technical specialist")],
        "care": [(0.25, "caregiver"), (0.45, "healer"), (0.70, "medical worker"), (1.01, "care systems worker")],
        "knowledge": [(0.25, "story keeper"), (0.45, "teacher"), (0.70, "scribe/scholar"), (1.01, "knowledge worker")],
        "logistics": [(0.25, "carrier"), (0.45, "trader"), (0.70, "merchant/logistician"), (1.01, "logistics specialist")],
        "governance": [(0.25, "elder"), (0.45, "council figure"), (0.70, "official"), (1.01, "governance specialist")],
        "information": [(0.25, "messenger"), (0.45, "record keeper"), (0.70, "clerk/analyst"), (1.01, "information worker")],
    }
    # Keep advanced information labels gated by actual information capacity.
    value = max(c, info if fam == "information" else 0.0, infra if fam in ("craft", "logistics") else 0.0)
    for ceiling, label in bands.get(fam, [(1.01, fam)]):
        if value < ceiling:
            return label
    return fam


def is_role_family(role: str | None, family: str) -> bool:
    return role_family(role) == role_family(family)


def role_snapshot(agent: Any) -> Dict[str, Any]:
    fam = role_family(getattr(getattr(agent, "traits", None), "role", "generalist"))
    ctx = civilization_context(agent)
    scores = capability_scores(agent)
    return {
        "family": fam,
        "label": role_label(fam, ctx),
        "context": {k: round(v, 4) for k, v in ctx.items()},
        "scores": {k: round(v, 4) for k, v in sorted(scores.items())},
    }
