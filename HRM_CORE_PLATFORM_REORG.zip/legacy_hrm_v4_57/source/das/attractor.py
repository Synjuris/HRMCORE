"""
attractor.py — v04.12 attractor classification

Replaces the hardcoded 6.0/14.0 thresholds in run_sim.py with
config-driven, rule-based classification.

Calibrated against v04.10 baseline (10 runs × 500 ticks):
  peaceful cluster:  0.21 – 5.28  (6 runs)
  mixed:             7.26          (1 run)
  conflict cluster: 15.33 – 19.18 (3 runs)
  natural gap:       5.28 → 7.26 and 7.26 → 15.33

Thresholds are set conservatively inside the natural gaps,
not at the edge of observed data.

New state: 'collapse'
  Fires when population drops below COLLAPSE_POPULATION_FLOOR or
  deaths-per-tick exceeds COLLAPSE_DEATH_RATE. Takes priority over
  all other classifications.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class AttractorConfig:
    # Conflict-rate thresholds (conflicts per 100 interactions)
    peaceful_max:   float = 2.0     # < this → peaceful  (v04.43: recalibrated for belief-decay distribution)
    conflict_min:   float = 3.5     # > this → conflict   (v04.43: recalibrated for belief-decay distribution)
    # Population collapse triggers (checked independently of conflict rate)
    collapse_population_floor: int   = 3      # living agents below this → collapse
    collapse_death_rate:       float = 0.10   # deaths / total_agents > this → collapse
    # Minimum interactions before classification is meaningful
    min_interactions_for_classification: int = 20


# Module-level singleton — overridable in tests or scenario configs
DEFAULT_CONFIG = AttractorConfig()


def classify(
    conflict_per_100: Optional[float],
    living: int = 10,
    total_agents: int = 10,
    deaths: int = 0,
    config: AttractorConfig = DEFAULT_CONFIG,
) -> str:
    """
    Classify the current attractor state.

    Returns: 'unknown' | 'peaceful' | 'mixed' | 'conflict' | 'collapse'
    """
    # Collapse check takes priority
    if living < config.collapse_population_floor:
        return "collapse"
    if total_agents > 0 and deaths / total_agents > config.collapse_death_rate:
        return "collapse"

    if conflict_per_100 is None:
        return "unknown"

    if conflict_per_100 < config.peaceful_max:
        return "peaceful"
    if conflict_per_100 > config.conflict_min:
        return "conflict"
    return "mixed"


def switches(metric_log: list, config: AttractorConfig = DEFAULT_CONFIG) -> dict:
    """
    Compute attractor trajectory from a metric_log (list of per-tick dicts).
    Each row needs 'tick', 'conflict_per_100_interactions', optionally 'living'/'dead'.

    Returns the same shape as the old attractor_switches() in run_sim.py,
    extended with the config snapshot so results are reproducible.
    """
    rows = [
        r for r in metric_log
        if r.get("tick", 0) >= 50
        and r.get("conflict_per_100_interactions") is not None
    ]
    if not rows:
        return {
            "early_attractor": "unknown",
            "final_attractor": "unknown",
            "switches": 0,
            "recovered": False,
            "collapsed": False,
            "trajectory": [],
            "config": _config_snapshot(config),
        }

    trajectory = []
    for r in rows:
        state = classify(
            r.get("conflict_per_100_interactions"),
            living=r.get("living", 10),
            total_agents=r.get("living", 10) + r.get("dead", 0),
            deaths=r.get("dead", 0),
            config=config,
        )
        trajectory.append({
            "tick":      r["tick"],
            "attractor": state,
            "c100":      r.get("conflict_per_100_interactions"),
        })

    # Compress consecutive identical states
    compressed = []
    for item in trajectory:
        if not compressed or compressed[-1]["attractor"] != item["attractor"]:
            compressed.append(item)

    early  = trajectory[0]["attractor"]
    final  = trajectory[-1]["attractor"]
    n_sw   = max(0, len(compressed) - 1)
    recovered = (early == "conflict" and final in ("mixed", "peaceful"))
    collapsed = (final == "collapse")

    return {
        "early_attractor": early,
        "final_attractor": final,
        "switches":   n_sw,
        "recovered":  recovered,
        "collapsed":  collapsed,
        "trajectory": compressed,
        "config":     _config_snapshot(config),
    }


def _config_snapshot(config: AttractorConfig) -> dict:
    return {
        "peaceful_max":   config.peaceful_max,
        "conflict_min":   config.conflict_min,
        "collapse_population_floor": config.collapse_population_floor,
        "collapse_death_rate":       config.collapse_death_rate,
    }
