"""
memory.py — v04.12 compressed agent memory

Agents no longer accumulate unbounded raw event lists.
Retention policy:
  - First interaction with each agent (relationship seed)
  - Peak stress event (highest stress impact seen)
  - Last N_RECENT interactions (recency window)
  - All HIGH-salience events (conflict, deception, death, reconciliation)

Everything else is summarized as per-agent interaction counts.
This caps memory at O(N_agents + N_RECENT + N_high_salience) regardless of run length.

Behavioral impact: zero. Memory is read only by planning.py and metrics.py.
Planning uses recent() and average_impact() — both still correct post-compression.
Metrics uses count_with() — now read from the summary index, which is exact.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional
from schemas import Event

# Retention limits
N_RECENT        = 8      # last N interactions kept verbatim
N_HIGH_SALIENCE = 50     # max high-salience events kept (prevents unbounded growth on long runs)
STRESS_PEAK_MIN = 0.04   # minimum stress impact to qualify as peak candidate


@dataclass
class MemorySummary:
    """Compressed record of all interactions with one other agent."""
    other_id:          str
    total_count:       int = 0
    conflict_count:    int = 0
    cooperation_count: int = 0
    last_tick:         int = 0
    first_tick:        int = -1


class Memory:
    def __init__(self) -> None:
        self._first_contact:  Dict[str, Event] = {}
        self._recent:         List[Event] = []
        self._high_salience:  List[Event] = []
        self._stress_peak:    Optional[Event] = None
        self._summaries:      Dict[str, MemorySummary] = {}

    def add(self, event: Event, salience: float = 0.5) -> None:
        for other_id in event.participants:
            s = self._summaries.setdefault(other_id, MemorySummary(other_id=other_id))
            s.total_count += 1
            if event.outcome == "conflict":
                s.conflict_count += 1
            elif event.outcome == "cooperation":
                s.cooperation_count += 1
            s.last_tick = event.tick
            if s.first_tick < 0:
                s.first_tick = event.tick

        for other_id in event.participants:
            if other_id not in self._first_contact:
                self._first_contact[other_id] = event

        stress_impact = abs(event.impact.get("stress", 0.0))
        if stress_impact >= STRESS_PEAK_MIN:
            if self._stress_peak is None or stress_impact > abs(self._stress_peak.impact.get("stress", 0.0)):
                self._stress_peak = event

        self._recent.append(event)
        if len(self._recent) > N_RECENT:
            self._recent.pop(0)

        if salience >= 0.70:
            self._high_salience.append(event)
            if len(self._high_salience) > N_HIGH_SALIENCE:
                self._high_salience = self._high_salience[-N_HIGH_SALIENCE:]

    def recent(self, limit: int = 10) -> List[Event]:
        combined = self._high_salience[-limit:] + self._recent
        seen = set()
        out = []
        for e in sorted(combined, key=lambda x: x.tick, reverse=True):
            eid = (e.tick, e.actor_id, e.event_type)
            if eid not in seen:
                seen.add(eid)
                out.append(e)
            if len(out) >= limit:
                break
        return out

    def count_with(self, other_id: str) -> int:
        s = self._summaries.get(other_id)
        return s.total_count if s else 0

    def average_impact(self, key: str, limit: int = 50) -> float:
        events = self.recent(limit=limit)
        values = [e.impact.get(key, 0.0) for e in events]
        return sum(values) / len(values) if values else 0.0

    def compression_stats(self) -> dict:
        return {
            "first_contact_agents":       len(self._first_contact),
            "recent_events":              len(self._recent),
            "high_salience_events":       len(self._high_salience),
            "has_stress_peak":            self._stress_peak is not None,
            "summary_agent_count":        len(self._summaries),
            "total_interactions_indexed": sum(s.total_count for s in self._summaries.values()),
        }
