from dataclasses import dataclass
import math
import random

@dataclass
class Position:
    x: float
    y: float

class SpatialWorld:
    def __init__(self, width=12, height=12, interaction_radius=2):
        self.width = width
        self.height = height
        self.interaction_radius = interaction_radius
        self.logistics_world = None
        self._zone_grid = None   # set externally when spatial ecology enabled

    def random_position(self, rng):
        return Position(rng.uniform(0, self.width - 1),
                        rng.uniform(0, self.height - 1))

    def distance(self, a, b):
        return math.sqrt((a.x - b.x)**2 + (a.y - b.y)**2)

    def move_agent(self, agent, phase, population=None, tick=0, rng=None):
        """
        Goal-directed movement if spatial agency layer is active.
        Falls back to legacy random drift if zone_grid not set.
        """
        if getattr(agent.state, 'movement_budget', 1.0) <= 0:
            return

        if self._zone_grid is not None:
            # Spatial Agency Layer v1 — goal-directed movement
            try:
                from movement_goals import evaluate_and_move
                _rng = rng or random.Random(tick + hash(agent.id) & 0xFFFF)
                _pop = population or []
                evaluate_and_move(
                    agent, tick, self._zone_grid, _pop, _rng,
                    self.width, self.height
                )
                return
            except Exception:
                pass  # fall through to legacy

        # Legacy random drift
        drift = max(0.05, min(0.6, getattr(phase, 'novelty', 0.2) + 0.1))
        _rng = rng or agent.rng
        if _rng.random() < drift:
            agent.position.x = max(0.0, min(float(self.width - 1),
                agent.position.x + _rng.choice([-1, 0, 1])))
            agent.position.y = max(0.0, min(float(self.height - 1),
                agent.position.y + _rng.choice([-1, 0, 1])))

    def nearby_agents(self, agent, population):
        return [
            a for a in population
            if a is not agent
            and getattr(a, 'alive', False)
            and self.distance(agent.position, a.position) <= self.interaction_radius
        ]
