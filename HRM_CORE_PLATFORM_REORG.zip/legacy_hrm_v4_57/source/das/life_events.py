"""Stub for life_events module (v04.48 not present in this build)."""

_NULL_DELTA = {"stress": 0.0, "support": 0.0, "trust": 0.0}

def initialize_life_events(agents, max_ticks=500, seed=0, tick=0, key="run"):
    for agent in agents:
        if not hasattr(agent, 'life_events'):
            agent.life_events = []

def step_disease_layer(agents, tick, key="run"):
    pass

def apply_all_life_effects(agent, tick, key="run"):
    return dict(_NULL_DELTA)
