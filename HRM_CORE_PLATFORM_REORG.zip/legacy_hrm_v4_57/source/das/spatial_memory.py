"""
spatial_memory.py — HRM Spatial Agency Layer v1

Per-agent cognitive map of zone yield quality.
Agents remember zones they have personally experienced.
Memory decays so ancient information loses weight.
Knowledge can spread through social exchange (trade/conversation).

Distinct from subjective_memory.py which tracks beliefs about OTHER AGENTS.
This tracks beliefs about PLACES.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    pass

# Decay constant — memory half-life in ticks
MEMORY_DECAY_HALFLIFE = 400.0

# Visit count bonus — more visits = more confident memory
VISIT_BONUS_SCALE = 0.08
VISIT_BONUS_CAP   = 0.25

# Minimum yield score to consider a zone "known good"
KNOWN_GOOD_THRESHOLD = 0.35

# Social transmission — fraction of partner's memory score adopted on exchange
SOCIAL_TRANSMISSION_RATE = 0.30


@dataclass
class ZoneMemory:
    """Memory of one zone's yield quality."""
    zone_id:     str
    last_yield:  float   # raw yield observed on last visit (0-1)
    last_tick:   int     # tick of last personal visit
    visit_count: int     # total visits to this zone

    def effective_score(self, current_tick: int) -> float:
        """
        Decayed yield score. Older memories count less.
        visit_count adds a small confidence bonus.
        """
        age = max(0, current_tick - self.last_tick)
        import math
        decay = math.exp(-age * 0.693 / MEMORY_DECAY_HALFLIFE)
        visit_bonus = min(VISIT_BONUS_CAP, self.visit_count * VISIT_BONUS_SCALE)
        return self.last_yield * decay + visit_bonus

    def is_known_good(self, current_tick: int) -> bool:
        return self.effective_score(current_tick) >= KNOWN_GOOD_THRESHOLD


class SpatialMemory:
    """
    Agent's personal cognitive map of the world.
    Keyed by zone_id. Only zones the agent has visited or
    learned about through social exchange are present.
    """

    def __init__(self) -> None:
        self._zones: Dict[str, ZoneMemory] = {}

    def update(self, zone_id: str, yield_obs: float, tick: int) -> None:
        """Record a personal yield observation in a zone."""
        if zone_id in self._zones:
            zm = self._zones[zone_id]
            # Running average of yield — weight recent higher
            zm.last_yield = zm.last_yield * 0.40 + yield_obs * 0.60
            zm.last_tick  = tick
            zm.visit_count += 1
        else:
            self._zones[zone_id] = ZoneMemory(
                zone_id=zone_id,
                last_yield=yield_obs,
                last_tick=tick,
                visit_count=1,
            )

    def best_zone(self, current_tick: int,
                  exclude: Optional[str] = None) -> Optional[str]:
        """Return zone_id with highest effective score, or None if no memory."""
        candidates = {
            zid: zm.effective_score(current_tick)
            for zid, zm in self._zones.items()
            if zid != exclude
        }
        if not candidates:
            return None
        return max(candidates, key=candidates.__getitem__)

    def score(self, zone_id: str, current_tick: int) -> float:
        """Return effective score for a zone, 0 if unknown."""
        zm = self._zones.get(zone_id)
        if zm is None:
            return 0.0
        return zm.effective_score(current_tick)

    def known_zones(self) -> Dict[str, ZoneMemory]:
        return dict(self._zones)

    def social_learn(self, other: "SpatialMemory",
                     current_tick: int) -> None:
        """
        Partially adopt another agent's zone memories.
        Simulates knowledge exchange during trade or conversation.
        Only zones the other agent rates highly get transmitted.
        """
        for zid, zm in other._zones.items():
            other_score = zm.effective_score(current_tick)
            if other_score < KNOWN_GOOD_THRESHOLD:
                continue
            if zid in self._zones:
                # Blend toward other's knowledge if theirs is higher
                my_score = self._zones[zid].effective_score(current_tick)
                if other_score > my_score:
                    self._zones[zid].last_yield += (
                        (zm.last_yield - self._zones[zid].last_yield)
                        * SOCIAL_TRANSMISSION_RATE
                    )
            else:
                # Learn a new zone — discounted version of their memory
                self._zones[zid] = ZoneMemory(
                    zone_id=zid,
                    last_yield=zm.last_yield * SOCIAL_TRANSMISSION_RATE,
                    last_tick=current_tick,
                    visit_count=0,   # haven't been there personally
                )

    def snapshot(self, current_tick: int) -> dict:
        return {
            zid: {
                "last_yield": round(zm.last_yield, 4),
                "last_tick":  zm.last_tick,
                "visit_count": zm.visit_count,
                "effective_score": round(zm.effective_score(current_tick), 4),
            }
            for zid, zm in self._zones.items()
        }
