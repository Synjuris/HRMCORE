"""
generational_psychology.py — v04.35 Generational Psychological Transmission

Closes the developmental loop:
  lived experience -> adult psychology -> household climate/story memory ->
  probabilistic child starting conditions -> later development.

Rules:
  - No deterministic trauma copying.
  - No era-specific assumptions.
  - Effects bend probabilities and recovery difficulty, not destiny.
  - Uses role families/capabilities rather than fixed occupations.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Dict, Iterable, List, Optional
import random

from schemas import Event
from adaptive_roles import role_family


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    try:
        return max(lo, min(hi, float(x)))
    except Exception:
        return lo


@dataclass
class TransmissionRecord:
    tick: int
    child_id: str
    child_name: str
    parent_ids: List[str]
    parent_names: List[str]
    parental_trauma_burden: float
    household_risk: float
    protective_care: float
    trait_deltas: Dict[str, float]


class GenerationalPsychologyLedger:
    def __init__(self) -> None:
        self.birth_transmission_records: List[Dict[str, Any]] = []
        self.story_events: List[Dict[str, Any]] = []
        self.recovery_events: List[Dict[str, Any]] = []
        self.birth_transmissions: int = 0
        self.story_transmissions: int = 0
        self.targeted_recoveries: int = 0

    def record_birth(self, record: TransmissionRecord) -> None:
        self.birth_transmissions += 1
        self.birth_transmission_records.append(asdict(record))

    def record_story_event(self, event: Event) -> None:
        self.story_transmissions += 1
        self.story_events.append(_event_to_dict(event))

    def record_recovery_event(self, event: Event) -> None:
        self.targeted_recoveries += 1
        self.recovery_events.append(_event_to_dict(event))

    def snapshot(self) -> Dict[str, Any]:
        avg_burden = 0.0
        if self.birth_transmission_records:
            avg_burden = sum(r.get("parental_trauma_burden", 0.0) for r in self.birth_transmission_records) / len(self.birth_transmission_records)
        return {
            "summary": {
                "birth_transmissions": self.birth_transmissions,
                "story_transmissions": self.story_transmissions,
                "targeted_recoveries": self.targeted_recoveries,
                "avg_parental_trauma_burden": round(avg_burden, 4),
            },
            "birth_transmission_records": self.birth_transmission_records[-250:],
            "story_events": self.story_events[-250:],
            "recovery_events": self.recovery_events[-250:],
        }


def _event_to_dict(event: Event) -> Dict[str, Any]:
    return {
        "tick": event.tick,
        "phase": event.phase,
        "actor_id": event.actor_id,
        "event_type": event.event_type,
        "participants": list(event.participants),
        "context": dict(event.context),
        "impact": dict(event.impact),
        "outcome": event.outcome,
    }


def _mean(xs: Iterable[float], default: float = 0.0) -> float:
    vals = list(xs)
    return sum(vals) / len(vals) if vals else default


def parent_trauma_burden(parent: Any) -> float:
    exp = getattr(parent, "experience", None)
    state = getattr(parent, "state", None)
    traits = getattr(parent, "traits", None)
    scars = clamp(getattr(exp, "scars", 0.0)) if exp else 0.0
    grudge = 0.0
    bond = 0.0
    if exp:
        tg = exp.top_grudge()
        tb = exp.top_bond()
        grudge = clamp(tg[1] if tg else 0.0)
        bond = clamp(tb[1] if tb else 0.0)
    stress = clamp(getattr(state, "stress", 0.2)) if state else 0.2
    fear = clamp(getattr(state, "fear", 0.2)) if state else 0.2
    trust_deficit = clamp(0.55 - getattr(traits, "trust_baseline", 0.5), 0.0, 0.55) / 0.55 if traits else 0.0
    resilience_gap = clamp(0.55 - getattr(traits, "resilience", 0.5), 0.0, 0.55) / 0.55 if traits else 0.0
    protective_bond = bond * 0.16
    # Scars weighted more heavily — they're accumulated history, not current state
    # trust_deficit and resilience_gap capture structural damage vs transient stress
    burden = scars * 0.40 + trust_deficit * 0.22 + resilience_gap * 0.16 + stress * 0.10 + fear * 0.08 + grudge * 0.10 - protective_bond
    return clamp(burden)


def household_emotional_climate(parents: List[Any]) -> Dict[str, float]:
    if not parents:
        return {"risk": 0.0, "protective_care": 0.0, "stress": 0.0, "fear": 0.0, "scar": 0.0, "instability": 0.0}
    stress = _mean(clamp(getattr(getattr(p, "state", None), "stress", 0.2)) for p in parents)
    fear = _mean(clamp(getattr(getattr(p, "state", None), "fear", 0.2)) for p in parents)
    hunger = _mean(clamp(getattr(getattr(p, "state", None), "hunger", 0.1)) for p in parents)
    scar = _mean(clamp(getattr(getattr(p, "experience", None), "scars", 0.0)) for p in parents)
    stability = _mean(clamp(getattr(getattr(p, "state", None), "household_stability", 0.5)) for p in parents)
    care = _mean(clamp(getattr(getattr(p, "state", None), "cooperation", 0.5)) * 0.45 + clamp(getattr(getattr(p, "state", None), "social_openness", 0.5)) * 0.35 + clamp(getattr(getattr(p, "traits", None), "resilience", 0.5)) * 0.20 for p in parents)
    instability = clamp(1.0 - stability)
    risk = clamp(stress * 0.26 + fear * 0.20 + hunger * 0.14 + scar * 0.24 + instability * 0.16)
    return {"risk": risk, "protective_care": care, "stress": stress, "fear": fear, "scar": scar, "instability": instability}


def apply_birth_transmission(child: Any, parents: List[Any], tick: int, rng: random.Random, ledger: Optional[GenerationalPsychologyLedger] = None) -> Optional[TransmissionRecord]:
    """Bias newborn baselines from parent history/environment without copying trauma."""
    parents = [p for p in parents if p is not None]
    if not parents or not hasattr(child, "traits") or not hasattr(child, "state"):
        return None

    burdens = [parent_trauma_burden(p) for p in parents]
    parental_burden = clamp(_mean(burdens))
    climate = household_emotional_climate(parents)
    protective = clamp(climate["protective_care"])

    # Separate trauma signal from protective signal.
    # Trauma effect: raw exposure from burden + household risk, NOT dampened by protective.
    # Protective care operates independently on its own traits — it does not cancel trauma.
    exposure = clamp(parental_burden * 0.65 + climate["risk"] * 0.35)
    jitter = rng.uniform(0.80, 1.20)
    trauma_effect = clamp(exposure * jitter)         # trauma signal — drives negative traits
    care_effect = clamp(protective * jitter * 0.75)  # care signal — drives positive traits

    before = {
        "trust_baseline": child.traits.trust_baseline,
        "conflict_sensitivity": child.traits.conflict_sensitivity,
        "risk_tolerance": child.traits.risk_tolerance,
        "attachment_rate": child.traits.attachment_rate,
        "avoidance_rate": child.traits.avoidance_rate,
        "resilience": child.traits.resilience,
        "recovery_speed": child.traits.recovery_speed,
        "ideology_sensitivity": getattr(child.traits, "ideology_sensitivity", 0.5),
        "stress": child.state.stress,
        "fear": child.state.fear,
        "social_openness": child.state.social_openness,
    }

    # Trauma signal drives traits in the expected direction — independently of protective care.
    # High trauma → lower trust, higher conflict sensitivity, lower resilience, higher avoidance.
    child.traits.trust_baseline = clamp(child.traits.trust_baseline - 0.18 * trauma_effect, 0.08, 0.92)
    child.traits.conflict_sensitivity = clamp(child.traits.conflict_sensitivity + 0.22 * trauma_effect, 0.05, 0.95)
    child.traits.avoidance_rate = clamp(child.traits.avoidance_rate + 0.025 * trauma_effect, 0.005, 0.18)
    child.traits.resilience = clamp(child.traits.resilience - 0.14 * trauma_effect, 0.05, 0.95)
    child.traits.recovery_speed = clamp(child.traits.recovery_speed - 0.025 * trauma_effect, 0.005, 0.22)
    child.traits.ideology_sensitivity = clamp(getattr(child.traits, "ideology_sensitivity", 0.5) + 0.12 * trauma_effect, 0.05, 0.95)
    child.state.stress = clamp(child.state.stress + 0.08 * trauma_effect)
    child.state.fear = clamp(child.state.fear + 0.07 * trauma_effect)
    child.state.social_openness = clamp(child.state.social_openness - 0.09 * trauma_effect)

    # Protective care signal drives its own traits positively — does not cancel trauma above.
    # High care → better attachment, slightly higher resilience, slightly better recovery.
    child.traits.attachment_rate = clamp(child.traits.attachment_rate + 0.018 * care_effect, 0.005, 0.18)
    child.traits.resilience = clamp(child.traits.resilience + 0.06 * care_effect, 0.05, 0.95)
    child.traits.recovery_speed = clamp(child.traits.recovery_speed + 0.012 * care_effect, 0.005, 0.22)
    child.traits.trust_baseline = clamp(child.traits.trust_baseline + 0.05 * care_effect, 0.08, 0.92)
    child.state.social_openness = clamp(child.state.social_openness + 0.04 * care_effect)
    child.traits.risk_tolerance = clamp(child.traits.risk_tolerance + rng.uniform(-0.04, 0.04) * trauma_effect, 0.05, 0.95)

    # Mark as inherited pressure, not direct experienced trauma.
    setattr(child, "inherited_trauma_burden", round(parental_burden, 4))
    setattr(child, "household_emotional_risk", round(climate["risk"], 4))
    setattr(child, "protective_care_buffer", round(protective, 4))

    if hasattr(child, "experience"):
        child.experience.add_trace(
            tick, "household", "inherited_climate",
            valence=-0.30 * trauma_effect + 0.15 * care_effect,
            intensity=0.30 + trauma_effect * 0.45,
            phrase="birth into inherited household climate",
        )

    after = {
        "trust_baseline": child.traits.trust_baseline,
        "conflict_sensitivity": child.traits.conflict_sensitivity,
        "risk_tolerance": child.traits.risk_tolerance,
        "attachment_rate": child.traits.attachment_rate,
        "avoidance_rate": child.traits.avoidance_rate,
        "resilience": child.traits.resilience,
        "recovery_speed": child.traits.recovery_speed,
        "ideology_sensitivity": getattr(child.traits, "ideology_sensitivity", 0.5),
        "stress": child.state.stress,
        "fear": child.state.fear,
        "social_openness": child.state.social_openness,
    }
    deltas = {k: round(after[k] - before[k], 5) for k in before if abs(after[k] - before[k]) >= 0.00001}
    rec = TransmissionRecord(
        tick=tick,
        child_id=child.id,
        child_name=getattr(child, "name", child.id),
        parent_ids=[p.id for p in parents],
        parent_names=[getattr(p, "name", p.id) for p in parents],
        parental_trauma_burden=round(parental_burden, 4),
        household_risk=round(climate["risk"], 4),
        protective_care=round(protective, 4),
        trait_deltas=deltas,
    )
    setattr(child, "_v435_birth_transmission", asdict(rec))
    if ledger:
        ledger.record_birth(rec)
    return rec


def apply_storykeeper_transmission(agents: List[Any], tick: int, phase_name: str, rng: random.Random, ledger: Optional[GenerationalPsychologyLedger] = None) -> List[Event]:
    """Knowledge/information agents transmit social memory that changes priors."""
    if tick % 20 != 0:
        return []
    living = [a for a in agents if getattr(a, "alive", False)]
    speakers = [a for a in living if role_family(getattr(getattr(a, "traits", None), "role", "")) in ("knowledge", "information")]
    if not speakers:
        # Early societies can still have oral memory if language complexity or scars make someone a de facto storykeeper.
        # Age gate removed — a scarred young adult can carry stories. LC threshold lowered to 0.28.
        speakers = [a for a in living if getattr(getattr(a, "state", None), "linguistic_complexity", 0.0) > 0.28 or getattr(getattr(a, "experience", None), "scars", 0.0) > 0.15]
    events: List[Event] = []
    for speaker in speakers[:5]:
        if rng.random() > 0.28:
            continue
        scar = clamp(getattr(getattr(speaker, "experience", None), "scars", 0.0))
        trust = clamp(getattr(getattr(speaker, "traits", None), "trust_baseline", 0.5))
        language = clamp(getattr(getattr(speaker, "state", None), "linguistic_complexity", 0.1))
        intensity = clamp(0.20 + scar * 0.35 + language * 0.30 + (0.55 - trust) * 0.15)
        if intensity < 0.25:
            continue
        recipients = [a for a in living if a.id != speaker.id and abs(a.position.x - speaker.position.x) <= 1 and abs(a.position.y - speaker.position.y) <= 1]
        rng.shuffle(recipients)
        recipients = recipients[:4]
        if not recipients:
            continue
        negative_memory = scar > 0.22 or trust < 0.38
        impact_fear = 0.0
        impact_trust = 0.0
        for r in recipients:
            openness = clamp(getattr(r.state, "social_openness", 0.5))
            susceptibility = clamp(openness * 0.45 + getattr(r.traits, "ideology_sensitivity", 0.5) * 0.35 + getattr(r.traits, "language_aptitude", 0.5) * 0.20)
            delta = intensity * susceptibility
            if negative_memory:
                r.state.fear = clamp(r.state.fear + 0.018 * delta)
                r.traits.trust_baseline = clamp(r.traits.trust_baseline - 0.012 * delta, 0.05, 0.95)
                r.traits.conflict_sensitivity = clamp(r.traits.conflict_sensitivity + 0.010 * delta, 0.05, 0.95)
                impact_fear += 0.018 * delta
                impact_trust -= 0.012 * delta
            else:
                r.state.cooperation = clamp(r.state.cooperation + 0.014 * delta)
                r.traits.resilience = clamp(r.traits.resilience + 0.010 * delta, 0.05, 0.95)
                r.traits.trust_baseline = clamp(r.traits.trust_baseline + 0.008 * delta, 0.05, 0.95)
                impact_trust += 0.008 * delta
            if hasattr(r, "experience"):
                r.experience.add_trace(tick, speaker.id, "oral_tradition", valence=(-0.25 if negative_memory else 0.20), intensity=delta, phrase="received remembered social lesson")
        event = Event(
            tick=tick,
            phase=phase_name,
            actor_id=speaker.id,
            event_type="oral_tradition_transmission",
            participants=[r.id for r in recipients],
            context={"negative_memory": negative_memory, "intensity": round(intensity, 4), "speaker_role_family": role_family(getattr(speaker.traits, "role", ""))},
            impact={"fear": round(impact_fear, 5), "trust_baseline": round(impact_trust, 5)},
            outcome="warning_story_spread" if negative_memory else "resilience_story_spread",
        )
        events.append(event)
        if ledger:
            ledger.record_story_event(event)
    return events


def apply_targeted_care_recovery(agents: List[Any], tick: int, phase_name: str, rng: random.Random, ledger: Optional[GenerationalPsychologyLedger] = None) -> List[Event]:
    """Care-family agents actively dampen individual trauma load when conditions support repair."""
    if tick % 10 != 0:
        return []
    living = [a for a in agents if getattr(a, "alive", False)]
    carers = [a for a in living if role_family(getattr(getattr(a, "traits", None), "role", "")) == "care"]
    # v04.38: in small founder bands a formal care specialist may not exist.
    # Let highly cooperative/social agents provide primitive repair so recovery
    # is an emergent social function before it becomes a specialized role.
    if not carers:
        carers = sorted(living, key=lambda a: (a.state.cooperation + a.state.social_openness + a.traits.attachment_rate * 4.0), reverse=True)[:3]
    events: List[Event] = []
    for carer in carers[:6]:
        if rng.random() > 0.62:
            continue
        candidates = [a for a in living if a.id != carer.id and abs(a.position.x - carer.position.x) <= 1 and abs(a.position.y - carer.position.y) <= 1]
        candidates = [a for a in candidates if getattr(a.experience, "scars", 0.0) > 0.015 or a.state.stress > 0.42 or a.state.fear > 0.50]
        if not candidates:
            continue
        target = max(candidates, key=lambda a: getattr(a.experience, "scars", 0.0) + a.state.stress)
        skill = clamp(carer.state.cooperation * 0.30 + carer.state.social_openness * 0.22 + carer.traits.resilience * 0.20 + carer.traits.attachment_rate * 2.0)
        receptivity = clamp(target.state.social_openness * 0.30 + target.traits.trust_baseline * 0.25 + max(0.0, 1.0 - target.state.fear) * 0.20 + target.traits.recovery_speed * 2.0)
        effect = clamp(skill * receptivity * rng.uniform(0.55, 1.15))
        if effect < 0.055:
            continue
        stress_delta = -0.040 * effect
        scar_delta = -0.026 * effect
        trust_delta = 0.010 * effect
        target.state.stress = clamp(target.state.stress + stress_delta)
        target.state.fear = clamp(target.state.fear - 0.014 * effect)
        target.traits.trust_baseline = clamp(target.traits.trust_baseline + trust_delta, 0.05, 0.95)
        target.traits.recovery_speed = clamp(target.traits.recovery_speed + 0.006 * effect, 0.005, 0.22)
        if hasattr(target, "experience"):
            target.experience.scars = clamp(target.experience.scars + scar_delta)
            target.experience.add_trace(tick, carer.id, "targeted_care_recovery", valence=0.35, intensity=effect, phrase="care-mediated recovery")
        event = Event(
            tick=tick,
            phase=phase_name,
            actor_id=carer.id,
            event_type="targeted_care_recovery",
            participants=[target.id],
            context={"effect": round(effect, 4), "target_scar_after": round(getattr(target.experience, "scars", 0.0), 4)},
            impact={"stress": round(stress_delta, 5), "scar": round(scar_delta, 5), "trust_baseline": round(trust_delta, 5)},
            outcome="individual_recovery_supported",
        )
        events.append(event)
        if ledger:
            ledger.record_recovery_event(event)
    return events


def benchmark_metrics(ledger: Optional[GenerationalPsychologyLedger], agents: Optional[List[Any]] = None) -> Dict[str, Any]:
    if ledger is None:
        return {
            "psych_transmission_births": 0,
            "psych_transmission_stories": 0,
            "psych_transmission_recoveries": 0,
        }
    snap = ledger.snapshot()["summary"]
    out = {
        "psych_transmission_births": snap["birth_transmissions"],
        "psych_transmission_stories": snap["story_transmissions"],
        "psych_transmission_recoveries": snap["targeted_recoveries"],
        "psych_transmission_avg_parental_burden": snap["avg_parental_trauma_burden"],
    }
    if agents is not None:
        living = [a for a in agents if getattr(a, "alive", False)]
        out["psych_transmission_avg_inherited_burden"] = round(_mean(getattr(a, "inherited_trauma_burden", 0.0) for a in living), 4) if living else 0.0
        out["psych_transmission_household_risk_carriers"] = sum(1 for a in living if getattr(a, "household_emotional_risk", 0.0) > 0.25)
    return out
