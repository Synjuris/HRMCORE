"""
harness.py — DAS v04.28 stability and scale harness.

Separates the concerns that were all crammed into run_sim.py's main loop:

1. EventStream     — append-only JSONL writer; never accumulates in memory
2. RollingCounters — O(1) metric tracking; replaces O(n) event_log scans
3. RunManifest     — crash-safe run state: started/completed/failed + traceback
4. SmokeTest       — minimal regression suite callable from CLI or CI

The simulation loop is unchanged. This wraps around it.
"""
from __future__ import annotations

import json
import os
import sys
import time
import traceback
import random
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, TextIO


# ── 1. EventStream ─────────────────────────────────────────────────────────────

class EventStream:
    """
    Append-only JSONL writer. Events are serialized and written immediately —
    never held in memory. Replaces event_log list accumulation.

    Usage:
        stream = EventStream(output_dir / "events.jsonl")
        stream.write(ev_dict)
        stream.close()

    Consumers read the JSONL file; they never block the sim loop.
    """

    def __init__(self, path: Path, mode: str = "w") -> None:
        self.path = path
        self._fh: TextIO = open(path, mode, encoding="utf-8", buffering=8192)
        self._count: int = 0

    def write(self, event: dict) -> None:
        self._fh.write(json.dumps(event, default=str) + "\n")
        self._count += 1

    def flush(self) -> None:
        self._fh.flush()

    def close(self) -> None:
        self._fh.flush()
        self._fh.close()

    @property
    def count(self) -> int:
        return self._count

    def __enter__(self) -> "EventStream":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()


# ── 2. RollingCounters ────────────────────────────────────────────────────────

class RollingCounters:
    """
    O(1) per-event metric tracking. Replaces O(n) scans of event_log.

    Call .record(event_dict) every time an event is written.
    Call .snapshot() to get current totals for metric_log or summary.

    No list is maintained. Counters only grow forward.
    """

    def __init__(self) -> None:
        self.interaction_total: int = 0
        self.conflict_total: int = 0
        self.cooperation_total: int = 0
        self.negotiation_total: int = 0
        self.negotiation_success: int = 0
        self.negotiation_failed: int = 0
        self.deception_total: int = 0
        self.deception_success: int = 0
        self.deception_detected: int = 0
        self.inst_prevented: int = 0
        self.inst_suppression_total: float = 0.0
        self.agent_death_total: int = 0
        self.birth_total: int = 0
        self.rumor_total: int = 0
        self.information_created: int = 0
        self.information_relayed: int = 0
        self.information_blocked: int = 0
        self.governance_compliance: int = 0
        self.governance_defiance: int = 0
        self.governance_succession: int = 0
        self.apprenticeship_formed: int = 0
        self.apprenticeship_completed: int = 0
        self.homicide_total: int = 0
        self.lethal_attempt_survived: int = 0

    def record(self, ev: dict) -> None:
        etype   = ev.get("event_type", "")
        outcome = ev.get("outcome", "")
        ctx     = ev.get("context", {}) or {}

        if etype == "interaction":
            self.interaction_total += 1
            if outcome == "conflict":
                self.conflict_total += 1
            elif outcome == "cooperation":
                self.cooperation_total += 1
            if ctx.get("institution_prevented_conflict"):
                self.inst_prevented += 1
            self.inst_suppression_total += ctx.get("institution_suppression", 0.0)

        elif etype == "negotiation":
            self.negotiation_total += 1
            if outcome == "negotiation_success":
                self.negotiation_success += 1
            elif outcome == "negotiation_failed":
                self.negotiation_failed += 1

        elif etype == "deception":
            self.deception_total += 1
            if outcome == "deception_success":
                self.deception_success += 1
            elif outcome == "deception_detected":
                self.deception_detected += 1

        elif etype == "agent_death":
            self.agent_death_total += 1

        elif etype == "lethal_conflict":
            if outcome == "homicide":
                self.homicide_total += 1
            elif outcome == "lethal_attempt_survived":
                self.lethal_attempt_survived += 1

        elif etype == "birth":
            self.birth_total += 1

        elif etype == "rumor_propagation":
            self.rumor_total += 1

        elif etype == "apprenticeship_formed":
            self.apprenticeship_formed += 1

        elif etype == "apprenticeship_completed":
            self.apprenticeship_completed += 1

        elif etype == "coordination":
            self.governance_compliance += ctx.get("compliant", 0)
            self.governance_defiance  += ctx.get("defiant", 0)

        elif etype in ("succession", "leadership_installed"):
            self.governance_succession += 1

    def snapshot(self) -> Dict[str, Any]:
        n = max(1, self.interaction_total)
        return {
            "interaction_events_cumulative":         self.interaction_total,
            "conflict_events_cumulative":            self.conflict_total,
            "cooperation_events_cumulative":         self.cooperation_total,
            "conflict_per_100_interactions":         round(100.0 * self.conflict_total / n, 4),
            "negotiation_events_cumulative":         self.negotiation_total,
            "negotiation_success_cumulative":        self.negotiation_success,
            "negotiation_failed_cumulative":         self.negotiation_failed,
            "deception_events_cumulative":           self.deception_total,
            "deception_success_cumulative":          self.deception_success,
            "deception_detected_cumulative":         self.deception_detected,
            "institution_prevented_conflicts_cumulative": self.inst_prevented,
            "institution_suppression_total_cumulative":  round(self.inst_suppression_total, 4),
            "agent_deaths_logged":                   self.agent_death_total,
            "birth_total":                           self.birth_total,
        }

    def summary_fields(self) -> Dict[str, Any]:
        """Fields for the per-run summary dict — mirrors old event_log scans."""
        n_int = max(1, self.interaction_total)
        n_neg = max(1, self.negotiation_total)
        n_dec = max(1, self.deception_total)
        return {
            "interaction_events":          self.interaction_total,
            "conflict_events":             self.conflict_total,
            "cooperation_events":          self.cooperation_total,
            "conflict_per_100_interactions": round(100.0 * self.conflict_total / n_int, 4),
            "cooperation_rate":            round(self.cooperation_total / n_int, 4),
            "negotiation_events":          self.negotiation_total,
            "negotiation_successes":       self.negotiation_success,
            "negotiation_failures":        self.negotiation_failed,
            "negotiation_success_rate":    round(self.negotiation_success / n_neg, 4),
            "negotiated_conflict_suppression": self.negotiation_success,
            "deception_events":            self.deception_total,
            "deception_success":           self.deception_success,
            "deception_detected":          self.deception_detected,
            "deception_success_rate":      round(self.deception_success / n_dec, 4),
            "institution_prevented_conflicts": self.inst_prevented,
            "institution_suppression_total": round(self.inst_suppression_total, 4),
            "institution_suppression_per_interaction": round(
                self.inst_suppression_total / n_int, 4),
            "agent_deaths_logged":         self.agent_death_total,
            "homicides":                   self.homicide_total,
            "lethal_attempts_survived":    self.lethal_attempt_survived,
            "births":                      self.birth_total,
            "rumor_events":                self.rumor_total,
            "apprenticeship_formed_events":    self.apprenticeship_formed,
            "apprenticeship_completed_events": self.apprenticeship_completed,
            "governance_compliance_events":    self.governance_compliance,
            "governance_defiance_events":      self.governance_defiance,
            "governance_succession_events":    self.governance_succession,
        }


# ── 3. RunManifest ────────────────────────────────────────────────────────────

@dataclass
class RunRecord:
    run_id: int
    status: str = "started"       # started | completed | failed
    started_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None
    ticks_completed: int = 0
    error: Optional[str] = None
    traceback_file: Optional[str] = None
    output_dir: Optional[str] = None


class RunManifest:
    """
    Crash-safe run state written to manifest.json after every state change.
    If a run fails, the manifest records status=failed + traceback path.
    On restart, the caller can skip completed runs or retry failed ones.
    """

    def __init__(self, output_root: Path) -> None:
        self.path = output_root / "manifest.json"
        self.records: Dict[int, RunRecord] = {}
        self._load()

    def _load(self) -> None:
        if self.path.exists():
            try:
                data = json.loads(self.path.read_text(encoding="utf-8"))
                for item in data:
                    r = RunRecord(**item)
                    self.records[r.run_id] = r
            except Exception:
                pass

    def _save(self) -> None:
        self.path.write_text(
            json.dumps([asdict(r) for r in self.records.values()], indent=2),
            encoding="utf-8",
        )

    def start(self, run_id: int, output_dir: Path) -> RunRecord:
        r = RunRecord(run_id=run_id, output_dir=str(output_dir))
        self.records[run_id] = r
        self._save()
        return r

    def tick(self, run_id: int, tick: int) -> None:
        r = self.records.get(run_id)
        if r:
            r.ticks_completed = tick
            # Save every 50 ticks to avoid disk thrash
            if tick % 50 == 0:
                self._save()

    def complete(self, run_id: int) -> None:
        r = self.records.get(run_id)
        if r:
            r.status = "completed"
            r.completed_at = time.time()
            self._save()

    def fail(self, run_id: int, exc: Exception, output_dir: Path) -> None:
        r = self.records.get(run_id)
        if not r:
            r = RunRecord(run_id=run_id)
            self.records[run_id] = r
        r.status = "failed"
        r.completed_at = time.time()
        r.error = str(exc)
        tb_path = output_dir / f"traceback_run{run_id}.txt"
        try:
            tb_path.write_text(traceback.format_exc(), encoding="utf-8")
            r.traceback_file = str(tb_path)
        except Exception:
            pass
        self._save()

    def summary(self) -> dict:
        return {
            "total": len(self.records),
            "completed": sum(1 for r in self.records.values() if r.status == "completed"),
            "failed": sum(1 for r in self.records.values() if r.status == "failed"),
            "started": sum(1 for r in self.records.values() if r.status == "started"),
        }


# ── 4. Safe agent tick wrapper ────────────────────────────────────────────────

def safe_agent_tick(agent: Any, tick: int, phase: Any,
                    population: List[Any], **kwargs) -> Optional[Any]:
    """
    Wraps agent.tick() in try/except. On failure: logs the error to
    agent._tick_errors, marks agent.alive = False to remove from population,
    and returns None. Never crashes the run.
    """
    try:
        return agent.tick(tick, phase, population, **kwargs)
    except Exception as exc:
        if not hasattr(agent, "_tick_errors"):
            agent._tick_errors = []
        agent._tick_errors.append({
            "tick": tick,
            "error": str(exc),
            "traceback": traceback.format_exc(),
        })
        # Mark dead so it's excluded from future ticks
        agent.alive = False
        return None


# ── 5. SmokeTest ──────────────────────────────────────────────────────────────

class SmokeTest:
    """
    Minimal regression suite. Runs the simulation under controlled conditions
    and asserts key invariants. Call from CLI with --test flag.
    """

    def __init__(self, run_sim_module: Any) -> None:
        self.mod = run_sim_module
        self.passed: List[str] = []
        self.failed: List[str] = []

    def _assert(self, name: str, condition: bool, detail: str = "") -> None:
        if condition:
            self.passed.append(name)
            print(f"  PASS: {name}")
        else:
            self.failed.append(name)
            print(f"  FAIL: {name}" + (f" — {detail}" if detail else ""))

    def run_all(self) -> bool:
        print("=== DAS Smoke Tests ===")
        self._test_smoke_1x120()
        self._test_3x300()
        self._test_compact_retention()
        self._test_no_crash_on_birth_death()
        self._print_summary()
        return len(self.failed) == 0

    def _run_sim(self, runs: int, ticks: int, retention: str = "full") -> Optional[dict]:
        import subprocess
        env = os.environ.copy()
        env["DAS_RUNS"]      = str(runs)
        env["DAS_TICKS"]     = str(ticks)
        env["DAS_RETENTION"] = retention
        env["DAS_OUTPUT_ROOT"] = "/tmp/das_smoketest"
        result = subprocess.run(
            [sys.executable, "run_sim.py"],
            capture_output=True, text=True, env=env, timeout=300,
            cwd=str(Path(__file__).parent),
        )
        return result

    def _test_smoke_1x120(self) -> None:
        print("\n[1] Smoke: 1 run × 120 ticks")
        r = self._run_sim(1, 120)
        self._assert("1x120 no crash", r.returncode == 0,
                     r.stderr[-300:] if r.returncode != 0 else "")
        self._assert("1x120 benchmark written",
                     any(Path("/tmp/das_smoketest").rglob("benchmark_*.json"))
                     or any(Path("/tmp/das_smoketest").rglob("summary.json")))

    def _test_3x300(self) -> None:
        print("\n[2] Regression: 3 runs × 300 ticks")
        r = self._run_sim(3, 300)
        self._assert("3x300 no crash", r.returncode == 0,
                     r.stderr[-300:] if r.returncode != 0 else "")

    def _test_compact_retention(self) -> None:
        print("\n[3] Compact retention mode")
        r = self._run_sim(1, 120, retention="compact")
        self._assert("compact no crash", r.returncode == 0,
                     r.stderr[-300:] if r.returncode != 0 else "")

    def _test_no_crash_on_birth_death(self) -> None:
        print("\n[4] Birth/death/reproduction stability (3x300)")
        r = self._run_sim(3, 300)
        self._assert("birth/death no crash", r.returncode == 0,
                     r.stderr[-300:] if r.returncode != 0 else "")
        # Check manifest exists and has completions
        manifest_files = list(Path("/tmp/das_smoketest").rglob("manifest.json"))
        self._assert("manifest written", len(manifest_files) > 0)

    def _print_summary(self) -> None:
        total = len(self.passed) + len(self.failed)
        print(f"\n=== {len(self.passed)}/{total} passed ===")
        if self.failed:
            print(f"FAILED: {', '.join(self.failed)}")
