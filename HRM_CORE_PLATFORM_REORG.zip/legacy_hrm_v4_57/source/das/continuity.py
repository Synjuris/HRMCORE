"""
continuity.py — v04.32 Continuity Engine

Turns agent events into durable historical continuity artifacts:
- life-history ledgers
- lineage summaries
- death-to-memory classifications
- cultural timeline
- civilization chronicle

This module is intentionally post-processing oriented. It reads completed run state
and event logs and writes observer-grade history artifacts without mutating the
simulation's causal state.
"""
from __future__ import annotations

import json
from collections import defaultdict, Counter
from pathlib import Path
from typing import Any, Dict, Iterable, List
from adaptive_roles import role_family

MAJOR_EVENT_TYPES = {
    "agent_death", "grief", "artifact", "deception", "interaction",
    "apprenticeship", "innovation", "governance", "information",
    "resource_action", "injury", "recovery", "post_deception_conflict_check",
}


def _safe_round(x, n=4):
    try:
        return round(float(x), n)
    except Exception:
        return x


def _agent_id(agent):
    return getattr(agent, "id", None)


def _agent_name(agent):
    return getattr(agent, "name", _agent_id(agent))


def _rel_snapshot(agent) -> Dict[str, Any]:
    rels = getattr(getattr(agent, "relationships", None), "_rels", {}) or {}
    out = {}
    for rid, r in rels.items():
        out[rid] = {
            "trust": _safe_round(getattr(r, "trust", 0.5)),
            "attachment": _safe_round(getattr(r, "attachment", 0.0)),
            "resentment": _safe_round(getattr(r, "resentment", 0.0)),
            "avoidance": _safe_round(getattr(r, "avoidance", 0.0)),
            "influence": _safe_round(getattr(r, "influence", 0.0)),
            "interactions": getattr(r, "interactions", 0),
        }
    return out


def _identity_tags(agent) -> List[str]:
    tags = []
    for attr in ("identity_tags", "identity", "psych_identity_tags"):
        val = getattr(agent, attr, None)
        if isinstance(val, (list, tuple, set)):
            tags.extend(str(x) for x in val)
        elif isinstance(val, dict):
            tags.extend(str(k) for k, v in val.items() if v)
    exp = getattr(agent, "experience", None)
    if exp is not None:
        # Read identity_tags already populated by psychology.py update_identity()
        exp_tags = getattr(exp, "identity_tags", []) or []
        tags.extend(str(t) for t in exp_tags)
        # Supplemental continuity-level tags derived from thresholds
        scar_val = getattr(exp, "scars", 0.0) or 0.0
        if scar_val >= 0.35:   # matches SCAR_IDENTITY_THRESHOLD in psychology.py
            tags.append("scarred_survivor")
        if len(getattr(exp, "bonds", {}) or {}) >= 3:
            tags.append("bonded_actor")
        if len(getattr(exp, "grudges", {}) or {}) >= 3:
            tags.append("grudge_carrier")
    if getattr(agent, "alive", False) is False:
        tags.append("dead")
    return sorted(set(tags))


def _classify_dead_memory(agent, agent_events: List[Dict[str, Any]], population: List[Any]) -> str:
    name = _agent_name(agent)
    conflicts = sum(1 for e in agent_events if e.get("outcome") == "conflict")
    coops = sum(1 for e in agent_events if e.get("outcome") == "cooperation")
    griefs = sum(1 for e in agent_events if e.get("event_type") == "grief" and name)
    artifacts = sum(1 for e in agent_events if e.get("event_type") == "artifact")
    role = getattr(getattr(agent, "traits", None), "role", "generalist")
    bond_mentions = 0
    for other in population:
        if _agent_id(other) == _agent_id(agent):
            continue
        rel = getattr(getattr(other, "relationships", None), "get", lambda _x: None)(_agent_id(agent))
        if rel and getattr(rel, "attachment", 0.0) > 0.35:
            bond_mentions += 1
    if artifacts >= 2 or role_family(role) in ("coordination", "diplomacy", "knowledge") and coops >= conflicts:
        return "founder_memory"
    if griefs >= 2 or bond_mentions >= 3:
        return "ancestor_memory"
    if conflicts >= max(3, coops * 2):
        return "cautionary_memory"
    if coops >= 5 and bond_mentions >= 1:
        return "honored_dead"
    return "forgotten_or_low_salience"


def _event_index(events: Iterable[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    idx = defaultdict(list)
    for e in events:
        ids = []
        if e.get("actor_id"):
            ids.append(e.get("actor_id"))
        ids.extend(e.get("participants") or [])
        for aid in set(ids):
            idx[aid].append(e)
    return idx


def _life_record(agent, events_for_agent: List[Dict[str, Any]], initial_agent_ids: set) -> Dict[str, Any]:
    state = getattr(agent, "state", None)
    traits = getattr(agent, "traits", None)
    exp = getattr(agent, "experience", None)
    parents = [getattr(p, "id", p) for p in getattr(agent, "parents", [])] or list(getattr(agent, "parent_ids", []) or [])
    major = [e for e in events_for_agent if e.get("event_type") in MAJOR_EVENT_TYPES or e.get("salience", 0) >= 0.6]
    major = sorted(major, key=lambda e: e.get("tick", 0))[-50:]
    return {
        "agent_id": _agent_id(agent),
        "name": _agent_name(agent),
        "generation": getattr(agent, "generation", 0),
        "born_in_initial_seed": _agent_id(agent) in initial_agent_ids,
        "birth_tick": getattr(agent, "birth_tick", 0 if _agent_id(agent) in initial_agent_ids else None),
        "parents": parents,
        "alive": bool(getattr(agent, "alive", False)),
        "death_cause": getattr(agent, "_death_cause", None) if not getattr(agent, "alive", False) else None,
        "final_state": {k: _safe_round(getattr(state, k)) for k in vars(state)} if state else {},
        "developmental_traits": {k: _safe_round(getattr(traits, k)) for k in vars(traits)} if traits else {},
        "identity_tags": _identity_tags(agent),
        "scar_load": round(getattr(exp, "scars", 0.0) or 0.0, 4) if exp else 0.0,
        "bond_count": len(getattr(exp, "bonds", {}) or {}) if exp else 0,
        "grudge_count": len(getattr(exp, "grudges", {}) or {}) if exp else 0,
        "relationships": _rel_snapshot(agent),
        "major_events": major,
    }


def _lineages(agents: List[Any], records: List[Dict[str, Any]]) -> Dict[str, Any]:
    by_id = {r["agent_id"]: r for r in records}
    children = defaultdict(list)
    roots = []
    for r in records:
        parents = [p for p in r.get("parents", []) if p]
        if not parents:
            roots.append(r["agent_id"])
        for p in parents:
            children[p].append(r["agent_id"])
    families = []
    for root in roots:
        stack = [root]
        descendants = []
        while stack:
            cur = stack.pop()
            for ch in children.get(cur, []):
                descendants.append(ch); stack.append(ch)
        families.append({
            "root_agent_id": root,
            "root_name": by_id.get(root, {}).get("name"),
            "descendant_count": len(descendants),
            "living_descendants": sum(1 for d in descendants if by_id.get(d, {}).get("alive")),
            "descendants": descendants,
        })
    return {
        "family_count": len(families),
        "families": sorted(families, key=lambda x: x["descendant_count"], reverse=True),
        "parent_child_edges": sum(len(v) for v in children.values()),
    }


def _culture_timeline(events: List[Dict[str, Any]], culture_pool=None, faction_registry=None) -> Dict[str, Any]:
    by_tick = defaultdict(list)
    for e in events:
        et = e.get("event_type")
        if et in ("artifact", "apprenticeship", "innovation", "governance", "information", "grief", "agent_death", "oral_tradition_transmission", "cultural_memory_transmission"):
            by_tick[e.get("tick", 0)].append({
                "event_type": et,
                "actor_id": e.get("actor_id"),
                "participants": e.get("participants", []),
                "outcome": e.get("outcome"),
                "context": e.get("context", {}),
            })
    meme_snapshot = culture_pool.snapshot() if culture_pool and hasattr(culture_pool, "snapshot") else {}
    faction_snapshot = faction_registry.snapshot() if faction_registry and hasattr(faction_registry, "snapshot") else []
    return {
        "timeline": [{"tick": t, "events": by_tick[t]} for t in sorted(by_tick)],
        "culture_snapshot": meme_snapshot,
        "faction_snapshot": faction_snapshot,
        "counts": dict(Counter(e.get("event_type") for e in events)),
        "conflict_count": sum(1 for e in events if e.get("outcome") == "conflict"),
        "interaction_count": sum(1 for e in events if e.get("event_type") == "interaction"),
    }


def _chronicle(records, lineage, memory, culture_timeline) -> str:
    living = [r for r in records if r["alive"]]
    dead = [r for r in records if not r["alive"]]
    generations = sorted(set(r.get("generation", 0) for r in records))
    top_family = lineage.get("families", [{}])[0] if lineage.get("families") else {}
    memory_counts = Counter(m["memory_class"] for m in memory)
    tl = culture_timeline.get("timeline", [])
    memes = culture_timeline.get("culture_snapshot", {}).get("meme_list", [])
    counts = culture_timeline.get("counts", {})

    lines = []
    lines.append("# Civilization Chronicle")
    lines.append("")

    # Population summary
    lines.append(f"## Population")
    lines.append(f"{len(records)} individuals recorded across {len(generations)} generation(s). "
                 f"{len(living)} survive; {len(dead)} have died.")
    if top_family:
        root = top_family.get("root_name", "unknown")
        desc = top_family.get("descendant_count", 0)
        lines.append(f"The largest lineage descends from {root}, with {desc} recorded descendant(s).")
    lines.append("")

    # Deaths
    if dead:
        causes = Counter(m.get("death_cause", "unknown") for m in memory)
        cause_str = ", ".join(f"{c} to {v}" for v, c in causes.most_common(3))
        lines.append(f"## Deaths")
        lines.append(f"Of those who died: {cause_str}.")
        if memory_counts:
            mc_str = ", ".join(f"{v} classified as {k}" for k, v in memory_counts.most_common())
            lines.append(f"Memory classification: {mc_str}.")
        lines.append("")

    # Key events from timeline
    if tl:
        lines.append("## History")
        # Flatten timeline into (tick, event) pairs
        flat_events = [(entry["tick"], e) for entry in tl for e in entry["events"]]

        deaths = [(tick, e["actor_id"]) for tick, e in flat_events if e["event_type"] == "agent_death"]
        innovations = [(tick, e["actor_id"]) for tick, e in flat_events if e["event_type"] == "innovation"]
        grief_events = [(tick, e["actor_id"]) for tick, e in flat_events if e["event_type"] == "grief"]
        artifacts = [(tick, e["actor_id"]) for tick, e in flat_events if e["event_type"] == "artifact"]
        apprenticeships = [(tick, e["actor_id"]) for tick, e in flat_events if e["event_type"] == "apprenticeship"]
        stories = [(tick, e["actor_id"]) for tick, e in flat_events if "oral" in e["event_type"] or "story" in e["event_type"]]

        # Build name lookup
        name_map = {r.get("id", ""): r.get("name", "unknown") for r in records}

        if apprenticeships:
            lines.append(f"Knowledge transfer began early: {len(apprenticeships)} apprenticeship event(s) recorded.")

        if innovations:
            lines.append(f"{len(innovations)} innovations emerged across the run. "
                         f"First at tick {innovations[0][0]}, last at tick {innovations[-1][0]}.")

        if artifacts:
            lines.append(f"{len(artifacts)} cultural artifact(s) created.")

        if deaths:
            first_tick, first_id = deaths[0]
            first_name = name_map.get(first_id, first_id[:8])
            lines.append(f"The first death came at tick {first_tick} ({first_name}). "
                         f"{len(grief_events)} grief response(s) followed across all deaths.")

        if stories:
            lines.append(f"Oral tradition transmitted {len(stories)} time(s), carrying memory between individuals.")

        lines.append("")

    # Cultural state
    if memes:
        lines.append("## Culture")
        dominant = sorted(memes, key=lambda m: m.get("strength", 0), reverse=True)
        for m in dominant[:3]:
            label = m.get("label", "unknown")
            strength = m.get("strength", 0)
            carriers = m.get("carriers", 0)
            valence = m.get("valence", 0)
            tone = "prosocial" if valence > 0 else "antisocial"
            lines.append(f"'{label}' ({tone}, strength {strength:.3f}) carried by {carriers} individual(s).")
        lines.append("")

    # Interaction texture
    interactions = culture_timeline.get("interaction_count", counts.get("interaction", 0))
    conflicts = culture_timeline.get("conflict_count", 0)
    if not conflicts:
        flat_all = [(entry["tick"], e) for entry in tl for e in entry["events"]]
        conflicts = sum(1 for _, e in flat_all if e.get("event_type") == "conflict" or e.get("outcome") == "conflict")
    if interactions:
        conflict_rate = round(conflicts / interactions * 100, 1)
        lines.append("## Social Texture")
        lines.append(f"{interactions} interactions recorded. Conflict rate: {conflict_rate}%.")
        lines.append("")

    lines.append("*Chronicle generated from recorded simulation events and final agent state. No external history invented.*")
    return "\n".join(lines)


def build_continuity_outputs(output_dir, agents, event_log, initial_agent_ids=None, culture_pool=None, faction_registry=None, generational_ledger=None) -> Dict[str, Any]:
    output_dir = Path(output_dir)
    cdir = output_dir / "continuity"
    cdir.mkdir(parents=True, exist_ok=True)
    initial_agent_ids = set(initial_agent_ids or [])
    idx = _event_index(event_log)
    records = [_life_record(a, idx.get(_agent_id(a), []), initial_agent_ids) for a in agents]
    lineage = _lineages(agents, records)
    memory = []
    for a in agents:
        if not getattr(a, "alive", False):
            ae = idx.get(_agent_id(a), [])
            memory.append({
                "agent_id": _agent_id(a),
                "name": _agent_name(a),
                "memory_class": _classify_dead_memory(a, ae, agents),
                "death_cause": getattr(a, "_death_cause", "unknown"),
                "event_count": len(ae),
            })
    culture = _culture_timeline(event_log, culture_pool, faction_registry)
    chronicle = _chronicle(records, lineage, memory, culture)
    (cdir / "life_history_ledger.json").write_text(json.dumps(records, indent=2, default=str), encoding="utf-8")
    (cdir / "lineages.json").write_text(json.dumps(lineage, indent=2, default=str), encoding="utf-8")
    (cdir / "death_memory.json").write_text(json.dumps(memory, indent=2, default=str), encoding="utf-8")
    (cdir / "culture_timeline.json").write_text(json.dumps(culture, indent=2, default=str), encoding="utf-8")
    (cdir / "civilization_chronicle.md").write_text(chronicle, encoding="utf-8")
    return {
        "continuity_records": len(records),
        "continuity_family_count": lineage.get("family_count", 0),
        "continuity_parent_child_edges": lineage.get("parent_child_edges", 0),
        "continuity_dead_memory_records": len(memory),
        "continuity_cultural_timeline_ticks": len(culture.get("timeline", [])),
    }
