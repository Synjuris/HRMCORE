import json, traceback
from pathlib import Path

def write(output_dir, **data):
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    (Path(output_dir)/'run_manifest_start.json').write_text(json.dumps(data, indent=2, default=str), encoding='utf-8')
