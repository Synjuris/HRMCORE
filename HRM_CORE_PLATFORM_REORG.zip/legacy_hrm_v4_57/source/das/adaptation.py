from schemas import AgentState, DevelopmentalTraits


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def apply_environment_to_state(state: AgentState, traits: DevelopmentalTraits, env) -> None:
    pressure_gain = (
        env.stress_load * (0.45 + traits.conflict_sensitivity * 0.20)
        + env.scarcity * 0.025
        + env.conflict_pressure * 0.035
    )

    recovery_gain = env.rest_quality * traits.recovery_speed * (0.80 + traits.resilience * 0.35)

    state.stress = clamp(state.stress + pressure_gain - recovery_gain)

    state.energy = clamp(
        state.energy
        - env.stress_load * 0.06
        - env.scarcity * 0.04
        - state.stress * 0.015
        + env.rest_quality * 0.08
    )

    state.curiosity = clamp(state.curiosity + env.novelty * 0.05 - state.fear * 0.02)

    state.fear = clamp(
        state.fear
        + env.conflict_pressure * traits.conflict_sensitivity * 0.035
        + max(0.0, state.stress - 0.70) * 0.025
        - env.rest_quality * 0.035
    )

    state.social_openness = clamp(
        state.social_openness
        + env.social_density * 0.012
        + state.cooperation * 0.008
        - state.fear * 0.025
        - max(0.0, state.stress - 0.65) * 0.04
    )


def irreversible_update(state: AgentState, traits: DevelopmentalTraits) -> None:
    if state.stress > traits.stress_limit * 0.85:
        traits.conflict_sensitivity = clamp(traits.conflict_sensitivity + 0.002)
        traits.risk_tolerance = clamp(traits.risk_tolerance - 0.0015)
        traits.recovery_speed = clamp(traits.recovery_speed - 0.0003, 0.015, 0.20)
        traits.resilience = clamp(traits.resilience - 0.001)

    if state.stability > 0.70 and state.stress < 0.35:
        traits.recovery_speed = clamp(traits.recovery_speed + 0.0006, 0.015, 0.20)
        traits.risk_tolerance = clamp(traits.risk_tolerance + 0.0003)
        traits.resilience = clamp(traits.resilience + 0.0008)

    state.stability = clamp(1.0 - state.stress * 0.70 + state.energy * 0.25 - state.fear * 0.15)
