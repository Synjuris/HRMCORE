from dataclasses import dataclass, asdict

@dataclass
class Vacancy:
    vacancy_type: str='social_role'

@dataclass
class DeathRecord:
    agent_id: str
    name: str
    tick: int
    cause: str
    social_residue: list
    systemic_impact: float
    vacancy: Vacancy|None=None

def build_death_record(agent, population=None, tick=0, cause='unknown', faction_registry=None, all_agents=None, events_so_far=None, archetype_label=None, **kwargs):
    population = population if population is not None else (all_agents or [])
    residue=[]
    for other in population:
        if getattr(other,'id',None)==agent.id or not getattr(other,'alive',False): continue
        rel=getattr(other,'relationships',None).get(agent.id) if hasattr(other,'relationships') else None
        strength=(getattr(rel,'trust',0.5)+getattr(rel,'attachment',0.0)+getattr(rel,'influence',0.0))/3 if rel else 0
        if strength>0.2: residue.append({'survivor_id':other.id,'strength':round(strength,4)})
    return DeathRecord(agent.id, getattr(agent,'name',agent.id), tick, cause, residue, round(min(1.0,len(residue)/10),4), Vacancy())

class DeathLedger:
    def __init__(self): self.deaths=[]
    def record(self, record): self.deaths.append(record)
    def write(self, output_dir):
        import json
        from pathlib import Path
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        (Path(output_dir)/'deaths.json').write_text(json.dumps([asdict(d) for d in self.deaths], indent=2), encoding='utf-8')
    def summary(self):
        return {'deaths':len(self.deaths),'total_deaths':len(self.deaths),'first_death_tick':min([d.tick for d in self.deaths], default=None),'avg_systemic_impact':round(sum(d.systemic_impact for d in self.deaths)/len(self.deaths),4) if self.deaths else 0.0}
