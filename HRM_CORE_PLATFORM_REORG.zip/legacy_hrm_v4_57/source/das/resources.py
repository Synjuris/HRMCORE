from schemas import ResourceNode, new_id

def clamp(x, lo=0.0, hi=1.0): return max(lo, min(hi, x))

class ResourceWorld:
    def __init__(self, width=12, height=12, n_nodes=20, rng=None):
        self.width=width; self.height=height; self.rng=rng; self.logistics_world=None
        rng = rng or __import__('random').Random(0)
        self.nodes=[ResourceNode(id=new_id('res'), x=rng.randrange(width), y=rng.randrange(height), stock=rng.uniform(.35,1.0), regen_rate=rng.uniform(.005,.03)) for _ in range(n_nodes)]
    def tick_regen(self):
        for n in self.nodes: n.stock=clamp(n.stock+n.regen_rate)
    def _near(self,pos):
        return [n for n in self.nodes if abs(n.x-pos.x)+abs(n.y-pos.y)<=1 and n.stock>0.02]
    def harvest(self, agent, position):
        near=self._near(position)
        if not near: return 0.0
        n=max(near,key=lambda x:x.stock)
        amt=min(n.stock, 0.05+agent.state.curiosity*0.05)
        n.stock-=amt; agent.state.resource_stock=clamp(agent.state.resource_stock+amt); agent.state.hunger=clamp(agent.state.hunger-amt*.7)
        return round(amt,4)
    def consume(self, agent):
        need=0.018+getattr(agent.state,'care_burden',0)*0.01
        if agent.state.resource_stock>=need:
            agent.state.resource_stock=clamp(agent.state.resource_stock-need); agent.state.hunger=clamp(agent.state.hunger-0.01)
        else:
            agent.state.hunger=clamp(agent.state.hunger+0.035); agent.state.stress=clamp(agent.state.stress+0.01)
