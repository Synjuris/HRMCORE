"""
Reproduction / Generational Inheritance — Layer 10
Agents can reproduce when:
  - both are alive, allied, and high-energy/low-stress
  - population is below capacity
Offspring inherit blended traits with mutation noise.
Dead agents are pruned; offspring take their slot.
Generational fitness is tracked as a running composite.
"""
import random
from typing import List, Optional
from schemas import DevelopmentalTraits, AgentState, new_id
import biology as biology_mod
import generational_psychology as genpsych_mod


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


REPRODUCE_ENERGY_MIN = 0.10
REPRODUCE_STRESS_MAX = 0.88
REPRODUCE_CHANCE = 0.520
MUTATION_SCALE = 0.04
MAX_POPULATION = 50
REPRODUCTION_COST = 0.045   # energy lost by parent


def compute_fitness(state: AgentState) -> float:
    return clamp(
        state.energy * 0.35
        + (1.0 - state.stress) * 0.25
        + state.stability * 0.20
        + state.cooperation * 0.10
        + state.resource_stock * 0.10
    )


def blend_traits(a: DevelopmentalTraits, b: DevelopmentalTraits,
                 rng: random.Random) -> DevelopmentalTraits:
    """Blend two trait objects with mutation noise."""
    def inherit(va, vb):
        w = rng.random()
        base = va * w + vb * (1 - w)
        noise = rng.gauss(0, MUTATION_SCALE)
        return clamp(base + noise)

    role_pool = [a.role, b.role]
    child_role = rng.choice(role_pool)

    return DevelopmentalTraits(
        stress_limit=      clamp(inherit(a.stress_limit,      b.stress_limit),      0.50, 1.00),
        recovery_speed=    clamp(inherit(a.recovery_speed,    b.recovery_speed),    0.01, 0.20),
        trust_baseline=    inherit(a.trust_baseline,    b.trust_baseline),
        conflict_sensitivity=inherit(a.conflict_sensitivity, b.conflict_sensitivity),
        risk_tolerance=    inherit(a.risk_tolerance,    b.risk_tolerance),
        attachment_rate=   clamp(inherit(a.attachment_rate,   b.attachment_rate),   0.01, 0.15),
        avoidance_rate=    clamp(inherit(a.avoidance_rate,    b.avoidance_rate),    0.01, 0.15),
        resilience=        inherit(a.resilience,        b.resilience),
        role=              child_role,
        generational_fitness=0.50,
        language_aptitude= inherit(a.language_aptitude, b.language_aptitude),
        ideology_sensitivity= inherit(getattr(a, "ideology_sensitivity", 0.5), getattr(b, "ideology_sensitivity", 0.5)),
    )


class ReproductionSystem:
    def __init__(self, max_population: int = MAX_POPULATION) -> None:
        self.max_population = max_population
        self.generation: int = 0
        self.total_births: int = 0

    def tick(self, agents: list, spatial_world, faction_registry,
             culture_pool, rng: random.Random, genpsych_ledger=None, tick: int = 0,
             eco_health: float = 0.5) -> list:
        """
        Returns list of new Agent objects born this tick.
        Caller is responsible for appending them to the population.
        """
        from agent import Agent

        living = [a for a in agents if a.alive]
        if len(living) >= self.max_population:
            return []

        new_agents = []
        paired = set()

        for agent in living:
            if agent.id in paired:
                continue
            if (agent.state.energy < REPRODUCE_ENERGY_MIN
                    or agent.state.stress > REPRODUCE_STRESS_MAX
                    or getattr(agent, "libido", 0.0) < 0.035):
                continue
            # v04.38: reproduction probability now depends on the biology layer
            # instead of bypassing it.  The chance remains bounded so small
            # founder groups can reproduce, but zero-libido agents no longer
            # produce births as if libido did not exist.
            libido_factor = clamp(getattr(agent, "libido", 0.0) * 1.35, 0.0, 1.0)
            # v04.43: environmental health modulates reproduction chance.
            # Good conditions (spring, abundance) amplify; winter/scarcity suppress.
            # Floor at 0.4 so reproduction never fully stops even in bad conditions.
            eco_mult = clamp(0.40 + eco_health * 0.60)
            if rng.random() > REPRODUCE_CHANCE * (0.62 + libido_factor) * eco_mult:
                continue
            # Find allied partner
            partner = self._find_partner(agent, living, paired, faction_registry)
            if partner is None:
                continue

            # Fitness update for parents
            agent.traits.generational_fitness = clamp(
                agent.traits.generational_fitness * 0.8 + compute_fitness(agent.state) * 0.2
            )
            partner.traits.generational_fitness = clamp(
                partner.traits.generational_fitness * 0.8 + compute_fitness(partner.state) * 0.2
            )

            # Reproduction cost
            agent.state.energy = clamp(agent.state.energy - REPRODUCTION_COST)
            partner.state.energy = clamp(partner.state.energy - REPRODUCTION_COST * 0.5)

            child_seed = rng.randint(0, 999999)
            child_name = f"Gen{self.generation+1}_{new_id('child').replace('child_', '')[:6]}"
            child = Agent(child_name, seed=child_seed, spatial_world=spatial_world)
            # Newborns must not inherit founder maturity.
            child.state.age = 0
            child.state.energy = max(child.state.energy, 0.52)
            child.state.resource_stock = max(child.state.resource_stock, 0.36)
            child.state.stress = min(child.state.stress, 0.18)
            child.state.safety = max(child.state.safety, 0.70)
            child.libido = 0.0

            # Override traits with inheritance
            child.traits = blend_traits(agent.traits, partner.traits, rng)
            # v04.35: parent history biases child baselines probabilistically.
            # This is not trait-copying; it bends developmental starting ranges.
            genpsych_mod.apply_birth_transmission(child, [agent, partner], tick, rng, genpsych_ledger)
            child.position.x = agent.position.x
            child.position.y = agent.position.y
            child._birth_parents = [agent, partner]
            biology_mod.on_reproduction(agent, partner, child, rng)
            # v04.40: small-population demographic viability guard. This does
            # not force mating outcomes; it prevents all-child cohorts from
            # drifting into a one-sex dead end before multi-generation dynamics
            # can appear.
            current_living = [x for x in agents if getattr(x, "alive", False)]
            males = sum(1 for x in current_living if getattr(x, "biological_sex", None) == "male")
            females = sum(1 for x in current_living if getattr(x, "biological_sex", None) == "female")
            if males == 0:
                child.biological_sex = "male"
            elif females == 0:
                child.biological_sex = "female"
            elif len(current_living) < 8 and abs(males - females) >= 3:
                child.biological_sex = "female" if males > females else "male"

            # Seed culture
            culture_pool.seed_agent(child.id, rng)

            # Inherit faction
            parent_faction = faction_registry.faction_of(agent.id)
            if parent_faction:
                parent_faction.members.append(child.id)
                faction_registry._agent_faction[child.id] = parent_faction.id

            paired.add(agent.id)
            paired.add(partner.id)
            new_agents.append(child)
            self.total_births += 1

        if new_agents:
            self.generation += 1

        return new_agents

    def _find_partner(self, agent, living: list, paired: set,
                      faction_registry) -> Optional[object]:
        candidates = []
        for other in living:
            if other.id == agent.id or other.id in paired:
                continue
            if other.state.energy < REPRODUCE_ENERGY_MIN or other.state.stress > REPRODUCE_STRESS_MAX or getattr(other, "libido", 0.0) < 0.035:
                continue
            # Biological reproduction requires opposite sex
            if not biology_mod.is_reproduction_viable(agent, other):
                continue
            rel = agent.relationships.get(other.id)
            same_faction = faction_registry.same_faction(agent.id, other.id)
            # v04.4: lower same-faction attachment gate 0.25→0.12 to fix
            # fragmented-faction seeds (e.g. run 3) where agents never get
            # enough same-faction face-time to accumulate attachment > 0.25.
            # Cross-faction gate unchanged (trust>0.78, attach>0.42).
            if same_faction and rel.trust > 0.32 and rel.attachment > 0.035:
                candidates.append(other)
            elif rel.trust > 0.37 and rel.attachment > 0.045:
                candidates.append(other)
        candidates.sort(key=lambda other: (agent.relationships.get(other.id).trust, agent.relationships.get(other.id).attachment), reverse=True)
        return candidates[0] if candidates else None

    def snapshot(self) -> dict:
        return {
            "generation": self.generation,
            "total_births": self.total_births,
        }
