"""
run_kernel_exp_A.py — Experiment A through the kernel runtime.

Thin wrapper. No simulation logic here.
Config: configs/exp_A.json
Runtime: kernel/runtime.py
Setup:   kernel/experiment_setup.py

Usage:
    python run_kernel_exp_A.py
    python run_kernel_exp_A.py --ticks 1000
    python run_kernel_exp_A.py --output /tmp/my_run
    python run_kernel_exp_A.py --config configs/exp_A.json
"""

import sys, argparse
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from kernel import (
    HRMRuntime, KernelConfig,
    register_standard_subsystems, setup_groups,
)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/exp_A.json")
    parser.add_argument("--ticks",  type=int, default=None)
    parser.add_argument("--output", default=None)
    args = parser.parse_args()

    cfg = KernelConfig.from_json(args.config)
    if args.ticks:  cfg.ticks = args.ticks
    if args.output: cfg.output_root = args.output

    print(f"EXPERIMENT A (kernel) — {cfg.ticks} ticks → {cfg.output_root}")

    rt = HRMRuntime(cfg)
    rt.build_world()
    register_standard_subsystems(rt)
    setup_groups(rt)

    import json as _json
    out = cfg.output_path / "run_1"
    out.mkdir(parents=True, exist_ok=True)
    (out / "agents_initial.json").write_text(
        _json.dumps([a.snapshot() for a in rt.agents], indent=2), encoding="utf-8")

    rt.registry.freeze()
    print(f"\nSystem registry:\n{rt.registry.summary()}\n")
    rt.run(start_tick=1)

    living = [a for a in rt.agents if a.alive]
    n_int  = max(rt._counters.interaction_total, 1)
    print(f"\n{'='*60}")
    print(f"  FINAL: {len(living)} alive after {cfg.ticks} ticks")
    print(f"  Total ever: {len(rt.agents)}")
    print(f"  Max gen: Gen{max((a.generation for a in living), default=0)}")
    print(f"  Conflict rate: {100*rt._counters.conflict_total/n_int:.2f}%")
    print(f"  Deaths: {len(rt.ledger.deaths)}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
