"""
run_exp_E_resume.py — True reproducible continuation harness for Experiment E.

Distinction:
  RESUME  = exact continuation (same RNG stream, tick counter, world state)
  RESEED  = new run seeded from old population (what a naive resume does)

This script is a RESUME. It restores:
  - tick counter
  - RNG state (per-agent and global)
  - agent state (full: psychology, relationships, memory, biology, development)
  - faction membership + hostility matrix
  - culture pool (all memes, not just top N)
  - innovation registry (all practices, not just top 10)
  - governance (leader records, legitimacy, gap state)
  - zone ecology (fauna pools per zone, seasonal state)
  - generational ledger (birth records, household events)
  - group map
  - death ledger
  - config hash (validates against original run)
  - session history (tracks which sessions ran which tick ranges)

On Ctrl+C or tick limit: saves full checkpoint, appends session record to manifest.

Usage:
    python run_exp_E_resume.py
    python run_exp_E_resume.py --from /tmp/hrm_exp_E_1k/run_1
    python run_exp_E_resume.py --ticks 2000
    python run_exp_E_resume.py --snap-every 250
"""

import sys, json, random, math, argparse, signal, hashlib, time
from pathlib import Path
from dataclasses import asdict as _asdict
sys.path.insert(0, str(Path(__file__).parent))

from agent import Agent
from environment import EnvironmentCycle
from metrics import population_metrics
from space import SpatialWorld
from resources import ResourceWorld
from factions import FactionRegistry
from territory import TerritoryMap
from institutions import InstitutionRegistry
from culture import CulturePool
from reproduction import ReproductionSystem
from language import WorldNarrative
from experiential import TextureChronicle
import attractor as attractor_mod
import salience as salience_mod
import psychology as psychology_mod
import continuity as continuity_mod
from checkpoint import CheckpointWriter
from death_ledger import DeathLedger, build_death_record, DeathRecord, Vacancy
from persistence import PersistenceLedger
from constraints import ConstraintLedger
from generational import GenerationalLedger, apply_tick as apply_generational_tick, assign_child_context, init_agent as init_generational_agent
from apprenticeship import ApprenticeshipLedger, apply_tick as apply_apprenticeship_tick, init_agent as init_apprenticeship_agent
from logistics import LogisticsWorld
import biology as biology_mod
from innovation import InnovationEngine, apply_tick as apply_innovation_tick, init_agent as init_innovation_agent, PracticeRecord
from harness import EventStream, RollingCounters, safe_agent_tick
from information import InformationLedger, apply_tick as apply_information_tick, init_agent as init_information_agent
from governance import GovernanceLedger, apply_tick as apply_governance_tick, init_agent as init_governance_agent
from subsistence import SubsistenceWorld
from generational_psychology import GenerationalPsychologyLedger, apply_storykeeper_transmission, apply_targeted_care_recovery
from institutional_memory import InstitutionalMemoryLedger, apply_institutional_memory_tick
from social_viability import apply_population_viability_tick
from settlements import SettlementLedger
from ecological_context import ecological_health as _eco_health_fn
import life_events as life_events_mod
from epochs import detect_epochs, summarize_epochs
from spatial_zone import ZoneGrid
from spatial_memory import SpatialMemory
from movement_goals import init_agent_movement
from resource_transfer import apply_resource_transfers
from schemas import Meme

# ── Config ────────────────────────────────────────────────────────────────────
DEFAULT_PRIOR_DIR = Path("/tmp/hrm_exp_E_1k/run_1")
SEED        = 23
WORLD_W, WORLD_H = 40, 40
MAX_POP     = 140

CONFIG = {
    "seed": SEED, "world_w": WORLD_W, "world_h": WORLD_H,
    "max_pop": MAX_POP, "script": "run_exp_E_resume.py", "version": "1.0",
}
CONFIG_HASH = hashlib.sha256(json.dumps(CONFIG, sort_keys=True).encode()).hexdigest()[:12]

# ── Shutdown ──────────────────────────────────────────────────────────────────
_stop_requested = False
def _handle_sigint(sig, frame):
    global _stop_requested
    print("\n\n  [Ctrl+C] Finishing this tick then saving cleanly...")
    _stop_requested = True
signal.signal(signal.SIGINT, _handle_sigint)

# ── Helpers ───────────────────────────────────────────────────────────────────
def serialize_event(ev):
    if hasattr(ev, '__dict__'):
        d = ev.__dict__.copy()
        d['phase'] = getattr(ev, 'phase', getattr(ev, 'phase_name', ''))
        for k, v in list(d.items()):
            if hasattr(v, '__dict__'):
                d[k] = v.__dict__
        return d
    return dict(ev)

def init_spatial_for_agent(a, zone_grid):
    x = getattr(a.position, 'x', 20.0)
    y = getattr(a.position, 'y', 20.0)
    zid = zone_grid.zone_id_for_position(x, y)
    init_agent_movement(a, zid)
    if a.spatial_memory is None:
        a.spatial_memory = SpatialMemory()

# ── Full checkpoint save ──────────────────────────────────────────────────────
def save_full_checkpoint(tick, output_dir, agents, agent_group, ledger,
                         culture_pool, innovation_engine, governance_ledger,
                         generational_ledger, zone_grid, faction_registry,
                         global_rng, metric_log, session_start_tick):
    """Write a complete restorable checkpoint."""
    cp = {
        "format": "hrm_exp_E_full_checkpoint_v1",
        "config_hash": CONFIG_HASH,
        "tick": tick,
        "session_start_tick": session_start_tick,
        "saved_at": time.time(),

        # RNG state — global seed-derived RNG
        "global_rng_state": [
            global_rng.getstate()[0],
            list(global_rng.getstate()[1]),
            global_rng.getstate()[2],
        ],

        # Per-agent RNG states
        "agent_rng_states": {
            a.id: [a.rng.getstate()[0], list(a.rng.getstate()[1]), a.rng.getstate()[2]]
            for a in agents if hasattr(a, 'rng') and a.rng is not None
        },

        # Full agent snapshots
        "agents": [a.snapshot() for a in agents],

        # Group membership
        "group_map": agent_group,

        # Faction state — full membership + hostility matrix
        "factions": [
            {
                "id": f.id, "name": f.name,
                "members": list(getattr(f, 'members', set())),
                "hostility": {k: round(v, 6) for k, v in getattr(f, 'hostility', {}).items()},
                "leader_id": getattr(f, 'leader_id', None),
            }
            for f in faction_registry.factions.values()
        ] if hasattr(faction_registry, 'factions') else [],

        # Full culture — all memes
        "culture": {
            "memes": [
                {
                    "id": m.id, "label": m.label, "valence": m.valence,
                    "spread_rate": m.spread_rate, "strength": round(m.strength, 6),
                    "origin_tick": m.origin_tick,
                }
                for m in culture_pool.memes.values()
            ],
            "agent_memes": {
                aid: list(mids)
                for aid, mids in (culture_pool._agent_memes.items()
                                  if hasattr(culture_pool, '_agent_memes') else {}.items())
            },
        },

        # Full innovation registry — all practices, not top 10
        "innovation": {
            "summary": {
                "total_attempts": innovation_engine.total_attempts,
                "total_successes": innovation_engine.total_successes,
                "total_diffusions": getattr(innovation_engine, 'total_diffusions', 0),
                "total_institutional_adoptions": getattr(innovation_engine, 'total_institutional_adoptions', 0),
            },
            "practice_registry": {
                name: {
                    "name": p.name, "domain": p.domain,
                    "utility_score": round(p.utility_score, 6),
                    "fidelity": round(p.fidelity, 6),
                    "origin_agent_id": p.origin_agent_id,
                    "origin_tick": p.origin_tick,
                    "attempts": p.attempts, "successes": p.successes,
                    "diffusion_count": p.diffusion_count,
                    "institutional_adoptions": p.institutional_adoptions,
                    "tags": p.tags,
                }
                for name, p in innovation_engine.practice_registry.items()
            },
        },

        # Governance — leader records
        "governance": {
            "total_successions": governance_ledger.total_successions,
            "total_compliance": governance_ledger.total_compliance,
            "total_defiance": governance_ledger.total_defiance,
            "leaders": {
                fid: {
                    "leader_id": rec.leader_id,
                    "legitimacy": round(rec.legitimacy, 6),
                    "ticks_in_power": getattr(rec, 'ticks_in_power', 0),
                    "in_governance_gap": getattr(rec, 'in_governance_gap', False),
                }
                for fid, rec in governance_ledger.leaders.items()
            },
        },

        # Zone ecology: not saved (FaunaPopulation objects not directly serializable;
        # reinitializes deterministically from seed on resume)
        # "zone_ecology": zone_grid.snapshot(),

        # Generational ledger summary
        "generational": {
            "birth_count": len(generational_ledger.birth_records),
            "household_count": len(generational_ledger.household_events),
        },

        # Death ledger
        "deaths": [
            _asdict(d) if hasattr(d, '__dataclass_fields__') else d
            for d in ledger.deaths
        ],

        # Latest metric row for continuity
        "last_metric_row": metric_log[-1] if metric_log else {},
    }

    cp_path = output_dir / f"checkpoint_full_{tick:06d}.json"
    cp_path.write_text(json.dumps(cp, indent=2), encoding="utf-8")
    print(f"  [checkpoint_full saved: tick {tick}, {len(agents)} agents, "
          f"{len(innovation_engine.practice_registry)} practices]")
    return cp_path

# ── Manifest ──────────────────────────────────────────────────────────────────
def load_manifest(output_dir):
    mp = output_dir / "run_manifest.json"
    if mp.exists():
        return json.loads(mp.read_text())
    return {"config_hash": None, "sessions": [], "format": "hrm_exp_E_manifest_v1"}

def save_manifest(output_dir, manifest, tick_start, tick_end, notes=""):
    manifest["config_hash"] = CONFIG_HASH
    manifest["sessions"].append({
        "started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "tick_start": tick_start,
        "tick_end": tick_end,
        "script": "run_exp_E_resume.py",
        "notes": notes,
    })
    (output_dir / "run_manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8")

# ── Snapshot report ───────────────────────────────────────────────────────────
def snapshot_report(tick, agents, ledger, culture_pool, faction_registry,
                    innovation_engine, counters, agent_group, session_start_tick):
    living = [a for a in agents if a.alive]
    top3 = sorted(living, key=lambda a: a.state.age, reverse=True)[:3]
    memes = sorted(culture_pool.memes.values(), key=lambda m: m.strength, reverse=True)[:4]
    meme_str = " | ".join(
        f"{m.label} ({'+' if m.valence>=0 else ''}{m.valence:.1f},{m.strength:.2f})"
        for m in memes)
    groups = {}
    for a in living:
        g = agent_group.get(a.id, '?')
        groups[g] = groups.get(g, 0) + 1
    innov = innovation_engine.snapshot().get('summary', {})
    total = counters.snapshot()
    n_int = max(total.get('interactions', 1), 1)
    n_con = total.get('conflicts', 0)

    print(f"\n{'='*60}")
    print(f"  TICK {tick}  (session +{tick - session_start_tick})")
    print(f"{'='*60}")
    print(f"  Population  : {len(living)} alive / {len(agents)} total")
    print(f"  Max gen     : Gen{max((a.generation for a in agents), default=0)}")
    print(f"  Deaths      : {len(ledger.deaths)}")
    for g, n in sorted(groups.items()):
        print(f"  Group {g}     : {n} alive")
    print(f"  Conflict    : {n_con}/{n_int} ({100*n_con/n_int:.1f}%)")
    print(f"  Memes       : {len(culture_pool.memes)} active")
    print(f"  Top memes   : {meme_str}")
    print(f"  Innovation  : {innov.get('total_successes',0)} successes, "
          f"registry={len(innovation_engine.practice_registry)}")
    for a in top3:
        tags = ' '.join(a.experience.identity_tags[:3]) if hasattr(a,'experience') else ''
        g = agent_group.get(a.id, '?')
        print(f"  {a.name:<14} G{g} gen={a.generation:2d} age={a.state.age:5.0f} "
              f"stress={a.state.stress:.2f} tags=[{tags}]")

# ── Agent restore ─────────────────────────────────────────────────────────────
def restore_agent(snap, spatial_world, faction_registry, culture_pool,
                  rng_state=None):
    a = Agent(snap['name'], seed=hash(snap['id']) & 0xFFFFFF,
              spatial_world=spatial_world,
              faction_registry=faction_registry,
              culture_pool=culture_pool)
    a.id         = snap['id']
    a.alive      = snap.get('alive', True)
    a.generation = snap.get('generation', 0)
    a.birth_tick = snap.get('birth_tick', 0)
    a.household_id = snap.get('household_id')
    a.parent_ids   = snap.get('parent_ids', [])

    pos = snap.get('position', {})
    a.position.x = float(pos.get('x', 20.0))
    a.position.y = float(pos.get('y', 20.0))

    st = snap.get('state', {})
    for attr in ['stress','energy','age','cooperation','stability','fear',
                 'dominance','social_openness','resource_stock','hunger',
                 'collapse_strikes','specialization_depth','linguistic_complexity',
                 'cultural_alignment','ideology_alignment','novelty_saturation',
                 'plan_confidence','status_security','goal_satisfaction']:
        if attr in st:
            setattr(a.state, attr, st[attr])

    bio = snap.get('biology', {})
    for attr in ['biological_sex','sexual_orientation','physical_attractiveness',
                 'libido','gestation_ticks_remaining','pair_bond_strength',
                 '_pair_bond_partner_id']:
        if attr in bio:
            setattr(a, attr, bio[attr])

    tr = snap.get('traits', {})
    for attr in ['stress_limit','recovery_speed','trust_baseline','conflict_sensitivity',
                 'risk_tolerance','attachment_rate','avoidance_rate','resilience',
                 'generational_fitness']:
        if attr in tr:
            setattr(a.traits, attr, tr[attr])
    if 'role' in tr:
        a.traits.role = tr['role']

    dev = snap.get('development', {})
    if hasattr(a, 'development') and a.development:
        for attr in ['stage','traits_consolidated','plasticity','trust_baseline',
                     'attachment_rate','avoidance_rate','conflict_sensitivity',
                     'resilience','risk_tolerance','ideology_sensitivity']:
            if attr in dev:
                setattr(a.development, attr, dev[attr])
        if 'identity_tags' in dev:
            a.development.identity_tags = dev['identity_tags']

    exp = snap.get('experience', {})
    if hasattr(a, 'experience'):
        for attr in ['identity_tags','scars']:
            if attr in exp:
                setattr(a.experience, attr, exp[attr])
        if 'bonds' in exp and isinstance(exp['bonds'], dict):
            a.experience.bonds = exp['bonds']
        if 'grudges' in exp and isinstance(exp['grudges'], dict):
            a.experience.grudges = exp['grudges']

    rels = snap.get('relationships', {})
    if hasattr(a, 'relationships'):
        for oid, rdata in rels.items():
            r = a.relationships.get(oid)
            for attr in ['trust','avoidance','influence','attachment',
                         'resentment','interactions','allied']:
                if attr in rdata:
                    setattr(r, attr, rdata[attr])

    # Restore per-agent RNG state if available
    if rng_state:
        try:
            a.rng.setstate((rng_state[0], tuple(rng_state[1]), rng_state[2]))
        except Exception:
            pass

    init_generational_agent(a, generation=a.generation,
                             household_id=a.household_id,
                             parents=a.parent_ids,
                             birth_tick=a.birth_tick)
    init_apprenticeship_agent(a)
    init_governance_agent(a)
    biology_mod.init_agent(a)
    init_innovation_agent(a)
    init_information_agent(a)
    return a

# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--from', dest='prior_dir', default=str(DEFAULT_PRIOR_DIR))
    parser.add_argument('--ticks', type=int, default=0,
                        help='Additional ticks to run (0 = indefinite)')
    parser.add_argument('--snap-every', type=int, default=500)
    args = parser.parse_args()

    output_dir = Path(args.prior_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    snap_every = args.snap_every

    # ── Validate manifest ─────────────────────────────────────────────────────
    manifest = load_manifest(output_dir)
    if manifest.get('config_hash') and manifest['config_hash'] != CONFIG_HASH:
        print(f"WARNING: Config hash mismatch.")
        print(f"  Saved:   {manifest['config_hash']}")
        print(f"  Current: {CONFIG_HASH}")
        print(f"  Proceeding as RESEED (not true resume) — world params differ.")
    else:
        print(f"Config hash OK: {CONFIG_HASH}")

    # ── Find best checkpoint ──────────────────────────────────────────────────
    full_cps = sorted(output_dir.glob("checkpoint_full_*.json"))
    fallback_cps = sorted(output_dir.glob("checkpoint_*.json"))
    # exclude full checkpoints from fallback list
    fallback_cps = [p for p in fallback_cps if 'full' not in p.name]

    cp_data = None
    if full_cps:
        print(f"Loading full checkpoint: {full_cps[-1].name}")
        cp_data = json.loads(full_cps[-1].read_text())
        start_tick = cp_data['tick'] + 1
        checkpoint_type = "full"
    elif fallback_cps:
        print(f"No full checkpoint found. Falling back to: {fallback_cps[-1].name}")
        print(f"  NOTE: RNG state, ecology, and registry will be reseeded.")
        cp_data = json.loads(fallback_cps[-1].read_text())
        start_tick = cp_data['tick'] + 1
        checkpoint_type = "partial"
    elif (output_dir / "agents_final.json").exists():
        print(f"No checkpoint found. Loading from agents_final.json.")
        print(f"  NOTE: This is a RESEED, not a true resume.")
        start_tick = 1
        checkpoint_type = "reseed"
    else:
        print("ERROR: No restorable state found.")
        sys.exit(1)

    end_tick = start_tick + args.ticks - 1 if args.ticks > 0 else None
    session_start_tick = start_tick

    print(f"\nRESUMING Experiment E from tick {start_tick}")
    print(f"  Mode: {checkpoint_type.upper()}")
    if end_tick:
        print(f"  Running {args.ticks} ticks → stopping at tick {end_tick}")
    else:
        print(f"  Running indefinitely (Ctrl+C to stop cleanly)")
    print(f"  Checkpointing every {snap_every} ticks")
    print(f"  Output: {output_dir}\n")

    # ── Required files check ──────────────────────────────────────────────────
    required = ["agents_final.json", "group_map.json"]
    missing = [f for f in required if not (output_dir / f).exists()]
    if missing:
        print(f"ERROR: Missing required files: {missing}")
        sys.exit(1)

    # ── Build world systems ───────────────────────────────────────────────────
    global_rng = random.Random(SEED + start_tick)
    if cp_data and 'global_rng_state' in cp_data:
        s = cp_data['global_rng_state']
        global_rng.setstate((s[0], tuple(s[1]), s[2]))
        print("  Restored global RNG state.")

    env_cycle        = EnvironmentCycle()
    spatial_world    = SpatialWorld(width=WORLD_W, height=WORLD_H, interaction_radius=3)
    resource_world   = ResourceWorld(width=WORLD_W, height=WORLD_H, n_nodes=120, rng=global_rng)
    faction_registry = FactionRegistry()
    territory_map    = TerritoryMap(WORLD_W, WORLD_H)
    institution_registry = InstitutionRegistry()
    culture_pool     = CulturePool()
    world_narrative  = WorldNarrative()
    texture_chronicle = TextureChronicle()
    generational_ledger   = GenerationalLedger()
    apprenticeship_ledger = ApprenticeshipLedger()
    governance_ledger     = GovernanceLedger()
    information_ledger    = InformationLedger()
    genpsych_ledger       = GenerationalPsychologyLedger()
    instmem_ledger        = InstitutionalMemoryLedger()
    settlement_ledger     = SettlementLedger()
    logistics_world       = LogisticsWorld(WORLD_W, WORLD_H, seed=SEED+44000)
    subsistence_world     = SubsistenceWorld(WORLD_W, WORLD_H, seed=SEED+43300)
    reproduction_system   = ReproductionSystem(max_population=MAX_POP)
    ledger               = DeathLedger()
    constraint_ledger    = ConstraintLedger()
    persistence_ledger   = PersistenceLedger()
    innovation_engine    = InnovationEngine()
    _counters = RollingCounters()

    # ── Zone grid ─────────────────────────────────────────────────────────────
    zone_grid = ZoneGrid(WORLD_W, WORLD_H, seed=SEED + 99000)
    spatial_world._zone_grid      = zone_grid
    subsistence_world._zone_grid  = zone_grid
    print(f"ZoneGrid: {len(zone_grid.zones)} zones")

    # Zone ecology: reinitialize from seed (deterministic from SEED+tick, close enough)
    # Full restore of fauna objects is complex and the seed-based reinit is stable.
    if cp_data and 'zone_ecology' in cp_data:
        print("  Zone ecology: reinitializing from seed (fauna objects not directly serializable).")

    # ── Restore culture ───────────────────────────────────────────────────────
    culture_src = cp_data.get('culture') if cp_data else None
    if culture_src is None:
        cp_path = output_dir / "culture.json"
        culture_src = json.loads(cp_path.read_text()) if cp_path.exists() else {}

    for mdata in culture_src.get('memes', []) + culture_src.get('meme_list', []):
        try:
            m = Meme(id=mdata['id'], label=mdata.get('label', mdata['id']),
                     valence=mdata.get('valence', 0.0),
                     spread_rate=mdata.get('spread_rate', 0.05),
                     strength=mdata.get('strength', 0.5),
                     origin_tick=mdata.get('origin_tick', 0))
            culture_pool.memes[m.id] = m
        except Exception:
            pass

    # Restore agent-meme assignments if available
    if culture_src.get('agent_memes') and hasattr(culture_pool, '_agent_memes'):
        culture_pool._agent_memes = {
            k: list(v) for k, v in culture_src['agent_memes'].items()
        }
    print(f"  Restored {len(culture_pool.memes)} memes.")

    # ── Restore innovation registry ───────────────────────────────────────────
    innov_src = cp_data.get('innovation') if cp_data else None
    if innov_src is None:
        ip = output_dir / "innovation.json"
        innov_src = json.loads(ip.read_text()) if ip.exists() else {}

    if 'practice_registry' in innov_src:
        for name, pdata in innov_src['practice_registry'].items():
            try:
                p = PracticeRecord(
                    name=pdata['name'], domain=pdata['domain'],
                    utility_score=pdata.get('utility_score', 0.5),
                    fidelity=pdata.get('fidelity', 0.5),
                    origin_agent_id=pdata.get('origin_agent_id', ''),
                    origin_tick=pdata.get('origin_tick', 0),
                    attempts=pdata.get('attempts', 1),
                    successes=pdata.get('successes', 1),
                    diffusion_count=pdata.get('diffusion_count', 0),
                    institutional_adoptions=pdata.get('institutional_adoptions', 0),
                    tags=pdata.get('tags', []),
                )
                innovation_engine.practice_registry[p.name] = p
            except Exception:
                pass
    summ = innov_src.get('summary', {})
    innovation_engine.total_attempts = summ.get('total_attempts', 0)
    innovation_engine.total_successes = summ.get('total_successes', 0)
    innovation_engine.total_diffusions = summ.get('total_diffusions', 0)
    innovation_engine.total_institutional_adoptions = summ.get('total_institutional_adoptions', 0)
    print(f"  Restored {len(innovation_engine.practice_registry)} practices.")

    # ── Restore governance ────────────────────────────────────────────────────
    gov_src = cp_data.get('governance') if cp_data else None
    if gov_src:
        governance_ledger.total_successions = gov_src.get('total_successions', 0)
        governance_ledger.total_compliance  = gov_src.get('total_compliance', 0)
        governance_ledger.total_defiance    = gov_src.get('total_defiance', 0)
        for fid, ldata in gov_src.get('leaders', {}).items():
            try:
                from governance import LeaderRecord
                rec = LeaderRecord(
                    leader_id=ldata['leader_id'],
                    legitimacy=ldata.get('legitimacy', 0.5),
                )
                rec.ticks_in_power = ldata.get('ticks_in_power', 0)
                rec.in_governance_gap = ldata.get('in_governance_gap', False)
                governance_ledger.leaders[fid] = rec
            except Exception:
                pass
        print(f"  Restored {len(governance_ledger.leaders)} governance records.")

    # ── Restore deaths ────────────────────────────────────────────────────────
    deaths_src = cp_data.get('deaths') if cp_data else None
    if deaths_src is None:
        dp = output_dir / "deaths.json"
        deaths_src = json.loads(dp.read_text()) if dp.exists() else []
    for d in deaths_src:
        try:
            vac_d = d.pop('vacancy', None) if isinstance(d, dict) else None
            vacancy = Vacancy(**vac_d) if vac_d else None
            if isinstance(d, dict):
                ledger.deaths.append(DeathRecord(**d, vacancy=vacancy))
        except Exception:
            pass
    death_logged = set(d.agent_id for d in ledger.deaths)
    print(f"  Restored {len(ledger.deaths)} death records.")

    # ── Restore agent_group ───────────────────────────────────────────────────
    agent_group = cp_data.get('group_map') if cp_data and 'group_map' in cp_data else {}
    if not agent_group:
        gm_path = output_dir / "group_map.json"
        agent_group = json.loads(gm_path.read_text()) if gm_path.exists() else {}

    # ── Restore agents ────────────────────────────────────────────────────────
    agents_src = cp_data.get('agents') if cp_data else None
    if agents_src is None:
        agents_src = json.loads((output_dir / "agents_final.json").read_text())

    agent_rng_states = cp_data.get('agent_rng_states', {}) if cp_data else {}
    agents = []
    for snap in agents_src:
        rng_state = agent_rng_states.get(snap['id'])
        a = restore_agent(snap, spatial_world, faction_registry, culture_pool, rng_state)
        init_spatial_for_agent(a, zone_grid)
        if a.id not in agent_group:
            agent_group[a.id] = 'A'
        agents.append(a)

    # ── Restore faction registry ──────────────────────────────────────────────
    factions_src = cp_data.get('factions') if cp_data else None
    if factions_src is None:
        fp = output_dir / "factions.json"
        factions_src = json.loads(fp.read_text()) if fp.exists() else []
    for fdata in factions_src:
        try:
            f = faction_registry.get_or_create(fdata['id'], fdata.get('name', fdata['id']))
            members = set(fdata.get('members', []))
            if hasattr(f, 'members'):
                f.members = members
            if hasattr(f, 'hostility'):
                f.hostility = fdata.get('hostility', {})
            if fdata.get('leader_id') and hasattr(f, 'leader_id'):
                f.leader_id = fdata['leader_id']
            # wire agents to faction
            for a in agents:
                if a.id in members:
                    try: faction_registry.assign(a, f)
                    except Exception: pass
        except Exception:
            pass
    print(f"  Restored {len(factions_src)} factions.")

    living_count = sum(1 for a in agents if a.alive)
    print(f"\nRestored {living_count} living / {len(agents)} total agents.")

    # ── Event stream ──────────────────────────────────────────────────────────
    events_path = output_dir / "events.jsonl"
    _stream = EventStream(events_path, mode="a" if events_path.exists() else "w")
    checkpoint_writer = CheckpointWriter(output_dir)
    event_log  = []
    metric_log = []

    snapshot_report(start_tick - 1, agents, ledger, culture_pool,
                    faction_registry, innovation_engine, _counters,
                    agent_group, session_start_tick)

    # ── Tick loop ─────────────────────────────────────────────────────────────
    tick = start_tick
    try:
        while True:
            if _stop_requested or (end_tick and tick > end_tick):
                break

            phase = env_cycle.get_phase(tick)

            _eco = _eco_health_fn(subsistence_world, agents,
                                  recent_deaths=sum(1 for a in agents if not a.alive))
            life_events_mod.step_disease_layer(agents, tick, key="resume_1")
            living = [a for a in agents if a.alive]

            for a in living:
                le = life_events_mod.apply_all_life_effects(a, tick, key="resume_1")
                if le["stress"]:  a.state.stress      = max(0., min(1., a.state.stress      + le["stress"]*0.012))
                if le["support"]: a.state.cooperation = max(0., min(1., a.state.cooperation + le["support"]*0.008))
                if le["trust"]:   a.state.stability   = max(0., min(1., a.state.stability   + le["trust"]*0.006))

            for a in living:
                a._population_ref = agents
                a._eco_health     = _eco

            zone_grid.update_local_populations(agents)
            zone_grid.tick(phase.name)

            tick_cooperation_events = []
            for a in list(living):
                if not a.alive: continue
                ev = safe_agent_tick(a, tick, phase, agents,
                    spatial_world=spatial_world, resource_world=resource_world,
                    faction_registry=faction_registry, territory_map=territory_map,
                    institution_registry=institution_registry, culture_pool=culture_pool,
                    world_narrative=world_narrative, texture_chronicle=texture_chronicle,
                    governance_ledger=governance_ledger, eco_health=_eco)
                if not ev: continue
                d = serialize_event(ev); d["salience"] = salience_mod.score(d)
                persistence_ledger.record_event(d); event_log.append(d)
                _counters.record(d); _stream.write(d)
                if getattr(ev, 'outcome', '') == 'cooperation':
                    tick_cooperation_events.append(ev)

                if ev.event_type == "birth":
                    child_id   = ev.context.get("child_id")
                    parent_ids = ev.context.get("parent_ids", [])
                    child = next((x for x in agents if x.id == child_id), None)
                    if child:
                        parents = [x for x in agents if x.id in parent_ids]
                        assign_child_context(child, parents, tick, generational_ledger)
                        init_innovation_agent(child); init_information_agent(child)
                        init_governance_agent(child)
                        init_spatial_for_agent(child, zone_grid)
                        for pid in parent_ids:
                            if pid in agent_group:
                                agent_group[child.id] = agent_group[pid]; break

                if ev.event_type == "death":
                    dead = next((x for x in agents if x.id == ev.actor_id), None)
                    if dead and dead.id not in death_logged:
                        death_logged.add(dead.id)
                        ledger.record(build_death_record(dead, agents, tick,
                                      cause=getattr(dead,'_death_cause','unknown')))
                        psychology_mod.notify_death_to_population(dead, agents, tick)

                for aux_ev in getattr(a, "aux_events", []):
                    d = serialize_event(aux_ev); d["salience"] = 0.90
                    persistence_ledger.record_event(d); event_log.append(d)
                    _counters.record(d); _stream.write(d)
                    if aux_ev.event_type == "lethal_conflict" and getattr(aux_ev, "outcome", "") == "homicide":
                        victim_id = aux_ev.participants[0] if aux_ev.participants else None
                        if victim_id:
                            victim = next((x for x in agents if x.id == victim_id), None)
                            if victim and victim.id not in death_logged:
                                death_logged.add(victim.id)
                                ledger.record(build_death_record(victim, agents, tick, cause="homicide"))
                                psychology_mod.notify_death_to_population(victim, agents, tick)
                a.aux_events = []

            # Natural mortality
            for a in list(agents):
                if not a.alive: continue
                a.check_death()
                if not a.alive and a.id not in death_logged:
                    death_logged.add(a.id)
                    ledger.record(build_death_record(a, agents, tick,
                                  cause=getattr(a,'_death_cause','unknown')))
                    psychology_mod.notify_death_to_population(a, agents, tick)

            # Subsistence
            for a in [x for x in agents if x.alive]:
                for sub_ev in subsistence_world.agent_tick(a, tick, phase.name,
                                                           culture_pool=culture_pool,
                                                           faction_registry=faction_registry):
                    d = serialize_event(sub_ev); d["salience"] = 0.52
                    subsistence_world.record_event(sub_ev)
                    persistence_ledger.record_event(d); event_log.append(d)
                    _counters.record(d); _stream.write(d)
                    a.aux_events.append(sub_ev)

            # Resource transfers
            for a in [x for x in agents if x.alive]:
                nearby = spatial_world.nearby_agents(a, agents)
                for tev in apply_resource_transfers(a, tick, phase.name, nearby,
                        random.Random(tick + hash(a.id) & 0xFFFF)):
                    d = serialize_event(tev); d["salience"] = 0.72
                    persistence_ledger.record_event(d); event_log.append(d)
                    _counters.record(d); _stream.write(d)

            # Reproduction
            if tick % 25 == 0:
                newborns = reproduction_system.tick(
                    agents, spatial_world, faction_registry,
                    culture_pool, random.Random(tick * 7),
                    genpsych_ledger=genpsych_ledger, tick=tick, eco_health=_eco)
                for child in newborns:
                    agents.append(child)
                    parent_id = child.parent_ids[0] if hasattr(child,'parent_ids') and child.parent_ids else ''
                    agent_group[child.id] = agent_group.get(parent_id, 'A')
                    init_innovation_agent(child); init_information_agent(child)
                    init_governance_agent(child)
                    init_spatial_for_agent(child, zone_grid)

            # Subsystem ticks
            apply_generational_tick(agents, tick, phase.name, generational_ledger)
            apply_apprenticeship_tick(agents, tick, phase.name, apprenticeship_ledger)
            apply_governance_tick(agents, tick, phase.name, governance_ledger, faction_registry)
            apply_information_tick(agents, tick, information_ledger,
                                   governance_ledger=governance_ledger,
                                   faction_registry=faction_registry,
                                   logistics_world=logistics_world,
                                   rng=random.Random(tick + SEED * 1031))
            apply_innovation_tick(agents, tick, phase.name, innovation_engine,
                                  institution_registry=institution_registry,
                                  governance_ledger=governance_ledger,
                                  rng=random.Random(tick + SEED * 1037),
                                  cooperation_events=[serialize_event(e) for e in tick_cooperation_events])
            apply_population_viability_tick(agents, tick, phase.name,
                                            spatial_world, random.Random(tick + SEED))
            apply_storykeeper_transmission(agents, tick, phase.name,
                                           random.Random(tick + SEED * 1013), genpsych_ledger)
            apply_targeted_care_recovery(agents, tick, phase.name,
                                         random.Random(tick + SEED * 1019), genpsych_ledger)
            apply_institutional_memory_tick(agents, tick, phase.name,
                                            random.Random(tick + SEED * 1021), instmem_ledger,
                                            event_log, faction_registry)

            if tick % 10 == 0:
                metric_log.append({
                    "tick": tick, "phase": phase.name,
                    **population_metrics(agents,
                        faction_registry=faction_registry,
                        institution_registry=institution_registry,
                        culture_pool=culture_pool,
                        reproduction_system=reproduction_system),
                    **_counters.snapshot(),
                })

            if tick % snap_every == 0:
                snapshot_report(tick, agents, ledger, culture_pool,
                                faction_registry, innovation_engine, _counters,
                                agent_group, session_start_tick)
                save_full_checkpoint(tick, output_dir, agents, agent_group, ledger,
                                     culture_pool, innovation_engine, governance_ledger,
                                     generational_ledger, zone_grid, faction_registry,
                                     global_rng, metric_log, session_start_tick)

            tick += 1

    except Exception as e:
        import traceback
        print(f"\n\nERROR at tick {tick}: {e}")
        traceback.print_exc()

    finally:
        final_tick = tick - 1
        print(f"\n\nSaving full checkpoint at tick {final_tick}...")

        save_full_checkpoint(final_tick, output_dir, agents, agent_group, ledger,
                             culture_pool, innovation_engine, governance_ledger,
                             generational_ledger, zone_grid, faction_registry,
                             global_rng, metric_log, session_start_tick)

        # Flush flat files for compatibility
        (output_dir/"agents_final.json").write_text(
            json.dumps([a.snapshot() for a in agents], indent=2), encoding="utf-8")
        (output_dir/"group_map.json").write_text(
            json.dumps(agent_group, indent=2), encoding="utf-8")

        # Append metrics
        if metric_log:
            ml_path = output_dir / "metrics.json"
            existing = []
            if ml_path.exists():
                try: existing = json.loads(ml_path.read_text())
                except: pass
            ml_path.write_text(json.dumps(existing + metric_log, indent=2), encoding="utf-8")

        # Write session record to manifest
        save_manifest(output_dir, manifest, session_start_tick, final_tick)

        living = sum(1 for a in agents if a.alive)
        print(f"Session: ticks {session_start_tick}–{final_tick} "
              f"({final_tick - session_start_tick + 1} ticks run)")
        print(f"Population: {living} alive. Deaths: {len(ledger.deaths)}. "
              f"Innovation: {len(innovation_engine.practice_registry)} practices.")
        print(f"State saved to: {output_dir}")

if __name__ == "__main__":
    main()
