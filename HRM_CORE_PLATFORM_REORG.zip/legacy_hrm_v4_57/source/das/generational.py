"""
generational.py — DAS v04.21 generational continuity layer.

Adds lightweight population-continuity pressure: life-stage curves,
dependency load, caretaker pressure, household clustering, and pair-bond
scaffolding. This is structural, not romantic/narrative scripting.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Dict, Iterable, List, Optional, Tuple
from schemas import Event
try:
    import biology as biology_mod
    _HAS_BIOLOGY = True
except ImportError:
    _HAS_BIOLOGY = False


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(x)))


def is_kin(a: Any, b: Any) -> bool:
    """True if a and b share a direct kin relationship (parent/child/sibling).
    Blocks romantic pair bond formation between close kin.
    """
    a_parents = set(getattr(a, "parent_ids", []) or [])
    b_parents = set(getattr(b, "parent_ids", []) or [])
    # Parent-child: b is a's parent or a is b's parent
    if b.id in a_parents or a.id in b_parents:
        return True
    # Siblings: share at least one parent
    if a_parents & b_parents:
        return True
    return False


@dataclass
class GenerationalConfig:
    child_ticks: int = 90
    juvenile_ticks: int = 180
    elder_ticks: int = 700
    dependency_child: float = 0.72
    dependency_juvenile: float = 0.34
    dependency_elder: float = 0.24
    caretaker_stress_scale: float = 0.020
    caretaker_energy_scale: float = 0.018
    pair_bond_attachment_gate: float = 0.34
    pair_bond_trust_gate: float = 0.66
    pair_bond_min_interactions: int = 8
    pair_bond_cooldown_ticks: int = 80
    dependency_radius: int = 1


DEFAULT_CONFIG = GenerationalConfig()


class GenerationalLedger:
    def __init__(self) -> None:
        self.birth_records: List[Dict[str, Any]] = []
        self.household_events: List[Dict[str, Any]] = []
        self.pair_bond_events: List[Dict[str, Any]] = []
        self.care_events: int = 0
        self.dependency_pressure_events: int = 0
        self.household_counter: int = 0
        self._pair_seen: Dict[Tuple[str, str], int] = {}

    def new_household_id(self) -> str:
        self.household_counter += 1
        return f"household_{self.household_counter:04d}"

    def record_birth(self, tick: int, child, parents: List[Any], household_id: Optional[str], dependency: float) -> None:
        self.birth_records.append({
            "tick": tick,
            "child_id": child.id,
            "child_name": child.name,
            "parent_ids": [p.id for p in parents if p is not None],
            "parent_names": [p.name for p in parents if p is not None],
            "household_id": household_id,
            "dependency_load": round(dependency, 4),
            "generation": getattr(child, "generation", 0),
            "cell": {"x": child.position.x, "y": child.position.y},
        })

    def record_household_event(self, tick: int, event_type: str, household_id: str, members: List[str], cell=None) -> None:
        self.household_events.append({
            "tick": tick,
            "event_type": event_type,
            "household_id": household_id,
            "members": list(members),
            "cell": ({"x": cell.x, "y": cell.y} if cell else None),
        })

    def record_pair_bond(self, tick: int, a, b, strength: float) -> None:
        key = tuple(sorted([a.id, b.id]))
        last = self._pair_seen.get(key, -10**9)
        if tick - last < DEFAULT_CONFIG.pair_bond_cooldown_ticks:
            return
        self._pair_seen[key] = tick
        self.pair_bond_events.append({
            "tick": tick,
            "agents": [a.id, b.id],
            "agent_names": [a.name, b.name],
            "strength": round(strength, 4),
            "households": [getattr(a, "household_id", None), getattr(b, "household_id", None)],
        })

    def snapshot(self, agents: Optional[List[Any]] = None) -> Dict[str, Any]:
        summary = {
            "births_recorded": len(self.birth_records),
            "household_events": len(self.household_events),
            "pair_bond_events": len(self.pair_bond_events),
            "care_events": self.care_events,
            "dependency_pressure_events": self.dependency_pressure_events,
        }
        if agents is not None:
            summary.update(summarize_generational_state(agents))
        return {
            "summary": summary,
            "birth_records": self.birth_records[-250:],
            "household_events": self.household_events[-250:],
            "pair_bond_events": self.pair_bond_events[-250:],
        }


def init_agent(agent, generation: Optional[int] = None, household_id: Optional[str] = None,
               parents: Optional[List[str]] = None, birth_tick: Optional[int] = None) -> None:
    if generation is not None:
        agent.generation = generation
    if not hasattr(agent, "household_id"):
        agent.household_id = household_id
    elif household_id is not None:
        agent.household_id = household_id
    if not hasattr(agent, "parent_ids"):
        agent.parent_ids = list(parents or [])
    elif parents is not None:
        agent.parent_ids = list(parents)
    if not hasattr(agent, "birth_tick"):
        agent.birth_tick = birth_tick
    elif birth_tick is not None:
        agent.birth_tick = birth_tick
    if not hasattr(agent.state, "dependency_load"):
        setattr(agent.state, "dependency_load", 0.0)
    if not hasattr(agent.state, "caretaker_load"):
        setattr(agent.state, "caretaker_load", 0.0)
    if not hasattr(agent.state, "pair_bond_strength"):
        setattr(agent.state, "pair_bond_strength", 0.0)
    if not hasattr(agent.state, "household_stability"):
        setattr(agent.state, "household_stability", 0.5)


def life_stage(agent, cfg: GenerationalConfig = DEFAULT_CONFIG) -> str:
    age = getattr(agent.state, "age", 0)
    if age < cfg.child_ticks:
        return "dependent_child"
    if age < cfg.juvenile_ticks:
        return "juvenile"
    if age >= cfg.elder_ticks:
        return "elder"
    return "adult"


def dependency_for(agent, cfg: GenerationalConfig = DEFAULT_CONFIG) -> float:
    stage = life_stage(agent, cfg)
    injury = getattr(agent.state, "injury", 0.0)
    hunger = getattr(agent.state, "hunger", 0.0)
    if stage == "dependent_child":
        base = cfg.dependency_child
    elif stage == "juvenile":
        base = cfg.dependency_juvenile
    elif stage == "elder":
        base = cfg.dependency_elder
    else:
        base = 0.04
    return clamp(base + injury * 0.25 + max(0.0, hunger - 0.55) * 0.20)


def _near(a, b, cfg: GenerationalConfig = DEFAULT_CONFIG) -> bool:
    return abs(a.position.x - b.position.x) <= cfg.dependency_radius and abs(a.position.y - b.position.y) <= cfg.dependency_radius


def apply_tick(agents: List[Any], tick: int, phase_name: str, ledger: GenerationalLedger,
               cfg: GenerationalConfig = DEFAULT_CONFIG) -> List[Event]:
    """Apply lightweight generational pressure once per tick after agents act."""
    events: List[Event] = []
    living = [a for a in agents if getattr(a, "alive", False)]
    for a in living:
        init_agent(a)
        setattr(a.state, "dependency_load", dependency_for(a, cfg))
        setattr(a.state, "caretaker_load", 0.0)

    households: Dict[str, List[Any]] = {}
    for a in living:
        hid = getattr(a, "household_id", None)
        if hid:
            households.setdefault(hid, []).append(a)

    for hid, members in households.items():
        dependents = [m for m in members if getattr(m.state, "dependency_load", 0.0) > 0.20]
        capable = [m for m in members if getattr(m.state, "dependency_load", 0.0) <= 0.18 and life_stage(m, cfg) == "adult"]
        local_capable = []
        for c in capable:
            if any(_near(c, d, cfg) for d in dependents):
                local_capable.append(c)
        total_dep = sum(getattr(d.state, "dependency_load", 0.0) for d in dependents)
        if total_dep <= 0:
            continue
        if local_capable:
            load = min(0.55, total_dep / max(1, len(local_capable)) * 0.22)
            for c in local_capable:
                c.state.caretaker_load = clamp(getattr(c.state, "caretaker_load", 0.0) + load)
                c.state.stress = clamp(c.state.stress + load * cfg.caretaker_stress_scale)
                c.state.energy = clamp(c.state.energy - load * cfg.caretaker_energy_scale)
                c.state.household_stability = clamp(getattr(c.state, "household_stability", 0.5) + 0.006)
                ledger.care_events += 1
                # Kin bond reinforcement: caretaking deepens trust and attachment between kin
                for d in dependents:
                    if is_kin(c, d):
                        c.relationships.update_after_interaction(
                            d.id, trust_delta=0.004, attachment_delta=0.006)
                        d.relationships.update_after_interaction(
                            c.id, trust_delta=0.005, attachment_delta=0.008)
                if load > 0.08 and tick % 10 == 0:
                    events.append(Event(
                        tick=tick, phase=phase_name, actor_id=c.id, event_type="caretaker_pressure",
                        participants=[d.id for d in dependents[:4]],
                        context={"household_id": hid, "caretaker_load": round(load, 4), "dependent_count": len(dependents)},
                        impact={"stress": round(load * cfg.caretaker_stress_scale, 4), "energy": round(-load * cfg.caretaker_energy_scale, 4)},
                        outcome="care_burden_absorbed",
                    ))
        else:
            for d in dependents:
                d.state.stress = clamp(d.state.stress + 0.010 + getattr(d.state, "dependency_load", 0.0) * 0.010)
                d.state.safety = clamp(getattr(d.state, "safety", 0.7) - 0.012)
                ledger.dependency_pressure_events += 1
                if tick % 10 == 0:
                    events.append(Event(
                        tick=tick, phase=phase_name, actor_id=d.id, event_type="unmet_dependency_pressure",
                        participants=[],
                        context={"household_id": hid, "dependency_load": round(getattr(d.state, "dependency_load", 0.0), 4)},
                        impact={"stress": 0.01, "safety": -0.012},
                        outcome="dependency_unmet",
                    ))

    # Pair-bond scaffolding: high-trust repeated dyad + mutual attraction.
    # Dissolution: bonds weaken from conflict, resentment, and grief.
    living_by_id = {a.id: a for a in living}

    for a in living:
        current_bond = getattr(a.state, "pair_bond_strength", 0.0)
        partner_id = getattr(a, "_pair_bond_partner_id", None)

        # Bond dissolution: weaken from conflict with partner, resentment, grief
        if partner_id and current_bond > 0.0:
            partner = living_by_id.get(partner_id)
            if partner is None:
                # Partner is dead — grief erodes bond strength slowly
                grief_decay = 0.0008 * tick  # time heals but leaves a scar
                a.state.pair_bond_strength = clamp(current_bond - 0.002)
                a._pair_bond_partner_id = None if current_bond < 0.10 else partner_id
            else:
                # Check relationship health with partner
                rels = a.relationships.snapshot()
                partner_rel = rels.get(partner_id, {})
                resentment = partner_rel.get("resentment", 0.0)
                conflict_count = partner_rel.get("conflicts", 0)
                # High resentment or repeated conflict erodes bond
                if resentment > 0.55 or conflict_count > 8:
                    erosion = (resentment - 0.40) * 0.004 + max(0, conflict_count - 8) * 0.001
                    a.state.pair_bond_strength = clamp(current_bond - erosion)
                    if a.state.pair_bond_strength < 0.15:
                        a._pair_bond_partner_id = None
                        a.state.pair_bond_strength = 0.0

        # Bond formation: trust + attachment + mutual attraction
        rels = a.relationships.snapshot()
        best_id = None; best_strength = 0.0
        for bid, rel in rels.items():
            b = living_by_id.get(bid)
            if b is None:
                continue
            if rel.get("interactions", 0) < cfg.pair_bond_min_interactions:
                continue
            if rel.get("trust", 0.0) < cfg.pair_bond_trust_gate:
                continue
            if rel.get("attachment", 0.0) < cfg.pair_bond_attachment_gate:
                continue
            # Kin gate: no romantic bonds between parent/child/siblings
            if is_kin(a, b):
                continue

            rel_strength = (rel.get("trust", 0.0) * 0.38 +
                           rel.get("attachment", 0.0) * 0.38 +
                           max(0.0, 1.0 - rel.get("resentment", 0.0)) * 0.08)

            # Wire in biological attraction if available
            attraction_bonus = 0.0
            if _HAS_BIOLOGY:
                try:
                    attr_a = biology_mod.attraction_score(a, b)
                    attr_b = biology_mod.attraction_score(b, a)
                    mutual_attraction = (attr_a + attr_b) / 2.0
                    # Attraction adds up to 0.16 to bond strength; zero attraction blocks bond
                    if mutual_attraction < 0.05:
                        continue  # no mutual attraction — no bond
                    attraction_bonus = mutual_attraction * 0.16
                except Exception:
                    pass

            strength = clamp(rel_strength + attraction_bonus)
            if strength > best_strength:
                best_id = bid; best_strength = strength

        if best_id:
            b = living_by_id.get(best_id)
            if b:
                # Set bond for both agents
                a.state.pair_bond_strength = clamp(max(getattr(a.state, "pair_bond_strength", 0.0), best_strength))
                b.state.pair_bond_strength = clamp(max(getattr(b.state, "pair_bond_strength", 0.0), best_strength * 0.85))
                # Track partner IDs for infidelity and grief checks
                if not getattr(a, "_pair_bond_partner_id", None):
                    a._pair_bond_partner_id = best_id
                if not getattr(b, "_pair_bond_partner_id", None):
                    b._pair_bond_partner_id = a.id
                ledger.record_pair_bond(tick, a, b, best_strength)
    return events


def assign_child_context(child, parents: List[Any], tick: int, ledger: GenerationalLedger,
                         cfg: GenerationalConfig = DEFAULT_CONFIG) -> None:
    parent_ids = [p.id for p in parents if p is not None]
    parent_hids = [getattr(p, "household_id", None) for p in parents if p is not None and getattr(p, "household_id", None)]
    household_id = parent_hids[0] if parent_hids else ledger.new_household_id()
    for p in parents:
        if p is not None and not getattr(p, "household_id", None):
            p.household_id = household_id
    init_agent(child, generation=max([getattr(p, "generation", 0) for p in parents if p is not None] + [0]) + 1,
               household_id=household_id, parents=parent_ids, birth_tick=tick)
    child.state.age = 0
    child.state.dependency_load = cfg.dependency_child
    child.state.caretaker_load = 0.0
    child.state.household_stability = 0.50
    child.state.energy = clamp(min(child.state.energy, 0.52))
    child.state.resource_stock = clamp(min(child.state.resource_stock, 0.38))
    ledger.record_birth(tick, child, parents, household_id, child.state.dependency_load)
    ledger.record_household_event(tick, "birth_added_dependent", household_id, parent_ids + [child.id], cell=child.position)


def summarize_generational_state(agents: List[Any]) -> Dict[str, Any]:
    living = [a for a in agents if getattr(a, "alive", False)]
    if not living:
        return {
            "household_count": 0,
            "dependent_agents": 0,
            "adult_agents": 0,
            "elder_agents": 0,
            "avg_dependency_load": 0.0,
            "avg_caretaker_load": 0.0,
            "avg_pair_bond_strength": 0.0,
            "avg_household_stability": 0.0,
        }
    households = {getattr(a, "household_id", None) for a in living if getattr(a, "household_id", None)}
    stages = [life_stage(a) for a in living]
    def avg(attr: str) -> float:
        return round(sum(getattr(a.state, attr, 0.0) for a in living) / len(living), 4)
    return {
        "household_count": len(households),
        "dependent_agents": sum(1 for s in stages if s in ("dependent_child", "juvenile", "elder")),
        "child_agents": stages.count("dependent_child"),
        "juvenile_agents": stages.count("juvenile"),
        "adult_agents": stages.count("adult"),
        "elder_agents": stages.count("elder"),
        "avg_dependency_load": avg("dependency_load"),
        "avg_caretaker_load": avg("caretaker_load"),
        "avg_pair_bond_strength": avg("pair_bond_strength"),
        "avg_household_stability": avg("household_stability"),
    }
