"""
lethality.py — DAS v04.43 agent-on-agent killing.

Humans kill each other. Agents must too.

Lethality is not automatic on conflict. It requires escalation — a confluence
of relational history, psychological state, role, and contextual pressure.
When it fires, it is consequential: the victim dies, the killer is marked,
and the event propagates through belief and information systems.

Design principles:
    - Rare but real. Base rate ~2-4% of conflict interactions escalate.
    - Historically grounded escalation factors: resentment, dominance
      differential, faction hostility, desperation (starvation/stress),
      repeated conflict in the same dyad, warrior role.
    - Victim survival chance: resilience + stress headroom + energy.
    - Killer aftermath: dominance spike, stress spike, trauma flag, belief update.
    - Distinct death cause: "homicide" — recorded in death ledger.
    - Generates a "lethal_conflict" event visible to information propagation.

Escalation factors (each adds to base lethality probability):
    RESENTMENT          high resentment in killer toward victim
    DOMINANCE_GAP       large dominance differential favoring killer
    FACTION_HOSTILITY   inter-faction hostility above threshold
    DYAD_HISTORY        repeated prior conflicts between same two agents
    DESPERATION         killer near starvation or stress ceiling
    WARRIOR_ROLE        protection-family role in killer
    PHASE_PRESSURE      high-pressure environmental phase
"""

from __future__ import annotations

from typing import Any, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    pass


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(x)))


# ── Config ────────────────────────────────────────────────────────────────────

BASE_LETHALITY_CHANCE       = 0.018   # ~1.8% of conflicts escalate at baseline

# Escalation additive contributions
RESENTMENT_THRESHOLD        = 0.55    # above this, resentment contributes
RESENTMENT_ADD              = 0.025   # per unit above threshold

DOMINANCE_GAP_THRESHOLD     = 0.30    # killer dominance - victim dominance
DOMINANCE_GAP_ADD           = 0.020

FACTION_HOSTILITY_THRESHOLD = 0.40
FACTION_HOSTILITY_ADD       = 0.018

DYAD_CONFLICT_THRESHOLD     = 3       # prior conflicts in this dyad
DYAD_CONFLICT_ADD           = 0.012   # per prior conflict above threshold (capped)
DYAD_CONFLICT_CAP           = 0.048   # max contribution from dyad history

DESPERATION_STRESS_FLOOR    = 0.80    # killer stress above this
DESPERATION_RESOURCE_FLOOR  = 0.12    # killer resource below this
DESPERATION_ADD             = 0.022

WARRIOR_ROLE_ADD            = 0.015   # protection-family role
PHASE_PRESSURE_ADD          = 0.010   # per unit of phase.conflict_pressure

MAX_LETHALITY_CHANCE        = 0.18    # ceiling — never more than 18%

# Victim survival
SURVIVAL_BASE               = 0.52    # base survival chance when targeted
RESILIENCE_SURVIVAL_MULT    = 0.28    # resilience contribution
STRESS_HEADROOM_MULT        = 0.14    # (stress_limit - stress) contribution
ENERGY_SURVIVAL_MULT        = 0.10    # energy contribution

# Killer aftermath
KILLER_DOMINANCE_SPIKE      = 0.08
KILLER_STRESS_SPIKE         = 0.12
KILLER_TRAUMA_BURDEN        = 0.06    # added to gen_psych burden if tracked

# Survival aftermath (victim escapes)
SURVIVOR_STRESS_SPIKE       = 0.18
SURVIVOR_RESENTMENT_SPIKE   = 0.22


# ── Dyad conflict history ─────────────────────────────────────────────────────

def _dyad_prior_conflicts(actor: Any, other: Any) -> int:
    """
    Count prior conflicts between this dyad using belief memory.
    Proxy: threat belief toward other, scaled back to rough event count.
    Not perfect — but avoids adding a new data structure.
    """
    threat = actor.beliefs.get_threat(other.id)
    # threat accumulates ~0.096 per direct conflict (0.060 * 1.6 negativity bias)
    # after decay this is a lower bound estimate
    return int(threat / 0.08)


# ── Role check ────────────────────────────────────────────────────────────────

def _is_warrior(agent: Any) -> bool:
    try:
        from adaptive_roles import role_family
        return role_family(getattr(agent.traits, "role", "generalist")) == "protection"
    except Exception:
        return False


# ── Core lethality check ──────────────────────────────────────────────────────

def compute_lethality_chance(
    actor: Any,
    other: Any,
    faction_hostility: float,
    phase_conflict_pressure: float,
    eco_health: float = 0.5,
    n_living: int = 10,
) -> float:
    """
    Compute probability that this conflict escalates to lethal intent.
    Returns float [0, MAX_LETHALITY_CHANCE].
    """
    r = actor.relationships.get(other.id)
    resentment = getattr(r, "resentment", 0.0)
    actor_dom = getattr(actor.state, "dominance", 0.5)
    other_dom = getattr(other.state, "dominance", 0.5)
    dom_gap = actor_dom - other_dom

    chance = BASE_LETHALITY_CHANCE

    # Resentment
    if resentment > RESENTMENT_THRESHOLD:
        chance += (resentment - RESENTMENT_THRESHOLD) * RESENTMENT_ADD * 10

    # Dominance gap (killer stronger)
    if dom_gap > DOMINANCE_GAP_THRESHOLD:
        chance += (dom_gap - DOMINANCE_GAP_THRESHOLD) * DOMINANCE_GAP_ADD * 5

    # Faction hostility
    if faction_hostility > FACTION_HOSTILITY_THRESHOLD:
        chance += (faction_hostility - FACTION_HOSTILITY_THRESHOLD) * FACTION_HOSTILITY_ADD * 5

    # Dyad history
    prior = _dyad_prior_conflicts(actor, other)
    if prior > DYAD_CONFLICT_THRESHOLD:
        dyad_contrib = min((prior - DYAD_CONFLICT_THRESHOLD) * DYAD_CONFLICT_ADD,
                           DYAD_CONFLICT_CAP)
        chance += dyad_contrib

    # Desperation
    actor_stress = getattr(actor.state, "stress", 0.0)
    actor_resource = getattr(actor.state, "resource_stock", 1.0)
    if actor_stress > DESPERATION_STRESS_FLOOR or actor_resource < DESPERATION_RESOURCE_FLOOR:
        chance += DESPERATION_ADD

    # Warrior role
    if _is_warrior(actor):
        chance += WARRIOR_ROLE_ADD

    # Phase pressure
    chance += phase_conflict_pressure * PHASE_PRESSURE_ADD

    # Ecological modifier — abundance suppresses, extinction pressure escalates
    try:
        from ecological_context import lethality_eco_modifier
        chance += lethality_eco_modifier(eco_health, n_living)
    except Exception:
        pass

    return clamp(chance, lo=0.0, hi=MAX_LETHALITY_CHANCE)


def compute_survival_chance(victim: Any) -> float:
    """
    Probability victim survives a lethal attempt.
    Driven by resilience, stress headroom, and energy.
    """
    resilience = getattr(victim.traits, "resilience", 0.5)
    stress = getattr(victim.state, "stress", 0.5)
    stress_limit = getattr(victim.traits, "stress_limit", 1.0)
    stress_headroom = clamp(stress_limit - stress)
    energy = getattr(victim.state, "energy", 0.5)

    survival = (
        SURVIVAL_BASE
        + resilience * RESILIENCE_SURVIVAL_MULT
        + stress_headroom * STRESS_HEADROOM_MULT
        + energy * ENERGY_SURVIVAL_MULT
    )
    return clamp(survival)


# ── Main resolution ───────────────────────────────────────────────────────────

def resolve_lethality(
    actor: Any,
    other: Any,
    tick: int,
    phase_name: str,
    faction_hostility: float,
    phase_conflict_pressure: float,
    rng,
    genpsych_ledger: Any = None,
    eco_health: float = 0.5,
    n_living: int = 10,
) -> Optional[dict]:
    """
    Call this after a conflict outcome is determined.
    Returns a lethality event dict if escalation fires, else None.

    The caller is responsible for:
        - Checking agent.alive after this call
        - Recording the death via death_ledger
        - Appending the returned event to event_log
    """
    lethality_chance = compute_lethality_chance(
        actor, other, faction_hostility, phase_conflict_pressure,
        eco_health=eco_health, n_living=n_living,
    )

    if rng.random() > lethality_chance:
        return None  # Conflict stays non-lethal

    # Lethal intent fires — does victim survive?
    survival_chance = compute_survival_chance(other)
    victim_survives = rng.random() < survival_chance

    if victim_survives:
        # Near-death: victim survives but is badly damaged
        other.state.stress = clamp(other.state.stress + SURVIVOR_STRESS_SPIKE)
        other.state.energy = clamp(other.state.energy - 0.25)
        other.state.resource_stock = clamp(other.state.resource_stock - 0.15)
        r_other = other.relationships.get(actor.id)
        other.relationships.update_after_interaction(
            actor.id,
            trust_delta=-0.25,
            resentment_delta=SURVIVOR_RESENTMENT_SPIKE,
            attachment_delta=-0.15,
            influence_delta=0.0,
        )
        # Killer aftermath (failed kill — still psychologically costly)
        actor.state.stress = clamp(actor.state.stress + KILLER_STRESS_SPIKE * 0.5)
        actor.state.dominance = clamp(actor.state.dominance + KILLER_DOMINANCE_SPIKE * 0.4)

        return {
            "tick": tick,
            "phase": phase_name,
            "actor_id": actor.id,
            "event_type": "lethal_conflict",
            "participants": [other.id],
            "context": {
                "lethality_chance": round(lethality_chance, 4),
                "survival_chance": round(survival_chance, 4),
                "victim_survived": True,
                "killer_role": getattr(actor.traits, "role", "unknown"),
            },
            "impact": {
                "victim_stress": SURVIVOR_STRESS_SPIKE,
                "victim_energy": -0.25,
            },
            "outcome": "lethal_attempt_survived",
        }

    else:
        # Victim dies
        other.alive = False
        other._death_cause = "homicide"

        # Killer aftermath
        actor.state.dominance = clamp(actor.state.dominance + KILLER_DOMINANCE_SPIKE)
        actor.state.stress = clamp(actor.state.stress + KILLER_STRESS_SPIKE)

        # Killer belief update — threat from victim zeroes, but stress encodes
        actor.beliefs._get_agent_belief(other.id).threat = 0.0
        actor.beliefs._get_agent_belief(other.id).safety = clamp(
            actor.beliefs.get_safety(other.id) + 0.10
        )

        # Generational psychology: killing carries psychological burden
        if genpsych_ledger is not None:
            try:
                burden = getattr(actor, "_genpsych_burden", 0.0)
                actor._genpsych_burden = clamp(burden + KILLER_TRAUMA_BURDEN)
            except Exception:
                pass

        return {
            "tick": tick,
            "phase": phase_name,
            "actor_id": actor.id,
            "event_type": "lethal_conflict",
            "participants": [other.id],
            "context": {
                "lethality_chance": round(lethality_chance, 4),
                "survival_chance": round(survival_chance, 4),
                "victim_survived": False,
                "killer_role": getattr(actor.traits, "role", "unknown"),
                "victim_role": getattr(other.traits, "role", "unknown"),
            },
            "impact": {
                "victim_alive": False,
            },
            "outcome": "homicide",
        }
