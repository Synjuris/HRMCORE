from dataclasses import dataclass, field, asdict

@dataclass
class EnvironmentProfile:
    world_width:int=12; world_height:int=12; interaction_radius:int=2; resource_nodes:int=24; max_population:int=40
    phase_bias:dict=field(default_factory=dict)
@dataclass
class PopulationProfile:
    initial_agents:int=10; name_prefix:str='Agent'
@dataclass
class ScenarioProfile:
    name:str='default'; description:str='Default recovered HRM scenario'; tags:list=field(default_factory=lambda:['recovered','default'])
    environment:EnvironmentProfile=field(default_factory=EnvironmentProfile)
    population:PopulationProfile=field(default_factory=PopulationProfile)
    def as_dict(self): return asdict(self)

def load_scenario(name):
    p=ScenarioProfile(name=name or 'default')
    if name in ('large','scalable'):
        p.environment.world_width=25; p.environment.world_height=25; p.environment.resource_nodes=80; p.environment.max_population=80; p.population.initial_agents=25
    return p

def scenario_agent_names(pop):
    base=['Ada','Bruno','Cleo','Dax','Eli','Faye','Gio','Hana','Ira','Juno','Kira','Lio','Mara','Nico','Orin','Pia','Quin','Rhea','Sol','Tala']
    return [base[i] if i<len(base) else f'{getattr(pop,"name_prefix","Agent")}_{i+1:02d}' for i in range(getattr(pop,'initial_agents',10))]

def apply_population_profile(agent, i, n, population, world=None, seed=0):
    agent.generation=getattr(agent,'generation',0)
    return agent

def summarize_scenario_agents(agents, prefix='scenario'):
    return {f'{prefix}_agent_count':len(agents)}
