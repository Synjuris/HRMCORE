"""
run_validation_suite.py — HRM v4.56 validation entry point.

Run from das/ directory:
    PYTHONHASHSEED=0 python run_validation_suite.py

The PYTHONHASHSEED=0 prefix is required for reproducibility tests to pass.
"""

import os
import sys

# ── Determinism guard ─────────────────────────────────────────────────────────
# Must be set before any Python dict/set with string keys is created.
# If already set externally, respect that value; else enforce 0.
if os.environ.get("PYTHONHASHSEED") not in ("0",):
    print("[WARNING] PYTHONHASHSEED is not '0'. "
          "Reproducibility tests may fail due to non-deterministic hash order.")

from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
sys.path.insert(0, str(Path(__file__).parent.parent / "core"))

from kernel.config import KernelConfig, make_exp_E_config
from kernel.validation import ValidationHarness, write_scheduler_report
from kernel.schedulers import (
    SequentialScheduler, ShuffledScheduler,
    PartialScheduler, CadenceScheduler,
)


def make_runtime(cfg: KernelConfig, seed: int):
    """Factory: build a fresh HRMRuntime from cfg, overriding seed."""
    from kernel.runtime import HRMRuntime
    from kernel.experiment_setup import setup_experiment

    cfg_copy = KernelConfig(**{**cfg.to_dict(), "seed": seed,
                               "groups": cfg.groups})
    rt = HRMRuntime(cfg_copy)
    rt.build_world()
    setup_experiment(rt)
    return rt


def main():
    # Use a small config so the suite completes quickly
    cfg = make_exp_E_config(ticks=200, output_root="/tmp/hrm_validation_suite")

    harness = ValidationHarness(make_runtime)
    schedulers = [
        SequentialScheduler(),
        ShuffledScheduler(),
        PartialScheduler(activation_ratio=0.4),
        CadenceScheduler(),
    ]

    report = harness.run_suite(cfg, seed=cfg.seed, schedulers=schedulers)

    output_dir = cfg.output_root
    write_scheduler_report(report["scheduler_results"], output_dir)

    # Write a combined summary
    import json
    from pathlib import Path as P
    P(output_dir).mkdir(parents=True, exist_ok=True)
    summary_path = P(output_dir) / "validation_summary.json"
    summary_path.write_text(json.dumps(report, indent=2, default=str),
                            encoding="utf-8")
    print(f"\nSummary written to {summary_path}")
    print(f"Reproducibility: {'PASS' if report['reproducibility_pass'] else 'FAIL'}")


if __name__ == "__main__":
    main()
