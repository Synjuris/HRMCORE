
"""
subjective_memory.py — HRM v04.43 subjective narrative abstraction layer.

Purpose:
Convert repeated raw social interactions into persistent interpreted beliefs.

This is NOT ideology, religion, or advanced cognition.
This is the first abstraction layer between:
    raw event logs
and:
    interpreted social reality.

Core outcome:
Agents stop remembering ONLY events and begin remembering conclusions.

Examples:
    "Marcus humiliates weakness."
    "Priya protects distressed people."
    "Dominic abandons allies under pressure."

These beliefs bias future interaction weighting and emotional continuity.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Any
from collections import defaultdict


@dataclass
class SubjectiveBelief:
    target_id: str
    summary: str
    valence: float
    confidence: float
    evidence_count: int = 0


class SubjectiveMemory:
    def __init__(self):
        self.social_patterns: Dict[str, Dict[str, float]] = defaultdict(dict)
        self.subjective_beliefs: Dict[str, SubjectiveBelief] = {}

    def observe_interaction(self,
                            target_id: str,
                            interaction_type: str,
                            emotional_weight: float):
        pattern = self.social_patterns.setdefault(target_id, {})
        pattern[interaction_type] = pattern.get(interaction_type, 0.0) + emotional_weight

    def synthesize(self):
        """
        Compress recurring interaction patterns into narrative beliefs.
        """
        for target_id, patterns in self.social_patterns.items():

            hostility = patterns.get("hostility", 0.0)
            support = patterns.get("support", 0.0)
            abandonment = patterns.get("abandonment", 0.0)
            protection = patterns.get("protection", 0.0)

            summary = None
            valence = 0.0

            if hostility > 3.0:
                summary = "perceived_public_humiliator"
                valence = -0.7

            elif abandonment > 3.0:
                summary = "perceived_unreliable_under_pressure"
                valence = -0.5

            elif protection > 3.0:
                summary = "perceived_protector"
                valence = 0.7

            elif support > 3.0:
                summary = "perceived_supportive"
                valence = 0.5

            if summary:
                existing = self.subjective_beliefs.get(target_id)

                confidence = min(
                    1.0,
                    (
                        hostility
                        + support
                        + abandonment
                        + protection
                    ) / 10.0
                )

                belief = SubjectiveBelief(
                    target_id=target_id,
                    summary=summary,
                    valence=valence,
                    confidence=confidence,
                    evidence_count=int(
                        hostility
                        + support
                        + abandonment
                        + protection
                    ),
                )

                self.subjective_beliefs[target_id] = belief

    def get_bias(self, target_id: str) -> float:
        belief = self.subjective_beliefs.get(target_id)
        if not belief:
            return 0.0
        return belief.valence * belief.confidence

    def snapshot(self) -> Dict[str, Any]:
        return {
            target_id: {
                "summary": belief.summary,
                "valence": belief.valence,
                "confidence": belief.confidence,
                "evidence_count": belief.evidence_count,
            }
            for target_id, belief in self.subjective_beliefs.items()
        }
