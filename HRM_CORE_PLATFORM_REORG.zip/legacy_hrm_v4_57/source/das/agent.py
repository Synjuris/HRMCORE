import random
from typing import List, Optional

from schemas import AgentState, DevelopmentalTraits, Event, new_id
from memory import Memory
from relationships import RelationshipBook
from adaptation import apply_environment_to_state, irreversible_update
from beliefs import BeliefMemory
from space import Position

# Layer imports (in implementation order)
from goals import GoalStack
from planning import Planner
from deception import DeceptionModule
from specialization import SpecializationModule
from language import LanguageModule
from experiential import ExperientialMemory, apply_experience_from_event
from subjective_memory import SubjectiveMemory
import pressures as pressure_mod
import constraints as constraint_mod
import context_adaptation as context_mod
import lethality as lethality_mod
import generational as generational_mod
import apprenticeship as apprenticeship_mod
import governance as governance_mod
import biology as biology_mod
try:
    from spatial_memory import SpatialMemory as _SpatialMemory
    _SPATIAL_MEMORY_AVAILABLE = True
except ImportError:
    _SPATIAL_MEMORY_AVAILABLE = False
import innovation as innovation_mod
import psychology as psychology_mod
import development as development_mod


GOAL_RESET_INTERVAL = 50   # ticks between goal achieved-resets


class Agent:
    def __init__(self, name: str, seed: int, spatial_world=None,
                 faction_registry=None, culture_pool=None) -> None:
        self.id = new_id("agent")
        self.name = name
        self.rng = random.Random(seed)
        self.generation = 0

        self.position = spatial_world.random_position(self.rng) if spatial_world else Position(0, 0)

        self.state = AgentState(
            # v04.43: founder age shifted to 80–180 (pre-peak to peak
            # reproductive range). Prior range 140–300 put many founders
            # past libido peak before tick 1, collapsing the reproductive
            # window and causing generational handoff failure. Male libido
            # peaks at 180, female at 260 — founders now enter with a full
            # reproductive runway before senescence.
            age=self.rng.randint(80, 180),
            energy=self.rng.uniform(0.45, 0.85),
            stress=self.rng.uniform(0.05, 0.35),
            curiosity=self.rng.uniform(0.25, 0.80),
            fear=self.rng.uniform(0.05, 0.45),
            cooperation=self.rng.uniform(0.20, 0.80),
            dominance=self.rng.uniform(0.20, 0.80),
            stability=self.rng.uniform(0.40, 0.80),
            social_openness=self.rng.uniform(0.20, 0.80),
            resource_stock=self.rng.uniform(0.30, 0.70),
        )

        # v04.38: include the role families that later systems depend on.
        # Previously care/knowledge/craft/logistics were possible in downstream
        # code but almost absent at initialization, leaving recovery and
        # cultural-memory mechanisms dormant.
        roles = ("generalist", "subsistence", "protection", "coordination", "diplomacy", "care", "knowledge", "craft", "logistics")
        self.traits = DevelopmentalTraits(
            stress_limit=self.rng.uniform(0.75, 1.00),
            recovery_speed=self.rng.uniform(0.03, 0.08),
            trust_baseline=self.rng.uniform(0.35, 0.65),
            conflict_sensitivity=self.rng.uniform(0.30, 0.70),
            risk_tolerance=self.rng.uniform(0.30, 0.70),
            attachment_rate=self.rng.uniform(0.02, 0.08),
            avoidance_rate=self.rng.uniform(0.02, 0.08),
            resilience=self.rng.uniform(0.35, 0.75),
            role=self.rng.choice(roles),
            generational_fitness=self.rng.uniform(0.30, 0.70),
            language_aptitude=self.rng.uniform(0.20, 0.80),
            ideology_sensitivity=self.rng.uniform(0.20, 0.80),
        )

        # Core v03 subsystems
        self.memory = Memory()
        self.beliefs = BeliefMemory()
        self.relationships = RelationshipBook()
        self.experience = ExperientialMemory()
        self.subjective_memory = SubjectiveMemory()
        # Spatial Agency Layer v1 — cognitive map of zone yield quality
        if _SPATIAL_MEMORY_AVAILABLE:
            self.spatial_memory = _SpatialMemory()
        else:
            self.spatial_memory = None
        self.home_zone_id: str = ""   # set by movement_goals.init_agent_movement
        self._last_move_tick: int = -999
        self.alive = True
        self._death_cause: str = "unknown"   # set by check_death()
        self.aux_events = []  # side-channel events emitted during a tick

        # v04.20 constraint/survival layer
        constraint_mod.init_agent_constraints(self)
        generational_mod.init_agent(self)
        apprenticeship_mod.init_agent(self)
        governance_mod.init_agent(self)
        biology_mod.init_agent(self)
        innovation_mod.init_agent(self)

        # v04 subsystems (all optional refs to world-level registries)
        self.goals = GoalStack(self.rng)                      # Layer 1
        # Layer 2: resources handled by ResourceWorld (world-level)
        self.planner = Planner(self.rng)                      # Layer 3
        # Layer 4: factions handled by FactionRegistry (world-level)
        self.faction_registry = faction_registry              # ref
        # Layer 5: territory handled by TerritoryMap (world-level)
        # Layer 6: deception
        self.deception = DeceptionModule(self.rng)            # Layer 6
        # Layer 7: specialization
        self.specialization = SpecializationModule()          # Layer 7
        # Layer 8: institutions handled by InstitutionRegistry (world-level)
        # Layer 9: culture handled by CulturePool (world-level); seed on init
        if culture_pool:
            culture_pool.seed_agent(self.id, self.rng)
        # Layer 10: reproduction handled by ReproductionSystem (world-level)
        # Layer 11: language
        self.language = LanguageModule()                      # Layer 11

    # ─────────────────────────────────────────────────────────────────────────
    def tick(self, tick: int, phase, population: List["Agent"],
             spatial_world=None,
             resource_world=None,
             faction_registry=None,
             territory_map=None,
             institution_registry=None,
             culture_pool=None,
             world_narrative=None,
             texture_chronicle=None,
             governance_ledger=None,
             eco_health: float = 0.5) -> Optional[Event]:

        if not self.alive:
            return None

        self._governance_ledger = governance_ledger
        self._population_ref = population
        self._eco_health = eco_health
        self.state.age += 1
        biology_mod.update_libido(self)
        self.experience.decay()

        # ── v04.31: developmental stage + psychology per-tick ────────────────
        self._dev_summary  = development_mod.tick_development(self, tick)
        self._psych_summary = psychology_mod.tick_psychology(self, tick, faction_registry)

        # ── v04.20: finite capacity + survival pressure ─────────────────────
        constraint_mod.begin_tick(self, phase, tick)

        # ── Spatial movement ─────────────────────────────────────────────────
        if spatial_world:
            old_x, old_y = self.position.x, self.position.y
            spatial_world.move_agent(self, phase)
            moved_distance = spatial_world.distance(Position(old_x, old_y), self.position)
            if moved_distance > 0:
                if hasattr(spatial_world, "logistics_world") and spatial_world.logistics_world:
                    info = spatial_world.logistics_world.record_travel(moved_distance, self.position)
                    moved_distance = info.get("travel_cost", moved_distance)
                self.aux_events.append(constraint_mod.spend_movement(self, moved_distance, tick, phase.name))

        # ── Layer 1: Goal update ─────────────────────────────────────────────
        self.goals.update(self.state, self.traits, agent=self, eco_health=eco_health)
        if tick % GOAL_RESET_INTERVAL == 0:
            self.goals.reset_achieved()
        active_goal = self.goals.active

        # ── Layer 2: Resource harvest + consumption ──────────────────────────
        if resource_world:
            if active_goal.label in ("acquire_resource", "survive") or self.state.resource_stock < 0.45 or self.state.hunger > 0.45:
                gained = resource_world.harvest(self, self.position)
                if gained > 0:
                    if hasattr(resource_world, "logistics_world") and resource_world.logistics_world:
                        adjusted = resource_world.logistics_world.modulate_harvest(self, gained)
                        storage_event = resource_world.logistics_world.attempt_storage_withdrawal(self, tick, phase.name)
                        if storage_event:
                            self.aux_events.append(storage_event)
                        gained = adjusted or gained
                    self.aux_events.append(constraint_mod.spend_resource_action(self, tick, phase.name, gained))
            resource_world.consume(self)

        # ── Core environment pressure ────────────────────────────────────────
        apply_environment_to_state(self.state, self.traits, phase)

        # ── v04.15: per-tick pressure state updates ───────────────────────────
        pressure_mod.update_novelty_saturation(self, phase.novelty)
        pressure_mod.update_ideology_alignment(self, faction_registry)
        # Novelty saturation dampens curiosity gain — correct the raw env boost
        # by removing the oversupply from high-saturation states.
        if phase.novelty > 0.0 and self.state.novelty_saturation > 0.0:
            raw_boost = phase.novelty * 0.05
            eff_boost = pressure_mod.apply_novelty_to_curiosity(self, phase.novelty) * 0.05
            correction = raw_boost - eff_boost   # amount to subtract
            self.state.curiosity = max(0.0, self.state.curiosity - correction)

        # ── Layer 5: Territory effects ───────────────────────────────────────
        extra_conflict_pressure = 0.0
        if territory_map and faction_registry:
            extra_conflict_pressure += territory_map.apply_territory_effects(self, faction_registry)
            # Claim current cell if in a faction
            faction = faction_registry.faction_of(self.id)
            if faction:
                territory_map.claim(self.position.x, self.position.y, faction.id)

        # ── Belief-modulated fear ────────────────────────────────────────────
        phase_risk = self.beliefs.get_phase_risk(phase.name)
        if phase_risk > 0.55:
            self.state.social_openness = max(0.0, self.state.social_openness - phase_risk * 0.035)
            self.state.fear = min(1.0, self.state.fear + phase_risk * 0.015)

        # ── Layer 8: Institution conflict suppression ─────────────────────────
        # InstitutionRegistry.tick() is world-level only. Calling it here caused
        # institutions to age/tax/apply bonuses once per agent per tick.
        inst_suppression = 0.0
        if institution_registry:
            inst_suppression = institution_registry.inst_conflict_suppression(
                self.id,
                governance_ledger=getattr(self, "_governance_ledger", None),
                faction_registry=faction_registry,
            )

        # ── Social target selection ───────────────────────────────────────────
        candidates = spatial_world.nearby_agents(self, population) if spatial_world else [
            a for a in population if a.id != self.id and a.alive
        ]
        other = self.choose_social_target(candidates, phase.social_density)

        # ── Layer 3: Planning ─────────────────────────────────────────────────
        target_id = other.id if other else None
        if self.planner.current_plan is None or self.planner.current_plan.completed:
            self.planner.form_plan(active_goal, tick, self.state, target_id)

        # ── Interaction or solo ───────────────────────────────────────────────
        if other:
            distance = spatial_world.distance(self.position, other.position) if spatial_world else None

            # ── Layer 6: Deception attempt ────────────────────────────────────
            deception_event = None
            if self.deception.should_attempt_deception(self, other):
                deception_event = self.deception.execute_deception(self, other, tick)
                self.aux_events.append(Event(
                    tick=tick,
                    phase=phase.name,
                    actor_id=self.id,
                    event_type="deception",
                    participants=[other.id],
                    context={
                        "actor": self.id,
                        "target": other.id,
                        "deception_score": round(self.state.dominance * self.traits.risk_tolerance, 4),
                        "actor_dominance": round(self.state.dominance, 4),
                        "actor_risk_tolerance": round(self.traits.risk_tolerance, 4),
                    },
                    impact={},
                    outcome=deception_event.get("outcome", "deception_unknown"),
                ))

            event = self.interact(tick, phase, other,
                                  distance=distance,
                                  extra_conflict_pressure=extra_conflict_pressure,
                                  inst_suppression=inst_suppression)

            # v04.15: update status security after outcome is known
            pressure_mod.update_status_security(self, event.outcome)
            self.aux_events.append(constraint_mod.spend_social_action(self, other, event.outcome, tick, phase.name))
            if event.outcome == "conflict":
                injury_event = constraint_mod.maybe_injure_from_conflict(self, other, tick, phase.name, self.rng)
                if injury_event:
                    self.aux_events.append(injury_event)

            # ── v04.7: subjective experiential memory and symbolic artifacts
            apply_experience_from_event(self, other, event, tick, texture_chronicle)
            if texture_chronicle:
                artifact = texture_chronicle.maybe_create_artifact(tick, self, event, self.rng)
                if artifact:
                    self.aux_events.append(Event(
                        tick=tick, phase=phase.name, actor_id=self.id,
                        event_type="artifact", participants=[other.id],
                        context={"artifact_id": artifact.id, "label": artifact.label, "kind": artifact.kind, "valence": artifact.valence},
                        impact={"symbolic_strength": artifact.strength},
                        outcome="artifact_created",
                    ))

            # ── Layer 4: Faction dynamics ─────────────────────────────────────
            if faction_registry:
                if event.outcome == "cooperation":
                    faction_registry.try_join(self, other)
                elif event.outcome == "conflict":
                    faction_registry.try_split(self)
                    faction_registry.update_hostility(self.id, other.id, +0.03)

            # ── Layer 9: Culture spread ────────────────────────────────────────
            if culture_pool and event.outcome == "cooperation":
                culture_pool.try_spread(other.id, self.id, self.rng, self.state.social_openness)

            # ── Layer 11: Language utterance ──────────────────────────────────
            utterance = self.language.emit_utterance(self, event.outcome)
            self.language.tick(self, had_cooperation=(event.outcome == "cooperation"),
                               had_conflict=(event.outcome == "conflict"))

            # ── v04.57: subjective belief accumulation ────────────────────────
            # Feed each resolved interaction into the pattern accumulator so
            # synthesize() has evidence to build conclusions from.
            # Emotional weight is scaled by stress at time of event so
            # high-stakes interactions write more strongly than routine ones.
            _sm = self.subjective_memory
            _r  = self.relationships.get(other.id)
            _stress_weight = 0.5 + self.state.stress * 0.5
            if event.outcome == "conflict":
                # Conflict from a high-resentment dyad → hostility pattern
                # Conflict from a trusted dyad (betrayal) → abandonment pattern
                if _r.resentment > 0.35:
                    _sm.observe_interaction(other.id, "hostility",
                                            _stress_weight * (0.6 + _r.resentment * 0.4))
                else:
                    _sm.observe_interaction(other.id, "abandonment",
                                            _stress_weight * 0.7)
            elif event.outcome == "cooperation":
                # Cooperation during high stress → protection pattern
                # Routine cooperation → support pattern
                if self.state.stress > 0.55 or event.context.get("negotiated"):
                    _sm.observe_interaction(other.id, "protection",
                                            _stress_weight * 0.9)
                else:
                    _sm.observe_interaction(other.id, "support",
                                            0.4 + _r.attachment * 0.4)

        else:
            event = self.solo_event(tick, phase)
            self.language.tick(self, had_cooperation=False, had_conflict=False)

        # ── Goal progress ─────────────────────────────────────────────────────
        if event.outcome == "cooperation" and active_goal.label == "bond":
            self.goals.record_progress("bond", 0.10)
        elif event.outcome == "conflict" and active_goal.label == "dominate":
            self.goals.record_progress("dominate", 0.08)
        elif resource_world and active_goal.label == "acquire_resource":
            self.goals.record_progress("acquire_resource",
                                       self.state.resource_stock * 0.05)

        self.state.goal_satisfaction = self.goals.active.progress

        # ── Layer 3: Plan step ─────────────────────────────────────────────────
        step = self.planner.step_plan(event.outcome)
        self.planner.update_state_confidence(self.state)

        # ── Layer 7: Specialization ────────────────────────────────────────────
        self.specialization.tick(self, event.outcome)

        # ── Layer 9: Cultural alignment effect ────────────────────────────────
        if culture_pool:
            culture_pool.update_agent_alignment(self)
            culture_pool.apply_alignment_effects(self)

        # ── World narrative record ─────────────────────────────────────────────
        if world_narrative and (event.outcome in ("conflict", "cooperation") or
                                 self.state.linguistic_complexity > 0.50):
            world_narrative.record(
                tick, self.name, event.outcome, event.participants,
                extra={"role": self.traits.role, "lc": round(self.state.linguistic_complexity, 3)}
            )

        # ── Memory and beliefs ─────────────────────────────────────────────────
        self._last_event = event
        self.memory.add(event)
        self.beliefs.update_from_event(event)

        # ── v04.57: periodic subjective synthesis ────────────────────────────
        # Compress accumulated interaction patterns into persistent social
        # conclusions every 25 ticks. Offset by agent id hash so agents don't
        # all synthesize on the same tick.
        _synthesis_offset = hash(self.id) % 25
        if (tick + _synthesis_offset) % 25 == 0:
            self.subjective_memory.synthesize()

        recovery_event = constraint_mod.recover(self, tick, phase.name)
        if recovery_event:
            self.aux_events.append(recovery_event)

        irreversible_update(self.state, self.traits)
        self.check_death()

        return event

    # ─────────────────────────────────────────────────────────────────────────
    def choose_social_target(self, candidates: List["Agent"],
                             social_density: float) -> Optional["Agent"]:
        candidates = [a for a in candidates if a.alive]
        if not candidates:
            return None

        # v04.37 viability pass: the previous formula could drive contact
        # effectively to zero after fear/scarcity, starving every downstream
        # system. Keep context sensitivity, but add a small floor and a
        # low-population/social-drive recovery term.
        low_pop_bonus = 0.12 if len(candidates) <= 4 else 0.0
        contact_drive = getattr(self, 'social_viability_drive', 0.0)
        interaction_chance = max(0.16, min(0.95,
            social_density * self.state.social_openness * (1.0 - self.state.fear * 0.32)
            + low_pop_bonus + contact_drive
        ))
        if self.rng.random() > interaction_chance:
            return None

        weighted = []
        for c in candidates:
            r = self.relationships.get(c.id)
            remembered_safety = self.beliefs.get_safety(c.id)
            remembered_threat = self.beliefs.get_threat(c.id)

            # Faction bonus: prefer allies
            faction_bonus = 0.0
            if self.faction_registry and self.faction_registry.same_faction(self.id, c.id):
                faction_bonus = 0.30

            # v04.57: subjective social conclusion bias
            # Agents who have formed a persistent belief about someone
            # (perceived_protector, perceived_humiliator, etc.) let that
            # conclusion weight their target selection — not just raw events.
            subjective_bias = self.subjective_memory.get_bias(c.id)

            weight = (
                0.15
                + r.trust * 0.70
                + r.attachment * 0.80
                + remembered_safety * 0.65
                - r.avoidance * 0.80
                - r.resentment * 0.90
                - remembered_threat * 1.10
                + faction_bonus
                + subjective_bias * 0.55
            )
            weighted.append((max(0.01, weight), c))

        total = sum(w for w, _ in weighted)
        pick = self.rng.random() * total
        running = 0.0
        for weight, candidate in weighted:
            running += weight
            if running >= pick:
                return candidate
        return candidates[0]

    # ─────────────────────────────────────────────────────────────────────────
    def interact(self, tick: int, phase, other: "Agent",
                 distance=None,
                 extra_conflict_pressure: float = 0.0,
                 inst_suppression: float = 0.0) -> Event:

        r = self.relationships.get(other.id)
        remembered_safety = self.beliefs.get_safety(other.id)
        remembered_threat = self.beliefs.get_threat(other.id)
        phase_risk = self.beliefs.get_phase_risk(phase.name)

        # Inter-faction hostility modifier
        faction_hostility = 0.0
        same_faction = False
        if self.faction_registry:
            faction_hostility = self.faction_registry.inter_faction_hostility(self.id, other.id)
            same_faction = self.faction_registry.same_faction(self.id, other.id)

        # v04.15: pressure contributions (status security + ideology)
        pcontrib = pressure_mod.compute_pressure_contributions(self, other, same_faction)

        # v04.20.1: contextual adaptive value. Behavior costs/rewards are not
        # fixed moral constants; they shift with scarcity, interdependence, and
        # institutional/social complexity. This is deliberately generic: it
        # applies to cooperation/conflict as adaptive strategies, not to a
        # specific narrative category.
        adaptive_context = context_mod.compute_context(self, other, phase, inst_suppression)
        adaptive_adj = context_mod.interaction_pull_adjustments(adaptive_context)
        self._last_adaptive_context = adaptive_context

        _attraction_pull = biology_mod.cooperation_pull_from_attraction(self, other)
        _valence_pull    = psychology_mod.valence_cooperation_add(self)
        cooperation_pull = (
            self.state.cooperation
            + r.trust
            + r.attachment
            + remembered_safety
            + pcontrib["status_coop_add"]
            + pcontrib["ideology_coop_add"]
            + adaptive_adj["cooperation_add"]
            - adaptive_adj["cooperation_subtract"]
            + _attraction_pull
            + _valence_pull
        ) / 1.9

        raw_conflict_pull = (
            phase.conflict_pressure
            + phase_risk * 0.30
            + self.state.stress
            + r.resentment
            + remembered_threat * 0.45
            + self.state.dominance * 0.15
            - r.trust * 0.20
            - remembered_safety * 0.15
            + extra_conflict_pressure
            + faction_hostility
            + pcontrib["status_conflict_add"]
            + pcontrib["ideology_conflict_add"]
            + adaptive_adj["conflict_add"]
            - adaptive_adj["conflict_subtract"]
            + biology_mod.male_competition_conflict_pressure(self, other, getattr(self, "_population_ref", []))
        )
        # v04.37: founder-band viability should make cooperation more likely
        # when local social infrastructure is being actively rebuilt. This is a
        # pressure modifier, not an outcome override.
        viability_drive = getattr(self, 'social_viability_drive', 0.0)
        cooperation_pull += viability_drive * 0.22
        conflict_pull = raw_conflict_pull - inst_suppression - viability_drive * 0.42
        institution_prevented_conflict = (
            raw_conflict_pull > cooperation_pull
            and conflict_pull <= cooperation_pull
            and inst_suppression > 0.0
        )

        # ── Layer 11: Negotiation attempt before conflict ─────────────────────
        # Trigger when conflict pressure is meaningful (> 0.15), not only when
        # it's already winning — in cooperative sims conflict_pull rarely exceeds
        # cooperation_pull so negotiation was never reaching the table.
        negotiated = False
        negotiation_attempted = False
        negotiation_pressure_gap = conflict_pull - cooperation_pull
        negotiation_trigger_noise = self.rng.uniform(-0.12, 0.12)
        NEGOTIATION_CONFLICT_FLOOR = 0.08  # v04.38: proto-negotiation fires at low but real conflict pressure
        # v04.38: negotiation should be visible but not spam every mildly tense
        # encounter. Attempt when conflict is near/overtaking cooperation, or
        # sample a minority of low-grade tensions as proto-mediation.
        should_attempt_negotiation = (
            conflict_pull > cooperation_pull - 0.06
            or (conflict_pull > NEGOTIATION_CONFLICT_FLOOR and self.rng.random() < 0.22)
        )
        if should_attempt_negotiation:
            negotiation_attempted = True
            negotiated = self.language.try_negotiate(self, other, self.rng)
            self.aux_events.append(Event(
                tick=tick,
                phase=phase.name,
                actor_id=self.id,
                event_type="negotiation",
                participants=[other.id],
                context={
                    "actor_lc": round(self.state.linguistic_complexity, 4),
                    "target_lc": round(other.state.linguistic_complexity, 4),
                    "raw_conflict_pull": round(raw_conflict_pull, 4),
                    "institution_suppression": round(inst_suppression, 4),
                    "final_conflict_pull": round(conflict_pull, 4),
                    "cooperation_pull": round(cooperation_pull, 4),
                    "pressure_gap": round(negotiation_pressure_gap, 4),
                    "trigger_noise": round(negotiation_trigger_noise, 4),
                    "suppressed_conflict": bool(negotiated),
                },
                impact={"stress": -0.5 if negotiated else 0.0},
                outcome="negotiation_success" if negotiated else "negotiation_failed",
            ))

        outcome_noise = self.rng.uniform(-0.12, 0.12)
        if negotiated or conflict_pull <= cooperation_pull + outcome_noise:
            outcome = "cooperation"
            stress_delta = -0.030
            trust_delta = 0.045
            resentment_delta = -0.025
            attachment_delta = self.traits.attachment_rate * 0.95
            influence_delta = 0.012
        else:
            outcome = "conflict"
            stress_delta = 0.006 + phase.conflict_pressure * 0.010
            trust_delta = -0.006
            resentment_delta = 0.010
            attachment_delta = -0.004
            influence_delta = 0.006

        self.state.stress = max(0.0, min(1.0, self.state.stress + stress_delta))

        self.relationships.update_after_interaction(
            other.id,
            trust_delta=trust_delta,
            resentment_delta=resentment_delta,
            attachment_delta=attachment_delta,
            influence_delta=influence_delta,
        )
        other.relationships.update_after_interaction(
            self.id,
            trust_delta=trust_delta * 0.60,
            resentment_delta=resentment_delta * 0.60,
            attachment_delta=attachment_delta * 0.60,
            influence_delta=influence_delta * 0.60,
        )

        # v04.43: agent-on-agent lethality. Fires only on conflict outcomes,
        # driven by resentment, dominance, faction hostility, dyad history,
        # desperation, and role. Rare but real — humans kill each other.
        if outcome == "conflict" and other.alive:
            _pop_ref = getattr(self, '_population_ref', []) or []
            _n_living = sum(1 for a in _pop_ref if getattr(a, 'alive', False))

            # v04.49 SRK forensic trace: capture the last threat/scarcity message
            # the actor held at the moment of lethal escalation. If the message
            # was mutated in transit, mutation_count and semantic_drift are non-zero,
            # making the rumor chain that led to this kill traceable.
            _inbox = getattr(self, 'inbox', None)
            _rumor_trace = None
            if _inbox is not None:
                for _ct in ("threat_near", "resource_scarce"):
                    _msg = _inbox.get(_ct)
                    if _msg is not None:
                        _rumor_trace = {
                            "content_type": _msg.content_type,
                            "source_id": _msg.source_id,
                            "origin_tick": _msg.origin_tick,
                            "fidelity": round(_msg.fidelity, 4),
                            "mutation_count": int(_msg.payload.get("mutation_count", 0)),
                            "semantic_drift": round(float(_msg.payload.get("semantic_drift", 0.0)), 4),
                            "precision_loss": round(float(_msg.payload.get("precision_loss", 0.0)), 4),
                            "cross_faction_pressure": round(float(_msg.payload.get("cross_faction_pressure", 0.0)), 4),
                            "payload_threat_level": round(float(_msg.payload.get("threat_level", _msg.payload.get("scarcity", 0.0))), 4),
                        }
                        break

            lethal_event = lethality_mod.resolve_lethality(
                actor=self,
                other=other,
                tick=tick,
                phase_name=phase.name,
                faction_hostility=faction_hostility,
                phase_conflict_pressure=phase.conflict_pressure,
                rng=self.rng,
                genpsych_ledger=getattr(self, "_genpsych_ledger_ref", None),
                eco_health=getattr(self, "_eco_health", 0.5),
                n_living=_n_living,
            )
            if lethal_event:
                # Embed rumor trace into event context
                if _rumor_trace is not None:
                    lethal_event["context"]["rumor_trace"] = _rumor_trace
                self.aux_events.append(Event(
                    tick=lethal_event["tick"],
                    phase=lethal_event["phase"],
                    actor_id=lethal_event["actor_id"],
                    event_type=lethal_event["event_type"],
                    participants=lethal_event["participants"],
                    context=lethal_event["context"],
                    impact=lethal_event["impact"],
                    outcome=lethal_event["outcome"],
                ))

        return Event(
            tick=tick,
            phase=phase.name,
            actor_id=self.id,
            event_type="interaction",
            participants=[other.id],
            context={
                "social_density": phase.social_density,
                "conflict_pressure": phase.conflict_pressure,
                "remembered_safety": remembered_safety,
                "remembered_threat": remembered_threat,
                "phase_risk": phase_risk,
                "faction_hostility": faction_hostility,
                "cooperation_pull": round(cooperation_pull, 4),
                "raw_conflict_pull": round(raw_conflict_pull, 4),
                "institution_suppression": round(inst_suppression, 4),
                "final_conflict_pull": round(conflict_pull, 4),
                "institution_prevented_conflict": institution_prevented_conflict,
                "inst_suppression": inst_suppression,
                "negotiation_attempted": negotiation_attempted,
                "negotiated": negotiated,
                "outcome_noise": round(outcome_noise, 4),
                "position": {"x": self.position.x, "y": self.position.y},
                "other_position": {"x": other.position.x, "y": other.position.y},
                "distance": distance,
                "active_goal": self.goals.active.label,
                "role": self.traits.role,
                "pressure_contributions": pcontrib,
                "adaptive_context": adaptive_context,
                "adaptive_adjustments": adaptive_adj,
            },
            impact={"stress": stress_delta, "trust": trust_delta, "resentment": resentment_delta},
            outcome=outcome,
        )

    # ─────────────────────────────────────────────────────────────────────────
    def solo_event(self, tick: int, phase) -> Event:
        if phase.rest_quality > 0.70:
            outcome = "recover"
            stress_delta = -self.traits.recovery_speed * (0.90 + self.traits.resilience * 0.30)
        elif phase.novelty > 0.70:
            outcome = "explore"
            stress_delta = -0.005 if self.state.curiosity > self.state.fear else 0.006
            self.state.curiosity = min(1.0, self.state.curiosity + 0.025)
        else:
            outcome = "endure"
            stress_delta = phase.stress_load * 0.012

        self.state.stress = max(0.0, min(1.0, self.state.stress + stress_delta))

        return Event(
            tick=tick,
            phase=phase.name,
            actor_id=self.id,
            event_type="solo",
            participants=[],
            context={
                "phase": phase.name,
                "position": {"x": self.position.x, "y": self.position.y},
                "active_goal": self.goals.active.label,
                "role": self.traits.role,
            },
            impact={"stress": stress_delta},
            outcome=outcome,
        )

    # ─────────────────────────────────────────────────────────────────────────
    def check_death(self) -> None:
        # v04.37 viability guard: the last founder remnants should not be
        # removed by a single scalar pressure while the continuity system is
        # trying to recover contact topology. This does not make agents immortal;
        # it gives small populations a bounded refuge window.
        pop = getattr(self, '_population_ref', []) or []
        living_count = sum(1 for a in pop if getattr(a, 'alive', False))
        # v04.40 settlement/demographic stability: children and last small-
        # group adults get a bounded survival buffer so runs can express
        # multi-generation dynamics instead of deleting the population before
        # settlement/institution systems have time to operate.
        age = getattr(self.state, 'age', 0)
        if (living_count <= 3 and age < 1200) or age < 300 or getattr(self, 'generation', 0) > 0:
            self.state.stress = min(self.state.stress, 0.86)
            self.state.energy = max(self.state.energy, 0.16 if age < 300 else 0.13)
            self.state.resource_stock = max(self.state.resource_stock, 0.06)
            if self.state.stress < self.traits.stress_limit:
                self.state.collapse_strikes = max(0, self.state.collapse_strikes - 2)
            elif age < 300:
                self.state.collapse_strikes = max(0, self.state.collapse_strikes - 1)
            if living_count <= 2 and age < 1200:
                self.state.collapse_strikes = 0
                return

        if self.state.stress >= self.traits.stress_limit:
            self.state.collapse_strikes += 1
        else:
            self.state.collapse_strikes = max(0, self.state.collapse_strikes - 1)

        if self.state.collapse_strikes >= 35:
            self.alive = False
            self._death_cause = "stress_collapse"

        if self.state.energy <= 0.02 and self.state.stability <= 0.10:
            self.alive = False
            self._death_cause = "energy_stability_failure"

        # Starvation death
        if self.state.resource_stock <= 0.0 and self.state.energy <= 0.10:
            self.alive = False
            self._death_cause = "starvation"

    # ─────────────────────────────────────────────────────────────────────────
    def snapshot(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "alive": self.alive,
            "generation": self.generation,
            "household_id": getattr(self, "household_id", None),
            "parent_ids": getattr(self, "parent_ids", []),
            "birth_tick": getattr(self, "birth_tick", None),
            "role": self.traits.role,
            "position": {"x": self.position.x, "y": self.position.y},
            "state": vars(self.state).copy(),
            "traits": vars(self.traits).copy(),
            "beliefs": self.beliefs.snapshot(),
            "relationships": self.relationships.snapshot(),
            "experience": self.experience.snapshot(),
            "memory_count": self.memory.compression_stats()["total_interactions_indexed"],
            "goals": self.goals.snapshot(),
            "plan": self.planner.snapshot(),
            "specialization": self.specialization.snapshot(self),
            "deception": self.deception.snapshot(),
            "language": {
                "linguistic_complexity": round(self.state.linguistic_complexity, 4),
                "recent_utterances": self.language.utterances[-5:],
            },
            "apprenticeship": {
                "mentor_id": getattr(self, "mentor_id", None),
                "skill_transfer_given": getattr(self, "skill_transfer_given", 0),
                "skill_transfer_received": getattr(self, "skill_transfer_received", 0),
            },
            "governance": {
                "is_leader": getattr(self, "is_leader", False),
                "compliance_count": getattr(self, "compliance_count", 0),
                "defiance_count": getattr(self, "defiance_count", 0),
            },
            "innovation": {
                **getattr(self, "practice_memory",
                    innovation_mod.PracticeMemory()).snapshot(),
                "innovation_attempts": getattr(self, "innovation_attempts", 0),
                "innovation_successes": getattr(self, "innovation_successes", 0),
            },
            "biology": {
                "biological_sex": getattr(self, "biological_sex", "unknown"),
                "sexual_orientation": round(getattr(self, "sexual_orientation", 0.0), 4),
                "physical_attractiveness": round(getattr(self, "physical_attractiveness", 0.5), 4),
                "libido": round(getattr(self, "libido", 0.0), 4),
                "gestation_ticks_remaining": getattr(self, "gestation_ticks_remaining", 0),
            },
            "psychology": {
                "valence": round(self.state.valence, 4),
                "identity_tags": list(self.experience.identity_tags),
                "scars": round(self.experience.scars, 4),
                "top_grudge": self.experience.top_grudge(),
                "top_bond": self.experience.top_bond(),
            },
            "development": development_mod.snapshot(self),
        }
