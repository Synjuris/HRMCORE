"""
movement_goals.py — HRM Spatial Agency Layer v1

Replaces random drift with goal-directed movement.
Each tick an agent evaluates a priority-ordered goal set and
moves toward the best target position.

Priority order:
  1. Survival  — hungry → best remembered food zone
  2. Social    — stable → trusted partner / known trade contact
  3. Care      — care-role → attached low-energy agent
  4. Explore   — well-fed and stable → unknown or long-unvisited zone
  5. Home      — default → home range center

Movement is PROBABILISTIC not rigid:
  80% follow top goal
  20% noise / drift / social randomness

Inertia: agents have a recent_move_penalty that discourages
constantly switching zones. Prevents jittery teleporting behavior.

Home range: each agent has a home_zone_id (set at founding or
updated when a zone proves consistently good). Home pull is weak
but persistent — the default when nothing else pulls harder.
"""

from __future__ import annotations
import random
import math
from typing import Optional, Tuple, TYPE_CHECKING

if TYPE_CHECKING:
    from agent import Agent
    from spatial_zone import ZoneGrid
    from spatial_memory import SpatialMemory

# Movement speed — cells per tick maximum
MOVE_SPEED = 1.5

# Goal-follow probability — 20% noise built in
GOAL_FOLLOW_PROB = 0.80

# Inertia — ticks before agent is "free" to switch zones again
MOVE_INERTIA_TICKS = 8

# Hunger threshold to trigger survival goal
HUNGER_SURVIVAL_THRESHOLD = 0.50

# Trust threshold to trigger social goal
SOCIAL_TRUST_THRESHOLD = 0.55

# Stress ceiling — above this, social/explore goals suppressed
STRESS_SOCIAL_CEILING = 0.82

# Care goal — attachment floor to move toward struggling partner
CARE_ATTACHMENT_FLOOR = 0.50
CARE_TARGET_ENERGY_CEILING = 0.30

# Explore goal — minimum ticks since last visit to consider exploring
EXPLORE_MIN_AGE = 300

# Home pull strength relative to other goals (0-1)
HOME_PULL_STRENGTH = 0.35


def _distance(x1, y1, x2, y2) -> float:
    return math.sqrt((x2-x1)**2 + (y2-y1)**2)


def _zone_center(zone, grid: "ZoneGrid") -> Tuple[float, float]:
    """Return grid coordinates of zone center."""
    cx = (zone.col + 0.5) * grid.cell_w
    cy = (zone.row + 0.5) * grid.cell_h
    return cx, cy


def _move_toward(agent, tx: float, ty: float,
                 world_w: int, world_h: int,
                 speed: float = MOVE_SPEED) -> None:
    """Move agent position one step toward target."""
    px = getattr(agent.position, "x", 0.0)
    py = getattr(agent.position, "y", 0.0)
    dx = tx - px
    dy = ty - py
    dist = math.sqrt(dx*dx + dy*dy)
    if dist < 0.5:
        return
    step = min(speed, dist)
    nx = px + (dx / dist) * step
    ny = py + (dy / dist) * step
    agent.position.x = max(0.0, min(float(world_w - 1), nx))
    agent.position.y = max(0.0, min(float(world_h - 1), ny))


def _random_drift(agent, world_w: int, world_h: int,
                  rng: random.Random, speed: float = MOVE_SPEED) -> None:
    """Legacy random movement — used for noise component."""
    angle = rng.uniform(0, 2 * math.pi)
    tx = agent.position.x + math.cos(angle) * speed
    ty = agent.position.y + math.sin(angle) * speed
    agent.position.x = max(0.0, min(float(world_w - 1), tx))
    agent.position.y = max(0.0, min(float(world_h - 1), ty))


def get_home_zone_id(agent) -> Optional[str]:
    return getattr(agent, "home_zone_id", None)


def set_home_zone_id(agent, zone_id: str) -> None:
    agent.home_zone_id = zone_id


def get_last_move_tick(agent) -> int:
    return getattr(agent, "_last_move_tick", -999)


def set_last_move_tick(agent, tick: int) -> None:
    agent._last_move_tick = tick


def init_agent_movement(agent, zone_id: str) -> None:
    """Called at agent creation. Sets home zone and movement state."""
    agent.home_zone_id = zone_id
    agent._last_move_tick = -999


def evaluate_and_move(agent: "Agent", tick: int,
                      grid: "ZoneGrid",
                      population: list,
                      rng: random.Random,
                      world_w: int, world_h: int) -> str:
    """
    Evaluate movement goals and move agent one step.
    Returns the goal label that was pursued ('survival','social',
    'care','explore','home','noise').
    """
    if not getattr(agent, "alive", False):
        return "dead"

    # Inertia check — don't move every tick if recently moved
    last_move = get_last_move_tick(agent)
    inertia_ok = (tick - last_move) >= MOVE_INERTIA_TICKS

    # 20% noise regardless
    if rng.random() > GOAL_FOLLOW_PROB:
        _random_drift(agent, world_w, world_h, rng)
        set_last_move_tick(agent, tick)
        return "noise"

    sm: Optional["SpatialMemory"] = getattr(agent, "spatial_memory", None)
    state = agent.state
    hunger = getattr(state, "hunger", 0.0)
    stress = getattr(state, "stress", 0.5)
    energy = getattr(state, "energy", 0.5)

    # ── Goal 1: Survival ──────────────────────────────────────────────────────
    if hunger >= HUNGER_SURVIVAL_THRESHOLD and inertia_ok:
        target_zone_id = sm.best_zone(tick) if sm else None
        if target_zone_id and target_zone_id in grid.zones:
            tz = grid.zones[target_zone_id]
            tx, ty = _zone_center(tz, grid)
            _move_toward(agent, tx, ty, world_w, world_h)
            set_last_move_tick(agent, tick)
            return "survival"

    # ── Goal 2: Social ────────────────────────────────────────────────────────
    if stress < STRESS_SOCIAL_CEILING and inertia_ok:
        best_partner = _find_social_target(agent, population, tick)
        if best_partner is not None:
            tx = getattr(best_partner.position, "x", 20.0)
            ty = getattr(best_partner.position, "y", 20.0)
            _move_toward(agent, tx, ty, world_w, world_h)
            set_last_move_tick(agent, tick)
            return "social"

    # ── Goal 3: Care ──────────────────────────────────────────────────────────
    try:
        from adaptive_roles import role_family
        is_care = role_family(getattr(getattr(agent, "traits", None),
                                      "role", "")) == "care"
    except Exception:
        is_care = False

    if is_care and stress < STRESS_SOCIAL_CEILING and inertia_ok:
        care_target = _find_care_target(agent, population)
        if care_target is not None:
            tx = getattr(care_target.position, "x", 20.0)
            ty = getattr(care_target.position, "y", 20.0)
            _move_toward(agent, tx, ty, world_w, world_h)
            set_last_move_tick(agent, tick)
            return "care"

    # ── Goal 4: Explore ───────────────────────────────────────────────────────
    if hunger < 0.30 and stress < 0.70 and inertia_ok and sm:
        explore_zone = _find_explore_target(sm, grid, tick)
        if explore_zone:
            tx, ty = _zone_center(explore_zone, grid)
            _move_toward(agent, tx, ty, world_w, world_h)
            set_last_move_tick(agent, tick)
            return "explore"

    # ── Goal 5: Home ─────────────────────────────────────────────────────────
    home_zid = get_home_zone_id(agent)
    if home_zid and home_zid in grid.zones and rng.random() < HOME_PULL_STRENGTH:
        hz = grid.zones[home_zid]
        tx, ty = _zone_center(hz, grid)
        _move_toward(agent, tx, ty, world_w, world_h, speed=MOVE_SPEED * 0.6)
        return "home"

    # Default: random drift
    _random_drift(agent, world_w, world_h, rng, speed=MOVE_SPEED * 0.5)
    return "drift"


def _find_social_target(agent, population: list, tick: int):
    """Find highest-trust living partner within reasonable distance."""
    best = None
    best_score = SOCIAL_TRUST_THRESHOLD
    rels = getattr(agent, "relationships", None)
    if rels is None:
        return None
    ax = getattr(agent.position, "x", 20.0)
    ay = getattr(agent.position, "y", 20.0)
    for other in population:
        if not getattr(other, "alive", False) or other.id == agent.id:
            continue
        r = rels.get(other.id)
        score = r.trust + r.attachment * 0.5
        if score > best_score:
            best_score = score
            best = other
    return best


def _find_care_target(agent, population: list):
    """Find attached low-energy agent to move toward."""
    best = None
    best_need = 0.0
    rels = getattr(agent, "relationships", None)
    if rels is None:
        return None
    for other in population:
        if not getattr(other, "alive", False) or other.id == agent.id:
            continue
        r = rels.get(other.id)
        if r.attachment < CARE_ATTACHMENT_FLOOR:
            continue
        other_energy = getattr(other.state, "energy", 1.0)
        if other_energy < CARE_TARGET_ENERGY_CEILING:
            need = r.attachment * (CARE_TARGET_ENERGY_CEILING - other_energy)
            if need > best_need:
                best_need = need
                best = other
    return best


def _find_explore_target(sm: "SpatialMemory", grid: "ZoneGrid",
                         tick: int):
    """Find zone not recently visited or entirely unknown."""
    known = sm.known_zones()
    best_zone = None
    best_age = EXPLORE_MIN_AGE

    # Prefer unknown zones first
    unknown = [z for zid, z in grid.zones.items() if zid not in known]
    if unknown:
        import random as _rnd
        return _rnd.choice(unknown)

    # Otherwise find longest-unvisited known zone
    for zid, zm in known.items():
        age = tick - zm.last_tick
        if age > best_age:
            best_age = age
            best_zone = grid.zones.get(zid)
    return best_zone


def update_home_zone(agent, grid: "ZoneGrid", tick: int,
                     yield_obs: float) -> None:
    """
    Update agent's home zone if current zone is consistently better.
    Called after each subsistence event with observed yield.
    """
    sm: Optional["SpatialMemory"] = getattr(agent, "spatial_memory", None)
    if sm is None:
        return
    x = getattr(getattr(agent, "position", None), "x", 20.0)
    y = getattr(getattr(agent, "position", None), "y", 20.0)
    current_zid = grid.zone_id_for_position(x, y)
    home_zid = get_home_zone_id(agent)

    if home_zid is None:
        set_home_zone_id(agent, current_zid)
        return

    current_score = sm.score(current_zid, tick)
    home_score    = sm.score(home_zid, tick)

    # Only update home if current zone is meaningfully better
    # and agent has visited it enough to be confident
    zm = sm.known_zones().get(current_zid)
    if zm and zm.visit_count >= 3 and current_score > home_score * 1.25:
        set_home_zone_id(agent, current_zid)
