"""
Specialization — v04.34 adaptive capability ontology

This replaces fixed historical role assumptions with capability families.  The
mechanic no longer asks "is this a farmer/blacksmith/programmer era?"  It asks
which functional need is being reinforced by the agent's repeated behavior and
by current local pressures.  Human-readable labels are display-only and change
with emergent capability maturity.
"""
from schemas import DevelopmentalTraits, AgentState
from adaptive_roles import (
    capability_scores, role_family, infer_role_family, role_snapshot
)


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


# Capability-domain effects.  These are functional, not historical occupations.
ROLE_EFFECTS = {
    "subsistence":  {"resource_stock": +0.006, "energy": +0.002},
    "protection":  {"fear": -0.005, "stress": -0.004, "dominance": +0.003},
    "coordination": {"plan_confidence": +0.008, "stress": -0.002},
    "diplomacy":   {"social_openness": +0.006, "cooperation": +0.004, "fear": -0.003},
    "craft":       {"curiosity": +0.003, "plan_confidence": +0.003},
    "care":        {"stress": -0.003, "social_openness": +0.003},
    "knowledge":   {"linguistic_complexity": +0.0025, "curiosity": +0.002},
    "logistics":   {"resource_stock": +0.003, "plan_confidence": +0.003},
    "governance":  {"stability": +0.003, "cultural_alignment": +0.002},
    "information": {"linguistic_complexity": +0.002, "plan_confidence": +0.002},
    "generalist": {},
}

DEEPEN_RATE = 0.003
PASSIVE_SOFT_CAP = 0.35
PASSIVE_POST_CAP_MULTIPLIER = 0.25
PASSIVE_EFFECTIVE_MAX = 0.55


def effective_depth(depth: float) -> float:
    """Depth used for passive effects; observed depth still grows normally."""
    if depth <= PASSIVE_SOFT_CAP:
        return depth
    return min(PASSIVE_EFFECTIVE_MAX, PASSIVE_SOFT_CAP + (depth - PASSIVE_SOFT_CAP) * PASSIVE_POST_CAP_MULTIPLIER)


# Backward-compatible wrappers used by old reports/tests.
def role_scores(state: AgentState, traits: DevelopmentalTraits) -> dict:
    class _A: pass
    a = _A(); a.state = state; a.traits = traits
    return capability_scores(a)


def infer_natural_role(state: AgentState, traits: DevelopmentalTraits) -> str:
    class _A: pass
    a = _A(); a.state = state; a.traits = traits
    return infer_role_family(a)


class SpecializationModule:
    def __init__(self) -> None:
        pass

    def tick(self, agent, outcome: str) -> None:
        state = agent.state
        depth = state.specialization_depth
        current_family = role_family(getattr(agent.traits, "role", "generalist"))
        natural_family = infer_role_family(agent, outcome)

        # Keep stored role canonical.  Legacy saved roles are accepted but normalized.
        if getattr(agent.traits, "role", "generalist") != current_family:
            agent.traits.role = current_family

        matched = current_family == natural_family or current_family == "generalist"
        if matched:
            state.specialization_depth = clamp(depth + DEEPEN_RATE)
        else:
            state.specialization_depth = clamp(depth + DEEPEN_RATE * 0.2)

        scaled_depth = effective_depth(depth)
        for attr, delta in ROLE_EFFECTS.get(current_family, {}).items():
            if hasattr(state, attr):
                setattr(state, attr, clamp(getattr(state, attr) + delta * scaled_depth))

        # Drift only when pressure clearly favors a new capability family.
        # Threshold scales with depth — deeper specialization resists drift more.
        drift_threshold = 0.16 + clamp(depth * 0.30, 0.0, 0.25)
        scores = capability_scores(agent, outcome)
        current_score = scores.get(current_family, 0.35)
        natural_score = scores.get(natural_family, 0.35)
        if natural_family != current_family and (depth < 0.08 or natural_score > current_score + drift_threshold):
            agent.traits.role = natural_family

    def snapshot(self, agent) -> dict:
        snap = role_snapshot(agent)
        return {
            "role": agent.traits.role,
            "family": snap["family"],
            "display_label": snap["label"],
            "depth": round(agent.state.specialization_depth, 4),
            "effective_depth": round(effective_depth(agent.state.specialization_depth), 4),
            "capability_context": snap["context"],
            "capability_scores": snap["scores"],
        }
