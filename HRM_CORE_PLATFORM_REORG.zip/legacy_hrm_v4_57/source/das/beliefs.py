"""
beliefs.py — DAS v04.43 belief memory with decay, negativity bias, and confidence.

Replaces v04.x flat-dictionary belief memory.

Four realism fixes applied:

1. TEMPORAL DECAY
   Beliefs fade over time. Safety/threat assessments of agents not recently
   encountered decay toward neutral (0.5 safety, 0.0 threat) each tick.
   Phase risk assessments decay toward a baseline floor.
   Decay is exponential: recent experiences dominate, old ones fade.
   Half-life defaults: ~120 ticks for agent beliefs, ~200 ticks for phase risk.

2. NEGATIVITY BIAS
   Threat encodes ~1.6x stronger than equivalent safety signal.
   Threat decays ~0.7x slower than safety.
   Empirically grounded: negative events are encoded more strongly and
   persist longer than positive events of equal magnitude.

3. CONFIDENCE WEIGHTING
   Each agent-belief entry tracks an interaction count.
   Low-confidence beliefs (few interactions) shift faster on new evidence.
   High-confidence beliefs are stickier — require more evidence to move.
   This prevents a single lucky cooperation from erasing a well-earned threat
   assessment, and vice versa.

4. INFORMATION PROPAGATION INTEGRATION
   update_from_message() accepts fidelity-scaled secondhand signals from
   information.py and applies them at reduced weight vs. direct experience.
   Secondhand safety/threat updates are gated by fidelity and confirmation bias.
   Direct dict access to agent_safety, agent_threat, phase_risk still works
   (information.py writes these directly; maintained for backward compatibility).

Public interface unchanged:
    get_safety(agent_id) -> float
    get_threat(agent_id) -> float
    get_phase_risk(phase) -> float
    update_from_event(event) -> None
    update_from_message(source_id, content_type, weight, fidelity) -> None  [NEW]
    decay(current_tick) -> None  [NEW — call once per tick from run_sim.py]
    snapshot() -> dict
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, Optional


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    try:
        return max(lo, min(hi, float(x)))
    except Exception:
        return lo


# ── Decay config ──────────────────────────────────────────────────────────────

# Half-life in ticks. After this many ticks without reinforcement,
# belief drifts halfway back to neutral.
AGENT_SAFETY_HALF_LIFE    = 120.0   # safety beliefs fade moderately fast
AGENT_THREAT_HALF_LIFE    = 200.0   # threat beliefs persist longer (negativity bias)
PHASE_RISK_HALF_LIFE      = 180.0   # phase risk fades slowly
PHASE_SAFETY_HALF_LIFE    = 150.0

SAFETY_NEUTRAL            = 0.50   # resting state for safety belief
THREAT_NEUTRAL            = 0.00   # resting state for threat belief
PHASE_RISK_FLOOR          = 0.15   # phase risk doesn't decay below ambient caution
PHASE_SAFETY_FLOOR        = 0.30

# Negativity bias
NEGATIVE_ENCODE_MULT      = 1.60   # threat/risk updates hit this much harder
POSITIVE_ENCODE_MULT      = 1.00   # safety/cooperation updates at base rate

# Confidence gating: how quickly beliefs shift as a function of interaction count
CONFIDENCE_MIN_SHIFT      = 0.40   # low-confidence beliefs shift at 40% of base
CONFIDENCE_MAX_SHIFT      = 1.00   # high-confidence beliefs shift at 100% (sticky)
CONFIDENCE_SATURATION     = 12     # interactions to reach full confidence

# Secondhand info weight relative to direct experience
SECONDHAND_WEIGHT_MULT    = 0.35   # max secondhand impact vs direct


# ── Belief entries ────────────────────────────────────────────────────────────

@dataclass
class AgentBelief:
    """Safety and threat assessment of one specific other agent."""
    safety: float = 0.50
    threat: float = 0.00
    last_update_tick: int = 0
    interaction_count: int = 0


@dataclass
class PhaseBelief:
    """Risk/safety assessment of a named environmental phase."""
    risk: float = 0.20
    safety: float = 0.50
    last_update_tick: int = 0
    observation_count: int = 0


# ── Core class ────────────────────────────────────────────────────────────────

class BeliefMemory:
    """
    Per-agent belief store with decay, negativity bias, and confidence weighting.

    Backward compatible: agent_safety, agent_threat, phase_risk, phase_safety
    are maintained as live dict proxies so information.py direct writes still work.
    """

    def __init__(self) -> None:
        self._agent: Dict[str, AgentBelief] = {}
        self._phase: Dict[str, PhaseBelief] = {}
        self._current_tick: int = 0

        # Backward-compat dict proxies (information.py writes these directly)
        # These are views into the underlying AgentBelief/PhaseBelief objects.
        # Reads go through __getitem__; writes are intercepted by _ProxyDict.
        self.agent_safety  = _SafetyProxy(self)
        self.agent_threat  = _ThreatProxy(self)
        self.phase_risk    = _PhaseRiskProxy(self)
        self.phase_safety  = _PhaseSafetyProxy(self)

    # ── Internal access ───────────────────────────────────────────────────────

    def _get_agent_belief(self, agent_id: str) -> AgentBelief:
        if agent_id not in self._agent:
            self._agent[agent_id] = AgentBelief()
        return self._agent[agent_id]

    def _get_phase_belief(self, phase: str) -> PhaseBelief:
        if phase not in self._phase:
            self._phase[phase] = PhaseBelief()
        return self._phase[phase]

    def _confidence_shift(self, count: int) -> float:
        """
        Shift multiplier based on interaction count.
        Low count → beliefs shift faster (high plasticity).
        High count → beliefs are stickier (high confidence).
        Inverted: high confidence = LESS shift on new evidence.
        """
        t = min(count / CONFIDENCE_SATURATION, 1.0)
        # At count=0: returns CONFIDENCE_MIN_SHIFT (beliefs very plastic)
        # At count≥saturation: returns CONFIDENCE_MAX_SHIFT (beliefs sticky)
        return CONFIDENCE_MIN_SHIFT + t * (CONFIDENCE_MAX_SHIFT - CONFIDENCE_MIN_SHIFT)

    # ── Public getters (unchanged interface) ──────────────────────────────────

    def get_safety(self, agent_id: str) -> float:
        return self._get_agent_belief(agent_id).safety

    def get_threat(self, agent_id: str) -> float:
        return self._get_agent_belief(agent_id).threat

    def get_phase_risk(self, phase: str) -> float:
        return self._get_phase_belief(phase).risk

    def get_phase_safety(self, phase: str) -> float:
        return self._get_phase_belief(phase).safety

    # ── Direct experience update (unchanged interface) ─────────────────────────

    def update_from_event(self, event) -> None:
        """
        Update beliefs from a directly-experienced event.
        Negativity bias applied: threat encodes harder and decays slower.
        Confidence gates plasticity: early beliefs shift fast, then stabilize.
        """
        phase = event.phase
        pb = self._get_phase_belief(phase)
        pb.last_update_tick = self._current_tick
        pb.observation_count += 1
        phase_conf = self._confidence_shift(pb.observation_count)

        if event.outcome == "conflict":
            # Phase: risk up, safety down — negativity bias on risk
            pb.risk   = clamp(pb.risk   + 0.035 * NEGATIVE_ENCODE_MULT * phase_conf)
            pb.safety = clamp(pb.safety - 0.025 * phase_conf)

            for other_id in event.participants:
                ab = self._get_agent_belief(other_id)
                ab.interaction_count += 1
                ab.last_update_tick = self._current_tick
                conf = self._confidence_shift(ab.interaction_count)
                # Threat up strong, safety down — negativity bias
                ab.threat  = clamp(ab.threat  + 0.060 * NEGATIVE_ENCODE_MULT * conf)
                ab.safety  = clamp(ab.safety  - 0.045 * conf)

        elif event.outcome == "cooperation":
            pb.risk   = clamp(pb.risk   - 0.015 * phase_conf)
            pb.safety = clamp(pb.safety + 0.025 * POSITIVE_ENCODE_MULT * phase_conf)

            for other_id in event.participants:
                ab = self._get_agent_belief(other_id)
                ab.interaction_count += 1
                ab.last_update_tick = self._current_tick
                conf = self._confidence_shift(ab.interaction_count)
                ab.threat  = clamp(ab.threat  - 0.030 * conf)
                ab.safety  = clamp(ab.safety  + 0.050 * POSITIVE_ENCODE_MULT * conf)

        elif event.outcome == "recover":
            pb.risk   = clamp(pb.risk   - 0.025 * phase_conf)
            pb.safety = clamp(pb.safety + 0.035 * phase_conf)

        elif event.outcome == "endure":
            pb.risk   = clamp(pb.risk   + 0.005 * phase_conf)

    # ── Secondhand update from information propagation ────────────────────────

    def update_from_message(
        self,
        source_id: str,
        content_type: str,
        weight: float,
        fidelity: float,
    ) -> None:
        """
        Apply a secondhand belief update from information.py propagation.

        weight    — pre-computed weight from update_beliefs_from_message()
        fidelity  — message fidelity [0,1]; scales the update down
        content_type — "threat_near" | "safe_zone" | others (ignored here)

        Only threat_near and safe_zone map to agent-specific beliefs.
        Other content types update agent state (handled in information.py).
        """
        effective = weight * fidelity * SECONDHAND_WEIGHT_MULT
        if effective < 0.005:
            return

        if content_type == "threat_near":
            ab = self._get_agent_belief(source_id)
            # Secondhand threat: weaker than direct, still negativity-biased
            ab.threat = clamp(ab.threat + 0.045 * NEGATIVE_ENCODE_MULT * effective)
            ab.safety = clamp(ab.safety - 0.025 * effective)
            # Don't increment interaction_count — this wasn't a direct encounter

        elif content_type == "safe_zone":
            ab = self._get_agent_belief(source_id)
            ab.safety = clamp(ab.safety + 0.035 * POSITIVE_ENCODE_MULT * effective)
            ab.threat = clamp(ab.threat - 0.015 * effective)

    # ── Temporal decay ────────────────────────────────────────────────────────

    def decay(self, current_tick: int) -> None:
        """
        Decay all beliefs toward neutral proportional to time since last update.
        Call once per tick from run_sim.py after life events, before agent ticks.

        Uses exponential decay: value(t) = neutral + (value - neutral) * e^(-λt)
        where λ = ln(2) / half_life.
        """
        self._current_tick = current_tick

        for ab in self._agent.values():
            dt = current_tick - ab.last_update_tick
            if dt <= 0:
                continue
            # Safety decays toward neutral
            s_lambda = math.log(2) / AGENT_SAFETY_HALF_LIFE
            ab.safety = clamp(SAFETY_NEUTRAL + (ab.safety - SAFETY_NEUTRAL) * math.exp(-s_lambda * dt))
            # Threat decays toward 0, but slower (negativity bias on persistence)
            t_lambda = math.log(2) / AGENT_THREAT_HALF_LIFE
            ab.threat = clamp(THREAT_NEUTRAL + (ab.threat - THREAT_NEUTRAL) * math.exp(-t_lambda * dt))

        for pb in self._phase.values():
            dt = current_tick - pb.last_update_tick
            if dt <= 0:
                continue
            r_lambda = math.log(2) / PHASE_RISK_HALF_LIFE
            pb.risk = clamp(
                PHASE_RISK_FLOOR + (pb.risk - PHASE_RISK_FLOOR) * math.exp(-r_lambda * dt),
                lo=PHASE_RISK_FLOOR
            )
            s_lambda = math.log(2) / PHASE_SAFETY_HALF_LIFE
            pb.safety = clamp(
                PHASE_SAFETY_FLOOR + (pb.safety - PHASE_SAFETY_FLOOR) * math.exp(-s_lambda * dt),
                lo=PHASE_SAFETY_FLOOR
            )

    # ── Snapshot (unchanged interface) ────────────────────────────────────────

    def snapshot(self) -> dict:
        return {
            "agent_safety":  {k: round(v.safety, 4) for k, v in self._agent.items()},
            "agent_threat":  {k: round(v.threat, 4) for k, v in self._agent.items()},
            "agent_interactions": {k: v.interaction_count for k, v in self._agent.items()},
            "phase_risk":    {k: round(v.risk, 4)    for k, v in self._phase.items()},
            "phase_safety":  {k: round(v.safety, 4)  for k, v in self._phase.items()},
        }


# ── Backward-compat dict proxies ──────────────────────────────────────────────
# information.py does: b.agent_threat[msg.source_id] = clamp(...)
# These proxy objects intercept those writes and route them into BeliefMemory.

class _SafetyProxy:
    def __init__(self, mem: BeliefMemory) -> None:
        self._m = mem
    def __getitem__(self, key: str) -> float:
        return self._m.get_safety(key)
    def __setitem__(self, key: str, val: float) -> None:
        self._m._get_agent_belief(key).safety = clamp(val)
    def get(self, key: str, default: float = 0.50) -> float:
        return self._m._agent[key].safety if key in self._m._agent else default
    def keys(self):
        return self._m._agent.keys()


class _ThreatProxy:
    def __init__(self, mem: BeliefMemory) -> None:
        self._m = mem
    def __getitem__(self, key: str) -> float:
        return self._m.get_threat(key)
    def __setitem__(self, key: str, val: float) -> None:
        self._m._get_agent_belief(key).threat = clamp(val)
    def get(self, key: str, default: float = 0.00) -> float:
        return self._m._agent[key].threat if key in self._m._agent else default
    def keys(self):
        return self._m._agent.keys()


class _PhaseRiskProxy:
    def __init__(self, mem: BeliefMemory) -> None:
        self._m = mem
    def __getitem__(self, key: str) -> float:
        return self._m.get_phase_risk(key)
    def __setitem__(self, key: str, val: float) -> None:
        self._m._get_phase_belief(key).risk = clamp(val)
    def get(self, key: str, default: float = 0.20) -> float:
        return self._m._phase[key].risk if key in self._m._phase else default
    def keys(self):
        return self._m._phase.keys()


class _PhaseSafetyProxy:
    def __init__(self, mem: BeliefMemory) -> None:
        self._m = mem
    def __getitem__(self, key: str) -> float:
        return self._m.get_phase_safety(key)
    def __setitem__(self, key: str, val: float) -> None:
        self._m._get_phase_belief(key).safety = clamp(val)
    def get(self, key: str, default: float = 0.50) -> float:
        return self._m._phase[key].safety if key in self._m._phase else default
    def keys(self):
        return self._m._phase.keys()


# v04.43 SUBJECTIVE MEMORY PATCH
#
# This release introduces the first interpreted-memory substrate.
#
# Agents no longer operate solely from raw event retention.
# A parallel subjective abstraction layer can now compress repeated
# interactions into persistent social narratives.
#
# Example emergent abstractions:
#   - perceived_public_humiliator
#   - perceived_supportive
#   - perceived_protector
#   - perceived_unreliable_under_pressure
#
# This is the first bridge between:
#   event simulation
# and:
#   interpreted social reality.
