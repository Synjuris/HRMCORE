from schemas import Plan

def clamp(x, lo=0.0, hi=1.0): return max(lo, min(hi, x))

class Planner:
    def __init__(self, rng):
        self.rng = rng
        self.current_plan = None
    def form_plan(self, goal, tick, state, target_id=None):
        label = getattr(goal, 'label', 'survive')
        steps = {
            'acquire_resource': ['locate_resource','harvest','store'],
            'survive': ['reduce_risk','recover','seek_resource'],
            'bond': ['approach','signal_trust','cooperate'],
            'dominate': ['approach','pressure','assert'],
            'explore': ['move','observe','remember'],
        }.get(label, ['observe','act'])
        self.current_plan = Plan(steps=steps, target_id=target_id, confidence=clamp(state.stability), tick_created=tick)
        state.plan_confidence = self.current_plan.confidence
        return self.current_plan
    def step_plan(self, outcome):
        if not self.current_plan:
            return None
        if outcome in ('cooperation','resource_gain','solo_recovery'):
            self.current_plan.confidence = clamp(self.current_plan.confidence + 0.03)
        elif outcome in ('conflict','deception_detected','failure'):
            self.current_plan.confidence = clamp(self.current_plan.confidence - 0.05)
        if self.current_plan.steps:
            step = self.current_plan.steps.pop(0)
            if not self.current_plan.steps:
                self.current_plan.completed = True
            return step
        self.current_plan.completed = True
        return None
    def update_state_confidence(self, state):
        state.plan_confidence = self.current_plan.confidence if self.current_plan else 0.5

    def snapshot(self):
        if not self.current_plan:
            return {"active": None}
        return {
            "steps_remaining": list(self.current_plan.steps),
            "target_id": self.current_plan.target_id,
            "confidence": round(self.current_plan.confidence, 4),
            "tick_created": self.current_plan.tick_created,
            "completed": self.current_plan.completed,
        }
