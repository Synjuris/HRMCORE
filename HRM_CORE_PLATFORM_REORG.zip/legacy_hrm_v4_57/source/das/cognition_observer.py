"""
cognition_observer.py — K2-3C+ readable cognition observer.

This module adds a read-only observability lens over live Agent state.
It does NOT mutate agents, ledgers, culture, factions, governance, or any
simulation substrate. Its outputs are interpretation records stored outside
agent state as JSONL.

Contract:
    - called only via observe(tick, runtime)
    - never implements simulation step logic
    - samples selected agents/ticks only
    - writes observation records separately
    - rendered thoughts are not simulation truth

Default renderer is deterministic/template-based so the package runs without
network access or API keys. External LLM wiring can be added later by passing a
renderer callable that accepts the prompt packet and returns text.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional
import hashlib
import json


Renderer = Callable[[Dict[str, Any]], str]


def anthropic_renderer(packet: Dict[str, Any]) -> str:
    """
    LLM renderer using the Anthropic API.

    Converts the full substrate snapshot into a genuine first-person thought —
    not a template, but something generated from what this specific agent has
    actually experienced. Falls back to template_renderer if the API call fails
    so the simulation never blocks on a network error.

    Requires ANTHROPIC_API_KEY in environment or .env.user at project root.
    """
    import os, urllib.request, urllib.error

    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key:
        # Try .env.user in parent dirs
        from pathlib import Path
        for candidate in (Path.cwd(), Path(__file__).resolve().parent,
                          Path(__file__).resolve().parents[1]):
            p = candidate / ".env.user"
            if p.exists():
                for line in p.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if line.startswith("ANTHROPIC_API_KEY="):
                        api_key = line.split("=", 1)[1].strip().strip('"').strip("'")
                        break
            if api_key:
                break

    if not api_key:
        return template_renderer(packet)

    agent_name = packet.get("agent", {}).get("name") or "the agent"
    s = packet.get("substrate_snapshot", {})
    subj = packet.get("subjective_beliefs", {})
    recent = packet.get("recent_context", [])
    mem = packet.get("memory_summary", {})

    # Build a tight natural-language brief for the system prompt
    belief_lines = []
    for tid, b in list((subj or {}).items())[:4]:
        belief_lines.append(f"  {tid}: {b.get('summary','')} (confidence {b.get('confidence',0):.2f})")
    belief_str = "\n".join(belief_lines) if belief_lines else "  none formed yet"

    recent_str = ", ".join(
        f"{e.get('type','?')} ({e.get('outcome','?')})"
        for e in recent[-4:]
    ) if recent else "none"

    goal_snap = mem.get("goals") or {}
    # goals snapshot is a list of {label, priority, progress, achieved}
    if isinstance(goal_snap, list):
        eligible = [g for g in goal_snap if not g.get("achieved", False)]
        active_goal = max(eligible, key=lambda g: g.get("priority", 0)) if eligible else (goal_snap[0] if goal_snap else {})
        goal_label = active_goal.get("label", "unknown") if isinstance(active_goal, dict) else str(active_goal)
    elif isinstance(goal_snap, dict):
        active_goal = goal_snap.get("active", {})
        goal_label = active_goal.get("label", "unknown") if isinstance(active_goal, dict) else str(active_goal)
    else:
        goal_label = "unknown"

    system = (
        "You render internal thoughts for simulated agents in a civilization model. "
        "Write exactly one sentence of first-person thought grounded strictly in the "
        "substrate data provided. Do not invent events. Do not moralize. "
        "The thought should feel lived-in — specific, not generic."
    )

    user = (
        f"Agent: {agent_name} | Tick: {packet.get('tick', '?')} | Phase: {packet.get('phase', '?')}\n"
        f"State: stress={s.get('stress',0):.2f} fear={s.get('fear',0):.2f} "
        f"energy={s.get('energy',0):.2f} valence={s.get('valence',0):.2f} "
        f"hunger={s.get('hunger',0):.2f}\n"
        f"Role: {s.get('role','?')} | Generation: {s.get('generation',0)} | "
        f"Scars: {s.get('scars',0):.2f}\n"
        f"Identity: {', '.join(s.get('identity_tags', []) or [])}\n"
        f"Top bond: {s.get('top_bond','none')} | Top grudge: {s.get('top_grudge','none')}\n"
        f"Active goal: {goal_label}\n"
        f"Social conclusions:\n{belief_str}\n"
        f"Recent events: {recent_str}\n"
        f"Governance: leader={s.get('governance',{}).get('is_leader',False)} "
        f"compliance={s.get('governance',{}).get('compliance_count',0)} "
        f"defiance={s.get('governance',{}).get('defiance_count',0)}\n"
        f"Write one first-person sentence as {agent_name}."
    )

    body = json.dumps({
        "model": "claude-haiku-4-5-20251001",
        "max_tokens": 120,
        "system": system,
        "messages": [{"role": "user", "content": user}],
    }).encode("utf-8")

    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=body,
        headers={
            "Content-Type": "application/json",
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=12) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data["content"][0]["text"].strip()
    except Exception:
        return template_renderer(packet)


@dataclass
class CognitionObserverConfig:
    enabled: bool = False
    every_n: int = 50
    sample_size: int = 3
    agent_ids: Optional[List[str]] = None
    output_file: str = "cognition_observations.jsonl"
    include_prompt_packet: bool = True


class CognitionObserver:
    """
    Read-only cognition observer.

    The observer converts current agent substrate state into a separately
    stored first-person readable thought record. The observer is intentionally
    not attached to Agent and does not write anything back to Agent.
    """

    def __init__(self, config: Optional[CognitionObserverConfig] = None,
                 renderer: Optional[Renderer] = None):
        self.config = config or CognitionObserverConfig()
        self.renderer = renderer or template_renderer
        self.records_written = 0

    @classmethod
    def from_runtime(cls, runtime: Any,
                     renderer: Optional[Renderer] = None) -> "CognitionObserver":
        cfg = getattr(runtime, "cfg", None)
        return cls(CognitionObserverConfig(
            enabled=bool(getattr(cfg, "cognition_observer_enabled", False)),
            every_n=max(1, int(getattr(cfg, "cognition_observer_every_n", 50))),
            sample_size=max(1, int(getattr(cfg, "cognition_observer_sample_size", 3))),
            agent_ids=list(getattr(cfg, "cognition_observer_agent_ids", []) or []),
            output_file=str(getattr(cfg, "cognition_observer_output_file",
                                    "cognition_observations.jsonl")),
            include_prompt_packet=bool(getattr(cfg,
                "cognition_observer_include_prompt_packet", True)),
        ), renderer=renderer)

    def observe(self, tick: int, runtime: Any) -> None:
        """Collect read-only sampled cognition records for this tick."""
        if not self.config.enabled:
            return
        if tick % self.config.every_n != 0:
            return

        agents = [a for a in getattr(runtime, "agents", []) if getattr(a, "alive", False)]
        if not agents:
            return

        sampled = self._sample_agents(agents, tick)
        if not sampled:
            return

        # Try runtime._output_dir first (set by runtime after run starts),
        # then fall back to output_path (may have run_N subdir appended by runtime)
        _base = getattr(runtime, "_output_dir", None)
        if _base is None:
            _cfg_path = getattr(runtime.cfg, "output_path", Path("."))
            # Runtime writes into output_path / run_N — find the latest run dir
            _cfg_path = Path(_cfg_path)
            _run_dirs = sorted(_cfg_path.glob("run_*")) if _cfg_path.exists() else []
            _base = _run_dirs[-1] if _run_dirs else _cfg_path
        out_dir = Path(_base)
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / self.config.output_file

        with out_path.open("a", encoding="utf-8") as f:
            for agent in sampled:
                packet = build_prompt_packet(agent, tick, runtime)
                thought = self.renderer(packet)
                rec = {
                    "tick": tick,
                    "agent_id": getattr(agent, "id", None),
                    "agent_name": getattr(agent, "name", None),
                    "group": getattr(runtime, "agent_group", {}).get(getattr(agent, "id", None)),
                    "observer": "CognitionObserver",
                    "render_mode": "template",
                    "thought": thought,
                    "substrate_snapshot": packet["substrate_snapshot"],
                    "recent_context": packet["recent_context"],
                }
                if self.config.include_prompt_packet:
                    rec["prompt_packet"] = packet
                f.write(json.dumps(rec, sort_keys=True) + "\n")
                self.records_written += 1

    def _sample_agents(self, agents: List[Any], tick: int) -> List[Any]:
        ids = set(self.config.agent_ids or [])
        if ids:
            return [a for a in agents if getattr(a, "id", None) in ids][:self.config.sample_size]

        # Deterministic sample independent of Python's salted hash().
        ranked = sorted(
            agents,
            key=lambda a: hashlib.sha256(
                f"{tick}:{getattr(a, 'id', getattr(a, 'name', ''))}".encode()
            ).hexdigest(),
        )
        return ranked[:self.config.sample_size]


def build_prompt_packet(agent: Any, tick: int, runtime: Any) -> Dict[str, Any]:
    """Build a read-only cognition packet from current runtime state."""
    state = getattr(agent, "state", None)
    exp = getattr(agent, "experience", None)
    group = getattr(runtime, "agent_group", {}).get(getattr(agent, "id", None))
    phase = None
    try:
        phase = runtime.env_cycle.get_phase(tick).name
    except Exception:
        phase = None

    recent_events = _recent_agent_events(agent, runtime, limit=8)

    substrate = {
        "age": _round(getattr(state, "age", None)),
        "energy": _round(getattr(state, "energy", None)),
        "stress": _round(getattr(state, "stress", None)),
        "fear": _round(getattr(state, "fear", None)),
        "curiosity": _round(getattr(state, "curiosity", None)),
        "valence": _round(getattr(state, "valence", None)),
        "hunger": _round(getattr(state, "hunger", None)),
        "exhaustion": _round(getattr(state, "exhaustion", None)),
        "injury": _round(getattr(state, "injury", None)),
        "safety": _round(getattr(state, "safety", None)),
        "resource_stock": _round(getattr(state, "resource_stock", None)),
        "generation": getattr(agent, "generation", None),
        "role": getattr(getattr(agent, "traits", None), "role", None),
        "identity_tags": list(getattr(exp, "identity_tags", []) or [])[:8],
        "scars": _round(getattr(exp, "scars", None)),
        "top_grudge": _safe_call(exp, "top_grudge"),
        "top_bond": _safe_call(exp, "top_bond"),
        "governance": {
            "is_leader": bool(getattr(agent, "is_leader", False)),
            "compliance_count": getattr(agent, "compliance_count", 0),
            "defiance_count": getattr(agent, "defiance_count", 0),
        },
    }

    memory = {
        "beliefs": _safe_snapshot(getattr(agent, "beliefs", None)),
        "goals": _safe_snapshot(getattr(agent, "goals", None)),
        "plan": _safe_snapshot(getattr(agent, "planner", None)),
        "language_recent_utterances": list(getattr(getattr(agent, "language", None),
                                                   "utterances", []) or [])[-5:],
        "memory_count": _memory_count(agent),
    }

    # v04.57: include subjective social conclusions in the packet so the
    # LLM renderer has the agent's formed opinions about specific people,
    # not just raw state values.
    subj_mem = getattr(agent, "subjective_memory", None)
    subjective_beliefs = {}
    if subj_mem is not None:
        snap = getattr(subj_mem, "snapshot", None)
        if callable(snap):
            try:
                subjective_beliefs = snap()
            except Exception:
                pass

    packet = {
        "instruction": (
            "Render a concise first-person thought for this simulated agent. "
            "Do not add facts outside the substrate snapshot. Treat this as "
            "an observation, not agent state."
        ),
        "tick": tick,
        "phase": phase,
        "agent": {
            "id": getattr(agent, "id", None),
            "name": getattr(agent, "name", None),
            "group": group,
        },
        "substrate_snapshot": substrate,
        "memory_summary": memory,
        "recent_context": recent_events,
        "subjective_beliefs": subjective_beliefs,
    }
    return packet


def template_renderer(packet: Dict[str, Any]) -> str:
    """
    Deterministic non-LLM renderer.

    This is intentionally modest. It gives the readable layer a stable output
    without pretending to be a deep model. Replace with an external LLM renderer
    later without changing the observer contract.
    """
    agent_name = packet.get("agent", {}).get("name") or "I"
    s = packet.get("substrate_snapshot", {})
    stress = s.get("stress") or 0.0
    fear = s.get("fear") or 0.0
    valence = s.get("valence") or 0.0
    energy = s.get("energy") or 0.0
    hunger = s.get("hunger") or 0.0
    tags = s.get("identity_tags") or []
    bond = s.get("top_bond")
    grudge = s.get("top_grudge")

    mood = "steady"
    if valence <= -0.35 or stress >= 0.65:
        mood = "strained"
    elif valence >= 0.35 and stress <= 0.45:
        mood = "open"
    elif fear >= 0.55:
        mood = "watchful"

    body = "I can keep moving."
    if energy <= 0.25 or hunger >= 0.65:
        body = "My body is asking for resources before anything else."
    elif fear >= 0.55:
        body = "I am scanning for danger before trust."

    identity = ""
    if tags:
        identity = f" I keep returning to what I have become: {', '.join(map(str, tags[:3]))}."

    social = ""
    if bond:
        social += f" Bond pulls me toward {bond}."
    if grudge:
        social += f" Grudge keeps {grudge} close in mind."

    return f"I am {agent_name}, and right now I feel {mood}. {body}{identity}{social}".strip()


def _recent_agent_events(agent: Any, runtime: Any, limit: int = 8) -> List[Dict[str, Any]]:
    aid = getattr(agent, "id", None)
    out: List[Dict[str, Any]] = []
    for ev in reversed(list(getattr(getattr(runtime, "bus", None), "event_log", []) or [])):
        participants = ev.get("participants") or []
        actor = ev.get("actor_id") or ev.get("agent_id") or ev.get("source")
        target = ev.get("target_id") or ev.get("target")
        if aid in participants or aid == actor or aid == target:
            out.append({
                "tick": ev.get("tick"),
                "type": ev.get("type") or ev.get("event_type"),
                "salience": ev.get("salience"),
                "participants": participants[:6] if isinstance(participants, list) else participants,
                "outcome": ev.get("outcome"),
            })
            if len(out) >= limit:
                break
    out.reverse()
    return out


def _safe_snapshot(obj: Any) -> Any:
    if obj is None:
        return None
    snap = getattr(obj, "snapshot", None)
    if not callable(snap):
        return None
    try:
        data = snap()
    except TypeError:
        try:
            data = snap(None)
        except Exception:
            return None
    except Exception:
        return None
    return _truncate(data)


def _safe_call(obj: Any, name: str) -> Any:
    if obj is None:
        return None
    fn = getattr(obj, name, None)
    if not callable(fn):
        return None
    try:
        return _truncate(fn())
    except Exception:
        return None


def _memory_count(agent: Any) -> Optional[int]:
    mem = getattr(agent, "memory", None)
    stats = getattr(mem, "compression_stats", None)
    if not callable(stats):
        return None
    try:
        return int(stats().get("total_interactions_indexed", 0))
    except Exception:
        return None


def _round(v: Any) -> Any:
    if isinstance(v, (int, float)):
        return round(float(v), 4)
    return v


def _truncate(obj: Any, max_items: int = 12) -> Any:
    if isinstance(obj, dict):
        return {k: _truncate(v, max_items=max_items) for k, v in list(obj.items())[:max_items]}
    if isinstance(obj, list):
        return [_truncate(v, max_items=max_items) for v in obj[:max_items]]
    if isinstance(obj, tuple):
        return tuple(_truncate(v, max_items=max_items) for v in obj[:max_items])
    return obj
