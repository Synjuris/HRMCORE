"""settlements.py — v04.40 Settlement Persistence + Demographic Stability.

This layer turns repeated co-location and infrastructure accumulation into
persistent places without naming eras or scripting civilization outcomes.  It
adds home-cell attachment, modest settlement-level mutual aid, infrastructure
memory, controlled spatial differentiation, and demographic buffers that are
visible through events/metrics.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Dict, Iterable, List, Tuple
import random

from schemas import Event


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(x)))


@dataclass
class SettlementRecord:
    id: str
    cell: Tuple[int, int]
    founded_tick: int
    visits: int = 0
    resident_claims: int = 0
    continuity: float = 0.0
    infrastructure: float = 0.0
    storage: float = 0.0
    care_capacity: float = 0.0
    institution_memory: float = 0.0
    trade_pull: float = 0.0

    def snapshot(self) -> dict:
        d = asdict(self)
        d["cell"] = list(self.cell)
        for k, v in list(d.items()):
            if isinstance(v, float):
                d[k] = round(v, 4)
        return d


class SettlementLedger:
    def __init__(self) -> None:
        self.records: Dict[Tuple[int, int], SettlementRecord] = {}
        self.events_created = 0
        self.support_events = 0
        self.expansion_events = 0
        self.home_assignments = 0

    def _get_or_create(self, key: Tuple[int, int], tick: int) -> SettlementRecord:
        if key not in self.records:
            sid = f"settlement_{key[0]}_{key[1]}_{tick}"
            self.records[key] = SettlementRecord(id=sid, cell=key, founded_tick=tick)
            self.events_created += 1
        return self.records[key]

    def assign_home(self, agent: Any, key: Tuple[int, int], tick: int) -> None:
        if not getattr(agent, "alive", False):
            return
        rec = self._get_or_create(key, tick)
        old = getattr(agent, "home_cell", None)
        if old != key:
            setattr(agent, "home_cell", key)
            setattr(agent, "settlement_id", rec.id)
            setattr(agent, "settlement_attachment", max(getattr(agent, "settlement_attachment", 0.0), 0.18))
            self.home_assignments += 1

    def seed_founder_settlements(self, agents: List[Any], logistics_world: Any, tick: int = 0) -> List[Event]:
        living = [a for a in agents if getattr(a, "alive", False)]
        events: List[Event] = []
        if not living:
            return events
        # Split founders over two or three nearby good cells instead of a single pile.
        cells = sorted(logistics_world.cells.values(), key=lambda c: (c.fertility + c.carrying_capacity + c.settlement_pull), reverse=True)
        chosen = [(c.x, c.y) for c in cells[:max(2, min(3, len(living) // 3 + 1))]]
        for i, a in enumerate(living):
            key = chosen[i % len(chosen)]
            a.position.x, a.position.y = key
            self.assign_home(a, key, tick)
            c = logistics_world.cells[key]
            c.settlement_pull = clamp(c.settlement_pull + 0.08)
            c.infrastructure = clamp(c.infrastructure + 0.035)
        for key in chosen:
            rec = self._get_or_create(key, tick)
            rec.continuity = max(rec.continuity, 0.25)
            rec.infrastructure = max(rec.infrastructure, 0.05)
            events.append(Event(tick, "seed", "world", "settlement_seeded", [], {"cell": list(key), "settlement_id": rec.id}, {"continuity": rec.continuity}, "home_site_established"))
        return events

    def tick(self, agents: List[Any], tick: int, phase_name: str, logistics_world: Any, rng: random.Random) -> List[Event]:
        living = [a for a in agents if getattr(a, "alive", False)]
        events: List[Event] = []
        if not living:
            for rec in self.records.values():
                rec.continuity *= 0.998
            return events

        # Update settlement records from current occupation and home claims.
        occ: Dict[Tuple[int, int], List[Any]] = {}
        for a in living:
            key = (a.position.x, a.position.y)
            occ.setdefault(key, []).append(a)
            if getattr(a, "home_cell", None) is None:
                self.assign_home(a, key, tick)

        home_counts: Dict[Tuple[int, int], int] = {}
        for a in living:
            h = getattr(a, "home_cell", None)
            if isinstance(h, tuple):
                home_counts[h] = home_counts.get(h, 0) + 1

        for key, residents in occ.items():
            # Do not turn every one-tick travel cell into a settlement. A cell
            # becomes settlement-relevant only through a home claim, repeated
            # infrastructure, or enough simultaneous residents.
            has_home_claim = home_counts.get(key, 0) > 0
            has_prior_record = key in self.records
            cell = logistics_world.cells[key]
            if not (has_home_claim or has_prior_record or len(residents) >= 2 or cell.infrastructure > 0.20 or cell.storage > 0.03):
                continue
            rec = self._get_or_create(key, tick)
            rec.visits += len(residents)
            rec.resident_claims = home_counts.get(key, rec.resident_claims)
            social = sum(getattr(a.state, "cooperation", 0.5) for a in residents) / len(residents)
            rec.continuity = clamp(rec.continuity * 0.997 + min(0.035, 0.004 * len(residents) + 0.004 * social))
            rec.infrastructure = clamp(rec.infrastructure * 0.999 + cell.infrastructure * 0.015 + rec.continuity * 0.002)
            rec.storage = max(0.0, rec.storage * 0.999 + cell.storage * 0.025)
            rec.care_capacity = clamp(rec.care_capacity * 0.996 + social * 0.006 + min(0.020, len(residents) * 0.002))
            rec.trade_pull = clamp(rec.trade_pull * 0.998 + (cell.storage + cell.infrastructure) * 0.003)
            cell.settlement_pull = clamp(cell.settlement_pull + 0.006 + rec.continuity * 0.004)
            cell.infrastructure = clamp(cell.infrastructure + 0.0015 * len(residents) + rec.continuity * 0.0008)

            # Settlement mutual aid: not free immortality; a small benefit from being
            # in a place with accumulated care/storage/infrastructure.
            support = min(0.020, rec.care_capacity * 0.018 + cell.infrastructure * 0.010 + cell.storage * 0.004)
            if support > 0.001:
                for a in residents:
                    a.state.exhaustion = clamp(a.state.exhaustion - support * 0.70)
                    a.state.stress = clamp(a.state.stress - support * 0.45)
                    a.state.safety = clamp(a.state.safety + support * 0.65)
                    if a.state.energy < 0.42:
                        a.state.energy = clamp(a.state.energy + support * 0.65)
                self.support_events += 1
                if tick % 25 == 0:
                    events.append(Event(tick, phase_name, "world", "settlement_support", [a.id for a in residents[:6]], {"cell": list(key), "support": round(support, 4), "continuity": round(rec.continuity, 4)}, {"stress_reduction": round(support * 0.45, 4)}, "settlement_buffered_residents"))

        # Home gravity: agents near their home tend to stay attached, but crowded
        # cells seed adjacent secondary sites so spatial diversity does not collapse.
        if tick % 15 == 0:
            for key, residents in list(occ.items()):
                if len(residents) >= 5:
                    candidates = self._neighbor_keys(key, logistics_world)
                    candidates = sorted(candidates, key=lambda k: (logistics_world.cells[k].fertility + logistics_world.cells[k].carrying_capacity - logistics_world.cells[k].friction), reverse=True)
                    if candidates:
                        dest = candidates[0]
                        mover = min(residents, key=lambda a: getattr(a, "settlement_attachment", 0.0))
                        mover.position.x, mover.position.y = dest
                        self.assign_home(mover, dest, tick)
                        self._get_or_create(dest, tick).continuity = max(self._get_or_create(dest, tick).continuity, 0.12)
                        self.expansion_events += 1
                        events.append(Event(tick, phase_name, mover.id, "settlement_budding", [], {"from": list(key), "to": list(dest)}, {"spatial_differentiation": 0.05}, "secondary_site_seeded"))
                elif len(living) >= 5 and len(occ) < 2:
                    # prevent total spatial collapse when enough people still exist
                    candidates = self._neighbor_keys(key, logistics_world)
                    if candidates:
                        dest = max(candidates, key=lambda k: logistics_world.cells[k].fertility + logistics_world.cells[k].carrying_capacity)
                        mover = residents[-1]
                        mover.position.x, mover.position.y = dest
                        self.assign_home(mover, dest, tick)

        # Demographic stabilization: children and reproductive-age adults receive
        # settlement-mediated buffers when the whole population is still fragile.
        if len(living) < 8:
            for a in living:
                h = getattr(a, "home_cell", None) or (a.position.x, a.position.y)
                rec = self.records.get(h)
                age = getattr(a.state, "age", 9999)
                if age < 260 or 180 <= age <= 720:
                    bonus = 0.006 + (rec.care_capacity * 0.010 if rec else 0.0)
                    a.state.energy = clamp(a.state.energy + bonus)
                    a.state.exhaustion = clamp(a.state.exhaustion - bonus)
                    a.state.stress = clamp(a.state.stress - bonus * 0.65)
                    if getattr(a.state, "collapse_strikes", 0) > 0 and a.state.energy > 0.18:
                        a.state.collapse_strikes = max(0, a.state.collapse_strikes - 1)

        return events

    def _neighbor_keys(self, key: Tuple[int, int], logistics_world: Any) -> List[Tuple[int, int]]:
        x, y = key
        out = []
        for dx, dy in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,-1),(1,-1),(-1,1)):
            nk = (max(0, min(logistics_world.width - 1, x + dx)), max(0, min(logistics_world.height - 1, y + dy)))
            if nk != key and nk in logistics_world.cells:
                out.append(nk)
        return out

    def metrics(self, agents: Iterable[Any]) -> dict:
        living = [a for a in agents if getattr(a, "alive", False)]
        active = [r for r in self.records.values() if r.continuity > 0.08 or r.resident_claims > 0]
        home_cells = {getattr(a, "home_cell", None) for a in living if getattr(a, "home_cell", None) is not None}
        return {
            "settlement_records": len(self.records),
            "settlement_active": len(active),
            "settlement_home_cells_living": len(home_cells),
            "settlement_avg_continuity": round(sum(r.continuity for r in active) / len(active), 4) if active else 0.0,
            "settlement_total_storage_memory": round(sum(r.storage for r in self.records.values()), 4),
            "settlement_total_infrastructure_memory": round(sum(r.infrastructure for r in self.records.values()), 4),
            "settlement_support_events": self.support_events,
            "settlement_expansion_events": self.expansion_events,
            "settlement_home_assignments": self.home_assignments,
        }

    def snapshot(self, agents: Iterable[Any] = ()) -> dict:
        return {
            "version": "v04.40",
            "summary": self.metrics(agents),
            "settlements": [r.snapshot() for r in sorted(self.records.values(), key=lambda r: (r.continuity, r.infrastructure, r.storage), reverse=True)[:50]],
        }
