"""
resource_transfer.py — DAS v04.44 Resource Transfer System

Implements the full spectrum of inter-agent resource transfer:
  - Trade:   mutual exchange, both parties willing, trust-gated
  - Theft:   unilateral taking, hunger/scarcity driven, resentment generating
  - Charity: voluntary giving, attachment/care driven, reputation building

Each transfer type:
  1. Has a distinct trigger condition based on agent state
  2. Modifies resource_stock on both agents
  3. Updates the relationship in qualitatively different ways
  4. Writes a belief label to the subjective memory system
  5. Emits an Event for the chronicle and metrics systems

The module is called from agent.tick() after normal interaction resolution,
when two agents are in proximity. It does not replace interaction — it extends
the set of things that can happen between agents beyond cooperation/conflict.

Biome complementarity (from spatial_biomes) amplifies trade probability when
agents come from different resource zones. Same-biome agents trade less because
they have less to offer each other.

Design principles:
  - All three behaviors emerge from agent state, not scripted triggers
  - Reputation (subjective memory labels) persists and spreads
  - Theft is always costly socially even when profitable materially
  - Charity is always costly materially but profitable socially
  - The system creates natural tension: starving agents face steal-vs-beg choice
"""

from __future__ import annotations
import random
from dataclasses import dataclass
from typing import Optional, List, TYPE_CHECKING

from schemas import Event, new_id

if TYPE_CHECKING:
    from agent import Agent

# ── Tuning constants ───────────────────────────────────────────────────────────

# Trade
TRADE_TRUST_FLOOR        = 0.15   # minimum trust to attempt trade (low — first contact possible)
TRADE_SURPLUS_THRESHOLD  = 0.55   # donor needs this much resource_stock to offer trade
TRADE_DEFICIT_THRESHOLD  = 0.35   # receiver needs to be below this to want trade
TRADE_TRANSFER_FRACTION  = 0.28   # fraction of surplus transferred per trade event
TRADE_TRUST_BOOST        = 0.08   # trust gain for both parties on successful trade
TRADE_ENERGY_BOOST       = 0.06   # energy gain for receiver
TRADE_BIOME_MULTIPLIER   = 1.55   # cross-biome trade probability bonus

# Theft
THEFT_HUNGER_FLOOR       = 0.55   # agent must be this hungry to consider theft
THEFT_TRUST_CEILING      = 0.40   # only steal from strangers/low-trust (not bonded kin)
THEFT_SUCCESS_BASE       = 0.45   # base success probability
THEFT_TRANSFER_FRACTION  = 0.22   # fraction stolen on success
THEFT_RESENTMENT_HIT     = 0.28   # resentment added to victim's relationship
THEFT_TRUST_HIT          = 0.18   # trust destroyed in both directions
THEFT_STRESS_RELIEF      = 0.04   # stress relief for thief on success
THEFT_CATCH_RESENTMENT   = 0.40   # extra resentment if caught (failed attempt still seen)

# Charity
CHARITY_ATTACHMENT_FLOOR = 0.45   # donor must have this attachment to recipient
CHARITY_SURPLUS_THRESHOLD= 0.65   # donor must have this much stock to give freely
CHARITY_CARE_ROLE_BONUS  = 0.25   # extra probability for care-family role agents
CHARITY_TRANSFER_FRACTION= 0.20   # fraction given
CHARITY_TRUST_BOOST      = 0.12   # trust gain (higher than trade — gift > exchange)
CHARITY_ATTACHMENT_BOOST = 0.08   # attachment boost to donor from act of giving
CHARITY_STRESS_RELIEF    = 0.05   # giving reduces donor stress (prosocial reward)
CHARITY_CROSS_GROUP_MULT = 1.80   # cross-faction charity is memorable and spreads

# Subjective memory belief labels
BELIEF_FAIR_TRADER   = "perceived_fair_trader"
BELIEF_THIEF         = "perceived_thief"
BELIEF_GENEROUS      = "perceived_generous"
BELIEF_EXPLOITER     = "perceived_exploiter"   # repeated theft without retaliation

# ── Utility helpers ────────────────────────────────────────────────────────────

def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))

def _resource_stock(agent) -> float:
    return getattr(agent.state, "resource_stock", 0.0)

def _set_resource_stock(agent, value: float) -> None:
    agent.state.resource_stock = _clamp(value)

def _biome_name(agent) -> Optional[str]:
    try:
        from spatial_biomes import get_biome
        x = int(getattr(getattr(agent, "position", None), "x", 20))
        y = int(getattr(getattr(agent, "position", None), "y", 20))
        return get_biome(x, y).name
    except ImportError:
        return None

def _role_family(agent) -> str:
    try:
        from adaptive_roles import role_family
        return role_family(getattr(getattr(agent, "traits", None), "role", ""))
    except Exception:
        return ""

def _write_belief(agent, target_id: str, label: str) -> None:
    """Write a subjective belief about target into agent's memory."""
    try:
        sm = getattr(agent, "subjective_memory", None)
        if sm and hasattr(sm, "record_belief"):
            sm.record_belief(target_id, label)
        else:
            # Fallback: store in a simple dict on the agent
            if not hasattr(agent, "_transfer_beliefs"):
                agent._transfer_beliefs = {}
            agent._transfer_beliefs[target_id] = label
    except Exception:
        pass

def _same_faction(actor, other) -> bool:
    fr = getattr(actor, "faction_registry", None)
    if fr:
        return fr.same_faction(actor.id, other.id)
    return False

def _make_event(tick, phase_name, actor_id, event_type, participants,
                context, impact, outcome) -> Event:
    return Event(
        tick=tick, phase=phase_name, actor_id=actor_id,
        event_type=event_type, participants=participants,
        context=context, impact=impact, outcome=outcome,
    )

# ── Core transfer functions ────────────────────────────────────────────────────

def attempt_trade(actor: "Agent", other: "Agent", tick: int,
                  phase_name: str, rng: random.Random) -> Optional[Event]:
    """
    Attempt a resource trade between actor and other.
    Requires: trust floor, surplus/deficit asymmetry, mutual willingness.
    Returns an Event on success, None if conditions not met.
    """
    r_actor = actor.relationships.get(other.id)
    r_other = other.relationships.get(actor.id)

    # Trust gate — both must have baseline trust
    if r_actor.trust < TRADE_TRUST_FLOOR or r_other.trust < TRADE_TRUST_FLOOR:
        return None

    # Resource asymmetry — actor has surplus, other has deficit (or vice versa)
    stock_actor = _resource_stock(actor)
    stock_other = _resource_stock(other)

    # Determine who gives and who receives
    if stock_actor >= TRADE_SURPLUS_THRESHOLD and stock_other <= TRADE_DEFICIT_THRESHOLD:
        donor, receiver = actor, other
    elif stock_other >= TRADE_SURPLUS_THRESHOLD and stock_actor <= TRADE_DEFICIT_THRESHOLD:
        donor, receiver = other, actor
    else:
        return None  # No meaningful asymmetry

    # Biome complementarity bonus
    biome_actor = _biome_name(actor)
    biome_other = _biome_name(other)
    cross_biome = (biome_actor and biome_other and biome_actor != biome_other)
    trade_prob = 0.35 + r_actor.trust * 0.20 + r_other.trust * 0.20
    if cross_biome:
        trade_prob *= TRADE_BIOME_MULTIPLIER

    if rng.random() > trade_prob:
        return None

    # Execute transfer
    transfer_amount = _resource_stock(donor) * TRADE_TRANSFER_FRACTION
    _set_resource_stock(donor, _resource_stock(donor) - transfer_amount)
    _set_resource_stock(receiver, _resource_stock(receiver) + transfer_amount)
    receiver.state.energy = _clamp(receiver.state.energy + TRADE_ENERGY_BOOST)
    donor.state.energy = _clamp(donor.state.energy + TRADE_ENERGY_BOOST * 0.4)

    # Relationship updates — both benefit
    for a, b in [(actor, other), (other, actor)]:
        a.relationships.update_after_interaction(
            b.id,
            trust_delta=TRADE_TRUST_BOOST,
            resentment_delta=-0.012,
            attachment_delta=0.025,
            influence_delta=0.015,
        )

    # Reputation
    _write_belief(receiver, donor.id, BELIEF_FAIR_TRADER)
    _write_belief(donor, receiver.id, BELIEF_FAIR_TRADER)

    return _make_event(
        tick=tick, phase_name=phase_name,
        actor_id=donor.id, event_type="trade",
        participants=[receiver.id],
        context={
            "donor": donor.name, "receiver": receiver.name,
            "amount": round(transfer_amount, 4),
            "cross_biome": cross_biome,
            "biome_donor": biome_actor if donor is actor else biome_other,
            "biome_receiver": biome_other if donor is actor else biome_actor,
            "trust": round(r_actor.trust, 4),
        },
        impact={"resource_transfer": round(transfer_amount, 4),
                "trust_delta": TRADE_TRUST_BOOST},
        outcome="trade_success",
    )


def attempt_theft(actor: "Agent", other: "Agent", tick: int,
                  phase_name: str, rng: random.Random) -> Optional[Event]:
    """
    Attempt resource theft by actor from other.
    Requires: actor hungry enough, other has surplus, low trust (stranger/enemy).
    Generates high resentment and reputation damage regardless of success.
    """
    # Hunger/desperation gate
    hunger = getattr(actor.state, "hunger", 0.0)
    energy = actor.state.energy
    desperation = hunger * 0.6 + (1.0 - energy) * 0.4
    if desperation < THEFT_HUNGER_FLOOR:
        return None

    # Only steal from strangers or enemies — not bonded partners
    r = actor.relationships.get(other.id)
    if r.trust > THEFT_TRUST_CEILING:
        return None

    # Other must have something worth stealing
    stock_other = _resource_stock(other)
    if stock_other < 0.20:
        return None

    # Theft probability driven by desperation and risk tolerance
    risk_tolerance = getattr(getattr(actor, "traits", None), "risk_tolerance", 0.5)
    theft_prob = desperation * 0.35 + risk_tolerance * 0.20 - r.trust * 0.15
    if rng.random() > theft_prob:
        return None

    # Attempt — success depends on skill, other's awareness
    success_p = THEFT_SUCCESS_BASE + risk_tolerance * 0.15 - other.state.stress * 0.10
    success = rng.random() < success_p

    if success:
        stolen = stock_other * THEFT_TRANSFER_FRACTION
        _set_resource_stock(other, stock_other - stolen)
        _set_resource_stock(actor, _resource_stock(actor) + stolen)
        actor.state.energy = _clamp(actor.state.energy + stolen * 0.15)
        actor.state.stress = _clamp(actor.state.stress - THEFT_STRESS_RELIEF)
        outcome = "theft_success"
        impact = {"stolen": round(stolen, 4), "resentment_generated": THEFT_RESENTMENT_HIT}
    else:
        stolen = 0.0
        outcome = "theft_failed"
        impact = {"stolen": 0.0, "resentment_generated": THEFT_CATCH_RESENTMENT}
        # Getting caught generates extra resentment
        extra_resent = THEFT_CATCH_RESENTMENT - THEFT_RESENTMENT_HIT
    
    # Relationship damage — victim's view of thief
    resentment_hit = THEFT_RESENTMENT_HIT if success else THEFT_CATCH_RESENTMENT
    other.relationships.update_after_interaction(
        actor.id,
        trust_delta=-THEFT_TRUST_HIT,
        resentment_delta=resentment_hit,
        attachment_delta=-0.035,
        influence_delta=0.008,
    )
    # Thief's relationship with victim also shifts (guilt/contempt)
    actor.relationships.update_after_interaction(
        other.id,
        trust_delta=-0.04,
        resentment_delta=0.02,
        attachment_delta=-0.015,
        influence_delta=0.005,
    )

    # Victim stress
    other.state.stress = _clamp(other.state.stress + 0.04 + resentment_hit * 0.08)

    # Reputation — victim labels thief, and if witnessed, others too
    _write_belief(other, actor.id, BELIEF_THIEF)

    # Faction hostility update — theft across faction lines escalates group tension
    fr = getattr(actor, "faction_registry", None)
    if fr and not _same_faction(actor, other):
        fr.update_hostility(actor.id, other.id, delta=0.06 if success else 0.03)

    return _make_event(
        tick=tick, phase_name=phase_name,
        actor_id=actor.id, event_type="theft",
        participants=[other.id],
        context={
            "thief": actor.name, "victim": other.name,
            "success": success, "stolen": round(stolen, 4),
            "desperation": round(desperation, 4),
            "cross_faction": not _same_faction(actor, other),
        },
        impact=impact,
        outcome=outcome,
    )


def attempt_charity(actor: "Agent", other: "Agent", tick: int,
                    phase_name: str, rng: random.Random) -> Optional[Event]:
    """
    Attempt charitable giving from actor to other.
    Requires: high attachment, actor surplus, other in need.
    Cross-faction charity is rare but generates strong reputation signals.
    """
    # Donor must have surplus
    stock_actor = _resource_stock(actor)
    if stock_actor < CHARITY_SURPLUS_THRESHOLD:
        return None

    # Receiver must be in genuine need
    stock_other = _resource_stock(other)
    receiver_hungry = getattr(other.state, "hunger", 0.0) > 0.40
    receiver_low = stock_other < 0.30
    if not (receiver_hungry or receiver_low):
        return None

    # Attachment gate — you give to people you care about
    r = actor.relationships.get(other.id)
    if r.attachment < CHARITY_ATTACHMENT_FLOOR:
        return None

    # Probability — care role agents more likely to give
    role_bonus = CHARITY_CARE_ROLE_BONUS if _role_family(actor) == "care" else 0.0
    cross_faction = not _same_faction(actor, other)
    cross_bonus = 0.10 if cross_faction else 0.0  # rare but possible
    
    charity_prob = (
        r.attachment * 0.45
        + actor.state.cooperation * 0.20
        + role_bonus
        + cross_bonus
        - actor.state.stress * 0.15  # stressed donors give less
    )
    if rng.random() > charity_prob:
        return None

    # Execute transfer
    gift_amount = stock_actor * CHARITY_TRANSFER_FRACTION
    _set_resource_stock(actor, stock_actor - gift_amount)
    _set_resource_stock(other, stock_other + gift_amount)
    other.state.energy = _clamp(other.state.energy + gift_amount * 0.20)
    other.state.stress = _clamp(other.state.stress - 0.03)
    
    # Donor gets prosocial reward
    actor.state.stress = _clamp(actor.state.stress - CHARITY_STRESS_RELIEF)
    actor.state.cooperation = _clamp(actor.state.cooperation + 0.012)

    # Relationship updates — charity builds stronger bond than trade
    trust_boost = CHARITY_TRUST_BOOST
    if cross_faction:
        trust_boost *= CHARITY_CROSS_GROUP_MULT  # cross-faction generosity is memorable

    other.relationships.update_after_interaction(
        actor.id,
        trust_delta=trust_boost,
        resentment_delta=-0.020,
        attachment_delta=CHARITY_ATTACHMENT_BOOST * 1.4,
        influence_delta=0.020,
    )
    actor.relationships.update_after_interaction(
        other.id,
        trust_delta=trust_boost * 0.5,
        resentment_delta=-0.010,
        attachment_delta=CHARITY_ATTACHMENT_BOOST,
        influence_delta=0.010,
    )

    # Reputation — receiver labels donor as generous
    _write_belief(other, actor.id, BELIEF_GENEROUS)
    
    # Cross-faction charity reduces hostility
    fr = getattr(actor, "faction_registry", None)
    if fr and cross_faction:
        fr.update_hostility(actor.id, other.id, delta=-0.08)

    return _make_event(
        tick=tick, phase_name=phase_name,
        actor_id=actor.id, event_type="charity",
        participants=[other.id],
        context={
            "donor": actor.name, "receiver": other.name,
            "gift": round(gift_amount, 4),
            "cross_faction": cross_faction,
            "donor_attachment": round(r.attachment, 4),
            "donor_role": getattr(getattr(actor, "traits", None), "role", "unknown"),
        },
        impact={"gift": round(gift_amount, 4), "trust_boost": round(trust_boost, 4)},
        outcome="charity_given",
    )


# ── Main entry point ───────────────────────────────────────────────────────────

def apply_resource_transfers(agent: "Agent", tick: int, phase_name: str,
                              nearby_agents: List["Agent"],
                              rng: random.Random) -> List[Event]:
    """
    Called once per agent per tick with their nearby neighbors.
    Evaluates trade, theft, and charity for each neighbor in priority order:
      1. Charity (if strong attachment and surplus — care comes first)
      2. Trade (if trust floor met and asymmetry exists)
      3. Theft (if desperate and neighbor is a low-trust stranger)
    
    At most one transfer per agent per tick to avoid flooding.
    """
    if not getattr(agent, "alive", False):
        return []

    events = []
    rng.shuffle(nearby_agents)

    for other in nearby_agents:
        if not getattr(other, "alive", False):
            continue
        if other.id == agent.id:
            continue

        # Priority 1: Charity
        ev = attempt_charity(agent, other, tick, phase_name, rng)
        if ev:
            events.append(ev)
            break  # one transfer per tick

        # Priority 2: Trade
        ev = attempt_trade(agent, other, tick, phase_name, rng)
        if ev:
            events.append(ev)
            break

        # Priority 3: Theft
        ev = attempt_theft(agent, other, tick, phase_name, rng)
        if ev:
            events.append(ev)
            break

    return events


def transfer_metrics(event_log: list, since_tick: int = 0) -> dict:
    """Summarize resource transfer events for snapshot reporting."""
    trades = [e for e in event_log if e.get("event_type") == "trade" and e.get("tick", 0) >= since_tick]
    thefts = [e for e in event_log if e.get("event_type") == "theft" and e.get("tick", 0) >= since_tick]
    charities = [e for e in event_log if e.get("event_type") == "charity" and e.get("tick", 0) >= since_tick]
    cross_biome_trades = [t for t in trades if t.get("context", {}).get("cross_biome")]
    cross_faction_charities = [c for c in charities if c.get("context", {}).get("cross_faction")]
    theft_successes = [t for t in thefts if t.get("outcome") == "theft_success"]

    return {
        "trades": len(trades),
        "cross_biome_trades": len(cross_biome_trades),
        "thefts": len(thefts),
        "theft_successes": len(theft_successes),
        "charities": len(charities),
        "cross_faction_charities": len(cross_faction_charities),
        "total_transfers": len(trades) + len(thefts) + len(charities),
    }
