# DEPRECATED (v4.50 kernel migration)
# Runtime logic has moved to kernel/runtime.py
# Use: python run_kernel_exp_E.py --config configs/exp_E.json
# This file is preserved for reference. Do not add new simulation logic here.
# See kernel/kernel_migration_audit.md

"""Single band: 30 agents, 1 group, 1000 ticks."""
import sys, os, json, random
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from agent import Agent
from environment import EnvironmentCycle
from metrics import population_metrics, topology_metrics
from space import SpatialWorld
from resources import ResourceWorld
from factions import FactionRegistry
from territory import TerritoryMap
from institutions import InstitutionRegistry
from culture import CulturePool
from reproduction import ReproductionSystem
from language import WorldNarrative
from deception import DECEIVE_THRESHOLD
from experiential import TextureChronicle
import attractor as attractor_mod
import salience as salience_mod
import manifest as manifest_mod
import psychology as psychology_mod
import continuity as continuity_mod
from checkpoint import CheckpointWriter
from death_ledger import DeathLedger, build_death_record
from persistence import PersistenceLedger
from scenario_profiles import load_scenario, apply_population_profile, scenario_agent_names, summarize_scenario_agents
from constraints import ConstraintLedger
from generational import GenerationalLedger, apply_tick as apply_generational_tick, assign_child_context, init_agent as init_generational_agent
from apprenticeship import ApprenticeshipLedger, apply_tick as apply_apprenticeship_tick, init_agent as init_apprenticeship_agent
from logistics import LogisticsWorld
import biology as biology_mod
from innovation import InnovationEngine, apply_tick as apply_innovation_tick, init_agent as init_innovation_agent
from harness import EventStream, RollingCounters, RunManifest, safe_agent_tick
from information import InformationLedger, apply_tick as apply_information_tick, init_agent as init_information_agent
from governance import GovernanceLedger, apply_tick as apply_governance_tick, init_agent as init_governance_agent
from subsistence import SubsistenceWorld
from generational_psychology import GenerationalPsychologyLedger, apply_storykeeper_transmission, apply_targeted_care_recovery
from institutional_memory import InstitutionalMemoryLedger, apply_institutional_memory_tick
from social_viability import seed_viable_founder_band, apply_population_viability_tick
from settlements import SettlementLedger
from ecological_context import ecological_health as _eco_health_fn
import life_events as life_events_mod
from epochs import detect_epochs, summarize_epochs

TICKS = 1000
SEED = 42
OUTPUT_ROOT = Path("/tmp/hrm_run_single_band")
CHECKPOINT_INTERVAL = 100

AGENT_NAMES = [
    "Ada","Bruno","Cleo","Dax","Eli","Faye","Gio","Hana","Ira","Juno",
    "Kael","Lira","Marsh","Neva","Orin","Pell","Quinn","Rook","Sera","Tarn",
    "Ulan","Vara","Wren","Xan","Yeva","Zale","Asha","Bram","Cove","Dell"
]

def serialize_event(event):
    return {"tick":event.tick,"phase":event.phase,"actor_id":event.actor_id,
            "event_type":event.event_type,"participants":event.participants,
            "context":event.context,"impact":event.impact,"outcome":event.outcome}

def main():
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    output_dir = OUTPUT_ROOT / "run_1"
    output_dir.mkdir(parents=True, exist_ok=True)

    world_rng = random.Random(SEED)
    spatial_world = SpatialWorld(width=20, height=20, interaction_radius=3)
    resource_world = ResourceWorld(width=20, height=20, n_nodes=60, rng=world_rng)
    faction_registry = FactionRegistry()
    territory_map = TerritoryMap(width=20, height=20)
    institution_registry = InstitutionRegistry()
    culture_pool = CulturePool()
    reproduction_system = ReproductionSystem(max_population=60)
    world_narrative = WorldNarrative()
    texture_chronicle = TextureChronicle()
    persistence_ledger = PersistenceLedger()
    env = EnvironmentCycle()
    logistics_world = LogisticsWorld(20, 20, seed=SEED+44000)
    subsistence_world = SubsistenceWorld(20, 20, seed=SEED+43300)
    genpsych_ledger = GenerationalPsychologyLedger()
    institutional_memory_ledger = InstitutionalMemoryLedger()
    spatial_world.logistics_world = logistics_world
    resource_world.logistics_world = logistics_world
    settlement_ledger = SettlementLedger()

    agents = []
    for i, name in enumerate(AGENT_NAMES):
        agent = Agent(name, seed=i+1,
                     spatial_world=spatial_world,
                     faction_registry=faction_registry,
                     culture_pool=culture_pool)
        init_generational_agent(agent, generation=0, household_id=None, parents=[], birth_tick=0)
        init_apprenticeship_agent(agent)
        init_governance_agent(agent)
        biology_mod.init_agent(agent)
        init_innovation_agent(agent)
        init_information_agent(agent)
        agents.append(agent)

    seed_viable_founder_band(agents, spatial_world, random.Random(SEED*43700))
    life_events_mod.initialize_life_events(agents, max_ticks=TICKS, seed=1, key="run_1")
    settlement_seed_events = settlement_ledger.seed_founder_settlements(agents, logistics_world, tick=0)
    (output_dir/"agents_initial.json").write_text(json.dumps([a.snapshot() for a in agents], indent=2), encoding="utf-8")

    ckpt = CheckpointWriter(output_dir, interval=CHECKPOINT_INTERVAL)
    ledger = DeathLedger()
    event_log = []
    metric_log = []
    _counters = RollingCounters()
    _stream = EventStream(output_dir/"events.jsonl")
    RUN_MANIFEST = RunManifest(OUTPUT_ROOT)
    RUN_MANIFEST.start(1, output_dir)

    for st_ev in settlement_seed_events:
        d = serialize_event(st_ev); d["salience"] = 0.58
        persistence_ledger.record_event(d); event_log.append(d); _counters.record(d); _stream.write(d)

    constraint_ledger = ConstraintLedger()
    generational_ledger = GenerationalLedger()
    apprenticeship_ledger = ApprenticeshipLedger()
    governance_ledger = GovernanceLedger()
    innovation_engine = InnovationEngine()
    information_ledger = InformationLedger()
    death_logged = set()

    print(f"Starting single-band: {len(agents)} agents, {TICKS} ticks")

    for tick in range(TICKS):
        phase = env.get_phase(tick)
        phase = subsistence_world.apply_to_phase(phase)

        for sub_ev in subsistence_world.begin_tick(tick):
            d = serialize_event(sub_ev); d["salience"] = 0.50
            subsistence_world.record_event(sub_ev)
            persistence_ledger.record_event(d); event_log.append(d); _counters.record(d); _stream.write(d)

        _eco_health = _eco_health_fn(subsistence_world, agents, recent_deaths=len([a for a in agents if not a.alive]))
        life_events_mod.step_disease_layer(agents, tick, key="run_1")
        living = [a for a in agents if a.alive]

        for agent in living:
            le_delta = life_events_mod.apply_all_life_effects(agent, tick, key="run_1")
            if le_delta["stress"] != 0.0:
                agent.state.stress = max(0.0, min(1.0, agent.state.stress + le_delta["stress"]*0.012))
            if le_delta["support"] != 0.0:
                agent.state.cooperation = max(0.0, min(1.0, agent.state.cooperation + le_delta["support"]*0.008))
            if le_delta["trust"] != 0.0:
                agent.state.stability = max(0.0, min(1.0, agent.state.stability + le_delta["trust"]*0.006))

        for agent in list(living):
            if not agent.alive: continue
            ev = safe_agent_tick(
                agent, tick, phase, agents,
                spatial_world=spatial_world, resource_world=resource_world,
                faction_registry=faction_registry, territory_map=territory_map,
                institution_registry=institution_registry, culture_pool=culture_pool,
                world_narrative=world_narrative, texture_chronicle=texture_chronicle,
                governance_ledger=governance_ledger, eco_health=_eco_health,
            )
            if not ev: continue
            d = serialize_event(ev)
            d["salience"] = salience_mod.score(d)
            persistence_ledger.record_event(d); event_log.append(d); _counters.record(d); _stream.write(d)

            if ev.event_type == "birth":
                child_id = ev.context.get("child_id")
                parent_ids = ev.context.get("parent_ids", [])
                child = next((a for a in agents if a.id == child_id), None)
                if child:
                    assign_child_context(child, parent_ids, agents, tick)
                    init_innovation_agent(child); init_information_agent(child); init_governance_agent(child)

            if ev.event_type == "death":
                dead = next((a for a in agents if a.id == ev.actor_id), None)
                if dead and dead.id not in death_logged:
                    death_logged.add(dead.id)
                    ledger.record(build_death_record(dead, tick, agents))
                    psychology_mod.notify_death_to_population(dead, agents)

        apply_generational_tick(agents, tick, phase.name, generational_ledger)
        apply_apprenticeship_tick(agents, tick, phase.name, apprenticeship_ledger)
        apply_governance_tick(agents, tick, phase.name, governance_ledger, faction_registry)
        apply_innovation_tick(agents, tick, phase.name, innovation_engine)
        apply_information_tick(agents, tick, information_ledger)
        apply_storykeeper_transmission(agents, tick, phase.name, random.Random(tick+1), genpsych_ledger)
        apply_targeted_care_recovery(agents, tick, phase.name, random.Random(tick+2), genpsych_ledger)
        apply_institutional_memory_tick(agents, tick, phase.name, random.Random(tick+3), institutional_memory_ledger, event_log, faction_registry)
        apply_population_viability_tick(agents, tick, phase.name, spatial_world, random.Random(tick+SEED))

        if tick % 10 == 0:
            living = [a for a in agents if a.alive]
            pm = population_metrics(living)
            tm = topology_metrics(living, faction_registry, tick)
            metric_log.append({
                "tick": tick, "phase": phase.name,
                "alive_count": len(living), **pm, **tm,
                "deaths": len(ledger.deaths),
                "births": sum(1 for a in agents if a.generation > 0),
                "meme_count": len(culture_pool.memes),
                "factions": len(faction_registry.factions),
                "conflict_cumulative": _counters.conflict_total,
                "interaction_cumulative": _counters.interaction_total,
            })

        if ckpt.should_write(tick):
            ckpt.write(tick, phase.name, agents, faction_registry, institution_registry, culture_pool)

        if tick % 100 == 0:
            living = [a for a in agents if a.alive]
            gen1 = sum(1 for a in living if a.generation > 0)
            print(f"  t={tick:4d}: alive={len(living)} (gen0={len(living)-gen1} gen1+={gen1}) "
                  f"factions={len(faction_registry.factions)} memes={len(culture_pool.memes)} "
                  f"births={sum(1 for a in agents if a.generation>0)}")

    # Outputs
    living_final = [a for a in agents if a.alive]
    (output_dir/"agents_final.json").write_text(json.dumps([a.snapshot() for a in agents], indent=2), encoding="utf-8")
    (output_dir/"deaths.json").write_text(json.dumps(ledger.deaths, indent=2), encoding="utf-8")
    (output_dir/"metrics.json").write_text(json.dumps(metric_log, indent=2), encoding="utf-8")
    (output_dir/"culture.json").write_text(json.dumps(culture_pool.snapshot(), indent=2), encoding="utf-8")
    (output_dir/"factions.json").write_text(json.dumps(
        [{"id":f.id,"name":f.name,"members":f.members,"hostility":f.hostility} for f in faction_registry.factions.values()], indent=2), encoding="utf-8")
    (output_dir/"innovation.json").write_text(json.dumps(innovation_engine.snapshot(), indent=2), encoding="utf-8")

    initial_ids = {a.id for a in agents if getattr(a,'generation',0)==0}
    continuity_mod.build_continuity_outputs(output_dir, agents, event_log, initial_ids, culture_pool, faction_registry, generational_ledger)

    print(f"\nComplete. {len(living_final)}/{len(agents)} survive.")
    print(f"Interactions: {_counters.interaction_total}  Conflicts: {_counters.conflict_total}  "
          f"({100*_counters.conflict_total/max(1,_counters.interaction_total):.2f}%)")
    print(f"Births: {sum(1 for a in agents if a.generation>0)}")
    print(f"Survivors: {[a.name for a in living_final]}")

if __name__ == "__main__":
    main()
