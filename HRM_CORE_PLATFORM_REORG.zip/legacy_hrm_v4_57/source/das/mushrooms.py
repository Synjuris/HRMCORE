"""
das/mushrooms.py  —  Psychoactive mushroom patch (v4.57 add-on)

A single, droppable psychoactive resource patch. Drop it anywhere on the world
grid like a shock event; agents that wander into its radius get "dosed" and
their affect/behaviour state is perturbed for a while, then decays.

This module is fully self-contained. It imports only existing schemas and does
not modify any engine file. Wire it in where you run ticks:

    from das.mushrooms import MushroomPatch

    shrooms = MushroomPatch()            # created once, dormant until dropped
    shrooms.drop(x=10, y=8)              # the "shock": one patch, here
    ...
    # inside your per-tick loop, after agents have positions:
    events = shrooms.tick(agents, tick, phase_name="mushroom")

`agents` is any iterable of objects exposing `.id`, `.state` (an AgentState),
and an (x, y) position. Position lookup is flexible: it checks agent.x/agent.y,
agent.pos.x/.y, or agent.state.x/.y — whatever your run loop uses.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import math
import random

try:
    from schemas import Event, new_id
except Exception:  # allow `from das.mushrooms import ...`
    from das.schemas import Event, new_id


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def _agent_xy(agent) -> Optional[tuple]:
    """Find an agent's (x, y) wherever the run loop stored it."""
    for getter in (
        lambda a: (a.x, a.y),
        lambda a: (a.pos.x, a.pos.y),
        lambda a: (a.position.x, a.position.y),
        lambda a: (a.state.x, a.state.y),
    ):
        try:
            x, y = getter(agent)
            if x is not None and y is not None:
                return float(x), float(y)
        except Exception:
            continue
    return None


@dataclass
class MushroomPatch:
    """One psychoactive patch. Dormant until drop() is called."""
    radius: float = 2.5            # grid-cells of effect
    potency: float = 1.0           # global multiplier on the trip
    onset: float = 0.45            # per-tick build-up of trip intensity in-patch
    decay: float = 0.06            # per-tick fade of trip once out of patch
    regen_rate: float = 0.015      # patch restocks slowly after being foraged down
    seed: int = 0

    # runtime state (set by drop())
    active: bool = False
    x: Optional[float] = None
    y: Optional[float] = None
    stock: float = 1.0
    id: str = field(default_factory=lambda: new_id("shroom"))
    _trip: Dict[str, float] = field(default_factory=dict)   # agent_id -> intensity 0..1
    _rng: random.Random = field(default=None, repr=False)

    def __post_init__(self):
        self._rng = random.Random(self.seed)

    # ── control ──────────────────────────────────────────────────────────────
    def drop(self, x: float, y: float, stock: float = 1.0) -> None:
        """Place the single patch (the 'shock'). Re-dropping moves it."""
        self.x, self.y = float(x), float(y)
        self.stock = clamp(stock)
        self.active = True

    def clear(self) -> None:
        self.active = False
        self.x = self.y = None

    def _in_patch(self, ax: float, ay: float) -> float:
        """Returns dose factor 0..1 by distance; 0 outside radius."""
        d = math.hypot(ax - self.x, ay - self.y)
        if d > self.radius:
            return 0.0
        return (1.0 - d / self.radius)

    # ── the trip ─────────────────────────────────────────────────────────────
    def _apply_trip(self, agent, intensity: float) -> None:
        """
        Psychoactive effect, expressed in the engine's real state fields.
        A trip loosens the agent: perception widens, ego-boundaries soften,
        ordinary threat/striving quiet down, but it can also destabilise.
        Scaled by intensity (0..1) so it ramps and fades smoothly.
        """
        s = agent.state
        k = intensity * self.potency
        j = lambda: (self._rng.random() * 2.0 - 1.0)   # jitter -1..1

        # widened perception / openness — the core of the effect
        s.curiosity        = clamp(s.curiosity        + 0.030 * k)
        s.social_openness  = clamp(s.social_openness  + 0.035 * k)
        if hasattr(s, "novelty_saturation"):
            s.novelty_saturation = clamp(s.novelty_saturation + 0.040 * k)

        # ego / striving quiet down
        s.dominance        = clamp(s.dominance        - 0.025 * k)
        s.fear             = clamp(s.fear             - 0.020 * k)

        # affect swings — usually warmer, sometimes a bad trip
        warm = 0.030 * k if self._rng.random() > 0.18 else -0.045 * k
        if hasattr(s, "valence"):
            s.valence = clamp(s.valence + warm, -1.0, 1.0)

        # destabilisation: identity/coherence loosens, stress wobbles either way
        s.stability        = clamp(s.stability        - 0.030 * k)
        s.stress           = clamp(s.stress           + 0.015 * k * abs(j()))
        if hasattr(s, "ideology_alignment"):
            # suggestible: alignment drifts randomly while tripping
            s.ideology_alignment = clamp(s.ideology_alignment + 0.05 * k * j())

        # mild metabolic cost — tripping is not eating
        if hasattr(s, "hunger"):
            s.hunger = clamp(s.hunger + 0.004 * k)

    def tick(self, agents, tick: int, phase_name: str = "mushroom") -> List[Event]:
        """
        Advance the patch one tick. Dose agents inside it, fade agents outside,
        regrow stock. Returns Events for any newly-dosed agents (observer-visible).
        """
        events: List[Event] = []
        if not self.active:
            return events

        for agent in agents:
            xy = _agent_xy(agent)
            if xy is None:
                continue
            dose = self._in_patch(*xy) if self.stock > 0.03 else 0.0
            cur = self._trip.get(agent.id, 0.0)

            if dose > 0.0:
                # build up intensity, consume a little patch stock
                new = clamp(cur + self.onset * dose)
                self.stock = clamp(self.stock - 0.01 * dose)
                if cur < 0.05 and new >= 0.05:   # just crossed into tripping
                    events.append(Event(
                        tick, phase_name, agent.id, "mushroom_dose", [],
                        {"patch": self.id, "dose": round(dose, 3)},
                        {"curiosity": 0.03, "social_openness": 0.035, "stability": -0.03},
                        "tripping",
                    ))
                self._trip[agent.id] = new
            else:
                # fade out
                new = cur - self.decay
                if new <= 0.0:
                    if agent.id in self._trip:
                        del self._trip[agent.id]
                    continue
                self._trip[agent.id] = new

            self._apply_trip(agent, self._trip[agent.id])

        # patch slowly regrows after being foraged down
        if self.stock < 1.0:
            self.stock = clamp(self.stock + self.regen_rate)
        return events

    # ── observability ────────────────────────────────────────────────────────
    def tripping_count(self) -> int:
        return sum(1 for v in self._trip.values() if v >= 0.05)

    def snapshot(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "active": self.active,
            "x": self.x, "y": self.y,
            "radius": self.radius,
            "stock": round(self.stock, 4),
            "tripping": self.tripping_count(),
            "potency": self.potency,
        }


if __name__ == "__main__":
    # tiny self-test with fake agents (no engine needed)
    class _S:  # minimal stand-in for AgentState
        def __init__(self):
            self.curiosity=0.5; self.social_openness=0.5; self.dominance=0.5
            self.fear=0.2; self.stability=0.6; self.stress=0.2
            self.valence=0.0; self.novelty_saturation=0.0
            self.ideology_alignment=0.5; self.hunger=0.1
    class _A:
        def __init__(self, i, x, y): self.id=f"a{i}"; self.x=x; self.y=y; self.state=_S()

    agents=[_A(0,10,8), _A(1,10.5,8.2), _A(2,30,30)]  # first two in patch, third far
    patch=MushroomPatch(seed=1)
    patch.drop(10, 8)
    for t in range(8):
        ev=patch.tick(agents, t)
        print(f"tick {t}: tripping={patch.tripping_count()} "
              f"a0.curiosity={agents[0].state.curiosity:.3f} "
              f"a0.stability={agents[0].state.stability:.3f} events={len(ev)}")
    print("snapshot:", patch.snapshot())
