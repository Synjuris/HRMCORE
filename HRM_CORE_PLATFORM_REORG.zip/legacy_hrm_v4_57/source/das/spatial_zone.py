"""
spatial_zone.py — HRM Spatial Agency Layer v1

Divides the world grid into zones, each with independent local fauna pools
that deplete and recover independently. Global fauna remains as fallback.

Zone grid: configurable, default 4x4 = 16 zones on a 40x40 world.
Each zone cell covers (world_w / zone_cols) x (world_h / zone_rows) grid cells.

Fauna drift: slow, conservative. Each tick, 1-3% of surplus fauna in a zone
bleeds into adjacent lower-density zones. Prevents permanent dead zones.

Seasonal modifiers: biome-specific, applied on top of global season.
Woodland buffers winter. Wetland collapses in winter. Meadow booms in spring.
Savanna stays hunted year-round.

Feature flag: SPATIAL_ECOLOGY_ENABLED
If False, all methods return None and subsistence falls back to global fauna.
"""

from __future__ import annotations
import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

SPATIAL_ECOLOGY_ENABLED = True

# Zone grid dimensions
ZONE_COLS = 4
ZONE_ROWS = 4

# Fauna drift rate — fraction of surplus that moves to adjacent zone per tick
DRIFT_RATE_MIN = 0.010
DRIFT_RATE_MAX = 0.028

# Crowding pressure — yield scales down as local population rises
CROWDING_DENOMINATOR = 6.0   # agents before crowding starts hurting yield

# Biome seasonal modifiers — multiplier on fauna recovery per season
# Format: biome -> {season_name: recovery_multiplier}
BIOME_SEASONAL_RECOVERY = {
    "woodland": {
        "spring": 1.30, "summer": 1.10, "autumn": 0.90, "winter": 0.65,
    },
    "meadow": {
        "spring": 1.60, "summer": 1.20, "autumn": 0.70, "winter": 0.30,
    },
    "wetland": {
        "spring": 1.50, "summer": 1.30, "autumn": 0.80, "winter": 0.20,
    },
    "savanna": {
        "spring": 1.10, "summer": 1.00, "autumn": 1.05, "winter": 0.80,
    },
}

# Biome seasonal gather modifiers — multiplier on plant yield per season
BIOME_SEASONAL_GATHER = {
    "woodland": {
        "spring": 1.10, "summer": 1.00, "autumn": 0.85, "winter": 0.40,
    },
    "meadow": {
        "spring": 1.70, "summer": 1.40, "autumn": 0.60, "winter": 0.15,
    },
    "wetland": {
        "spring": 1.80, "summer": 1.60, "autumn": 0.70, "winter": 0.10,
    },
    "savanna": {
        "spring": 0.80, "summer": 0.70, "autumn": 0.65, "winter": 0.35,
    },
}

# Starting fauna per zone by biome — scaled from global baseline
BIOME_FAUNA_INIT = {
    "woodland": {"deer": 40.0, "boar": 24.0, "rabbits": 60.0,
                 "goats": 10.0, "aurochs": 5.0},
    "meadow":   {"deer": 15.0, "boar": 8.0,  "rabbits": 120.0,
                 "goats": 25.0, "aurochs": 8.0},
    "wetland":  {"deer": 10.0, "boar": 12.0, "rabbits": 90.0,
                 "goats": 8.0,  "aurochs": 3.0},
    "savanna":  {"deer": 8.0,  "boar": 6.0,  "rabbits": 40.0,
                 "goats": 30.0, "aurochs": 35.0},
}

BIOME_FAUNA_MAX = {
    "woodland": {"deer": 60.0, "boar": 35.0, "rabbits": 100.0,
                 "goats": 18.0, "aurochs": 10.0},
    "meadow":   {"deer": 25.0, "boar": 14.0, "rabbits": 180.0,
                 "goats": 40.0, "aurochs": 15.0},
    "wetland":  {"deer": 18.0, "boar": 20.0, "rabbits": 140.0,
                 "goats": 14.0, "aurochs": 6.0},
    "savanna":  {"deer": 14.0, "boar": 10.0, "rabbits": 65.0,
                 "goats": 50.0, "aurochs": 55.0},
}

FAUNA_BASE_RECOVERY = {
    "deer": 0.042, "boar": 0.036, "rabbits": 0.110,
    "goats": 0.058, "aurochs": 0.025,
}


@dataclass
class ZoneFauna:
    """Local fauna pool for one zone."""
    species: str
    population: float
    max_population: float
    recovery_rate: float

    def tick(self, season_name: str, biome: str) -> None:
        """Recover population this tick, modified by biome+season."""
        mod = BIOME_SEASONAL_RECOVERY.get(biome, {}).get(season_name, 1.0)
        growth = self.population * self.recovery_rate * mod
        self.population = min(self.max_population, self.population + growth)

    def deplete(self, amount: float) -> float:
        """Remove amount from local pool. Returns actual amount taken."""
        taken = min(self.population, max(0.0, amount))
        self.population = max(0.0, self.population - taken)
        return taken

    def surplus_fraction(self) -> float:
        """How full is this zone? 0=empty, 1=at capacity."""
        if self.max_population <= 0:
            return 0.0
        return self.population / self.max_population


@dataclass
class Zone:
    """One zone cell in the world grid."""
    zone_id: str
    col: int
    row: int
    biome: str
    fauna: Dict[str, ZoneFauna] = field(default_factory=dict)
    local_population: int = 0   # agents currently in this zone, updated each tick

    def get_fauna(self, species: str) -> Optional[ZoneFauna]:
        return self.fauna.get(species)

    def total_fauna(self) -> float:
        return sum(f.population for f in self.fauna.values())

    def hunt_yield_modifier(self) -> float:
        """How favorable is this zone for hunting right now?"""
        total = self.total_fauna()
        max_total = sum(f.max_population for f in self.fauna.values())
        if max_total <= 0:
            return 0.0
        return total / max_total

    def gather_modifier(self, season_name: str) -> float:
        """Gather yield modifier for this zone this season."""
        return BIOME_SEASONAL_GATHER.get(self.biome, {}).get(season_name, 1.0)

    def crowding_factor(self) -> float:
        """Yield penalty from local overcrowding. 1.0 = no penalty."""
        if self.local_population <= CROWDING_DENOMINATOR:
            return 1.0
        return CROWDING_DENOMINATOR / self.local_population

    def effective_hunt_yield(self, season_name: str) -> float:
        """Combined hunt yield signal for agent memory."""
        return self.hunt_yield_modifier() * self.crowding_factor()

    def effective_gather_yield(self, season_name: str) -> float:
        """Combined gather yield signal for agent memory."""
        return self.gather_modifier(season_name) * self.crowding_factor()

    def tick_fauna(self, season_name: str) -> None:
        for f in self.fauna.values():
            f.tick(season_name, self.biome)

    def adjacent_ids(self, cols: int, rows: int) -> List[str]:
        """Return zone_ids of cardinal neighbors."""
        neighbors = []
        for dc, dr in [(-1,0),(1,0),(0,-1),(0,1)]:
            nc, nr = self.col + dc, self.row + dr
            if 0 <= nc < cols and 0 <= nr < rows:
                neighbors.append(f"z_{nc}_{nr}")
        return neighbors


class ZoneGrid:
    """
    Manages the full zone grid for a world.
    Handles zone lookup, fauna ticking, and inter-zone drift.
    """

    def __init__(self, world_w: int, world_h: int,
                 cols: int = ZONE_COLS, rows: int = ZONE_ROWS,
                 seed: int = 0):
        self.world_w = world_w
        self.world_h = world_h
        self.cols = cols
        self.rows = rows
        self.cell_w = world_w / cols
        self.cell_h = world_h / rows
        self.rng = random.Random(seed)
        self.zones: Dict[str, Zone] = {}
        self._build_zones()

    def _build_zones(self) -> None:
        try:
            from spatial_biomes import get_biome
        except ImportError:
            get_biome = None

        for col in range(self.cols):
            for row in range(self.rows):
                zid = f"z_{col}_{row}"
                cx = int((col + 0.5) * self.cell_w)
                cy = int((row + 0.5) * self.cell_h)
                biome = get_biome(cx, cy).name if get_biome else "meadow"

                fauna = {}
                init = BIOME_FAUNA_INIT.get(biome, BIOME_FAUNA_INIT["meadow"])
                maxf = BIOME_FAUNA_MAX.get(biome, BIOME_FAUNA_MAX["meadow"])
                for species, pop in init.items():
                    # Small random variation at init
                    pop_v = pop * self.rng.uniform(0.85, 1.15)
                    max_v = maxf[species]
                    rec = FAUNA_BASE_RECOVERY[species]
                    fauna[species] = ZoneFauna(species, pop_v, max_v, rec)

                self.zones[zid] = Zone(
                    zone_id=zid, col=col, row=row,
                    biome=biome, fauna=fauna,
                )

    def zone_for_position(self, x: float, y: float) -> Zone:
        """Return the zone containing grid position (x, y)."""
        col = min(self.cols - 1, int(x / self.cell_w))
        row = min(self.rows - 1, int(y / self.cell_h))
        return self.zones[f"z_{col}_{row}"]

    def zone_id_for_position(self, x: float, y: float) -> str:
        col = min(self.cols - 1, int(x / self.cell_w))
        row = min(self.rows - 1, int(y / self.cell_h))
        return f"z_{col}_{row}"

    def update_local_populations(self, agents: list) -> None:
        """Count living agents per zone. Call once per tick before fauna tick."""
        for z in self.zones.values():
            z.local_population = 0
        for a in agents:
            if getattr(a, "alive", False):
                x = getattr(getattr(a, "position", None), "x", 0)
                y = getattr(getattr(a, "position", None), "y", 0)
                zid = self.zone_id_for_position(x, y)
                if zid in self.zones:
                    self.zones[zid].local_population += 1

    def tick(self, season_name: str) -> None:
        """Tick all zone fauna and apply drift."""
        for z in self.zones.values():
            z.tick_fauna(season_name)
        self._drift_fauna()

    def _drift_fauna(self) -> None:
        """Move small fraction of surplus fauna into adjacent lower-density zones."""
        for zid, zone in self.zones.items():
            neighbor_ids = zone.adjacent_ids(self.cols, self.rows)
            for species, f in zone.fauna.items():
                if f.population < 2.0:
                    continue
                surplus = f.surplus_fraction()
                if surplus < 0.55:
                    continue
                rate = self.rng.uniform(DRIFT_RATE_MIN, DRIFT_RATE_MAX)
                drift_amount = f.population * rate * (surplus - 0.50)
                if drift_amount < 0.1:
                    continue
                # Find neighbors with lower density
                targets = []
                for nid in neighbor_ids:
                    nz = self.zones.get(nid)
                    if nz:
                        nf = nz.fauna.get(species)
                        if nf and nf.surplus_fraction() < surplus - 0.10:
                            targets.append(nf)
                if not targets:
                    continue
                per_target = drift_amount / len(targets)
                f.population = max(0.0, f.population - drift_amount)
                for tf in targets:
                    tf.population = min(tf.max_population,
                                        tf.population + per_target)

    def deplete_fauna(self, x: float, y: float,
                      species: str, amount: float) -> float:
        """
        Deplete fauna in the zone at position (x,y).
        Returns actual amount taken (may be less than requested).
        """
        zone = self.zone_for_position(x, y)
        f = zone.fauna.get(species)
        if f is None:
            return 0.0
        return f.deplete(amount)

    def snapshot(self) -> dict:
        out = {}
        for zid, z in self.zones.items():
            out[zid] = {
                "biome": z.biome,
                "local_pop": z.local_population,
                "total_fauna": round(z.total_fauna(), 2),
                "fauna": {s: round(f.population, 2)
                          for s, f in z.fauna.items()},
            }
        return out
