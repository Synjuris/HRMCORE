# DEPRECATED (v4.50 kernel migration)
# Runtime logic has moved to kernel/runtime.py
# Use: python run_kernel_exp_E.py --config configs/exp_E.json
# This file is preserved for reference. Do not add new simulation logic here.
# See kernel/kernel_migration_audit.md

"""
Civilization run: 16 founders, single band, 5000 ticks, snapshot every 500.
Tuned for generational depth and cultural emergence.
"""
import sys, json, random
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from agent import Agent
from environment import EnvironmentCycle
from metrics import population_metrics, topology_metrics
from space import SpatialWorld
from resources import ResourceWorld
from factions import FactionRegistry
from territory import TerritoryMap
from institutions import InstitutionRegistry
from culture import CulturePool
from reproduction import ReproductionSystem
from language import WorldNarrative
from experiential import TextureChronicle
import attractor as attractor_mod
import salience as salience_mod
import psychology as psychology_mod
import continuity as continuity_mod
from checkpoint import CheckpointWriter
from death_ledger import DeathLedger, build_death_record
from persistence import PersistenceLedger
from constraints import ConstraintLedger
from generational import GenerationalLedger, apply_tick as apply_generational_tick, assign_child_context, init_agent as init_generational_agent
from apprenticeship import ApprenticeshipLedger, apply_tick as apply_apprenticeship_tick, init_agent as init_apprenticeship_agent
from logistics import LogisticsWorld
import biology as biology_mod
from innovation import InnovationEngine, apply_tick as apply_innovation_tick, init_agent as init_innovation_agent
from harness import EventStream, RollingCounters, RunManifest, safe_agent_tick
from information import InformationLedger, apply_tick as apply_information_tick, init_agent as init_information_agent
from governance import GovernanceLedger, apply_tick as apply_governance_tick, init_agent as init_governance_agent
from subsistence import SubsistenceWorld
from generational_psychology import GenerationalPsychologyLedger, apply_storykeeper_transmission, apply_targeted_care_recovery
from institutional_memory import InstitutionalMemoryLedger, apply_institutional_memory_tick
from social_viability import seed_viable_founder_band, apply_population_viability_tick
from settlements import SettlementLedger
from ecological_context import ecological_health as _eco_health_fn
import life_events as life_events_mod
from epochs import detect_epochs, summarize_epochs

TICKS       = 5000
SEED        = 13
SNAP_EVERY  = 500
OUTPUT_ROOT = Path("/tmp/hrm_civilization_v2")
WORLD_W, WORLD_H = 18, 18

AGENT_NAMES = [
    "Ada","Bruno","Cleo","Dax","Eli","Faye","Gio","Hana",
    "Ira","Juno","Kael","Lira","Marsh","Neva","Orin","Pell",
    "Quinn","Rook","Sera","Tarn",
]

def serialize_event(e):
    return {"tick":e.tick,"phase":e.phase,"actor_id":e.actor_id,
            "event_type":e.event_type,"participants":e.participants,
            "context":e.context,"impact":e.impact,"outcome":e.outcome}

def snapshot_report(tick, agents, ledger, culture_pool, faction_registry,
                    innovation_engine, counters, generational_ledger, event_log):
    """Print a narrative snapshot at each 500-tick stop."""
    living = [a for a in agents if a.alive]
    gen0   = [a for a in living if a.generation == 0]
    gen1p  = [a for a in living if a.generation >= 1]
    births = sum(1 for a in agents if a.generation >= 1)
    
    total_int  = counters.interaction_total
    total_conf = counters.conflict_total
    conf_rate  = 100 * total_conf / max(1, total_int)

    memes = sorted(culture_pool.memes.values() if hasattr(culture_pool,'memes') and isinstance(culture_pool.memes, dict)
                   else culture_pool.memes if hasattr(culture_pool,'memes') else [],
                   key=lambda m: getattr(m,'strength',0), reverse=True)

    innov_s = innovation_engine.snapshot().get('summary', {})

    print(f"\n{'='*60}")
    print(f"  TICK {tick} SNAPSHOT")
    print(f"{'='*60}")
    print(f"  Population : {len(living)} alive / {len(agents)} total  ({len(gen0)} founders, {len(gen1p)} born-in-run)")
    print(f"  Deaths     : {len(ledger.deaths)}  (births so far: {births})")
    print(f"  Conflict   : {total_conf}/{total_int} interactions ({conf_rate:.2f}%)")
    print(f"  Factions   : {len(faction_registry.factions)}")
    print(f"  Memes      : {len(culture_pool.memes if hasattr(culture_pool,'memes') else [])} active")
    print(f"  Innovation : {innov_s.get('total_successes',0)} successes, registry={innov_s.get('registry_size',0)}")
    
    top_memes = []
    snap = culture_pool.snapshot()
    for m in sorted(snap.get('meme_list',[]), key=lambda x: x.get('strength',0), reverse=True)[:3]:
        top_memes.append(f"{m['label']} (val={m['valence']:+.1f}, str={m.get('strength',0):.2f})")
    if top_memes:
        print(f"  Top memes  : {' | '.join(top_memes)}")

    if gen1p:
        print(f"  Born agents: {[a.name for a in gen1p[:8]]}")
    
    # Notable survivors
    for a in sorted(living, key=lambda x: x.state.age, reverse=True)[:3]:
        tags = a.experience.identity_tags[:3] if hasattr(a.experience,'identity_tags') else []
        print(f"  {a.name:12s} age={a.state.age:4d} role={a.snapshot()['specialization']['role']:12s} "
              f"stress={a.state.stress:.2f} tags={tags}")
    print()

def main():
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    output_dir = OUTPUT_ROOT / "run_1"
    output_dir.mkdir(parents=True, exist_ok=True)

    world_rng   = random.Random(SEED)
    spatial_world = SpatialWorld(width=WORLD_W, height=WORLD_H, interaction_radius=3)
    resource_world = ResourceWorld(width=WORLD_W, height=WORLD_H, n_nodes=55, rng=world_rng)
    faction_registry   = FactionRegistry()
    territory_map      = TerritoryMap(width=WORLD_W, height=WORLD_H)
    institution_registry = InstitutionRegistry()
    culture_pool       = CulturePool()
    reproduction_system = ReproductionSystem(max_population=50)
    world_narrative    = WorldNarrative()
    texture_chronicle  = TextureChronicle()
    persistence_ledger = PersistenceLedger()
    env                = EnvironmentCycle()
    logistics_world    = LogisticsWorld(WORLD_W, WORLD_H, seed=SEED+44000)
    subsistence_world  = SubsistenceWorld(WORLD_W, WORLD_H, seed=SEED+43300)
    genpsych_ledger    = GenerationalPsychologyLedger()
    inst_mem_ledger    = InstitutionalMemoryLedger()
    spatial_world.logistics_world  = logistics_world
    resource_world.logistics_world = logistics_world
    settlement_ledger  = SettlementLedger()

    agents = []
    for i, name in enumerate(AGENT_NAMES):
        a = Agent(name, seed=i+1, spatial_world=spatial_world,
                  faction_registry=faction_registry, culture_pool=culture_pool)
        # Override age to peak-libido window: 60–140
        a.state.age = random.Random(SEED+i).randint(60, 140)
        init_generational_agent(a, generation=0, household_id=None, parents=[], birth_tick=0)
        init_apprenticeship_agent(a)
        init_governance_agent(a)
        biology_mod.init_agent(a)
        init_innovation_agent(a)
        init_information_agent(a)
        agents.append(a)

    seed_viable_founder_band(agents, spatial_world, random.Random(SEED*43700))
    life_events_mod.initialize_life_events(agents, max_ticks=TICKS, seed=1, key="run_1")
    settlement_seed_events = settlement_ledger.seed_founder_settlements(agents, logistics_world, tick=0)
    (output_dir/"agents_initial.json").write_text(
        json.dumps([a.snapshot() for a in agents], indent=2), encoding="utf-8")

    ckpt    = CheckpointWriter(output_dir, interval=500)
    ledger  = DeathLedger()
    event_log  = []
    metric_log = []
    _counters  = RollingCounters()
    _stream    = EventStream(output_dir/"events.jsonl")
    RUN_MANIFEST = RunManifest(OUTPUT_ROOT)
    RUN_MANIFEST.start(1, output_dir)

    for st_ev in settlement_seed_events:
        d = serialize_event(st_ev); d["salience"] = 0.58
        persistence_ledger.record_event(d); event_log.append(d)
        _counters.record(d); _stream.write(d)

    constraint_ledger    = ConstraintLedger()
    generational_ledger  = GenerationalLedger()
    apprenticeship_ledger = ApprenticeshipLedger()
    governance_ledger    = GovernanceLedger()
    innovation_engine    = InnovationEngine()
    information_ledger   = InformationLedger()
    death_logged = set()

    print(f"CIVILIZATION RUN: {len(agents)} founders, {TICKS} ticks, snapshot every {SNAP_EVERY}")
    print(f"World: {WORLD_W}x{WORLD_H}, max_pop=50, stress_repro_ceiling=0.88, energy_floor=0.10")
    snapshot_report(0, agents, ledger, culture_pool, faction_registry,
                    innovation_engine, _counters, generational_ledger, event_log)

    for tick in range(1, TICKS + 1):
        phase = env.get_phase(tick)
        phase = subsistence_world.apply_to_phase(phase)

        for sub_ev in subsistence_world.begin_tick(tick):
            d = serialize_event(sub_ev); d["salience"] = 0.50
            subsistence_world.record_event(sub_ev)
            persistence_ledger.record_event(d); event_log.append(d)
            _counters.record(d); _stream.write(d)

        _eco = _eco_health_fn(subsistence_world, agents,
                              recent_deaths=sum(1 for a in agents if not a.alive))
        life_events_mod.step_disease_layer(agents, tick, key="run_1")
        living = [a for a in agents if a.alive]

        for a in living:
            le = life_events_mod.apply_all_life_effects(a, tick, key="run_1")
            if le["stress"]:  a.state.stress     = max(0., min(1., a.state.stress     + le["stress"]*0.012))
            if le["support"]: a.state.cooperation= max(0., min(1., a.state.cooperation+ le["support"]*0.008))
            if le["trust"]:   a.state.stability  = max(0., min(1., a.state.stability  + le["trust"]*0.006))

        for a in list(living):
            if not a.alive: continue
            ev = safe_agent_tick(a, tick, phase, agents,
                spatial_world=spatial_world, resource_world=resource_world,
                faction_registry=faction_registry, territory_map=territory_map,
                institution_registry=institution_registry, culture_pool=culture_pool,
                world_narrative=world_narrative, texture_chronicle=texture_chronicle,
                governance_ledger=governance_ledger, eco_health=_eco)
            if not ev: continue
            d = serialize_event(ev); d["salience"] = salience_mod.score(d)
            persistence_ledger.record_event(d); event_log.append(d)
            _counters.record(d); _stream.write(d)

            if ev.event_type == "birth":
                child_id   = ev.context.get("child_id")
                parent_ids = ev.context.get("parent_ids", [])
                child = next((a for a in agents if a.id == child_id), None)
                if child:
                    assign_child_context(child, parent_ids, agents, tick)
                    init_innovation_agent(child); init_information_agent(child); init_governance_agent(child)

            if ev.event_type == "death":
                dead = next((a for a in agents if a.id == ev.actor_id), None)
                if dead and dead.id not in death_logged:
                    death_logged.add(dead.id)
                    ledger.record(build_death_record(dead, tick, agents))
                    psychology_mod.notify_death_to_population(dead, agents)

        # Feed every living agent through the subsistence system
        for a in [x for x in agents if x.alive]:
            for sub_ev in subsistence_world.agent_tick(a, tick, phase.name,
                                                       culture_pool=culture_pool,
                                                       faction_registry=faction_registry):
                d = serialize_event(sub_ev); d["salience"] = 0.52
                subsistence_world.record_event(sub_ev)
                persistence_ledger.record_event(d); event_log.append(d)
                _counters.record(d); _stream.write(d)

        # Reproduction every 25 ticks
        if tick % 25 == 0:
            newborns = reproduction_system.tick(
                agents, spatial_world, faction_registry,
                culture_pool, random.Random(tick * 7), genpsych_ledger=genpsych_ledger,
                tick=tick, eco_health=_eco,
            )
            for child in newborns:
                birth_parents = list(getattr(child, "_birth_parents", []))
                assign_child_context(child, birth_parents, tick, generational_ledger)
                init_innovation_agent(child)
                init_information_agent(child)
                init_governance_agent(child)
                print(f"    *** BIRTH tick={tick}: {child.name} parents={[p.name for p in birth_parents]} ***")
            agents.extend(newborns)

        apply_generational_tick(agents, tick, phase.name, generational_ledger)
        apply_apprenticeship_tick(agents, tick, phase.name, apprenticeship_ledger)
        apply_governance_tick(agents, tick, phase.name, governance_ledger, faction_registry)
        apply_innovation_tick(agents, tick, phase.name, innovation_engine)
        apply_information_tick(agents, tick, information_ledger)
        apply_storykeeper_transmission(agents, tick, phase.name, random.Random(tick+1), genpsych_ledger)
        apply_targeted_care_recovery(agents, tick, phase.name, random.Random(tick+2), genpsych_ledger)
        apply_institutional_memory_tick(agents, tick, phase.name, random.Random(tick+3),
                                        inst_mem_ledger, event_log, faction_registry)
        apply_population_viability_tick(agents, tick, phase.name, spatial_world, random.Random(tick+SEED))

        if tick % 10 == 0:
            lv = [a for a in agents if a.alive]
            pm = population_metrics(lv)
            tm = topology_metrics(lv, faction_registry, tick)
            metric_log.append({
                "tick": tick, "phase": phase.name, "alive_count": len(lv), **pm, **tm,
                "deaths": len(ledger.deaths),
                "births": sum(1 for a in agents if a.generation >= 1),
                "meme_count": len(culture_pool.memes) if hasattr(culture_pool,'memes') else 0,
                "factions": len(faction_registry.factions),
                "conflict_cumulative": _counters.conflict_total,
                "interaction_cumulative": _counters.interaction_total,
                "gen0_alive": sum(1 for a in lv if a.generation == 0),
                "gen1p_alive": sum(1 for a in lv if a.generation >= 1),
            })

        if ckpt.should_write(tick):
            ckpt.write(tick, phase.name, agents, faction_registry, institution_registry, culture_pool)

        if tick % SNAP_EVERY == 0:
            snapshot_report(tick, agents, ledger, culture_pool, faction_registry,
                            innovation_engine, _counters, generational_ledger, event_log)

    # Final outputs
    living_final = [a for a in agents if a.alive]
    (output_dir/"agents_final.json").write_text(json.dumps([a.snapshot() for a in agents], indent=2), encoding="utf-8")
    (output_dir/"deaths.json").write_text(json.dumps(ledger.deaths, indent=2), encoding="utf-8")
    (output_dir/"metrics.json").write_text(json.dumps(metric_log, indent=2), encoding="utf-8")
    (output_dir/"culture.json").write_text(json.dumps(culture_pool.snapshot(), indent=2), encoding="utf-8")
    (output_dir/"factions.json").write_text(json.dumps(
        [{"id":f.id,"name":f.name,"members":f.members,"hostility":f.hostility}
         for f in faction_registry.factions.values()], indent=2), encoding="utf-8")
    (output_dir/"innovation.json").write_text(json.dumps(innovation_engine.snapshot(), indent=2), encoding="utf-8")

    initial_ids = {a.id for a in agents if a.generation == 0}
    continuity_mod.build_continuity_outputs(output_dir, agents, event_log,
                                            initial_ids, culture_pool, faction_registry, generational_ledger)

    print(f"\n{'='*60}")
    print(f"  FINAL: {len(living_final)}/{len(agents)} alive after {TICKS} ticks")
    print(f"  Births: {sum(1 for a in agents if a.generation>=1)}")
    print(f"  Conflict rate: {100*_counters.conflict_total/max(1,_counters.interaction_total):.2f}%")
    print(f"  Survivors: {[a.name for a in living_final]}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
