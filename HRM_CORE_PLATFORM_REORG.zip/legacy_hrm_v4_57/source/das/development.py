"""
development.py — v04.31 developmental imprinting layer

Core thesis:
  The same event has categorically different effects depending on when in
  the lifespan it occurs. Early experience doesn't just add stress — it
  reshapes the trait baseline itself. Traits are supposed to be stable
  personality parameters; the developmental window is the one period when
  lived experience can rewrite them permanently.

Life stages (based on state.age ticks; tune to sim timescale):
  INFANT      0  – 19    Attachment formation. Highest plasticity.
  CHILD      20  – 59    Trust, fear, curiosity calibration. High plasticity.
  ADOLESCENT 60  – 119   Identity and ideology crystallization. Moderate plasticity.
  ADULT     120  – 399   Traits consolidated. Events hit state, not traits.
  ELDER     400+          Resilience degrades; mortality pressure rises.

Sensitive periods:
  - INFANT/CHILD trauma   → rewrites trust_baseline, attachment_rate,
                            avoidance_rate, conflict_sensitivity
  - ADOLESCENT trauma     → rewrites ideology_sensitivity, risk_tolerance,
                            and locks identity_tags early
  - ADOLESCENT bonding    → consolidates trust_baseline upward; resilience boost
  - ADULT+               → trait writes capped at ADULT_TRAIT_WRITE_CAP (10%)
                            of the developmental rate; state absorbs the rest

Attractor lock:
  After adolescence a 'traits_consolidated' flag is set. Post-consolidation
  events can still nudge traits but at a drastically reduced rate. This is the
  mechanism behind why childhood wounds are so persistent — not that they can't
  heal, but that the baseline they set is far more resistant to revision than
  a wound acquired on an already-formed personality.

Recovery path:
  Strong bonding events during CHILD/ADOLESCENT stages can partially offset
  prior trauma within the same window. Once consolidated, recovery requires
  chronic positive experience (many cooperation events) over many ticks, not
  a single event.

Design constraints:
  - No new state variables beyond 'traits_consolidated' (bool attr on agent)
    and 'developmental_stage' (str attr, for snapshot/logging only).
  - All trait writes are bounded and logged.
  - Grief and psychology modules remain independent; development.py calls
    neither. It is called by agent.tick() and apply_experience_from_event().
  - Calibration: a single severe childhood trauma should shift trust_baseline
    by at most -0.18 and attachment_rate by at most -0.12. These are large
    but not total — agents are not broken by one event, just marked.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from agent import Agent

# ── Life stage boundaries (in age ticks) ──────────────────────────────────────

STAGE_INFANT_END      = 19
STAGE_CHILD_END       = 59
STAGE_ADOLESCENT_END  = 119
STAGE_ADULT_END       = 399
# 400+ = ELDER

# ── Plasticity multipliers by stage ───────────────────────────────────────────
# How strongly a traumatic event writes to traits vs. only state.
# 1.0 = full developmental write. 0.0 = state only.

PLASTICITY = {
    "infant":     1.00,
    "child":      0.80,
    "adolescent": 0.45,
    "adult":      0.08,   # attractor lock — traits resist but don't freeze
    "elder":      0.05,
}

# ── Trait write magnitudes (per event, before plasticity scaling) ──────────────

# Trauma writes (negative events — conflict, grief, deception_detected)
TRAUMA_TRUST_HIT          = -0.18   # trust_baseline
TRAUMA_ATTACHMENT_HIT     = -0.12   # attachment_rate
TRAUMA_AVOIDANCE_RISE     = +0.10   # avoidance_rate
TRAUMA_CONFLICT_SENS_RISE = +0.14   # conflict_sensitivity
TRAUMA_RESILIENCE_HIT     = -0.08   # resilience (infant/child only)
TRAUMA_RISK_TOL_HIT       = -0.09   # risk_tolerance (adolescent: can also rise — see below)
TRAUMA_IDEOLOGY_SENS_LOCK  = +0.12  # ideology_sensitivity (adolescent trauma spikes this)

# Bonding writes (positive events — cooperation, sustained bond)
BOND_TRUST_GAIN           = +0.10
BOND_ATTACHMENT_GAIN      = +0.08
BOND_RESILIENCE_GAIN      = +0.07
BOND_CONFLICT_SENS_DROP   = -0.06
BOND_AVOIDANCE_DROP       = -0.05

# Absolute floor/ceiling guards on traits after developmental writes
TRUST_FLOOR       = 0.05
TRUST_CEIL        = 0.95
ATTACHMENT_FLOOR  = 0.01
AVOIDANCE_CEIL    = 0.90
CONFLICT_SENS_CEIL = 0.92
RESILIENCE_FLOOR  = 0.10
RISK_TOL_FLOOR    = 0.05

# Recovery: number of consecutive cooperation ticks needed to offset one trauma
# write by 50% post-consolidation
ADULT_RECOVERY_TICKS = 80


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


# ── Stage classification ───────────────────────────────────────────────────────

def life_stage(agent: "Agent") -> str:
    age = agent.state.age
    if age <= STAGE_INFANT_END:
        return "infant"
    if age <= STAGE_CHILD_END:
        return "child"
    if age <= STAGE_ADOLESCENT_END:
        return "adolescent"
    if age <= STAGE_ADULT_END:
        return "adult"
    return "elder"


def plasticity(agent: "Agent") -> float:
    return PLASTICITY[life_stage(agent)]


def is_pre_consolidation(agent: "Agent") -> bool:
    return agent.state.age <= STAGE_ADOLESCENT_END


# ── Consolidation ──────────────────────────────────────────────────────────────

def maybe_consolidate(agent: "Agent") -> bool:
    """
    Called each tick. Sets traits_consolidated flag at the adolescent/adult
    boundary. Once set, never unset. Returns True if consolidation just fired.
    """
    if getattr(agent, "traits_consolidated", False):
        return False
    if agent.state.age > STAGE_ADOLESCENT_END:
        agent.traits_consolidated = True
        # Stamp an identity tag marking the consolidated baseline
        stage_tags = []
        if agent.traits.trust_baseline < 0.35:
            stage_tags.append("early-wounded")
        elif agent.traits.trust_baseline > 0.65:
            stage_tags.append("early-secure")
        if agent.traits.conflict_sensitivity > 0.70:
            stage_tags.append("hypervigilant")
        if agent.traits.resilience > 0.68:
            stage_tags.append("hardened")
        for tag in stage_tags:
            if tag not in agent.experience.identity_tags:
                agent.experience.identity_tags.append(tag)
        return True
    return False


# ── Core imprinting functions ──────────────────────────────────────────────────

def imprint_trauma(agent: "Agent", intensity: float,
                   event_kind: str, tick: int) -> Optional[dict]:
    """
    Called when a negative event (conflict, grief, deception_detected) occurs.
    intensity: 0.0–1.0 scalar from the event.
    Returns a dict of trait deltas applied, or None if below threshold.
    """
    if intensity < 0.15:
        return None

    stage  = life_stage(agent)
    p      = plasticity(agent)
    scale  = intensity * p
    deltas = {}

    # All stages: trust and attachment take hits
    dt = clamp(TRAUMA_TRUST_HIT * scale,
               TRUST_FLOOR - agent.traits.trust_baseline,
               0.0)
    if dt != 0.0:
        agent.traits.trust_baseline = clamp(
            agent.traits.trust_baseline + dt, TRUST_FLOOR, TRUST_CEIL
        )
        deltas["trust_baseline"] = round(dt, 5)

    da = clamp(TRAUMA_ATTACHMENT_HIT * scale,
               ATTACHMENT_FLOOR - agent.traits.attachment_rate,
               0.0)
    if da != 0.0:
        agent.traits.attachment_rate = clamp(
            agent.traits.attachment_rate + da, ATTACHMENT_FLOOR, 1.0
        )
        deltas["attachment_rate"] = round(da, 5)

    dav = TRAUMA_AVOIDANCE_RISE * scale
    agent.traits.avoidance_rate = clamp(
        agent.traits.avoidance_rate + dav, 0.0, AVOIDANCE_CEIL
    )
    deltas["avoidance_rate"] = round(dav, 5)

    dcs = TRAUMA_CONFLICT_SENS_RISE * scale
    agent.traits.conflict_sensitivity = clamp(
        agent.traits.conflict_sensitivity + dcs, 0.0, CONFLICT_SENS_CEIL
    )
    deltas["conflict_sensitivity"] = round(dcs, 5)

    # Infant/child only: resilience takes a hit
    if stage in ("infant", "child"):
        dr = TRAUMA_RESILIENCE_HIT * scale
        agent.traits.resilience = clamp(
            agent.traits.resilience + dr, RESILIENCE_FLOOR, 1.0
        )
        deltas["resilience"] = round(dr, 5)

    # Adolescent: ideology_sensitivity spikes (trauma crystallises worldview
    # before it has stabilised — produces rigid ideological attachment)
    if stage == "adolescent":
        dis = TRAUMA_IDEOLOGY_SENS_LOCK * scale
        agent.traits.ideology_sensitivity = clamp(
            agent.traits.ideology_sensitivity + dis
        )
        deltas["ideology_sensitivity"] = round(dis, 5)
        # risk_tolerance: some adolescents go reckless, some go avoidant.
        # Resolved by dominance — high-dominance agents become reckless.
        if agent.state.dominance > 0.55:
            drt = +0.08 * scale  # reckless
        else:
            drt = TRAUMA_RISK_TOL_HIT * scale  # avoidant
        agent.traits.risk_tolerance = clamp(
            agent.traits.risk_tolerance + drt, RISK_TOL_FLOOR, 1.0
        )
        deltas["risk_tolerance"] = round(drt, 5)

    return {
        "stage": stage,
        "plasticity": round(p, 4),
        "intensity": round(intensity, 4),
        "event_kind": event_kind,
        "tick": tick,
        "trait_deltas": deltas,
    } if deltas else None


def imprint_bonding(agent: "Agent", intensity: float,
                    other_id: str, tick: int) -> Optional[dict]:
    """
    Called on cooperation/bonding events. Positive developmental write.
    Only meaningful during infant/child/adolescent stages, but available
    at low plasticity post-consolidation for slow adult recovery.
    """
    if intensity < 0.12:
        return None

    stage  = life_stage(agent)
    p      = plasticity(agent)
    scale  = intensity * p
    deltas = {}

    dt = BOND_TRUST_GAIN * scale
    agent.traits.trust_baseline = clamp(
        agent.traits.trust_baseline + dt, TRUST_FLOOR, TRUST_CEIL
    )
    deltas["trust_baseline"] = round(dt, 5)

    da = BOND_ATTACHMENT_GAIN * scale
    agent.traits.attachment_rate = clamp(
        agent.traits.attachment_rate + da, ATTACHMENT_FLOOR, 1.0
    )
    deltas["attachment_rate"] = round(da, 5)

    dr = BOND_RESILIENCE_GAIN * scale
    agent.traits.resilience = clamp(agent.traits.resilience + dr, RESILIENCE_FLOOR, 1.0)
    deltas["resilience"] = round(dr, 5)

    dcs = BOND_CONFLICT_SENS_DROP * scale
    agent.traits.conflict_sensitivity = clamp(
        agent.traits.conflict_sensitivity + dcs, 0.0, CONFLICT_SENS_CEIL
    )
    deltas["conflict_sensitivity"] = round(dcs, 5)

    dav = BOND_AVOIDANCE_DROP * scale
    agent.traits.avoidance_rate = clamp(agent.traits.avoidance_rate + dav, 0.0, 1.0)
    deltas["avoidance_rate"] = round(dav, 5)

    return {
        "stage": stage,
        "plasticity": round(p, 4),
        "intensity": round(intensity, 4),
        "other_id": other_id,
        "tick": tick,
        "trait_deltas": deltas,
    } if deltas else None


# ── Per-tick entry point ───────────────────────────────────────────────────────

def tick_development(agent: "Agent", tick: int) -> dict:
    """
    Called once per tick from agent.tick(), before event processing.
    Handles stage transitions and consolidation.
    Returns a summary dict for snapshot.
    """
    stage = life_stage(agent)
    agent.developmental_stage = stage   # attr for snapshot/logging

    just_consolidated = maybe_consolidate(agent)

    return {
        "stage": stage,
        "plasticity": round(plasticity(agent), 4),
        "traits_consolidated": getattr(agent, "traits_consolidated", False),
        "just_consolidated": just_consolidated,
    }


# ── Hook for experiential.apply_experience_from_event ─────────────────────────

def maybe_imprint_from_event(agent: "Agent", other, event, tick: int) -> Optional[dict]:
    """
    Called from apply_experience_from_event() in experiential.py.
    Decides whether this event triggers a developmental write and which kind.
    Returns imprint record or None.
    """
    outcome = event.outcome
    stress  = agent.state.stress

    # Trauma path
    if outcome in ("conflict", "grief"):
        # Intensity scales with event stress load and current stress state
        base_intensity = 0.55 if outcome == "conflict" else 0.70
        intensity = clamp(base_intensity + stress * 0.30)
        return imprint_trauma(agent, intensity, outcome, tick)

    if outcome == "deception_detected":
        intensity = clamp(0.45 + stress * 0.25)
        return imprint_trauma(agent, intensity, "deception_detected", tick)

    # Bonding path
    if outcome == "cooperation":
        # Bond strength from relationship book if available
        other_id = getattr(other, "id", None)
        bond_str = agent.experience.bonds.get(other_id, 0.0) if other_id else 0.0
        intensity = clamp(0.25 + bond_str * 0.40)
        return imprint_bonding(agent, intensity, other_id or "unknown", tick)

    return None


# ── Snapshot helper ────────────────────────────────────────────────────────────

def snapshot(agent: "Agent") -> dict:
    return {
        "stage": getattr(agent, "developmental_stage", life_stage(agent)),
        "traits_consolidated": getattr(agent, "traits_consolidated", False),
        "plasticity": round(plasticity(agent), 4),
        "trust_baseline": round(agent.traits.trust_baseline, 4),
        "attachment_rate": round(agent.traits.attachment_rate, 4),
        "avoidance_rate": round(agent.traits.avoidance_rate, 4),
        "conflict_sensitivity": round(agent.traits.conflict_sensitivity, 4),
        "resilience": round(agent.traits.resilience, 4),
        "risk_tolerance": round(agent.traits.risk_tolerance, 4),
        "ideology_sensitivity": round(agent.traits.ideology_sensitivity, 4),
        "identity_tags": list(agent.experience.identity_tags),
    }
