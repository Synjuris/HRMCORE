# HRM_UNIFIED v4.50 — Kernel Phase K1

## Summary
Minimal runtime extraction. No new simulation ideas.
One canonical tick loop, system registration, event routing, checkpointing.
Bugs now get fixed once.

## Problem Solved
Before K1, each run script (run_exp_A through run_exp_E_resume) was a
semi-forked world with its own wiring decisions. The homicide detection
bug existed in three files simultaneously. The death module fix required
patching run_exp_E, run_exp_E_1k, and run_exp_E_resume separately.
The kernel eliminates this class of problem.

## New Files

### das/kernel/__init__.py
Exports: HRMRuntime, EventBus, SystemRegistry, SystemPhase,
         KernelConfig, GroupConfig, KernelCheckpoint, make_exp_E_config

### das/kernel/config.py
KernelConfig — typed dataclass replacing scattered module-level constants.
GroupConfig — per-group label, arrival_tick, cluster_center, names, seed_memes.
make_exp_E_config() — returns KernelConfig for Experiment E.
from_dict() / from_json() / to_json() — config serialization.

### das/kernel/event_bus.py
EventBus — single event channel replacing per-script event_log + _stream +
_counters + persistence_ledger wiring. Systems call bus.emit(event).
Supports listener registration (bus.on("event_type", fn)).
bus.cooperation_events_this_tick(tick) — convenience for innovation system.

### das/kernel/system_registry.py
SystemRegistry — ordered system registration.
Systems register with a SystemPhase (PRE_AGENT, POST_AGENT, SUBSISTENCE,
TRANSFER, REPRODUCTION, SUBSYSTEMS, METRICS, CHECKPOINT).
runtime.registry.register(name, phase, fn) — fn(tick, runtime) -> None.
Deterministic execution order. Errors isolated per system.

### das/kernel/checkpoint.py
KernelCheckpoint — full restorable checkpoint replacing checkpoint_full_* 
logic in run_exp_E_resume.py. Saves: RNG states, agents, group map,
factions, full culture, full innovation registry, governance, deaths.
find_latest() / load() / save() / save_manifest() / load_manifest().

### das/kernel/runtime.py
HRMRuntime — owns tick loop, agent pool, world subsystems.
build_world() — constructs all subsystems deterministically.
run(start_tick) — tick loop with Ctrl+C handling and clean final save.
register_pending_group(arrival_tick, gl, agents, on_arrival) — groups
  spawn at their arrival tick; on_arrival callback fires first.
on_birth(fn) / on_death(fn) — hook registration.
_handle_lethal_conflict — wired to bus, routes homicides to death ledger.

### das/run_kernel_exp_E.py
Bridge runner. Reproduces run_exp_E behavior through kernel.
Experiment logic (group setup, meme seeding) is in the runner.
Simulation logic (tick loop, system calls) is in the kernel.

Usage:
    python run_kernel_exp_E.py
    python run_kernel_exp_E.py --ticks 1000
    python run_kernel_exp_E.py --output /tmp/my_run

## Validation (1000-tick run)
    990 innovation successes, registry=294
    57 deaths (41 homicide, 71.9%) — consistent with pre-kernel 70.7%
    7 memes active at tick 1000 — all group seeds propagating
    Gen8 by tick 1000 — generational depth intact
    Conflict rate 36.4% — consistent with SRK range

## Next
Phase K2: convert remaining experiments to configs.
Phase SRK-2: belief-mediated perception through kernel-managed hooks.
