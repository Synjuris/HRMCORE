@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo HRM_UNIFIED v3.2 - Disease Ecology + Public Health Layer
echo Folder: %CD%
echo ============================================================
set PYTHON_CMD=
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 set PYTHON_CMD=py -3
if "%PYTHON_CMD%"=="" (
  where python >nul 2>nul
  if %ERRORLEVEL% EQU 0 set PYTHON_CMD=python
)
if "%PYTHON_CMD%"=="" (
  where python3 >nul 2>nul
  if %ERRORLEVEL% EQU 0 set PYTHON_CMD=python3
)
if "%PYTHON_CMD%"=="" (
  echo ERROR: Could not find Python. Install Python 3.10+ and check "Add Python to PATH".
  pause
  exit /b 1
)
echo Using Python command: %PYTHON_CMD%
%PYTHON_CMD% --version
%PYTHON_CMD% run_disease_ecology.py --era now --disease auto --cycles 12 --seed 42 --run-world --mode toy --n 250 --force
echo.
echo Done. Reports are in outputs\disease_ecology_v3_2\disease_seeded_world_v3_2\reports\
pause
