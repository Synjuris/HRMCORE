# HRM_UNIFIED v1.3 — Calibrated Population Layer

## Purpose
v1.3 makes the panel structurally heterogeneous. The same stimulus can now produce different responses across age bands, economic-stability bands, education bands, and social-connectivity bands.

## Added
- `population/calibration.py` — generic profile schema, segment generation, aggregate-data derivation.
- `population/topology.py` — clustered social topology with hubs, bridges, and isolated nodes.
- `population/trust.py` — source-channel inference and trust-weighted response.
- `population/calibrated_panel.py` — calibrated panel with heterogeneous response and persistence/decay.
- `run_calibrated_panel.py` — CLI for the v1.3 calibrated panel.
- `compare_profiles.py` — compare one stimulus across multiple abstract population profiles.
- `calibration_benchmark.py` — deterministic v1.3 benchmark fingerprint.
- Abstract profiles in `profiles/`.

## Design boundaries
- No personal assumptions.
- No hardcoded locality.
- No locality-specific defaults.
- Real datasets are optional aggregate calibration inputs, not engine truth.
- The simulation remains geography-agnostic unless a user supplies external data at runtime.

## Example
```bash
python run_calibrated_panel.py "Official agency report announces a severe regional economic slowdown." --profile generic_mixed_region
python compare_profiles.py "Neighbors share a rumor about a local safety threat near several schools."
python calibration_benchmark.py
```

## Real aggregate data
`run_real_panel.py` now routes ACS aggregate data through the calibrated population layer. The engine remains generic; the API result only shapes broad structural distributions.
