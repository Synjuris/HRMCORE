@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
set "PYTHON_CMD="
where py >nul 2>nul
if %ERRORLEVEL%==0 set "PYTHON_CMD=py -3"
if not defined PYTHON_CMD (
  where python >nul 2>nul
  if %ERRORLEVEL%==0 set "PYTHON_CMD=python"
)
if not defined PYTHON_CMD (
  where python3 >nul 2>nul
  if %ERRORLEVEL%==0 set "PYTHON_CMD=python3"
)
if not defined PYTHON_CMD (
  echo ERROR: Python was not found.
  pause
  exit /b 1
)
%PYTHON_CMD% run_era_seeding.py --era modern --start-year 2026 --location "generic" --seed-only
pause
