"""HRM_UNIFIED v3.0 scalable world architecture.

This layer does not add a new civilization feature. It adds scale controls around
existing persistent/continuous world runs: fidelity modes, population guardrails,
summary tiers, replay compaction, memory compression, checkpoint pruning, and a
small performance benchmark.

Design rule: full-detail simulation should be reserved for the active slice of
the world; regional/statistical populations are represented as summaries until
an event makes them worth expanding.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
import json
import math
import os
import time

ENGINE_VERSION = "3.0"


MODE_PRESETS: Dict[str, Dict[str, Any]] = {
    "toy": {
        "max_agents": 250,
        "active_agents": 50,
        "regional_agents": 150,
        "statistical_agents": 50,
        "checkpoint_keep": 12,
        "replay_keep_events": 500,
        "max_generations_per_run": 12,
        "dashboard_event_limit": 250,
    },
    "desktop": {
        "max_agents": 2500,
        "active_agents": 150,
        "regional_agents": 850,
        "statistical_agents": 1500,
        "checkpoint_keep": 24,
        "replay_keep_events": 1500,
        "max_generations_per_run": 60,
        "dashboard_event_limit": 500,
    },
    "large": {
        "max_agents": 25000,
        "active_agents": 250,
        "regional_agents": 2500,
        "statistical_agents": 22250,
        "checkpoint_keep": 36,
        "replay_keep_events": 3000,
        "max_generations_per_run": 120,
        "dashboard_event_limit": 1000,
    },
}


@dataclass
class FidelityPlan:
    mode: str
    requested_agents: int
    simulated_agents: int
    active_agents: int
    regional_agents: int
    statistical_agents: int
    compression_ratio: float
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _preset(mode: str) -> Dict[str, Any]:
    if mode not in MODE_PRESETS:
        raise ValueError(f"Unknown mode {mode!r}. Use one of: {', '.join(MODE_PRESETS)}")
    return dict(MODE_PRESETS[mode])


def make_fidelity_plan(mode: str, requested_agents: int, force: bool = False) -> FidelityPlan:
    requested_agents = max(1, int(requested_agents))
    p = _preset(mode)
    warnings: List[str] = []
    max_agents = int(p["max_agents"])
    simulated = requested_agents
    if requested_agents > max_agents and not force:
        simulated = max_agents
        warnings.append(
            f"Requested {requested_agents} agents exceeds {mode} guardrail of {max_agents}; capped full simulation to {max_agents}."
        )
    elif requested_agents > max_agents and force:
        warnings.append(
            f"Requested {requested_agents} agents exceeds {mode} guardrail of {max_agents}; force mode allowed it."
        )

    active = min(simulated, int(p["active_agents"]))
    remaining = max(0, simulated - active)
    regional = min(remaining, int(p["regional_agents"]))
    statistical = max(0, requested_agents - active - regional)
    compression_ratio = round(float(requested_agents) / max(1, active + regional), 4)
    return FidelityPlan(mode, requested_agents, simulated, active, regional, statistical, compression_ratio, warnings)


def _read_json(path: str | Path, default: Any) -> Any:
    p = Path(path)
    if not p.exists():
        return default
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return default


def _write_json(path: str | Path, payload: Any) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    os.replace(tmp, p)


def _read_jsonl(path: str | Path) -> List[Dict[str, Any]]:
    p = Path(path)
    if not p.exists():
        return []
    rows: List[Dict[str, Any]] = []
    for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            rows.append(json.loads(line))
        except Exception:
            rows.append({"event_type": "corrupt_line", "raw": line[:500]})
    return rows


def _write_jsonl(path: str | Path, rows: Iterable[Dict[str, Any]]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, sort_keys=True) + "\n")
    os.replace(tmp, p)


def summarize_state_for_dashboard(state: Dict[str, Any], plan: FidelityPlan) -> Dict[str, Any]:
    novelties = list(state.get("novelties") or [])
    institutions = list(state.get("institutions") or [])
    memory = dict(state.get("memory") or {})
    civilization = dict(state.get("civilization") or {})

    top_novelties = sorted(
        [n for n in novelties if isinstance(n, dict)],
        key=lambda n: float(n.get("normalization", n.get("adoption", 0.0)) or 0.0),
        reverse=True,
    )[:25]
    top_institutions = sorted(
        [i for i in institutions if isinstance(i, dict)],
        key=lambda i: float(i.get("legitimacy", 0.0) or 0.0),
        reverse=True,
    )[:25]
    return {
        "engine_version": ENGINE_VERSION,
        "fidelity": plan.to_dict(),
        "counts": {
            "novelties_total": len(novelties),
            "institutions_total": len(institutions),
            "memory_keys": len(memory.keys()),
            "civilization_keys": len(civilization.keys()),
        },
        "top_novelties": top_novelties,
        "top_institutions": top_institutions,
        "memory_summary": {
            "cohorts": len(memory.get("cohorts", []) or []),
            "scars": len(memory.get("historical_scars", []) or []),
            "resilience": memory.get("resilience_inheritance"),
            "fingerprint": memory.get("fingerprint"),
        },
        "civilization_summary": {
            "fingerprint": civilization.get("fingerprint"),
            "generated_novelty_count": civilization.get("generated_novelty_count"),
            "dominant_shift": civilization.get("dominant_shift"),
        },
    }


def compact_replay(world_dir: str | Path, keep_events: int, dashboard_limit: int) -> Dict[str, Any]:
    world_dir = Path(world_dir)
    replay_path = world_dir / "replay_log.jsonl"
    timeline_path = world_dir / "evolution_timeline.json"
    rows = _read_jsonl(replay_path)
    original_count = len(rows)
    keep_events = max(1, int(keep_events))
    kept = rows[-keep_events:]
    archived_count = max(0, original_count - len(kept))
    if archived_count:
        archive_path = world_dir / "replay_archive_summary.json"
        prev = _read_json(archive_path, {"archived_event_count": 0, "archive_batches": []})
        prev["archived_event_count"] = int(prev.get("archived_event_count", 0)) + archived_count
        prev.setdefault("archive_batches", []).append({
            "archived_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "events_archived": archived_count,
            "first_cycle": rows[0].get("cycle") if rows else None,
            "last_cycle": rows[archived_count - 1].get("cycle") if archived_count else None,
        })
        _write_json(archive_path, prev)
        _write_jsonl(replay_path, kept)
    dashboard_events = kept[-max(1, int(dashboard_limit)):]
    _write_json(timeline_path, {
        "engine_version": ENGINE_VERSION,
        "updated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "events": dashboard_events,
        "compaction": {
            "original_count": original_count,
            "kept_count": len(kept),
            "archived_count_this_pass": archived_count,
        },
    })
    return {"original_count": original_count, "kept_count": len(kept), "archived_count_this_pass": archived_count}


def prune_checkpoints(world_dir: str | Path, keep: int) -> Dict[str, Any]:
    checkpoint_dir = Path(world_dir) / "checkpoints"
    if not checkpoint_dir.exists():
        return {"checkpoint_count": 0, "deleted": 0}
    files = sorted(checkpoint_dir.glob("checkpoint_*.json"), key=lambda p: p.stat().st_mtime)
    keep = max(1, int(keep))
    victims = files[:-keep]
    for p in victims:
        try:
            p.unlink()
        except Exception:
            pass
    return {"checkpoint_count_before": len(files), "kept": len(files) - len(victims), "deleted": len(victims)}


def compress_latest_world_state(world_dir: str | Path, plan: FidelityPlan) -> Dict[str, Any]:
    world_dir = Path(world_dir)
    latest_path = world_dir / "world_state_latest.json"
    latest = _read_json(latest_path, {})
    if not latest:
        return {"compressed": False, "reason": "no latest checkpoint"}
    state = latest.get("state") or {}
    summary = summarize_state_for_dashboard(state, plan)
    report_dir = world_dir / "reports"
    _write_json(report_dir / "scale_summary.json", summary)
    latest.setdefault("scale", {})
    latest["scale"].update({"engine_version": ENGINE_VERSION, "fidelity": plan.to_dict()})
    _write_json(latest_path, latest)
    return {"compressed": True, "scale_summary": str(report_dir / "scale_summary.json"), "fidelity": plan.to_dict()}


def apply_scale_maintenance(output_root: str | Path, world_id: str, mode: str, requested_agents: int, force: bool = False) -> Dict[str, Any]:
    p = _preset(mode)
    plan = make_fidelity_plan(mode, requested_agents, force=force)
    world_dir = Path(output_root) / world_id
    replay = compact_replay(world_dir, p["replay_keep_events"], p["dashboard_event_limit"])
    checkpoints = prune_checkpoints(world_dir, p["checkpoint_keep"])
    compression = compress_latest_world_state(world_dir, plan)
    health = {
        "engine_version": ENGINE_VERSION,
        "world_id": world_id,
        "mode": mode,
        "fidelity": plan.to_dict(),
        "replay": replay,
        "checkpoints": checkpoints,
        "compression": compression,
        "status": "ok" if not plan.warnings else "guarded",
    }
    _write_json(world_dir / "reports" / "scale_health_report.json", health)
    return health


def scale_health_markdown(health: Dict[str, Any]) -> str:
    f = health.get("fidelity", {})
    lines = [
        "# HRM_UNIFIED v3.0 Scale Health Report",
        "",
        f"World: `{health.get('world_id')}`",
        f"Mode: `{health.get('mode')}`",
        f"Status: `{health.get('status')}`",
        "",
        "## Fidelity Plan",
        f"- Requested agents: {f.get('requested_agents')}",
        f"- Full simulated agents: {f.get('simulated_agents')}",
        f"- Active-detail agents: {f.get('active_agents')}",
        f"- Regional-summary agents: {f.get('regional_agents')}",
        f"- Statistical/background agents: {f.get('statistical_agents')}",
        f"- Compression ratio: {f.get('compression_ratio')}",
        "",
        "## Maintenance",
        f"- Replay: {health.get('replay')}",
        f"- Checkpoints: {health.get('checkpoints')}",
        "",
    ]
    warnings = f.get("warnings") or []
    if warnings:
        lines += ["## Warnings"] + [f"- {w}" for w in warnings] + [""]
    lines += [
        "## Rule",
        "Full detail is reserved for the active slice of the world. Regional and statistical populations stay compressed until events justify expansion.",
    ]
    return "\n".join(lines) + "\n"
