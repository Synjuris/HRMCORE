"""Persistent continuous world layer for HRM_UNIFIED v2.7.

Adds crash-safe checkpointing, replay/event logs, save/load world state,
state diffing, and since-last-viewed reports. Continuous runtime is built on top
of checkpoints instead of an unsafe forever loop.

No user-specific or local real-world assumptions are encoded here.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
import hashlib
import json
import os
import time

ENGINE_VERSION = "2.7"


def utc_stamp() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def canonical(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def fingerprint(obj: Any) -> str:
    return hashlib.sha256(canonical(obj).encode("utf-8")).hexdigest()


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def atomic_write_json(path: str | Path, payload: Dict[str, Any]) -> None:
    path = Path(path)
    ensure_dir(path.parent)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    os.replace(tmp, path)


def read_json(path: str | Path, default: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    p = Path(path)
    if not p.exists():
        return dict(default or {})
    return json.loads(p.read_text(encoding="utf-8"))


@dataclass
class WorldCheckpoint:
    version: str
    world_id: str
    cycle: int
    generation: int
    created_at: str
    state: Dict[str, Any]
    benchmark: Dict[str, Any]
    previous_checkpoint: Optional[str] = None
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        payload = asdict(self)
        fp_payload = dict(payload)
        fp_payload.pop("fingerprint", None)
        payload["fingerprint"] = fingerprint(fp_payload)
        return payload


@dataclass
class ReplayEvent:
    cycle: int
    generation: int
    event_type: str
    message: str
    severity: str = "info"
    data: Dict[str, Any] = field(default_factory=dict)
    created_at: str = field(default_factory=utc_stamp)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class PersistentWorldStore:
    """Filesystem-backed checkpoint and replay store."""

    def __init__(self, root: str | Path = "outputs/persistent_world_v2_7", world_id: str = "default_world"):
        self.root = ensure_dir(root)
        self.world_id = world_id
        self.world_dir = ensure_dir(self.root / world_id)
        self.checkpoint_dir = ensure_dir(self.world_dir / "checkpoints")
        self.report_dir = ensure_dir(self.world_dir / "reports")
        self.latest_path = self.world_dir / "world_state_latest.json"
        self.last_viewed_path = self.world_dir / "world_state_last_viewed.json"
        self.replay_path = self.world_dir / "replay_log.jsonl"
        self.event_timeline_path = self.world_dir / "evolution_timeline.json"

    def latest(self) -> Optional[Dict[str, Any]]:
        if not self.latest_path.exists():
            return None
        return read_json(self.latest_path)

    def save_checkpoint(
        self,
        cycle: int,
        generation: int,
        state: Dict[str, Any],
        benchmark: Dict[str, Any],
        notes: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        prev = self.latest()
        cp = WorldCheckpoint(
            version=ENGINE_VERSION,
            world_id=self.world_id,
            cycle=cycle,
            generation=generation,
            created_at=utc_stamp(),
            state=state,
            benchmark=benchmark,
            previous_checkpoint=(prev or {}).get("fingerprint"),
            notes=list(notes or []),
        ).to_dict()
        filename = f"checkpoint_cycle_{cycle:06d}_gen_{generation:04d}_{cp['fingerprint'][:12]}.json"
        cp["checkpoint_file"] = str(Path("checkpoints") / filename)
        atomic_write_json(self.checkpoint_dir / filename, cp)
        atomic_write_json(self.latest_path, cp)
        self._append_replay(ReplayEvent(cycle, generation, "checkpoint", "World checkpoint saved.", data={"fingerprint": cp["fingerprint"], "file": cp["checkpoint_file"]}))
        self._write_timeline_cache()
        return cp

    def mark_viewed(self) -> Dict[str, Any]:
        latest = self.latest()
        if latest is None:
            raise FileNotFoundError("No latest checkpoint exists to mark as viewed.")
        atomic_write_json(self.last_viewed_path, latest)
        return latest

    def append_event(self, event: ReplayEvent) -> None:
        self._append_replay(event)
        self._write_timeline_cache()

    def _append_replay(self, event: ReplayEvent) -> None:
        with self.replay_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(event.to_dict(), sort_keys=True) + "\n")

    def read_replay(self) -> List[Dict[str, Any]]:
        if not self.replay_path.exists():
            return []
        rows = []
        for line in self.replay_path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                try:
                    rows.append(json.loads(line))
                except Exception:
                    rows.append({"event_type": "corrupt_replay_line", "raw": line})
        return rows

    def _write_timeline_cache(self) -> None:
        events = self.read_replay()
        atomic_write_json(self.event_timeline_path, {"world_id": self.world_id, "updated_at": utc_stamp(), "events": events[-1000:]})

    def diff_since_last_viewed(self) -> Dict[str, Any]:
        latest = self.latest() or {}
        prior = read_json(self.last_viewed_path, default={}) if self.last_viewed_path.exists() else {}
        return diff_checkpoints(prior, latest)

    def write_since_report(self, mark_viewed: bool = False) -> Path:
        diff = self.diff_since_last_viewed()
        md = since_last_viewed_markdown(diff)
        path = self.report_dir / "since_last_viewed_report.md"
        path.write_text(md, encoding="utf-8")
        if mark_viewed and self.latest_path.exists():
            self.mark_viewed()
        return path


def _get_metric(cp: Dict[str, Any], key: str, default: float = 0.0) -> float:
    bench = cp.get("benchmark") or {}
    try:
        return float(bench.get(key, default) or default)
    except Exception:
        return default


def _state(cp: Dict[str, Any]) -> Dict[str, Any]:
    return cp.get("state") or {}


def diff_checkpoints(prior: Dict[str, Any], latest: Dict[str, Any]) -> Dict[str, Any]:
    prior_state = _state(prior)
    latest_state = _state(latest)
    p_b = prior.get("benchmark") or {}
    l_b = latest.get("benchmark") or {}
    keys = sorted(set(p_b.keys()) | set(l_b.keys()))
    metric_delta = {}
    for k in keys:
        pv, lv = p_b.get(k), l_b.get(k)
        if isinstance(pv, (int, float)) or isinstance(lv, (int, float)):
            try:
                metric_delta[k] = round(float(lv or 0.0) - float(pv or 0.0), 6)
            except Exception:
                pass
    p_names = {n.get("name") for n in prior_state.get("novelties", []) if isinstance(n, dict)}
    l_names = {n.get("name") for n in latest_state.get("novelties", []) if isinstance(n, dict)}
    return {
        "world_id": latest.get("world_id") or prior.get("world_id"),
        "prior_cycle": prior.get("cycle", 0),
        "latest_cycle": latest.get("cycle", 0),
        "prior_generation": prior.get("generation", 0),
        "latest_generation": latest.get("generation", 0),
        "prior_fingerprint": prior.get("fingerprint"),
        "latest_fingerprint": latest.get("fingerprint"),
        "elapsed_cycles": int(latest.get("cycle", 0) or 0) - int(prior.get("cycle", 0) or 0),
        "elapsed_generations": int(latest.get("generation", 0) or 0) - int(prior.get("generation", 0) or 0),
        "metric_delta": metric_delta,
        "new_novelties": sorted([x for x in (l_names - p_names) if x]),
        "removed_novelties": sorted([x for x in (p_names - l_names) if x]),
        "latest_shift": l_b.get("final_shift") or l_b.get("dominant_shift") or "unknown",
        "created_at": utc_stamp(),
    }


def since_last_viewed_markdown(diff: Dict[str, Any]) -> str:
    lines = [
        "# HRM_UNIFIED v2.7 Since-Last-Viewed Report",
        "",
        f"World: `{diff.get('world_id')}`",
        f"Prior cycle: {diff.get('prior_cycle')} | Latest cycle: {diff.get('latest_cycle')} | Elapsed cycles: {diff.get('elapsed_cycles')}",
        f"Prior generation: {diff.get('prior_generation')} | Latest generation: {diff.get('latest_generation')} | Elapsed generations: {diff.get('elapsed_generations')}",
        f"Latest shift: **{diff.get('latest_shift')}**",
        "",
        "## Metric deltas",
    ]
    deltas = diff.get("metric_delta") or {}
    if deltas:
        for k in sorted(deltas):
            lines.append(f"- `{k}`: {deltas[k]:+.6f}")
    else:
        lines.append("- No numeric metric deltas available yet.")
    lines.extend(["", "## New novelty/idea/discovery records"])
    new = diff.get("new_novelties") or []
    if new:
        lines.extend([f"- {x}" for x in new])
    else:
        lines.append("- None detected since last viewed checkpoint.")
    lines.extend(["", "## Integrity", f"Prior fingerprint: `{diff.get('prior_fingerprint')}`", f"Latest fingerprint: `{diff.get('latest_fingerprint')}`"])
    return "\n".join(lines) + "\n"


def extract_major_events(cycle: int, generation: int, benchmark: Dict[str, Any], state: Dict[str, Any]) -> List[ReplayEvent]:
    events: List[ReplayEvent] = []
    shift = str(benchmark.get("final_shift") or benchmark.get("dominant_shift") or "")
    if shift and shift not in {"none", "unknown"}:
        events.append(ReplayEvent(cycle, generation, "civilization_shift", f"Civilization shift classified as {shift}.", data={"shift": shift}))
    if float(benchmark.get("civilization_shift_score", 0.0) or 0.0) >= 0.50:
        events.append(ReplayEvent(cycle, generation, "high_shift_score", "Civilization shift score crossed 0.50.", severity="warning", data={"score": benchmark.get("civilization_shift_score")}))
    generated = int(benchmark.get("generated_novelty_count", 0) or 0)
    if generated > 0:
        events.append(ReplayEvent(cycle, generation, "generated_novelty", f"Generated novelty count is now {generated}.", data={"generated_novelty_count": generated}))
    novelties = state.get("novelties") or []
    for n in novelties:
        if isinstance(n, dict) and float(n.get("normalization", 0.0) or 0.0) >= 0.70:
            events.append(ReplayEvent(cycle, generation, "normalized_novelty", f"Novelty normalized: {n.get('name')}", data={"name": n.get("name"), "normalization": n.get("normalization")}))
    return events
