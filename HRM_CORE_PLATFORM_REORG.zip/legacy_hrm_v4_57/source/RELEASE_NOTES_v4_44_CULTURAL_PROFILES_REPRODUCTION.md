# HRM_UNIFIED v4.44 — Cultural Profile Saturation + Reproduction

Three bugs identified in 1000-tick assessment.

## Bugs Fixed

### 1. Cultural profiles saturating to 1.0 (institutional_memory.py)
_update_profile_from_anchor() accumulated additively on every observed event.
Over 1000 ticks with thousands of care/threat events, trust and threat both
hit 1.0 within the first ~200 ticks and stayed there. All faction profiles
became identical. Divergence index was meaningless.

Fix: replaced accumulation with mean-reversion. Each anchor update pulls the
profile value toward a domain-specific target at a rate proportional to anchor
strength (weight=0.08). Values settle at meaningful equilibria and stay there.

Result: factions now show genuine differentiation. knowledge_preservation
ranges 0.21–0.75 across factions in the same run. trust varies 0.51–0.75.
threat varies 0.36–0.56. Divergence index meaningful.

### 2. Too few births — generational compounding couldn't show (reproduction.py, scenario_profiles.py)
20 starting agents with max_population=24 left only 4 birth slots.
REPRODUCE_CHANCE=0.340 combined with libido gating produced 6-7 births per
1000-tick run. Not enough for multi-generational dynamics to compound.

Fix: max_population raised 24→40. REPRODUCE_CHANCE raised 0.340→0.520.

Result: 9-10 births per 1000-tick run. Run 2 produced a Gen2 survivor.
Stories, recoveries, and oral tradition now have enough carriers to matter.

### 3. Chronicle conflict rate always showed 0% (continuity.py)
Conflict events are logged as event_type="interaction" with outcome="conflict",
not as a separate event type. Chronicle was reading counts["conflict"] which
was always 0. Also oral tradition events weren't included in the timeline.

Fix: culture_timeline now tracks conflict_count and interaction_count directly
from outcome fields. Chronicle reads these. Oral tradition event types added
to timeline tracker.

Result: Chronicle correctly reports 27-48% conflict rate across runs.
Oral tradition transmission count now appears in History section.
