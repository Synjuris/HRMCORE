#!/usr/bin/env python3
"""Deterministic policy benchmark for HRM_UNIFIED v1.7."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

try:
    from .population.policy import run_policy_sequence, default_policy_scenario, DEFAULT_POLICIES
    from .run_policy import write_policy_outputs
    from .export_utils import ensure_dir
except ImportError:
    from population.policy import run_policy_sequence, default_policy_scenario, DEFAULT_POLICIES
    from run_policy import write_policy_outputs
    from export_utils import ensure_dir


def main() -> int:
    out = ensure_dir("outputs/policy_benchmark_v1_7")
    result = run_policy_sequence(
        sequence=default_policy_scenario(),
        policies=DEFAULT_POLICIES,
        n=750,
        seed=1707,
        profile="generic_mixed_region",
        decay=0.86,
        scenario_name="policy_benchmark_v1_7",
    )
    payload = json.loads(result.to_json())
    fingerprint_source = json.dumps({
        "final_state": payload["final_state"],
        "events": payload["events"],
        "cost_benefit": payload["cost_benefit"],
        "step_count": len(payload["steps"]),
    }, sort_keys=True)
    fingerprint = hashlib.sha256(fingerprint_source.encode("utf-8")).hexdigest()

    paths = write_policy_outputs(result, str(out), prefix="policy_benchmark_v1_7")
    report = {
        "status": "PASS",
        "fingerprint": fingerprint,
        "event_count": len(result.events),
        "final_state": result.final_state.summary(),
        "cost_benefit": result.cost_benefit(),
        "outputs": paths,
    }
    (out / "policy_benchmark_result.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("HRM_UNIFIED v1.7 policy benchmark: PASS")
    print(f"fingerprint: {fingerprint}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
