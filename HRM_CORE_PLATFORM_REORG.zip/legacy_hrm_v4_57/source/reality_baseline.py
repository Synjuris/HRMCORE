"""HRM_UNIFIED v3.1 era seeding and reality baseline layer.

This layer lets the simulator start from an explicit historical/modern baseline
instead of always behaving like an unanchored emergent sandbox. It does not claim
to perfectly reproduce real history. It creates transparent, inspectable seed
profiles that downstream calibration can replace with real datasets.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Dict, List, Optional
import json
import math
import os
import time

ENGINE_VERSION = "3.1"

ERA_PRESETS: Dict[str, Dict[str, Any]] = {
    "ancient": {
        "label": "Ancient agrarian baseline",
        "reference_year": -500,
        "technology_level": 0.12,
        "institutional_complexity": 0.22,
        "urbanization": 0.08,
        "literacy": 0.04,
        "media_density": 0.01,
        "market_integration": 0.12,
        "healthcare_capacity": 0.03,
        "disease_burden": 0.62,
        "mobility": 0.10,
        "cultural_velocity": 0.05,
        "baseline_trust": 0.38,
        "baseline_stress": 0.58,
        "innovation_pressure": 0.18,
        "description": "Low technology, local institutions, high disease pressure, low media velocity.",
    },
    "medieval": {
        "label": "Medieval/feudal baseline",
        "reference_year": 1200,
        "technology_level": 0.22,
        "institutional_complexity": 0.34,
        "urbanization": 0.14,
        "literacy": 0.09,
        "media_density": 0.03,
        "market_integration": 0.20,
        "healthcare_capacity": 0.06,
        "disease_burden": 0.70,
        "mobility": 0.16,
        "cultural_velocity": 0.08,
        "baseline_trust": 0.41,
        "baseline_stress": 0.61,
        "innovation_pressure": 0.22,
        "description": "Kinship, religion, landed hierarchy, fragmented institutions, high epidemic vulnerability.",
    },
    "industrial": {
        "label": "Industrial baseline",
        "reference_year": 1880,
        "technology_level": 0.48,
        "institutional_complexity": 0.58,
        "urbanization": 0.46,
        "literacy": 0.48,
        "media_density": 0.28,
        "market_integration": 0.60,
        "healthcare_capacity": 0.22,
        "disease_burden": 0.48,
        "mobility": 0.42,
        "cultural_velocity": 0.26,
        "baseline_trust": 0.50,
        "baseline_stress": 0.55,
        "innovation_pressure": 0.54,
        "description": "Factories, rail/logistics acceleration, urban labor stress, early mass institutions.",
    },
    "modern": {
        "label": "Modern/current baseline",
        "reference_year": 2026,
        "technology_level": 0.86,
        "institutional_complexity": 0.82,
        "urbanization": 0.74,
        "literacy": 0.90,
        "media_density": 0.92,
        "market_integration": 0.88,
        "healthcare_capacity": 0.72,
        "disease_burden": 0.26,
        "mobility": 0.78,
        "cultural_velocity": 0.86,
        "baseline_trust": 0.47,
        "baseline_stress": 0.64,
        "innovation_pressure": 0.82,
        "description": "Networked society, fast media diffusion, high institutional complexity, chronic trust stress.",
    },
    "near_future": {
        "label": "Near-future baseline",
        "reference_year": 2040,
        "technology_level": 0.93,
        "institutional_complexity": 0.86,
        "urbanization": 0.80,
        "literacy": 0.92,
        "media_density": 0.96,
        "market_integration": 0.91,
        "healthcare_capacity": 0.78,
        "disease_burden": 0.24,
        "mobility": 0.82,
        "cultural_velocity": 0.92,
        "baseline_trust": 0.43,
        "baseline_stress": 0.67,
        "innovation_pressure": 0.90,
        "description": "High automation, accelerated cultural mutation, institutional legitimacy under pressure.",
    },
}


def _clamp(v: float, lo: float = 0.0, hi: float = 1.0) -> float:
    try:
        return max(lo, min(hi, float(v)))
    except Exception:
        return lo


def _read_json(path: str | Path, default: Any) -> Any:
    p = Path(path)
    if not p.exists():
        return default
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return default


def _write_json(path: str | Path, payload: Any) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    os.replace(tmp, p)


@dataclass
class RealityBaseline:
    era: str
    start_year: int
    location: str
    profile: str
    label: str
    description: str
    technology_level: float
    institutional_complexity: float
    urbanization: float
    literacy: float
    media_density: float
    market_integration: float
    healthcare_capacity: float
    disease_burden: float
    mobility: float
    cultural_velocity: float
    baseline_trust: float
    baseline_stress: float
    innovation_pressure: float
    reality_seed_strength: float = 1.0
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def make_reality_baseline(era: str = "modern", start_year: Optional[int] = None, location: str = "generic", profile: str = "generic_mixed_region", custom: Optional[Dict[str, Any]] = None) -> RealityBaseline:
    if custom:
        era = str(custom.get("era", era))
    if era == "now":
        era = "modern"
    if era not in ERA_PRESETS:
        raise ValueError(f"Unknown era {era!r}. Use one of: {', '.join(sorted(ERA_PRESETS))}, now")
    base = dict(ERA_PRESETS[era])
    if custom:
        base.update(custom)
    year = int(start_year if start_year is not None else base.get("reference_year", 2026))
    notes: List[str] = []
    if year != int(base.get("reference_year", year)):
        notes.append(f"Custom start_year {year} overrode preset reference year {base.get('reference_year')}.")
    return RealityBaseline(
        era=era,
        start_year=year,
        location=location,
        profile=profile,
        label=str(base.get("label", era)),
        description=str(base.get("description", "")),
        technology_level=_clamp(base.get("technology_level", 0.5)),
        institutional_complexity=_clamp(base.get("institutional_complexity", 0.5)),
        urbanization=_clamp(base.get("urbanization", 0.5)),
        literacy=_clamp(base.get("literacy", 0.5)),
        media_density=_clamp(base.get("media_density", 0.5)),
        market_integration=_clamp(base.get("market_integration", 0.5)),
        healthcare_capacity=_clamp(base.get("healthcare_capacity", 0.5)),
        disease_burden=_clamp(base.get("disease_burden", 0.5)),
        mobility=_clamp(base.get("mobility", 0.5)),
        cultural_velocity=_clamp(base.get("cultural_velocity", 0.5)),
        baseline_trust=_clamp(base.get("baseline_trust", 0.5)),
        baseline_stress=_clamp(base.get("baseline_stress", 0.5)),
        innovation_pressure=_clamp(base.get("innovation_pressure", 0.5)),
        reality_seed_strength=_clamp(base.get("reality_seed_strength", 1.0)),
        notes=notes + list(base.get("notes", []) or []),
    )


def baseline_to_timeline(b: RealityBaseline) -> Dict[str, Any]:
    """Create a compatible timeline dict for the existing HistoricalSimulator."""
    pressure = _clamp((b.baseline_stress + b.disease_burden + (1.0 - b.baseline_trust)) / 3.0)
    adaptation = _clamp((b.technology_level + b.institutional_complexity + b.healthcare_capacity + b.literacy) / 4.0)
    event_count = 4
    spacing = max(1, int(12 / event_count))
    return {
        "name": f"v3_1_{b.era}_{b.start_year}_{b.location}".replace(" ", "_"),
        "description": f"Reality baseline seed: {b.label}. {b.description}",
        "events": [
            {"t": 1, "label": "baseline_social_pressure", "type": "pressure", "intensity": round(pressure, 3)},
            {"t": 1 + spacing, "label": "institutional_baseline", "type": "institutional", "intensity": round(b.institutional_complexity, 3)},
            {"t": 1 + spacing * 2, "label": "media_culture_velocity", "type": "information", "intensity": round(b.media_density * b.cultural_velocity, 3)},
            {"t": 1 + spacing * 3, "label": "innovation_pressure", "type": "innovation", "intensity": round(b.innovation_pressure, 3)},
        ],
        "baseline": b.to_dict(),
        "derived": {"pressure": pressure, "adaptation_capacity": adaptation},
    }


def baseline_to_novelties(b: RealityBaseline) -> List[Dict[str, Any]]:
    tech = b.technology_level
    media = b.media_density
    healthcare = b.healthcare_capacity
    return [
        {
            "name": "baseline communication network",
            "domain": "media",
            "potency": round(media, 3),
            "adoption": round(_clamp(media * 0.8), 3),
            "resistance": round(_clamp(1.0 - media), 3),
        },
        {
            "name": "baseline production technology",
            "domain": "technology",
            "potency": round(tech, 3),
            "adoption": round(_clamp(tech * b.market_integration), 3),
            "resistance": round(_clamp(0.7 - tech * 0.4), 3),
        },
        {
            "name": "baseline healthcare system",
            "domain": "healthcare",
            "potency": round(healthcare, 3),
            "adoption": round(_clamp(healthcare * b.institutional_complexity), 3),
            "resistance": round(_clamp(b.disease_burden * 0.5), 3),
        },
    ]


def baseline_to_policy_modifiers(b: RealityBaseline) -> Dict[str, Any]:
    return {
        "baseline_trust_modifier": round(b.baseline_trust - 0.5, 4),
        "baseline_stress_modifier": round(b.baseline_stress - 0.5, 4),
        "institutional_capacity": round(b.institutional_complexity, 4),
        "market_integration": round(b.market_integration, 4),
        "mobility": round(b.mobility, 4),
        "healthcare_capacity": round(b.healthcare_capacity, 4),
        "disease_burden": round(b.disease_burden, 4),
    }


def write_seed_files(output_dir: str | Path, b: RealityBaseline) -> Dict[str, str]:
    root = Path(output_dir)
    root.mkdir(parents=True, exist_ok=True)
    timeline_path = root / "timeline_seed.json"
    novelty_path = root / "novelty_seed.json"
    baseline_path = root / "reality_baseline.json"
    _write_json(timeline_path, baseline_to_timeline(b))
    _write_json(novelty_path, {"novelties": baseline_to_novelties(b), "baseline": b.to_dict()})
    _write_json(baseline_path, b.to_dict())
    return {"timeline": str(timeline_path), "novelties": str(novelty_path), "baseline": str(baseline_path)}


def compute_divergence_report(baseline: RealityBaseline, latest: Dict[str, Any]) -> Dict[str, Any]:
    benchmark = latest.get("benchmark") or {}
    state = latest.get("state") or {}
    memory = state.get("memory") or {}
    civ = state.get("civilization") or {}
    institutions = state.get("institutions") or []
    avg_legitimacy = 0.0
    if institutions:
        vals = [float(i.get("legitimacy", 0.0) or 0.0) for i in institutions if isinstance(i, dict)]
        avg_legitimacy = sum(vals) / max(1, len(vals))
    observed = {
        "institutional_legitimacy": avg_legitimacy,
        "civilization_shift_score": float(benchmark.get("civilization_shift_score", 0.0) or 0.0),
        "average_adoption": float(benchmark.get("average_adoption", 0.0) or 0.0),
        "average_normalization": float(benchmark.get("average_normalization", 0.0) or 0.0),
        "memory_scar_count": len(memory.get("historical_scars", []) or []),
        "generated_novelty_count": int(benchmark.get("generated_novelty_count", civ.get("generated_novelty_count", 0)) or 0),
    }
    expected = {
        "institutional_legitimacy": baseline.institutional_complexity * baseline.baseline_trust,
        "civilization_shift_score": baseline.innovation_pressure * baseline.cultural_velocity,
        "average_adoption": baseline.technology_level * baseline.market_integration,
        "average_normalization": baseline.cultural_velocity * baseline.media_density,
        "memory_scar_count": int(round(baseline.baseline_stress * 3)),
        "generated_novelty_count": int(round(baseline.innovation_pressure * 5)),
    }
    deltas: Dict[str, float] = {}
    for k, exp in expected.items():
        obs = float(observed.get(k, 0.0) or 0.0)
        deltas[k] = round(obs - float(exp), 4)
    score = round(sum(abs(v) for v in deltas.values()) / max(1, len(deltas)), 4)
    return {
        "engine_version": ENGINE_VERSION,
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "baseline": baseline.to_dict(),
        "expected": expected,
        "observed": observed,
        "deltas": deltas,
        "divergence_score": score,
        "interpretation": "Higher divergence means the simulated world moved further from the seeded era baseline during the run.",
    }


def divergence_markdown(report: Dict[str, Any]) -> str:
    b = report.get("baseline", {})
    lines = [
        "# HRM_UNIFIED v3.1 Reality Baseline Divergence Report",
        "",
        f"Era: `{b.get('era')}`",
        f"Start year: `{b.get('start_year')}`",
        f"Location: `{b.get('location')}`",
        f"Profile: `{b.get('profile')}`",
        f"Divergence score: `{report.get('divergence_score')}`",
        "",
        "## Baseline",
        f"{b.get('description', '')}",
        "",
        "## Deltas",
    ]
    for k, v in (report.get("deltas") or {}).items():
        lines.append(f"- {k}: {v}")
    lines += ["", "## Meaning", str(report.get("interpretation", "")), ""]
    return "\n".join(lines)
