#!/usr/bin/env python3
"""Deterministic v1.5 spatial/institutional benchmark."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

try:
    from .population.calibrated_panel import CalibratedPanel
except ImportError:
    from population.calibrated_panel import CalibratedPanel

STIMULI = [
    "A media hub broadcasts reports of a safety threat spreading through the urban core.",
    "An employer announces layoffs affecting the industrial district and nearby households.",
    "Public health officials at a hospital announce a contained capacity warning.",
    "A community center coordinates relief support after a regional service disruption.",
    "A utility warns of a severe outage crisis and shortage affecting commercial and suburban districts."
]


def main() -> int:
    runs = []
    for i, stim in enumerate(STIMULI):
        panel = CalibratedPanel(n=500, seed=42 + i, profile="generic_mixed_region")
        result = panel.inject(stim, run_ticks=35)
        runs.append({
            "stimulus": stim,
            "channel": result.source_channel,
            "delta": result.delta,
            "top_hotspots": result.hotspot_report[:3],
            "district_count": len(result.spatial_summary.get("districts", [])),
            "institution_count": len(result.spatial_summary.get("institutions", [])),
        })
    payload = {"version": "v1.5", "name": "Spatial and Institutional Dynamics Benchmark", "runs": runs}
    fp = hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()
    payload["fingerprint_sha256"] = fp
    out = Path("outputs/spatial_benchmark_v1_5.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"fingerprint_sha256={fp}")
    print(f"wrote={out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
