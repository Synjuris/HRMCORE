# HRM Unified v4.35 — Generational Psychological Transmission

## Purpose
v4.35 closes the developmental loop introduced in v4.31 and preserved through v4.34:

experience → adult psychology → household climate/story memory → child baseline probabilities → later development

This release does not copy trauma deterministically from parent to child. It bends probability ranges and household exposure variables.

## Added

### `das/generational_psychology.py`
New v4.35 subsystem with:
- probabilistic intergenerational baseline biasing at birth
- household emotional climate scoring
- parent trauma burden scoring
- oral tradition transmission through knowledge/information-capable agents
- targeted care recovery through care-family agents
- `GenerationalPsychologyLedger`
- benchmark metrics for transmission events

### Birth integration
`das/reproduction.py` now calls `apply_birth_transmission()` immediately after inherited trait blending.

### Simulation integration
`das/run_sim.py` now:
- creates a `GenerationalPsychologyLedger`
- passes it into reproduction
- runs oral tradition and targeted care recovery ticks
- writes `generational_psychology_ledger.json`
- includes v4.35 metrics in metrics/summary/benchmark output
- defaults to `runs_v04_35`
- writes `benchmark_v04_35.json`

## Key design rules
- No child is marked traumatized simply because a parent was traumatized.
- Parent history, household risk, and protective care alter starting distributions.
- Care and oral tradition can transmit resilience as well as fear.
- Role logic uses adaptive role families, not era-specific occupations.

## Validation
- Python compile check passed.
- DAS smoke run passed.
- Direct v4.35 unit check passed for birth transmission callable path.
- Zip integrity check passed.
- Omission check against v4.34 base passed: 0 base files missing.
