# HRM v4.55 — K2-3C+ CognitionObserver

Adds the first readable cognition observer as a separate observability layer.

## Added

- `das/cognition_observer.py`
- `CognitionObserver.observe(tick, runtime)`
- deterministic template renderer for offline/no-API runs
- prompt packet builder for later LLM renderer wiring
- separate JSONL output: `cognition_observations.jsonl`
- config flags:
  - `cognition_observer_enabled`
  - `cognition_observer_every_n`
  - `cognition_observer_sample_size`
  - `cognition_observer_agent_ids`
  - `cognition_observer_output_file`
  - `cognition_observer_include_prompt_packet`

## Hard boundary

`CognitionObserver` is read-only. It does not mutate agents, memories, ledgers,
factions, culture, governance, or simulation state. Its records are
interpretations of substrate state, not substrate truth.

## Default behavior

Disabled by default. Enable in config or after config load:

```python
cfg.cognition_observer_enabled = True
cfg.cognition_observer_every_n = 50
cfg.cognition_observer_sample_size = 3
```

## Version chain

- v4.52: checkpoint restore integrity
- v4.53: orchestration integrity
- v4.54: observe hook infrastructure
- v4.55: cognition observer lens
