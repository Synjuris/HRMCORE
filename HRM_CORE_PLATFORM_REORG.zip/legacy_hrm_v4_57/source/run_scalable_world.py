#!/usr/bin/env python3
"""Run HRM_UNIFIED v3.0 scalable persistent world wrapper."""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

try:
    from .scalable_architecture import ENGINE_VERSION, make_fidelity_plan, apply_scale_maintenance, scale_health_markdown, MODE_PRESETS
except ImportError:
    from scalable_architecture import ENGINE_VERSION, make_fidelity_plan, apply_scale_maintenance, scale_health_markdown, MODE_PRESETS


def main() -> int:
    ap = argparse.ArgumentParser(description="Run scalable HRM world with fidelity guardrails, compaction, and health reporting.")
    ap.add_argument("timeline", nargs="?", help="Optional timeline JSON/YAML.")
    ap.add_argument("--mode", choices=sorted(MODE_PRESETS), default="desktop")
    ap.add_argument("--n", type=int, default=1200, help="Requested population. Guardrails may cap full-detail simulation.")
    ap.add_argument("--cycles", type=int, default=2)
    ap.add_argument("--generations-per-cycle", type=int, default=2)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--profile", default="generic_mixed_region")
    ap.add_argument("--world-id", default="default_world_v3")
    ap.add_argument("--output-dir", default="outputs/scalable_world_v3_0")
    ap.add_argument("--sleep", type=float, default=0.0)
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--force", action="store_true", help="Allow values beyond mode guardrails. Not recommended.")
    ap.add_argument("--maintenance-only", action="store_true", help="Only compact/prune/report an existing world.")
    ap.add_argument("--mark-viewed", action="store_true")
    args = ap.parse_args()

    plan = make_fidelity_plan(args.mode, args.n, force=args.force)
    if args.maintenance_only:
        health = apply_scale_maintenance(args.output_dir, args.world_id, args.mode, args.n, force=args.force)
    else:
        # Run the existing v2.7 continuous world through a bounded v3.0 plan.
        cmd = [
            sys.executable,
            str(Path(__file__).with_name("run_persistent_continuous_world.py")),
            "--n", str(plan.simulated_agents),
            "--cycles", str(args.cycles),
            "--generations-per-cycle", str(args.generations_per_cycle),
            "--seed", str(args.seed),
            "--profile", args.profile,
            "--world-id", args.world_id,
            "--output-dir", args.output_dir,
            "--sleep", str(args.sleep),
            "--name", "scalable_world_v3_0",
        ]
        if args.timeline:
            cmd.insert(2, args.timeline)
        if args.resume:
            cmd.append("--resume")
        if args.mark_viewed:
            cmd.append("--mark-viewed")
        completed = subprocess.run(cmd, cwd=Path(__file__).resolve().parent)
        health = apply_scale_maintenance(args.output_dir, args.world_id, args.mode, args.n, force=args.force)
        if completed.returncode not in (0, 2):
            health["status"] = "run_failed"
            health["runner_returncode"] = completed.returncode

    world_dir = Path(args.output_dir) / args.world_id
    report_path = world_dir / "reports" / "scale_health_report.md"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(scale_health_markdown(health), encoding="utf-8")

    print(f"HRM_UNIFIED v{ENGINE_VERSION} SCALABLE WORLD ARCHITECTURE")
    print(f"Mode: {args.mode}")
    print(f"Requested agents: {plan.requested_agents}")
    print(f"Full simulated agents: {plan.simulated_agents}")
    print(f"Active/regional/statistical: {plan.active_agents}/{plan.regional_agents}/{plan.statistical_agents}")
    for warning in plan.warnings:
        print("WARNING:", warning)
    print("Wrote:")
    print("  scale health:", report_path)
    print("  scale summary:", world_dir / "reports" / "scale_summary.json")
    print("  latest:", world_dir / "world_state_latest.json")
    return 0 if health.get("status") in ("ok", "guarded") else 2


if __name__ == "__main__":
    raise SystemExit(main())
