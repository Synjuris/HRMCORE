# HRM_UNIFIED v2.1 — HRM/DAS Bridge Layer

This release adds the first controlled integration point between the HRM civic-state environment and the DAS emergence substrate.

## Added

- `bridge/das_bridge.py`
- `run_das_bridge.py`
- `das_bridge_benchmark.py`
- optional `--enable-das-bridge` flag for `run_environment.py`
- DAS bridge state included in environment snapshots when enabled
- DAS bridge JSON/Markdown reports per run

## Design rule

DAS is not merged wholesale into HRM. v2.1 translates HRM civic pressures into a bounded substrate state:

- structural stress
- institutional adaptation
- faction volatility
- cooperation capacity
- innovation momentum
- migration tendency
- cultural drift
- resilience memory

This preserves causality and inspectability.

## Boundaries

- no personal hardcoding
- no locality hardcoding
- no API key embedding
- no predictive claims
- no full legacy DAS simulation activation yet

## Example

```bash
python run_das_bridge.py
```

or:

```bash
python run_environment.py --enable-das-bridge
```
