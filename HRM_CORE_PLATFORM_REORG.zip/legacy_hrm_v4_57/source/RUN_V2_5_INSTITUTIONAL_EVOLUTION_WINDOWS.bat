@echo off
setlocal
cd /d "%~dp0"
echo HRM_UNIFIED v2.5 - Institutional Evolution Layer
echo.
py -3 run_institutional_evolution.py --generations 5 --n 600 --seed 42 --output-dir outputs\institutional_evolution_v2_5
if errorlevel 1 (
  echo.
  echo Run completed with warnings or audit failures. See outputs\institutional_evolution_v2_5.
) else (
  echo.
  echo Run complete. See outputs\institutional_evolution_v2_5.
)
pause
