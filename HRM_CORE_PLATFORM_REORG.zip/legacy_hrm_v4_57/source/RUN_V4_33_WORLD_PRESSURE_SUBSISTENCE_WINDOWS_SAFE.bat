@echo off
setlocal
cd /d "%~dp0\das"
set DAS_RUNS=1
set DAS_TICKS=120
set DAS_OUTPUT_ROOT=runs_v04_33
py -3 run_sim.py
pause
