# HRM v4.57 — Mushrooms + Launch Dashboard

Two additions, both self-contained. Nothing in the existing engine was modified.

## 1. Psychoactive mushrooms — `das/mushrooms.py`

A single droppable psychoactive patch. Import it, drop it, tick it inside your
agent loop:

```python
from das.mushrooms import MushroomPatch

shrooms = MushroomPatch()        # dormant
shrooms.drop(x=7, y=7)           # the "shock" — one patch, placed here
events = shrooms.tick(agents, tick)   # each tick, after agents have positions
```

- Agents inside the patch radius get **dosed**: curiosity ↑, social_openness ↑,
  dominance ↓, fear ↓, stability ↓, valence usually warms (sometimes a bad trip),
  and ideology_alignment drifts (suggestibility). All on the real `AgentState`
  fields from `das/schemas.py`.
- The trip **ramps** while in the patch and **decays** once the agent leaves.
- Patch stock depletes with use and slowly regrows.
- `shrooms.tick(...)` returns observer-visible `mushroom_dose` Events.
- `shrooms.snapshot()` → patch state for dashboards (location, stock, #tripping).

Position lookup is flexible — it reads `agent.position.x/.y` (the engine's
layout), and also falls back to `agent.x/.y` etc.

### See it run
```
python demo/mushroom_demo.py --agents 24 --ticks 60 --drop 7 7
```
Builds real AgentState agents, drops the patch, prints affect shifts as agents
pass through, then the decay. A true end-to-end integration proof.

## 2. Launch dashboard — `index.html`

A landing-page-grade single file for HughMannResonance.com. Dark, animated
resonance backdrop, hero/thesis, live metrics, faction profiles, meme pool,
agent registry, chronicle, and a dedicated **Perturbations / Psychoactive Bloom**
section for the mushrooms.

It reads the same `SIM_DATA` shape the existing `world_dashboard.py` emits, plus
an optional `mushrooms` block:

```json
"mushrooms": {"active": true, "tripping": 2, "patch": {"x":7,"y":7,"radius":2.5,"stock":0.96}}
```

To wire it to fresh runs, have your dashboard generator write the same
`const SIM_DATA = {...};` line into `index.html` that it already writes into
`hrm_dashboard.html`. The current file ships with the latest recorded run baked in.
