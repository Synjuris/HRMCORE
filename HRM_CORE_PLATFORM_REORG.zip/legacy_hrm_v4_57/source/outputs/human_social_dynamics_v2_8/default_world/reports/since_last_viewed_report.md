# HRM_UNIFIED v2.7 Since-Last-Viewed Report

World: `default_world`
Prior cycle: 0 | Latest cycle: 1 | Elapsed cycles: 1
Prior generation: 0 | Latest generation: 1 | Elapsed generations: 1
Latest shift: **mixed_civilization_shift**

## Metric deltas
- `average_adoption`: +0.205270
- `average_normalization`: +0.029749
- `civilization_shift_score`: +0.082298
- `constitution_failures`: +0.000000
- `cycles_completed`: +1.000000
- `factionalism`: +0.257528
- `family_continuity`: +0.527612
- `generated_novelty_count`: +0.000000
- `generations_completed`: +1.000000
- `identity_expression`: +0.599403
- `migration_pressure`: +0.121145
- `novelty_count`: +4.000000
- `pair_bond_stability`: +0.540404
- `reproduction_rate`: +0.422524
- `role_specialization`: +0.361999
- `sexuality_expression`: +0.551245

## New novelty/idea/discovery records
- automated_substitution_system
- low_cost_coordination_tool
- resilience_doctrine
- status_market_product

## Integrity
Prior fingerprint: `None`
Latest fingerprint: `d756b7ed7f267a3149b05a6d6d52f0314e8213c2f097be8c866f7879cfb28450`
