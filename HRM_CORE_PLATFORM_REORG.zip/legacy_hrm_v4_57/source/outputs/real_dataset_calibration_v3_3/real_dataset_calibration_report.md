# HRM_UNIFIED v3.3 Real Dataset Calibration Report

**Geography / baseline:** sample_generic_region
**Calibration score:** 100.0 / 100
**Ready for experiment:** True

## Sources
- `input_1:sample_real_dataset.csv` | type=csv | records=1 | sha256=5cb6606bd335397723227aff12e4e0c509359f15d8c9e2e31e9142a21bdf0ab3

## Normalized Calibration Drivers
- `population_scale`: 0.1
- `economic_pressure`: 0.3899
- `resource_baseline`: 0.4665
- `demographic_youth`: 0.6618
- `demographic_aging`: 0.525
- `education_signal`: 0.4516
- `industrial_dependency`: 0.32
- `density_pressure`: 0.225
- `healthcare_capacity`: 0.4
- `mobility_pressure`: 0.4364
- `safety_pressure`: 0.35
- `social_complexity`: 0.3003
- `volatility_pressure`: 0.4177
- `public_health_vulnerability`: 0.4444
- `institutional_load`: 0.3584

## Missing / Weak Fields

## Warnings
- None

## Generated Patches

The JSON bundle contains four machine-readable sections:
- `hrm_config_patch`
- `disease_patch`
- `era_patch`
- `scale_patch`

These are calibration priors. They do not claim predictive certainty.
