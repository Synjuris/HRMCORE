# HRM_UNIFIED v3.0 Scale Health Report

World: `smoke_v3`
Mode: `toy`
Status: `ok`

## Fidelity Plan
- Requested agents: 80
- Full simulated agents: 80
- Active-detail agents: 50
- Regional-summary agents: 30
- Statistical/background agents: 0
- Compression ratio: 1.0

## Maintenance
- Replay: {'original_count': 2, 'kept_count': 2, 'archived_count_this_pass': 0}
- Checkpoints: {'checkpoint_count_before': 1, 'kept': 1, 'deleted': 0}

## Rule
Full detail is reserved for the active slice of the world. Regional and statistical populations stay compressed until events justify expansion.
