# HRM_UNIFIED v4.53 — Kernel Phase K2-3B: Declarative Orchestration

## Summary
Phases are declared constants. Subsystems declare dependencies explicitly.
Ordering is kernel-owned and validated at startup. The kernel is no longer
a cleaned-up runner — it is a simulation runtime.

## What Changed

### kernel/system_registry.py — Major rewrite

New: SYSTEM_PHASES tuple (14 phases, canonical declaration):
    PRE_AGENT, AGENT, POST_AGENT, SUBSISTENCE, TRANSFER, REPRODUCTION,
    GENERATIONAL, GOVERNANCE, INFORMATION, INNOVATION,
    CULTURE, VIABILITY, METRICS, CHECKPOINT

New: SubsystemSpec dataclass
    name, phase, fn, depends_on, every_n, enabled_flag

New: SystemRegistry.freeze()
    Validates all registrations. Hard-fails on:
        - Unknown phase name
        - Duplicate subsystem name
        - Unknown dependency name
        - Forward cross-phase dependency
        - Circular dependency within a phase
    Topo-sorts within each phase using Kahn's algorithm.
    Builds frozen execution plan. Called automatically on first run_phase()
    if not called explicitly.

New: SystemRegistry.register_spec(SubsystemSpec)
    K2-3B registration API.

Preserved: SystemRegistry.register() legacy API
    Still works. Maps SystemPhase enum to string phase name.
    SUBSYSTEMS → GENERATIONAL (legacy registrations land in first new phase).

### kernel/experiment_setup.py
All 9 subsystems now registered via SubsystemSpec with explicit phases
and depends_on declarations:
    generational    → GENERATIONAL
    apprenticeship  → GENERATIONAL  (depends_on: generational)
    governance      → GOVERNANCE    (depends_on: generational — earlier phase)
    information     → INFORMATION   (depends_on: governance — earlier phase)
    innovation      → INNOVATION    (depends_on: information — earlier phase)
    storykeeper     → CULTURE       (depends_on: innovation — earlier phase)
    care_recovery   → CULTURE       (depends_on: storykeeper)
    inst_memory     → CULTURE       (depends_on: care_recovery)
    viability       → VIABILITY     (depends_on: inst_memory — earlier phase)

### kernel/runtime.py
run_phase() calls updated from SystemPhase enum to string phase names.
SUBSYSTEMS single call replaced by 6 sequential phase calls:
    GENERATIONAL → GOVERNANCE → INFORMATION → INNOVATION → CULTURE → VIABILITY
freeze() called at start of run() before first tick.

### All run_kernel_*.py
freeze() called before summary() so registry output is always readable.

## Validation
20/20 unit tests passed:
    - Phase declaration (8 checks)
    - All 5 hard-fail cases
    - Topo-sort within-phase ordering
    - Cross-phase earlier dep allowed
    - Execution order correctness
    - Legacy register() compatibility
    - Auto-freeze on first run_phase()

End-to-end simulation: 25 ticks, 14 alive, 4 practices. Clean.

## Remaining K2-3C/D
- K2-3C: observe(tick, runtime) hook in METRICS phase
- K2-3D: run_sim.py → kernel benchmark harness
