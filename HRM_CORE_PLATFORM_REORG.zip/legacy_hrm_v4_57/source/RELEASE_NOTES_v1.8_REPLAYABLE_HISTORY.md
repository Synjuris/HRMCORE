# HRM_UNIFIED v1.8 — Replayable Historical Simulation

v1.8 adds persistent synthetic timelines. Instead of resetting after each scenario, the engine carries civic state forward across periods so stress, trust damage, recovery, institutional strain, and policy effects accumulate over simulated history.

## Added

- `population/history.py`
- `replay_history.py`
- `compare_histories.py`
- `history_benchmark.py`
- JSON/YAML timeline loading
- persistent civic-state snapshots
- save/load state support
- branch comparison outputs
- generic example timelines

## Boundaries

- No personal hardcoding.
- No locality hardcoding.
- No API key embedding.
- Historical replay is synthetic model evolution, not real-world prediction.
