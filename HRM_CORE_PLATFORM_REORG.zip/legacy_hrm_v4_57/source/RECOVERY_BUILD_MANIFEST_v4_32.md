# HRM Unified v4.32 Recovery Build Manifest

## Assembly rule

This full package was assembled by taking the union of available historical packages in chronological order, with newer files overwriting older files of the same path while preserving files that were present in earlier complete builds.

Applied sequence:

1. HRM_UNIFIED_v2_6_EMERGENT_CIVILIZATION_ENGINE_WINDOWS_SAFE
2. HRM_UNIFIED_v2_7_PERSISTENT_CONTINUOUS_WORLD_WINDOWS_SAFE
3. HRM_UNIFIED_v2_8_HUMAN_SOCIAL_DYNAMICS_DAS_DEEP_INTEGRATION_WINDOWS_SAFE
4. HRM_UNIFIED_v2_9_WORLD_INSPECTION_DASHBOARD_WINDOWS_SAFE_FIXED
5. HRM_UNIFIED_v3_0_SCALABLE_WORLD_ARCHITECTURE_WINDOWS_SAFE
6. HRM_UNIFIED_v3_1_ERA_SEEDING_REALITY_BASELINE_WINDOWS_SAFE_FIXED
7. HRM_UNIFIED_v3_2_DISEASE_ECOLOGY_PUBLIC_HEALTH_WINDOWS_SAFE
8. HRM_UNIFIED_v3_3_REAL_DATASET_INGESTION_CALIBRATION_WINDOWS_SAFE
9. HRM_UNIFIED_v3_3_1_REAL_DATA_API_CONNECTOR_WINDOWS_SAFE_REBUILT
10. hrm_unified_v4_31_psychology_development overlay
11. v4.32 Continuity Engine additions

## Critical recovery finding

The available v4.31 archive was not a full project package. It contained only seven files. This build restores it into a complete package by using the full historical v3.x package chain as the base and then applying the v4.31 overlay.

## Validation run performed

- Python compile pass: `python -m compileall -q .`
- Legacy self-test pass: `python run_self_test.py`
- DAS smoke run pass: `DAS_RUNS=1 DAS_TICKS=120 DAS_OUTPUT_ROOT=/mnt/data/hrm_recovery/test_runs_v432_120 python das/run_sim.py`
- Continuity artifacts verified under `run_1/continuity/`:
  - `life_history_ledger.json`
  - `lineages.json`
  - `death_memory.json`
  - `culture_timeline.json`
  - `civilization_chronicle.md`

## Added/restored DAS runtime support modules

The v4.31 overlay referenced runtime modules that were not present in the complete v3.x packages. To make the package runnable, this build restores compatible support modules:

- `das/relationships.py`
- `das/planning.py`
- `das/space.py`
- `das/environment.py`
- `das/resources.py`
- `das/metrics.py`
- `das/manifest.py`
- `das/death_ledger.py`
- `das/observer_router.py`
- `das/scenario_profiles.py`
- `das/constraints.py`
- `das/apprenticeship.py`
- `das/checkpoint.py`

## v4.32 additions

- `das/continuity.py`
- `RELEASE_NOTES_v4_32_CONTINUITY_ENGINE.md`
- `RUN_V4_32_CONTINUITY_ENGINE_WINDOWS_SAFE.bat`
