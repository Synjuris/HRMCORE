"""Export helpers for HRM_UNIFIED panel runs."""
from __future__ import annotations

import csv
import json
from dataclasses import asdict
from pathlib import Path
from typing import Iterable, Mapping, Any


def safe_slug(text: str, limit: int = 48) -> str:
    keep = []
    for ch in text.lower():
        if ch.isalnum():
            keep.append(ch)
        elif ch in {" ", "-", "_"}:
            keep.append("_")
    slug = "".join(keep).strip("_")
    while "__" in slug:
        slug = slug.replace("__", "_")
    return (slug[:limit].strip("_") or "run")


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def write_panel_result(result: Any, output_dir: str | Path = "outputs", prefix: str | None = None, include_raw: bool = True) -> Mapping[str, str]:
    out = ensure_dir(output_dir)
    prefix = prefix or safe_slug(result.stimulus_text)

    summary_json = out / f"{prefix}_summary.json"
    summary_md = out / f"{prefix}_summary.md"
    deltas_csv = out / f"{prefix}_deltas.csv"
    raw_jsonl = out / f"{prefix}_agent_sample.jsonl"

    payload = asdict(result)
    if not include_raw:
        payload.pop("raw_snapshot", None)
    summary_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    md_lines = [
        "# HRM Synthetic Panel Run",
        "",
        f"**Stimulus:** {result.stimulus_text}",
        f"**Population:** {result.population_size}",
        f"**Ticks run:** {result.ticks_run}",
        "",
        "## Delta from Baseline",
        "",
        "| Metric | Baseline | No-Stimulus Control | Post-Injection | Delta vs Control |",
        "|---|---:|---:|---:|---:|",
    ]
    for metric, delta in result.delta.items():
        control_val = getattr(result, "control_post", {}).get(metric, 0)
        md_lines.append(f"| {metric} | {result.baseline.get(metric, 0):.4f} | {control_val:.4f} | {result.post_injection.get(metric, 0):.4f} | {delta:+.4f} |")
    md_lines += ["", "## Segment Breakdown", "", "```json", json.dumps(result.segment_breakdown, indent=2), "```", ""]
    hotspots = getattr(result, "hotspot_report", None)
    if hotspots:
        md_lines += ["", "## Spatial Hotspots", "", "| District | Kind | Stress Δ | Valence Δ | Score |", "|---|---|---:|---:|---:|"]
        for h in hotspots:
            md_lines.append(f"| {h.get('district_id')} | {h.get('district_kind')} | {h.get('stress_delta',0):+.4f} | {h.get('valence_delta',0):+.4f} | {h.get('hotspot_score',0):+.4f} |")
        md_lines.append("")
    summary_md.write_text("\n".join(md_lines), encoding="utf-8")

    with deltas_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["metric", "baseline", "control_post", "post_injection", "delta"])
        writer.writeheader()
        for metric, delta in result.delta.items():
            writer.writerow({
                "metric": metric,
                "baseline": result.baseline.get(metric, 0),
                "control_post": getattr(result, "control_post", {}).get(metric, 0),
                "post_injection": result.post_injection.get(metric, 0),
                "delta": delta,
            })

    if include_raw:
        with raw_jsonl.open("w", encoding="utf-8") as f:
            for rec in result.raw_snapshot:
                f.write(json.dumps(rec) + "\n")

    paths = {"summary_json": str(summary_json), "summary_md": str(summary_md), "deltas_csv": str(deltas_csv)}
    if include_raw:
        paths["agent_sample_jsonl"] = str(raw_jsonl)
    return paths
