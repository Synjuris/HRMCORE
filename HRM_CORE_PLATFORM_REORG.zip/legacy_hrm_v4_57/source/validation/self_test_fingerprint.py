"""
HRM_UNIFIED v1.1 deterministic self-test.

Runs the HRM core with a fixed configuration and prints a stable record count
and SHA256 fingerprint. Use this to verify that the package runs end-to-end and
that later code changes did not silently alter baseline behavior.

Usage from project root:
    python run_self_test.py
    python -m validation.self_test_fingerprint
    python validation/self_test_fingerprint.py
"""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.hrm_core_kernel import HRMCore, DEFAULT_CONFIG


def run_and_fingerprint(output_path: str = "validation/self_test_output.jsonl") -> tuple[int, str]:
    cfg = dict(DEFAULT_CONFIG)
    cfg["num_agents"] = 300
    cfg["ticks"] = 150
    cfg["seed"] = 42
    cfg["export"] = dict(cfg.get("export", {}))
    cfg["export"].update({
        "enabled": True,
        "path": output_path,
        "log_interval": 1,
        "sample_ratio": 1.0,
    })

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    sim = HRMCore(config=cfg)
    for _ in range(cfg["ticks"]):
        sim.step()
    sim.close()

    path = Path(output_path)
    h = hashlib.sha256()
    record_count = 0
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                record_count += 1
    return record_count, h.hexdigest()


if __name__ == "__main__":
    count, digest = run_and_fingerprint()
    print("Self-test records:", count)
    print("Self-test SHA256:", digest)
    print("Re-run this command. If the build is intact, both values should match exactly.")
