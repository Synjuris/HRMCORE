"""Generate a deterministic HRM validation run and simple aggregate metrics."""
from __future__ import annotations

import json
import statistics
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.hrm_core_kernel import HRMCore, DEFAULT_CONFIG


def main() -> None:
    cfg = dict(DEFAULT_CONFIG)
    cfg["num_agents"] = 500
    cfg["ticks"] = 200
    cfg["seed"] = 42
    cfg["export"] = dict(cfg.get("export", {}))
    cfg["export"].update({
        "enabled": True,
        "path": "validation/validation_run.jsonl",
        "log_interval": 1,
        "sample_ratio": 1.0,
    })
    Path(cfg["export"]["path"]).parent.mkdir(parents=True, exist_ok=True)

    sim = HRMCore(config=cfg)
    for _ in range(cfg["ticks"]):
        sim.step()
    sim.close()

    stresses = []
    beliefs = []
    valences = []
    with Path(cfg["export"]["path"]).open(encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            rec = json.loads(line)
            state = rec["state"]
            stresses.append(state["stress"])
            beliefs.append(state["belief"])
            valences.append(state["valence"])

    print("Records:", len(stresses))
    if stresses:
        print("Mean stress:", round(statistics.mean(stresses), 4))
        print("Mean belief:", round(statistics.mean(beliefs), 4))
        print("Mean valence:", round(statistics.mean(valences), 4))
        print("Output:", cfg["export"]["path"])


if __name__ == "__main__":
    main()
