#!/usr/bin/env python3
"""Build a static HRM_UNIFIED v1.9 observatory from a replayable history timeline."""
from __future__ import annotations

import argparse
from pathlib import Path

try:
    from .population.history import HistoricalSimulator, load_timeline
    from .population.policy import load_policy_definitions, DEFAULT_POLICIES
    from .observatory import write_observatory
    from .export_utils import safe_slug
except ImportError:
    from population.history import HistoricalSimulator, load_timeline
    from population.policy import load_policy_definitions, DEFAULT_POLICIES
    from observatory import write_observatory
    from export_utils import safe_slug


def main() -> int:
    ap = argparse.ArgumentParser(description="Create a static observatory HTML replay report.")
    ap.add_argument("timeline", nargs="?", help="Optional JSON/YAML timeline. Defaults to the built-in generic history.")
    ap.add_argument("--policies", help="Optional policy definition JSON file.")
    ap.add_argument("--n", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--profile", default="generic_mixed_region")
    ap.add_argument("--decay", type=float, default=0.86)
    ap.add_argument("--name")
    ap.add_argument("--output-dir", default="outputs/observatory_v1_9")
    args = ap.parse_args()

    timeline = load_timeline(args.timeline)
    name = args.name or str(timeline.get("name", Path(args.timeline).stem if args.timeline else "generic_observatory_history"))
    policies = load_policy_definitions(args.policies) if args.policies else DEFAULT_POLICIES
    sim = HistoricalSimulator(n=args.n, seed=args.seed, profile=args.profile, decay=args.decay, policies=policies)
    result = sim.run(timeline, name=name)
    paths = write_observatory(result, output_dir=args.output_dir, prefix=safe_slug("observatory_" + name))
    print("HRM_UNIFIED v1.9 OBSERVATORY BUILD")
    print(f"Timeline: {name}")
    print(f"Fingerprint: {result.fingerprint()[:16]}")
    print("Wrote:")
    for k, v in paths.items():
        print(f"  {k}: {v}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
