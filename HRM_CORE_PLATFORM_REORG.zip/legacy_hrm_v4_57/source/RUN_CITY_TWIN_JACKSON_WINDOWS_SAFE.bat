@echo off
setlocal
cd /d "%~dp0"
echo Starting HRM Jackson City Twin build...
py -3 -m hrm_city_twin.jackson_tn --pop 5000 --seed 42 --root .
if errorlevel 1 (
  echo.
  echo Python command failed. Trying plain py fallback...
  py -m hrm_city_twin.jackson_tn --pop 5000 --seed 42 --root .
)
echo.
echo Outputs are in outputs\city_twin\jackson_tn, profiles, and scenarios.
pause
