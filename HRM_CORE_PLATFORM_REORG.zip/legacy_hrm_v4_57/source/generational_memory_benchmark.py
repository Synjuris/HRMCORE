#!/usr/bin/env python3
"""Compatibility benchmark entrypoint for HRM_UNIFIED v2.4."""
from __future__ import annotations

try:
    from .run_generational_memory import main
except ImportError:
    from run_generational_memory import main

if __name__ == "__main__":
    raise SystemExit(main())
