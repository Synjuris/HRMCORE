# HRM_UNIFIED v2.0 — Synthetic Civic Environment

v2.0 consolidates the prior simulation scripts into a persistent synthetic civic environment.

## Added

- `run_environment.py` main environment runner
- `environment.py` persistent environment state model
- `environment_benchmark.py` deterministic environment benchmark
- save/load/resume support
- branch naming support for alternate trajectories
- environment snapshots
- run history tracking
- observatory export per environment run
- packaged generic demo timeline

## Preserved boundaries

- no embedded API keys
- no personal context
- no hardcoded real-city defaults
- no prediction claims
- optional real-data calibration remains external and aggregate-only

## Verified commands

```bash
python run_environment.py
python environment_benchmark.py
python validate_engine.py
```

## Status

Prototype-level synthetic civic environment. Suitable for local experimentation, inspection, and further development. Not validated for real-world forecasting.
