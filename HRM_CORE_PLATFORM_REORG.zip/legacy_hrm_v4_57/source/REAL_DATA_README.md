# Real Dataset Mode

This release adds optional real U.S. Census ACS calibration.

Rules:

- No city, county, state, or personal context is hardcoded.
- The core engine still runs without any API key.
- Real data becomes a calibration profile, not engine truth.
- API keys live in `.env.user`, not Python source code.

## Key setup

The package includes `.env.user` for local use. For a public repo, delete `.env.user` and keep only `.env.example`.

## Fetch a real public calibration profile

Use Census FIPS codes:

```bash
python fetch_real_profile.py --state 06 --county 001
python fetch_real_profile.py --state 06 --place 44000
```

## Run a real-calibrated panel

```bash
python run_real_panel.py "A major employer announces layoffs." --state 06 --county 001
```

## Outputs

Real-data mode writes:

- normalized calibration profile JSON
- panel JSON summary
- markdown report
- deltas CSV
- optional raw agent sample JSONL

## Current adapter

- Source: U.S. Census Bureau ACS Data Profile API
- Dataset: 2024 ACS 5-year profile
- Geography: any supported county or place by FIPS code

## Boundary

This is not a prediction engine. ACS data is converted into broad trait priors such as resource baseline, economic pressure, and social complexity. The output is a synthetic response model, not a forecast.
