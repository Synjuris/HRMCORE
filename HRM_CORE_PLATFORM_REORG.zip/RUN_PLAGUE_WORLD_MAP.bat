@echo off
cd /d "%~dp0"
py apps\plague_world_map\hrm_world_map.py
pause
