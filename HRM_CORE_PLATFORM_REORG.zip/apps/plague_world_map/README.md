# Plague World Map App

Generic HRM map app. It should read HRM Core state frames, not edit HRM Core.
