#!/usr/bin/env python3
"""HRM Plague-Inc-style generic world map.

This is intentionally NOT Jackson-specific. It reads normal HRM world outputs when
available, then projects agents, factions, settlements, events, pressure, health,
trust, stress, novelty, and institutional signals onto a stylized strategic map.

No third-party dependencies are required. Run with:
    py hrm_world_map.py
or:
    py hrm_world_map.py --world-dir outputs/human_social_dynamics_v2_8/default_world
"""
from __future__ import annotations

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
import argparse
import hashlib
import json
import math
import mimetypes
import socket
import time
import webbrowser
from typing import Any, Dict, Iterable, List, Optional, Tuple

ENGINE_NAME = "HRM Strategic World Map"
ENGINE_VERSION = "1.0"

DEFAULT_WORLD_DIRS = [
    Path("outputs/human_social_dynamics_v2_8/default_world"),
    Path("outputs/persistent_world_v2_7/default_world"),
    Path("outputs/emergent_civilization_v2_6/default_world"),
    Path("outputs"),
]


def read_json(path: Path, default: Any) -> Any:
    try:
        if path.exists() and path.is_file():
            return json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except Exception as exc:
        return {"_error": f"Could not read {path}: {exc}"}
    return default


def choose_world_dir() -> Path:
    for candidate in DEFAULT_WORLD_DIRS:
        if (candidate / "world_state_latest.json").exists():
            return candidate
    for candidate in DEFAULT_WORLD_DIRS:
        if candidate.exists():
            return candidate
    return DEFAULT_WORLD_DIRS[0]


def clamp(x: Any, lo: float = 0.0, hi: float = 1.0, default: float = 0.0) -> float:
    try:
        v = float(x)
    except Exception:
        return default
    return max(lo, min(hi, v))


def stable_float(seed: str, salt: str = "") -> float:
    h = hashlib.sha256((seed + "|" + salt).encode("utf-8")).hexdigest()
    return int(h[:12], 16) / float(0xFFFFFFFFFFFF)


def deterministic_xy(name: str, kind: str = "agent") -> Tuple[float, float]:
    """Project arbitrary HRM entities onto a stylized map in normalized coordinates."""
    # Clusters create visible regions instead of total random scatter.
    region = int(stable_float(name, "region") * 6)
    centers = [
        (0.22, 0.27), (0.45, 0.22), (0.70, 0.30),
        (0.27, 0.62), (0.55, 0.64), (0.78, 0.70),
    ]
    cx, cy = centers[region]
    radius = 0.05 + 0.18 * stable_float(name, "radius")
    theta = stable_float(name, "theta") * math.tau
    x = cx + math.cos(theta) * radius
    y = cy + math.sin(theta) * radius * 0.72
    if kind in {"institution", "settlement"}:
        x = cx + (stable_float(name, "ix") - 0.5) * 0.08
        y = cy + (stable_float(name, "iy") - 0.5) * 0.08
    return clamp(x, 0.04, 0.96), clamp(y, 0.06, 0.94)


def recursively_find_entities(obj: Any, path: str = "") -> List[Dict[str, Any]]:
    """Find likely agent-like dictionaries anywhere in HRM output."""
    found: List[Dict[str, Any]] = []
    if isinstance(obj, dict):
        keys = {str(k).lower() for k in obj.keys()}
        identity_keys = {"id", "agent_id", "name", "label"}
        signal_keys = {
            "stress", "trust", "health", "fear", "valence", "openness", "status",
            "resilience", "legitimacy", "cohesion", "population", "role", "age",
            "faction", "generation", "wellbeing", "uncertainty", "anger", "norm_compliance",
        }
        if keys.intersection(identity_keys) and keys.intersection(signal_keys):
            e = dict(obj)
            e["_path"] = path
            found.append(e)
        for k, v in obj.items():
            found.extend(recursively_find_entities(v, f"{path}.{k}" if path else str(k)))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            found.extend(recursively_find_entities(v, f"{path}[{i}]"))
    return found


def as_list(value: Any) -> List[Any]:
    return value if isinstance(value, list) else []


def extract_entities(latest: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
    state = latest.get("state", latest) if isinstance(latest, dict) else {}
    social = state.get("human_social_dynamics", {}) if isinstance(state, dict) else {}

    raw_agents: List[Dict[str, Any]] = []
    for key in ["agents", "population", "people", "residents", "citizens"]:
        v = state.get(key) if isinstance(state, dict) else None
        if isinstance(v, list):
            raw_agents.extend([x for x in v if isinstance(x, dict)])
    raw_agents.extend(recursively_find_entities(state))

    seen = set()
    agents = []
    for i, a in enumerate(raw_agents[:2000]):
        name = str(a.get("name") or a.get("id") or a.get("agent_id") or a.get("label") or f"agent_{i}")
        if name in seen:
            continue
        seen.add(name)
        x = a.get("x", a.get("lon", a.get("longitude")))
        y = a.get("y", a.get("lat", a.get("latitude")))
        if isinstance(x, (int, float)) and isinstance(y, (int, float)):
            # Normalize unknown coordinate systems if necessary.
            nx = (float(x) + 180.0) / 360.0 if abs(float(x)) > 1 else float(x)
            ny = (90.0 - float(y)) / 180.0 if abs(float(y)) > 1 else float(y)
            nx, ny = clamp(nx, 0.02, 0.98), clamp(ny, 0.02, 0.98)
        else:
            nx, ny = deterministic_xy(name, "agent")
        stress = clamp(a.get("stress", a.get("fear", a.get("uncertainty", 0.25))), default=0.25)
        trust = clamp(a.get("trust", a.get("institutional_trust", a.get("social_trust", 0.5))), default=0.5)
        health = clamp(a.get("health", a.get("wellbeing", 1.0)), default=1.0)
        agents.append({
            "id": name,
            "name": name,
            "x": nx,
            "y": ny,
            "stress": stress,
            "trust": trust,
            "health": health,
            "faction": a.get("faction", a.get("faction_id", a.get("group", "unassigned"))),
            "role": a.get("role", a.get("occupation", a.get("archetype", "agent"))),
            "generation": a.get("generation", ""),
            "raw": {k: v for k, v in a.items() if k != "_path" and isinstance(v, (str, int, float, bool, type(None)))}
        })

    factions = []
    for i, f in enumerate(as_list(social.get("factions")) + as_list(state.get("factions") if isinstance(state, dict) else [])):
        if not isinstance(f, dict):
            continue
        name = str(f.get("name") or f.get("id") or f"faction_{i}")
        x, y = deterministic_xy(name, "faction")
        factions.append({
            "id": name,
            "name": name,
            "x": x,
            "y": y,
            "cohesion": clamp(f.get("cohesion", f.get("solidarity", 0.5)), default=0.5),
            "tension": clamp(f.get("tension", f.get("hostility", f.get("conflict", 0.25))), default=0.25),
            "population": f.get("population", f.get("size", "")),
        })

    institutions = []
    for i, inst in enumerate(as_list(state.get("institutions") if isinstance(state, dict) else [])):
        if not isinstance(inst, dict):
            continue
        name = str(inst.get("name") or inst.get("id") or f"institution_{i}")
        x, y = deterministic_xy(name, "institution")
        institutions.append({
            "id": name,
            "name": name,
            "x": x,
            "y": y,
            "legitimacy": clamp(inst.get("legitimacy", 0.5), default=0.5),
            "stability": clamp(inst.get("stability", 0.5), default=0.5),
            "type": inst.get("type", "institution"),
        })

    novelties = []
    for i, n in enumerate(as_list(state.get("novelties") if isinstance(state, dict) else [])):
        if not isinstance(n, dict):
            continue
        name = str(n.get("name") or n.get("id") or f"novelty_{i}")
        x, y = deterministic_xy(name, "novelty")
        novelties.append({
            "id": name,
            "name": name,
            "x": x,
            "y": y,
            "adoption": clamp(n.get("adoption", 0.2), default=0.2),
            "resistance": clamp(n.get("resistance", 0.2), default=0.2),
            "kind": n.get("kind", n.get("type", "novelty")),
        })

    timeline = read_json(MapHandler.world_dir / "evolution_timeline.json", {"events": []})
    events = as_list(timeline.get("events") if isinstance(timeline, dict) else [])[-100:]
    projected_events = []
    for i, ev in enumerate(events):
        if not isinstance(ev, dict):
            continue
        label = str(ev.get("message") or ev.get("event_type") or f"event_{i}")
        x, y = deterministic_xy(label, "event")
        projected_events.append({
            "id": f"event_{i}",
            "x": x,
            "y": y,
            "cycle": ev.get("cycle"),
            "type": ev.get("event_type", ev.get("type", "event")),
            "severity": clamp(ev.get("severity", 0.4), default=0.4),
            "message": label[:240],
        })

    return {
        "agents": agents,
        "factions": factions,
        "institutions": institutions,
        "novelties": novelties,
        "events": projected_events,
    }


def summarize_map(world_dir: Path) -> Dict[str, Any]:
    latest = read_json(world_dir / "world_state_latest.json", {})
    if not latest and world_dir.name == "outputs":
        # Fallback: find most recent world_state_latest below outputs.
        hits = sorted(world_dir.glob("**/world_state_latest.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        if hits:
            latest = read_json(hits[0], {})
            world_dir = hits[0].parent
            MapHandler.world_dir = world_dir
    state = latest.get("state", latest) if isinstance(latest, dict) else {}
    benchmark = latest.get("benchmark", {}) if isinstance(latest, dict) else {}
    entities = extract_entities(latest if isinstance(latest, dict) else {})
    agents = entities["agents"]
    avg = lambda arr, key, default=0.0: round(sum(float(a.get(key, default) or default) for a in arr) / len(arr), 4) if arr else default
    pressure = {
        "avg_stress": avg(agents, "stress", 0.25),
        "avg_trust": avg(agents, "trust", 0.5),
        "avg_health": avg(agents, "health", 1.0),
        "risk": round((avg(agents, "stress", 0.25) * 0.55) + ((1 - avg(agents, "trust", 0.5)) * 0.35) + ((1 - avg(agents, "health", 1.0)) * 0.10), 4),
    }
    return {
        "engine": ENGINE_NAME,
        "version": ENGINE_VERSION,
        "world_dir": str(world_dir),
        "exists": bool(latest),
        "cycle": latest.get("cycle") if isinstance(latest, dict) else None,
        "generation": latest.get("generation") if isinstance(latest, dict) else None,
        "fingerprint": latest.get("fingerprint") if isinstance(latest, dict) else None,
        "created_at": latest.get("created_at") if isinstance(latest, dict) else None,
        "benchmark": benchmark if isinstance(benchmark, dict) else {},
        "pressure": pressure,
        "entities": entities,
        "counts": {k: len(v) for k, v in entities.items()},
    }


MAP_HTML = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>HRM Strategic World Map</title>
<style>
:root{--bg:#071016;--panel:#0e1821;--panel2:#132332;--line:#244155;--text:#e7f2f6;--muted:#8ca2af;--hot:#ff5b4a;--warn:#f5b84b;--cool:#55d6be;--good:#64df89;--violet:#a78bfa}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 50% 10%,#123044 0,#071016 58%,#030608 100%);color:var(--text);font:13px/1.35 system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;overflow:hidden}.app{display:grid;grid-template-columns:340px 1fr 330px;height:100vh}.panel{background:rgba(8,17,24,.90);border-right:1px solid var(--line);backdrop-filter:blur(8px);padding:16px;overflow:auto}.right{border-right:0;border-left:1px solid var(--line)}h1{font-size:20px;margin:0 0 4px;letter-spacing:.02em}h2{font-size:13px;text-transform:uppercase;letter-spacing:.13em;color:var(--muted);margin:18px 0 8px}.sub{color:var(--muted);font-size:12px}.metricGrid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:14px}.metric{background:linear-gradient(180deg,rgba(26,47,65,.86),rgba(12,24,34,.86));border:1px solid var(--line);border-radius:14px;padding:10px}.metric b{display:block;font-size:22px}.metric span{color:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:.08em}.controls{display:grid;gap:8px;margin-top:12px}.controls button,.controls select,.controls input{background:#101d29;color:var(--text);border:1px solid var(--line);border-radius:10px;padding:9px;font:inherit}.controls button{cursor:pointer;font-weight:700}.controls button.active{background:#e6f6ff;color:#071016}.legend{display:grid;gap:7px}.legend div{display:flex;align-items:center;gap:8px;color:var(--muted)}.dot{width:11px;height:11px;border-radius:50%;display:inline-block}.mapWrap{position:relative;overflow:hidden}.toolbar{position:absolute;z-index:6;left:16px;right:16px;top:16px;display:flex;gap:8px;align-items:center;pointer-events:none}.toolbar > *{pointer-events:auto}.pill{background:rgba(7,16,22,.78);border:1px solid var(--line);border-radius:999px;padding:9px 12px;color:var(--muted);box-shadow:0 10px 30px rgba(0,0,0,.25)}#map{position:absolute;inset:0;cursor:grab}.mapWrap.grabbing #map{cursor:grabbing}.tooltip{position:absolute;z-index:9;display:none;max-width:330px;background:rgba(5,10,14,.94);border:1px solid #426b86;border-radius:14px;padding:12px;box-shadow:0 16px 40px rgba(0,0,0,.45);pointer-events:none}.tooltip h3{margin:0 0 6px;font-size:14px}.tooltip pre{white-space:pre-wrap;margin:8px 0 0;color:var(--muted);font-size:11px;max-height:150px;overflow:hidden}.list{display:grid;gap:8px}.item{background:rgba(19,35,50,.7);border:1px solid var(--line);border-radius:12px;padding:10px}.item b{display:block}.bar{height:6px;border-radius:99px;background:#08121a;overflow:hidden;margin-top:6px}.bar i{display:block;height:100%;background:linear-gradient(90deg,var(--cool),var(--warn),var(--hot))}.canvasNote{position:absolute;bottom:14px;left:16px;right:16px;color:var(--muted);font-size:12px;display:flex;justify-content:space-between;gap:10px}.scan{position:absolute;inset:-20%;background:linear-gradient(115deg,transparent 0,transparent 46%,rgba(85,214,190,.06) 50%,transparent 54%,transparent 100%);animation:scan 7s linear infinite;pointer-events:none;mix-blend-mode:screen}@keyframes scan{from{transform:translateX(-45%)}to{transform:translateX(45%)}}@media(max-width:1050px){.app{grid-template-columns:1fr}.panel.right{display:none}.panel:not(.right){position:absolute;z-index:20;max-width:350px;height:100%;transform:translateX(-100%);transition:.2s}.panel.open{transform:none}.mapWrap{height:100vh}.mobileBtn{display:block!important}}.mobileBtn{display:none}.warnText{color:#f5b84b}.goodText{color:#64df89}.badText{color:#ff7a68}
</style></head><body><div class="app">
<aside class="panel" id="left"><h1>HRM Strategic Map</h1><div class="sub" id="worldDir">Loading world output…</div><div class="metricGrid" id="metrics"></div><div class="controls"><button onclick="refresh()">Refresh state</button><button id="playBtn" onclick="togglePlay()">Live refresh: off</button><select id="layer" onchange="draw()"><option value="risk">Layer: Risk/pressure</option><option value="stress">Layer: Stress</option><option value="trust">Layer: Trust</option><option value="health">Layer: Health</option><option value="factions">Layer: Factions</option><option value="events">Layer: Events</option></select><input id="filter" placeholder="Filter agent/faction/event text" oninput="draw();renderLists()"></div><h2>Legend</h2><div class="legend"><div><span class="dot" style="background:#ff5b4a"></span> high stress / high risk</div><div><span class="dot" style="background:#f5b84b"></span> unstable / watch zone</div><div><span class="dot" style="background:#55d6be"></span> stable / low pressure</div><div><span class="dot" style="background:#a78bfa"></span> institution / novelty / event</div></div><h2>Map controls</h2><div class="sub">Drag to pan. Mouse wheel to zoom. Hover a dot for live entity data. This is generic HRM projection; real coordinates are used only when present.</div></aside>
<main class="mapWrap" id="wrap"><div class="toolbar"><button class="pill mobileBtn" onclick="document.getElementById('left').classList.toggle('open')">☰</button><div class="pill" id="status">loading</div><div class="pill">Plague-Inc style strategic surface</div></div><canvas id="map"></canvas><div class="scan"></div><div class="tooltip" id="tip"></div><div class="canvasNote"><span id="coords">zoom 1.00</span><span>HRM generic world map · no Jackson dependency</span></div></main>
<aside class="panel right"><h2>Hot zones</h2><div class="list" id="hotZones"></div><h2>Institutions</h2><div class="list" id="institutions"></div><h2>Recent events</h2><div class="list" id="events"></div></aside>
</div><script>
let DATA=null, playing=false, timer=null, scale=1, ox=0, oy=0, dragging=false, last=null, hover=null;
const canvas=document.getElementById('map'), ctx=canvas.getContext('2d'), wrap=document.getElementById('wrap'), tip=document.getElementById('tip');
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function metric(label,val){return `<div class="metric"><span>${esc(label)}</span><b>${esc(val??'—')}</b></div>`}
function filt(o){const f=(document.getElementById('filter').value||'').toLowerCase();return !f||JSON.stringify(o).toLowerCase().includes(f)}
function colorFor(v, invert=false){v=Math.max(0,Math.min(1,Number(v)||0)); if(invert)v=1-v; const r=Math.round(85+170*v), g=Math.round(214-123*v), b=Math.round(190-116*v); return `rgb(${r},${g},${b})`}
function resize(){const dpr=window.devicePixelRatio||1; canvas.width=wrap.clientWidth*dpr; canvas.height=wrap.clientHeight*dpr; canvas.style.width=wrap.clientWidth+'px'; canvas.style.height=wrap.clientHeight+'px'; ctx.setTransform(dpr,0,0,dpr,0,0); draw()}
function tx(x){return (x*wrap.clientWidth-wrap.clientWidth/2)*scale+wrap.clientWidth/2+ox} function ty(y){return (y*wrap.clientHeight-wrap.clientHeight/2)*scale+wrap.clientHeight/2+oy}
function invx(x){return ((x-ox-wrap.clientWidth/2)/scale+wrap.clientWidth/2)/wrap.clientWidth} function invy(y){return ((y-oy-wrap.clientHeight/2)/scale+wrap.clientHeight/2)/wrap.clientHeight}
function continents(){return [[[.08,.22],[.19,.12],[.36,.16],[.43,.30],[.35,.43],[.18,.46],[.09,.36]],[[.45,.18],[.60,.12],[.80,.22],[.88,.39],[.76,.53],[.55,.48],[.47,.35]],[[.18,.55],[.38,.52],[.46,.70],[.35,.88],[.17,.82],[.10,.66]],[[.52,.58],[.72,.55],[.90,.68],[.83,.88],[.60,.86],[.48,.74]]]}
function drawBase(){ctx.clearRect(0,0,wrap.clientWidth,wrap.clientHeight); const w=wrap.clientWidth,h=wrap.clientHeight; let grd=ctx.createRadialGradient(w*.5,h*.35,10,w*.5,h*.5,Math.max(w,h)*.8); grd.addColorStop(0,'#17364a');grd.addColorStop(.55,'#071016');grd.addColorStop(1,'#020507');ctx.fillStyle=grd;ctx.fillRect(0,0,w,h); ctx.strokeStyle='rgba(80,150,180,.12)';ctx.lineWidth=1; for(let i=-20;i<w+20;i+=42*scale){ctx.beginPath();ctx.moveTo(i+ox%42,0);ctx.lineTo(i+ox%42,h);ctx.stroke()} for(let j=-20;j<h+20;j+=42*scale){ctx.beginPath();ctx.moveTo(0,j+oy%42);ctx.lineTo(w,j+oy%42);ctx.stroke()} continents().forEach(poly=>{ctx.beginPath();poly.forEach((p,i)=>{let x=tx(p[0]),y=ty(p[1]); i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.closePath();ctx.fillStyle='rgba(35,70,62,.58)';ctx.fill();ctx.strokeStyle='rgba(97,172,152,.28)';ctx.lineWidth=2;ctx.stroke()})}
function drawHeat(points, key, invert=false){points.filter(filt).forEach(p=>{const v=Number(p[key]??0); const x=tx(p.x), y=ty(p.y); const r=(28+70*(invert?1-v:v))*scale; let g=ctx.createRadialGradient(x,y,0,x,y,r); g.addColorStop(0,colorFor(v,invert).replace('rgb','rgba').replace(')',',.24)')); g.addColorStop(1,'rgba(0,0,0,0)'); ctx.fillStyle=g; ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill()})}
function drawPoint(p, type, key){const x=tx(p.x), y=ty(p.y); let v=Number(p[key]??p.stress??p.severity??.5); let col= type==='institution'?'#e6f6ff': type==='novelty'?'#a78bfa': type==='event'?'#f5b84b':colorFor(v,key==='trust'||key==='health'); let r= type==='agent'?3.8: type==='faction'?11: type==='institution'?8: type==='event'?5:6; r*=Math.max(.75,Math.min(1.7,scale)); ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2); ctx.fillStyle=col;ctx.shadowColor=col;ctx.shadowBlur=10;ctx.fill();ctx.shadowBlur=0;ctx.strokeStyle='rgba(255,255,255,.35)';ctx.lineWidth=1;ctx.stroke(); p._screen={x,y,r:r+4,type}}
function draw(){if(!DATA)return; drawBase(); const layer=document.getElementById('layer').value; const E=DATA.entities; const agents=E.agents||[]; if(layer==='risk'||layer==='stress')drawHeat(agents,'stress'); if(layer==='trust')drawHeat(agents,'trust',true); if(layer==='health')drawHeat(agents,'health',true); agents.filter(filt).forEach(p=>drawPoint(p,'agent',layer==='trust'?'trust':layer==='health'?'health':'stress')); (E.factions||[]).filter(filt).forEach(p=>{drawHeat([p],'tension');drawPoint(p,'faction','tension')}); (E.institutions||[]).filter(filt).forEach(p=>drawPoint(p,'institution','legitimacy')); (E.novelties||[]).filter(filt).forEach(p=>drawPoint(p,'novelty','adoption')); if(layer==='events'||layer==='risk')(E.events||[]).filter(filt).forEach(p=>drawPoint(p,'event','severity')); if(hover)showTip(hover.event,hover.obj); document.getElementById('coords').textContent=`zoom ${scale.toFixed(2)} · pan ${Math.round(ox)},${Math.round(oy)}`}
function allObjects(){if(!DATA)return[];const E=DATA.entities;return [...(E.agents||[]),...(E.factions||[]),...(E.institutions||[]),...(E.novelties||[]),...(E.events||[])]}
function showTip(ev,o){tip.style.display='block';tip.style.left=Math.min(ev.clientX+14,window.innerWidth-350)+'px';tip.style.top=Math.min(ev.clientY+14,window.innerHeight-230)+'px';let title=o.name||o.id||o.type; let lines=Object.entries(o).filter(([k,v])=>!k.startsWith('_')&&typeof v!=='object').slice(0,14).map(([k,v])=>`${k}: ${v}`).join('\n'); tip.innerHTML=`<h3>${esc(title)}</h3><div class="sub">${esc(o._screen?.type||'entity')}</div><pre>${esc(lines)}</pre>`}
function renderLists(){if(!DATA)return; const E=DATA.entities; const agents=(E.agents||[]).filter(filt).slice().sort((a,b)=>(b.stress+(1-b.trust))-(a.stress+(1-a.trust))).slice(0,8); document.getElementById('hotZones').innerHTML=agents.map(a=>`<div class="item"><b>${esc(a.name)}</b><span class="sub">${esc(a.role)} · faction ${esc(a.faction)}</span><div class="bar"><i style="width:${Math.round((a.stress+(1-a.trust))*50)}%"></i></div></div>`).join('')||'<div class="sub">No agent entities found yet.</div>'; document.getElementById('institutions').innerHTML=(E.institutions||[]).filter(filt).slice(0,8).map(i=>`<div class="item"><b>${esc(i.name)}</b><span class="sub">legitimacy ${i.legitimacy} · stability ${i.stability}</span></div>`).join('')||'<div class="sub">No institutions found yet.</div>'; document.getElementById('events').innerHTML=(E.events||[]).filter(filt).slice(-8).reverse().map(e=>`<div class="item"><b>${esc(e.type)}</b><span class="sub">cycle ${esc(e.cycle)} · severity ${esc(e.severity)}</span><p>${esc(e.message)}</p></div>`).join('')||'<div class="sub">No events found yet.</div>'}
function render(){document.getElementById('worldDir').textContent=DATA.world_dir; document.getElementById('status').textContent=DATA.exists?`cycle ${DATA.cycle??'—'} · gen ${DATA.generation??'—'}`:'no world_state_latest.json yet'; const p=DATA.pressure||{}; document.getElementById('metrics').innerHTML=[metric('Agents',DATA.counts.agents),metric('Events',DATA.counts.events),metric('Stress',p.avg_stress),metric('Trust',p.avg_trust),metric('Health',p.avg_health),metric('Risk',p.risk)].join(''); renderLists(); draw()}
async function refresh(){DATA=await fetch('/api/map').then(r=>r.json()); render()}
function togglePlay(){playing=!playing; document.getElementById('playBtn').textContent='Live refresh: '+(playing?'on':'off'); document.getElementById('playBtn').classList.toggle('active',playing); if(timer)clearInterval(timer); if(playing)timer=setInterval(refresh,3000)}
canvas.addEventListener('mousedown',e=>{dragging=true;last=[e.clientX,e.clientY];wrap.classList.add('grabbing')}); window.addEventListener('mouseup',()=>{dragging=false;wrap.classList.remove('grabbing')}); window.addEventListener('mousemove',e=>{if(dragging){ox+=e.clientX-last[0];oy+=e.clientY-last[1];last=[e.clientX,e.clientY];draw();return} let hit=null; for(const o of allObjects()){if(o._screen){let dx=e.clientX-o._screen.x,dy=e.clientY-o._screen.y;if(dx*dx+dy*dy<o._screen.r*o._screen.r){hit=o;break}}} hover=hit?{event:e,obj:hit}:null; if(hit)showTip(e,hit); else tip.style.display='none'}); canvas.addEventListener('wheel',e=>{e.preventDefault(); const before=[invx(e.clientX),invy(e.clientY)]; scale*=e.deltaY<0?1.12:.89; scale=Math.max(.65,Math.min(5,scale)); const after=[tx(before[0]),ty(before[1])]; ox+=e.clientX-after[0]; oy+=e.clientY-after[1]; draw()},{passive:false}); window.addEventListener('resize',resize); resize(); refresh();
</script></body></html>'''


class MapHandler(BaseHTTPRequestHandler):
    world_dir: Path = choose_world_dir()

    def log_message(self, fmt: str, *args: Any) -> None:
        return

    def send_bytes(self, data: bytes, content_type: str, status: int = 200) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_text(self, text: str, content_type: str = "text/plain; charset=utf-8", status: int = 200) -> None:
        self.send_bytes(text.encode("utf-8"), content_type, status)

    def send_json(self, payload: Any, status: int = 200) -> None:
        self.send_text(json.dumps(payload, indent=2, sort_keys=True), "application/json; charset=utf-8", status)

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path in ("/", "/index.html"):
            return self.send_text(MAP_HTML, "text/html; charset=utf-8")
        if path == "/api/map":
            return self.send_json(summarize_map(self.world_dir))
        return self.send_text("Not found", status=404)


def choose_port(preferred: int) -> int:
    for port in [preferred] + list(range(preferred + 1, preferred + 50)):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    return preferred


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the generic HRM Plague-Inc-style world map.")
    parser.add_argument("--world-dir", default=str(choose_world_dir()), help="Directory containing world_state_latest.json")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8787)
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()

    MapHandler.world_dir = Path(args.world_dir)
    port = choose_port(args.port)
    server = ThreadingHTTPServer((args.host, port), MapHandler)
    url = f"http://{args.host}:{port}/"
    print(f"{ENGINE_NAME} v{ENGINE_VERSION}")
    print(f"World directory: {MapHandler.world_dir}")
    print(f"Map URL: {url}")
    print("Press CTRL+C to stop.")
    if not args.no_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping HRM map.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
