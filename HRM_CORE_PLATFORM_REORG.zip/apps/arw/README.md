# ARW App

This is now an app that uses HRM as an engine boundary. Legacy episode files are preserved here. Future work should import `hrm_core` for agent state/affect/memory instead of adding more code to the root HRM package.
