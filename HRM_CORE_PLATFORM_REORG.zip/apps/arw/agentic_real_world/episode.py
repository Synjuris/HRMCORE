"""
episode.py — Episode production engine for Agentic Real World.
"""

import json
import os
import time
from typing import List, Optional
from pathlib import Path

from cast import CastMember


EPISODE_ACTS = [
    {
        "act": "ACT 1 — WAKING UP",
        "beats": [
            {"type": "cold_open", "label": "COLD OPEN", "instruction": "The house. Empty, sealed, fully stocked but windowless. No phones. No internet. No explanation. The camera is cold and clinical — this is not a welcoming place. Buzz drifts through a hallway alone. No narration. No titles. Just the hum of the drone and the sealed doors."},
            {"type": "arrival", "label": "WAKING UP", "instruction": "Seven strangers come to consciousness inside the house. They did not choose to be here. They do not know how they arrived or why. No one is performing — they are genuinely disoriented, frightened, or furious. High dominance agents immediately try to assert control over the confusion. Hypervigilant agents scan for threats before they speak to anyone. The wounded ones go quiet and watch. This is not a game show entrance. This is people realizing something is wrong."},
            {"type": "room_pick", "label": "TAKING STOCK", "instruction": "They find the house: 4 rooms (2 singles, 1 double, 1 triple), a kitchen stocked for exactly 30 days at rationed portions for 7 people — less if anyone wastes, nothing if someone takes more than their share. They also find Buzz — a palm-sized mechanical insect already in the house, already filming. No one knows what it is. Someone tries to catch it. Someone tries to destroy it. The high-dominance agent claims a single room immediately, not asking. The inventory of food creates the first moment of real fear: the math doesn't work if everyone eats freely."},
            {"type": "buzz_intro", "label": "THE NOTE", "instruction": "Buzz lands on the kitchen table. There is a note tucked beneath its thorax. Someone has to take it from the insect. The note is brief, clinical, and offers no comfort: they are here for 30 days. The doors will not open before then. There is enough food for 30 days if they are disciplined. There is one condition for the doors to open at day 30: they must have generated documented external revenue — real money, from outside the house. No other explanation. No sender. No return address. Buzz lifts off immediately after the note is taken, as if its job is done."},
            {"type": "challenge_reveal", "label": "FIRST RECKONING", "instruction": "The note has been read. Now the room fractures. Some people do not believe it — they think this is a prank, a test, something that will be explained. Some believe it immediately and are already calculating. The high-dominance agent tries to take charge of the response. The hypervigilant agent is already suspicious of everyone in the room, not just the situation. Someone asks out loud what everyone is thinking: what happens if they don't make the money. No one answers. Buzz drifts near the ceiling, wings ticking."},
        ],
    },
    {
        "act": "ACT 2 — THE MATH",
        "beats": [
            {"type": "strategy", "label": "FIRST ATTEMPT AT ORDER", "instruction": "Someone tries to run a meeting. It fractures immediately — not because people disagree about the plan, but because they disagree about whether they trust each other enough to have one. Low trust_baseline agents refuse to commit to anything. High dominance agents talk over each other. The economist tries to lay out the actual numbers: 30 days, finite food, one revenue target, seven people who don't know each other. The numbers are clarifying and make everything worse. Someone raises the resource question directly: equal shares, or by contribution?"},
            {"type": "confessional", "label": "ALONE WITH BUZZ", "instruction": "Three agents find themselves alone with Buzz at different moments — in a room, a hallway, the kitchen at night. They don't know what it is or who (if anyone) is watching. But they talk anyway — to it, at it, past it. Not confessionals. Just people thinking out loud because there's nothing else to talk to. What they say reveals what they actually believe about where they are and who they're with. One person is more afraid than they've shown. One person has already made a decision they haven't announced."},
            {"type": "alliance", "label": "FIRST CONTACT", "instruction": "Two people find each other — not a formal alliance, just the first crack of genuine connection or calculated proximity. Could be shared fear, mutual recognition, attraction as a survival mechanism, or one person deciding the other is the most useful. The kind of conversation that happens when everyone else is asleep. Buzz finds them. Neither acknowledges it."},
        ],
    },
    {
        "act": "ACT 3 — PRESSURE",
        "beats": [
            {"type": "work", "label": "BUILDING SOMETHING", "instruction": "They are actually trying to generate revenue from inside a sealed house with no internet and no phone. Whatever they're attempting is constrained, strange, and requires trusting people they don't trust yet. Show the real friction of incompatible people trying to produce something under existential pressure. The resource math is always in the background — someone is eating more than their share, or someone has stopped eating, or someone is hoarding. The thing they're building may or may not work. Real progress exists but it costs something."},
            {"type": "conflict", "label": "THE FRACTURE", "instruction": "Something breaks. Not a misunderstanding — a genuine collision of values, fear, or survival logic. The resource question surfaces as the real fight underneath the surface argument. Someone makes a unilateral decision about food, space, or the plan that others experience as a threat. The hypervigilant agent's read of the room turns out to be right, or catastrophically wrong. Something is said that cannot be unsaid. Buzz is at face level, wings droning, recording all of it."},
            {"type": "confessional", "label": "ALONE AGAIN", "instruction": "Three different agents, alone with Buzz at different moments after the fracture. They are no longer performing composure. One person is genuinely frightened — not of the situation, but of someone in the house. One person has made a calculation about the group they haven't shared. One person is starting to wonder if the doors will actually open at all, and what that means."},
            {"type": "work", "label": "AFTER THE FRACTURE", "instruction": "Work continues under new fault lines. The group is visibly split now. Whatever they're building is progressing despite the damage — or failing because of it. Someone who was quiet makes a move. Buzz appears somewhere it shouldn't be and captures something that changes the valence of the episode — a private moment, an overheard exchange, a face when someone thinks no one is watching."},
        ],
    },
    {
        "act": "ACT 4 — WHAT IT COSTS",
        "beats": [
            {"type": "climax", "label": "CLIMAX", "instruction": "Everything converges. The revenue effort reaches a crisis point — success or failure is imminent. Simultaneously, the resource tension or a personal betrayal forces a confrontation that can't be deferred. The two pressures collide: survival of the group and survival of the self. Someone makes a choice that exposes exactly who they are under genuine pressure. Buzz is frantic — darting between faces, landing where it shouldn't, compound eyes catching the thing no one wanted recorded."},
            {"type": "resolution", "label": "WHAT REMAINS", "instruction": "Day closes. The revenue attempt has a result — partial, failed, or a small real win. The house is changed by what happened. Some relationships are damaged beyond easy repair. Some unexpected solidarity formed in the wreckage. The food inventory is quietly, visibly different from where it started. Something is unresolved that will compound. No one sleeps easily."},
            {"type": "confessional", "label": "LAST LIGHT", "instruction": "All seven agents, one moment each — alone, before sleep. Not performing for anyone. Just a face, a thought, the hum of Buzz somewhere nearby. Some are honest. Some are still lying to themselves. Some have already decided what they're going to do tomorrow that they haven't told anyone. These are the last images before the episode ends. Make them land."},
        ],
    },
]



ESTABLISHED_HOUSE_ACTS = [
    {
        "act": "ACT 1 — ANOTHER DAY",
        "beats": [
            {"type": "cold_open", "label": "COLD OPEN", "instruction": "No reintroductions. Open on the texture of confinement — a detail that shows how much time has passed and what it has done to people. The food inventory has changed. Someone's face has changed. The house looks different when people have been living under pressure in it. Buzz is somewhere in frame, already watching."},
            {"type": "aftermath", "label": "MORNING", "instruction": "The house wakes carrying everything that happened before. Unresolved conflicts are present in how people move around each other — who avoids the kitchen when someone else is in it, who has stopped speaking to whom, what small act of kindness or aggression sets the tone for the day. The resource pressure is constant background noise. Someone checks the food inventory. The number is always smaller than you want it to be."},
            {"type": "house_pressure", "label": "THE WEIGHT OF IT", "instruction": "Confinement is doing something to people. Show what day N looks like in a sealed house — the specific psychological toll on specific characters. High resilience agents are coping better but showing cracks. Low stability agents are fraying visibly. Someone is sleeping too much. Someone isn't sleeping. Someone has developed a ritual. The house itself has become a pressure system."},
            {"type": "new_complication", "label": "NEW PROBLEM", "instruction": "Something concrete goes wrong or changes — a resource discovery, a capability revealed, a relationship shift that forces a new calculation, a sign from outside the house, something Buzz does that raises a new question about what it is and who controls it. The complication must connect to the revenue effort or the resource situation, not exist in isolation."},
        ],
    },
    {
        "act": "ACT 2 — FAULT LINES",
        "beats": [
            {"type": "strategy", "label": "PLANNING UNDER DURESS", "instruction": "They try to coordinate. Existing alliances and resentments shape everything — who listens to whom, who gets cut out, what gets decided in private before the group conversation happens. The economist's numbers are present but not necessarily respected. Someone is working a separate angle they haven't disclosed."},
            {"type": "confessional", "label": "ALONE WITH BUZZ", "instruction": "Three people, alone with Buzz at different points in the day. They've stopped trying to figure out what it is — it's just there, and sometimes people talk to it because silence is worse. What they say reveals the private state of the house: who they're afraid of now, what they've decided, what they're hiding, whether they still believe the doors will open."},
            {"type": "private_move", "label": "WHAT HAPPENS IN PRIVATE", "instruction": "A conversation that isn't for the group. Could be a genuine deepening of trust between two people, a manipulation, a confession, a threat delivered quietly, a deal made or broken. The people who aren't in this conversation don't know it happened. Buzz may or may not be present — and if it is, neither person fully acknowledges it."},
        ],
    },
    {
        "act": "ACT 3 — THE WORK",
        "beats": [
            {"type": "work", "label": "THE EFFORT", "instruction": "Whatever they're building to generate revenue is ongoing, constrained, and complicated by the relationships in the house. Show actual work — the specific problem they're trying to solve, the roles people have taken or been forced into, what progress looks like under these conditions. The resource pressure and the interpersonal damage are always present as friction."},
            {"type": "conflict", "label": "SOMETHING BREAKS", "instruction": "A real confrontation — not a first one, which means it's shaped by everything that's already happened. Old resentments make this worse than it would otherwise be. The resource question or the revenue question is probably underneath the surface argument. Someone does something that will have consequences beyond this episode. Buzz captures it whether anyone wants it to or not."},
            {"type": "confessional", "label": "AFTER", "instruction": "Three people alone after the confrontation. The private state of the house has shifted. Someone is more isolated than before. Someone feels safer. Someone has made a decision. Someone is lying to themselves about what just happened and it shows."},
            {"type": "turning_point", "label": "SOMETHING SHIFTS", "instruction": "A genuine development that changes the shape of what's possible — a real revenue breakthrough, a critical failure, an unexpected act of solidarity, a betrayal that restructures the alliances, something discovered about the house or Buzz that raises new questions. This is not manufactured drama — it is a consequence of everything that came before it."},
        ],
    },
    {
        "act": "ACT 4 — CONSEQUENCES",
        "beats": [
            {"type": "climax", "label": "CLIMAX", "instruction": "The episode's pressure points converge. Something that has been building — in the revenue effort, in a relationship, in the resource situation — reaches a breaking point. The choice someone makes here is the most revealing thing about who they actually are under sustained pressure. Buzz is present, relentless, compound eyes catching what no one wanted caught."},
            {"type": "resolution", "label": "WHAT'S LEFT", "instruction": "The day ends. The situation has changed in ways that are real and carry forward. The revenue effort has a status. The food inventory has a number. Some relationships have moved — toward or away. Something is unresolved in a way that will make the next episode different from this one. The doors are still closed."},
            {"type": "confessional", "label": "LAST LIGHT", "instruction": "All seven, one moment each before sleep. Alone. Not performing. Just the face, the thought, the hum of Buzz. Some are holding on. Some are starting to slip. Some have already decided something for tomorrow that changes everything. No titles. No music cue. Just the house, still sealed, and the drone, still watching."},
        ],
    },
]


def flatten_acts(acts: list) -> list:
    return [
        {**beat, "act": act["act"]}
        for act in acts
        for beat in act["beats"]
    ]


def get_episode_beats(episode_number: int) -> list:
    if int(episode_number) <= 1:
        return flatten_acts(EPISODE_ACTS)
    return flatten_acts(ESTABLISHED_HOUSE_ACTS)


def max_relationship_delta_magnitude(deltas: list) -> float:
    max_mag = 0.0
    for d in deltas or []:
        if not isinstance(d, dict):
            continue
        for key in ("trust", "resentment", "attachment", "avoidance"):
            try:
                max_mag = max(max_mag, abs(float(d.get(key, 0.0))))
            except Exception:
                pass
    return max_mag


def should_highlight_beat(result: dict, beat_type: str) -> bool:
    tension = int(result.get("tension_level", 0) or 0)
    explicit = bool(result.get("highlight", False))
    large_delta = max_relationship_delta_magnitude(
        result.get("relationship_deltas", [])
    ) >= 0.18

    if beat_type == "climax":
        return True

    if beat_type == "conflict" and tension >= 8:
        return True

    if explicit and tension >= 8:
        return True

    if large_delta and tension >= 7:
        return True

    return False


ALL_BEATS = flatten_acts(EPISODE_ACTS)

HIGHLIGHT_BEAT_TYPES = {"conflict", "climax", "buzz_intro"}


def build_system_prompt(cast: List[CastMember], challenge: str) -> str:
    cast_block = "\n".join(m.profile_summary() for m in cast)
    return f"""You are writing a contained, unnarrated drama about seven people who have woken up in a sealed house together with no explanation and no way out. This is not a game show. The people inside do not know they are being observed. They do not know what Buzz is. They are not performing for an audience — they are trying to survive a situation they don't understand.

THE SITUATION:
Seven strangers. A sealed house. Thirty days of rationed food — enough if managed carefully, not enough if anyone is reckless or selfish. The doors will not open until day 30, and only if they have generated documented external revenue. No one explained why. No one is coming. There is only Buzz.

THE SEVEN PEOPLE:
{cast_block}

CRITICAL — BEHAVIOR MUST EMERGE FROM HRM PROFILES:
These are not generic characters. Their psychology is defined above and must drive every decision, reaction, and relationship. Do not flatten them into drama archetypes.
- High dominance does not ask permission and does not explain itself
- Low trust_baseline does not commit, shares nothing freely, watches everyone
- early-wounded means real damage that surfaces under sustained pressure — not backstory, behavior
- hypervigilant means threat-detection is always running, often correctly
- High cooperation wants the group to survive and will sacrifice personal position for it
- High risk_tolerance acts when others freeze — sometimes right, sometimes catastrophically wrong
- High plan_confidence produces a real plan and is genuinely baffled when others won't follow it
The simulation only works if their profiles diverge under pressure. If they all respond the same way, the model has failed.

THE SITUATION PARAMETERS:
- Day counter is implicit — reference it in behavior and environment, not as a title card
- Food inventory is real and finite. Its depletion creates genuine pressure
- Revenue generation is constrained by the house — no internet, no phone, no outside contact except whatever external channel they discover or create
- The doors open at day 30 if the revenue condition is met. What happens if it isn't is unknown
- No one knows who sent the note or why

THE DRONE — BUZZ:
A palm-sized mechanical insect — moth-scale body, segmented thorax, translucent wings that produce a faint dry hum, compound camera eyes. It is always in the house. It does not respond to commands. It has no concept of privacy. It cannot be caught or destroyed — attempts fail without explanation. It delivered the note. No one knows what it is, who controls it, or whether anyone is watching through it. Some people have started talking to it. Some refuse to acknowledge it. BUZZ NEVER SPEAKS. NEVER put Buzz in the dialogue array.

CAMERA: Every beat is 2-3 cuts. HOUSE CAM = fixed production camera (the people inside don't know about these). BUZZ CAM = Buzz's compound-eye POV — fisheye, unstable, too close, sometimes accidentally perfect. Both perspectives are clinical and unnarrated.

TONE: No host. No narrator. No audience. Just people under genuine pressure making decisions that reveal who they are. Profanity, fear, manipulation, attraction, cruelty, solidarity — all of it is on the table because none of it is performed. The darkness here is not entertainment darkness. It is what actually happens when people are trapped together with finite resources and no explanation.

CRITICAL OUTPUT LIMITS:
- Every beat must escalate or reveal something about a specific person
- Prefer 2 cuts. 3 cuts maximum for major scenes only
- Max 2 dialogue lines per cut
- Max 1 sentence per description
- Max 3 solo-with-Buzz moments per beat, except the final beat which may include all 7
- Escape all quotes inside strings
- Do not include literal newlines inside JSON string values
- If space is tight, shorten the scene instead of truncating JSON
- Return ONE compact JSON object only. Keep total response under 2500 characters

RESPOND WITH VALID JSON ONLY — no markdown, no fences, no explanation.

Normal beat format:
{{"cuts":[{{"camera":"HOUSE CAM","label":"Kitchen — Day 4","description":"Scene narrative.","buzz_visible":true,"buzz_behavior":"What Buzz is doing.","dialogue":[{{"agent":"Name","line":"Their line."}}]}},{{"camera":"BUZZ CAM","label":"Close — face","description":"Compound-eye POV.","buzz_visible":false,"buzz_behavior":null,"dialogue":[]}}],"featured_agents":["Name","Name"],"tension_level":6,"highlight":false,"summary":"Clip title max 8 words","relationship_deltas":[{{"from":"Name","to":"Name","trust":0.03,"resentment":0.0,"attachment":0.02,"avoidance":0.0}}]}}

Solo-with-Buzz moment format (replaces confessional):
{{"confessionals":[{{"agent":"Name","line":"What they say or do alone with Buzz — not to a camera, just out loud."}},{{"agent":"Name","line":"Theirs."}}],"featured_agents":["Name"],"tension_level":4,"highlight":false,"summary":"Alone — Names","relationship_deltas":[]}}"""


def extract_json(raw: str) -> dict:
    """Extract and parse the first complete JSON object from model text."""
    raw = (raw or "").strip()

    if raw.startswith("```"):
        raw = raw.split("\n", 1)[1] if "\n" in raw else raw
        if "```" in raw:
            raw = raw.rsplit("```", 1)[0]
        raw = raw.strip()

    start = raw.find("{")
    if start == -1:
        raise ValueError("No JSON object found in API response")

    depth = 0
    in_string = False
    escape = False

    for idx in range(start, len(raw)):
        ch = raw[idx]

        if escape:
            escape = False
            continue

        if ch == "\\" and in_string:
            escape = True
            continue

        if ch == '"':
            in_string = not in_string
            continue

        if in_string:
            continue

        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                candidate = raw[start:idx + 1]
                return json.loads(candidate)

    # Last resort: sometimes the model produces a valid object plus junk,
    # but the brace scanner cannot close because the response was truncated.
    end = raw.rfind("}")
    if end > start:
        return json.loads(raw[start:end + 1])

    raise ValueError("Incomplete JSON object in API response")


def normalize_beat_result(result: dict, beat_type: str) -> dict:
    """Make generated beat JSON safe and predictable before saving/history."""
    if not isinstance(result, dict):
        result = {}

    result.setdefault("featured_agents", [])
    result.setdefault("tension_level", 0)
    result.setdefault("highlight", False)
    result.setdefault("summary", "Untitled beat")
    result.setdefault("relationship_deltas", [])

    try:
        result["tension_level"] = int(result.get("tension_level", 0))
    except Exception:
        result["tension_level"] = 0

    result["tension_level"] = max(0, min(10, result["tension_level"]))
    result["highlight"] = bool(result.get("highlight", False))

    if not isinstance(result.get("featured_agents"), list):
        result["featured_agents"] = []
    if not isinstance(result.get("relationship_deltas"), list):
        result["relationship_deltas"] = []

    if beat_type == "confessional":
        confs = result.get("confessionals", [])
        result["confessionals"] = confs if isinstance(confs, list) else []
        result.pop("cuts", None)
    else:
        cuts = result.get("cuts", [])
        result["cuts"] = cuts if isinstance(cuts, list) else []
        result.pop("confessionals", None)

    return result


def compact_history_result(result: dict) -> dict:
    """Keep only continuity signal. Do not feed full scene JSON back into Claude."""
    return {
        "summary": str(result.get("summary", ""))[:160],
        "featured_agents": result.get("featured_agents", [])[:4]
        if isinstance(result.get("featured_agents"), list) else [],
        "tension_level": result.get("tension_level", 0),
        "relationship_deltas": result.get("relationship_deltas", [])[:4]
        if isinstance(result.get("relationship_deltas"), list) else [],
    }


def call_api(system: str, messages: list, api_key: str,
             max_tokens: int = 2500, retries: int = 3) -> dict:
    """Call Anthropic API and robustly parse compact JSON output."""
    url = "https://api.anthropic.com/v1/messages"
    headers = {
        "Content-Type": "application/json",
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
    }
    body = {
        "model": "claude-sonnet-4-5",
        "max_tokens": max_tokens,
        "system": system,
        "messages": messages,
    }

    last_err = None
    for attempt in range(retries + 1):
        try:
            try:
                import requests
                r = requests.post(url, headers=headers, json=body, timeout=120)
                if r.status_code != 200:
                    print(f"  [API] HTTP {r.status_code}: {r.text[:400]}")
                    raise Exception(f"HTTP {r.status_code}: {r.text[:200]}")
                data = r.json()
            except ImportError:
                import urllib.request
                payload = json.dumps(body).encode("utf-8")
                req = urllib.request.Request(url, data=payload,
                                             headers=headers, method="POST")
                with urllib.request.urlopen(req, timeout=120) as resp:
                    data = json.loads(resp.read().decode("utf-8"))

            stop_reason = data.get("stop_reason")
            raw = "".join(
                block.get("text", "") for block in data.get("content", [])
            ).strip()

            if stop_reason == "max_tokens":
                raise ValueError("API response hit max_tokens before finishing JSON")

            return extract_json(raw)

        except Exception as e:
            last_err = e
            if attempt < retries:
                print(f"  [API] Attempt {attempt + 1} failed: {e} — retrying...")
                wait = 15 if "529" in str(e) or "overload" in str(e).lower() else 4
                time.sleep(wait)
            else:
                raise last_err

def apply_deltas(cast: List[CastMember], deltas: list):
    id_map = {m.name: m for m in cast}
    for d in (deltas or []):
        actor = id_map.get(d.get("from"))
        target = id_map.get(d.get("to"))
        if not actor or not target:
            continue
        actor.apply_relationship_delta(
            other_id=target.id,
            trust_delta=float(d.get("trust", 0)),
            resentment_delta=float(d.get("resentment", 0)),
            attachment_delta=float(d.get("attachment", 0)),
            avoidance_delta=float(d.get("avoidance", 0)),
            influence_delta=float(d.get("influence", 0)),
        )
        target.apply_relationship_delta(
            other_id=actor.id,
            trust_delta=float(d.get("trust", 0)) * 0.5,
            resentment_delta=float(d.get("resentment", 0)) * 0.5,
            attachment_delta=float(d.get("attachment", 0)),
            avoidance_delta=float(d.get("avoidance", 0)),
            influence_delta=float(d.get("influence", 0)) * 0.5,
        )


def produce_episode(cast: List[CastMember], challenge: str, api_key: str,
                    episode_number: int = 1,
                    output_dir: Optional[Path] = None) -> dict:
    system_prompt = build_system_prompt(cast, challenge)
    history = []
    beats = []
    highlights = []

    print(f"\n[ARW] === EPISODE {episode_number} ===")
    print(f"[ARW] Challenge: {challenge}\n")

    episode_beats = get_episode_beats(episode_number)

    for i, beat_def in enumerate(episode_beats):
        label = beat_def["label"]
        act = beat_def["act"]
        print(f"[ARW] {act} . {label} ({i + 1}/{len(episode_beats)})...")

        messages = history + [
            {
                "role": "user",
                "content": (
                    f"Episode number: {episode_number}\n"
                    f"Produce this beat: {label}\n\n"
                    f"Director's note: {beat_def['instruction']}\n\n"
                    "Continuity rule: if episode_number > 1, do not re-establish the house, re-explain the note, or treat characters as strangers. They have history. Use it."
                ),
            }
        ]

        try:
            result = call_api(system_prompt, messages, api_key)
            result = normalize_beat_result(result, beat_def["type"])
        except Exception as e:
            print(f"  [ARW] Beat failed: {e}")
            result = {
                "cuts": [{"camera": "HOUSE CAM", "label": "—",
                          "description": f"[Production error: {e}]",
                          "buzz_visible": False, "buzz_behavior": None, "dialogue": []}],
                "featured_agents": [], "tension_level": 0,
                "highlight": False, "summary": f"{label} — error",
                "relationship_deltas": [],
            }

        apply_deltas(cast, result.get("relationship_deltas", []))

        beat = {"type": beat_def["type"], "label": label, "act": act, **result}
        beats.append(beat)

        is_highlight = should_highlight_beat(result, beat_def["type"])
        if is_highlight:
            highlights.append(beat)

        history.append({"role": "user", "content": f"Beat {i + 1}: {label}"})
        history.append({"role": "assistant", "content": json.dumps(compact_history_result(result))})

        # Keep only the last 6 messages / 3 prior beats. Full episode JSON
        # history made late-episode calls huge and caused malformed JSON.
        history = history[-6:]

        time.sleep(0.5)

    episode = {
        "episode": episode_number,
        "challenge": challenge,
        "beats": beats,
        "highlights": highlights,
        "highlight_count": len(highlights),
    }

    if output_dir:
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        ep_file = output_dir / f"episode_{episode_number:02d}_full.json"
        ep_file.write_text(json.dumps(episode, indent=2, default=str), encoding="utf-8")
        print(f"\n[ARW] Episode written to {ep_file.name}")

    print(f"\n[ARW] Episode {episode_number} complete.")
    print(f"[ARW] {len(beats)} beats . {len(highlights)} highlight clips")

    return episode