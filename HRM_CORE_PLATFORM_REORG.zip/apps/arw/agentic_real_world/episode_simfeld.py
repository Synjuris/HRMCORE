"""
episode_simfeld.py — ARW Simfeld mode.

This is NOT a separate engine. It uses ARW cast state, relationship deltas,
continuity, BUZZ-style observation, and episode persistence. The only change is
the environment: ordinary NYC apartment life with no season challenge.
"""

import json
import time
from pathlib import Path
from typing import List, Optional

from cast import CastMember
from episode import (
    apply_deltas,
    call_api,
    compact_history_result,
    max_relationship_delta_magnitude,
    normalize_beat_result,
)

SIMFELD_PREMISE = (
    "NYC apartment life inside The Hawthorne: an aging walk-up/elevator building "
    "with a lobby, hallway, laundry room, roof, package shelf, nearby diner, bodega, "
    "subway entrance, and small recurring annoyances. No competition. No prize. No apocalypse."
)

SIMFELD_BEATS_EP1 = [
    {"act": "ACT 1 — ORDINARY PRESSURE", "type": "cold_open", "label": "COLD OPEN", "instruction": "Open on a tiny inconvenience already underway in The Hawthorne. Do not explain the series. Do not introduce everyone. Let two or three residents reveal themselves through how they handle a small apartment-building problem."},
    {"act": "ACT 1 — ORDINARY PRESSURE", "type": "hallway", "label": "HALLWAY FRICTION", "instruction": "A hallway, elevator, package shelf, trash room, or stairwell issue forces residents into contact. The conflict should be low-stakes but personally irritating."},
    {"act": "ACT 1 — ORDINARY PRESSURE", "type": "diner", "label": "DINER TABLE", "instruction": "A few residents gather at the diner. Conversation should drift, get petty, misread motives, or turn a minor detail into a social problem."},
    {"act": "ACT 2 — ROUTINE COLLISION", "type": "laundry", "label": "LAUNDRY ROOM", "instruction": "The laundry room exposes territory, patience, timing, and unspoken rules. Nobody is saving the world. They are reacting to inconvenience."},
    {"act": "ACT 2 — ROUTINE COLLISION", "type": "buzzesque", "label": "UNEXPLAINED SOUND", "instruction": "A sitcom-like environmental response occurs once: a laugh track, applause, rimshot, or canned audience reaction. Do not assign it to BUZZ. Do not explain its source. The residents do not know why it happened. Their reactions should be personality-specific."},
    {"act": "ACT 2 — ROUTINE COLLISION", "type": "private", "label": "PRIVATE MOMENT", "instruction": "Show one or two residents alone or nearly alone with an object, routine, habit, worry, or small attachment. The point is not plot. The point is persistence of personhood."},
    {"act": "ACT 3 — SOCIAL AFTERTASTE", "type": "bodega", "label": "BODEGA / STOOP", "instruction": "A casual outside-building encounter at the bodega, stoop, sidewalk, or subway entrance changes how one resident thinks about another by a small amount."},
    {"act": "ACT 3 — SOCIAL AFTERTASTE", "type": "tag", "label": "TAG", "instruction": "End with a small callback, habit, misunderstanding, or repeated object from earlier in the episode. No grand resolution. Life continues."},
]

SIMFELD_BEATS_LATER = [
    {"act": "ACT 1 — TODAY'S ANNOYANCE", "type": "cold_open", "label": "COLD OPEN", "instruction": "Open on an established routine or recurring irritation from prior history. Do not reintroduce the building. Assume these people have lived near each other for a while."},
    {"act": "ACT 1 — TODAY'S ANNOYANCE", "type": "building", "label": "BUILDING PROBLEM", "instruction": "Use a mundane apartment-life problem: package confusion, elevator delay, hallway noise, laundry timing, rent rumor, bodega misunderstanding, roof access, thermostat dispute, borrowed object, neighbor smell, or a strange sound."},
    {"act": "ACT 2 — PEOPLE BEING PEOPLE", "type": "conversation", "label": "CONVERSATION THAT SHOULD HAVE ENDED", "instruction": "A conversation continues past the point where a normal person would have ended it. Let anxiety, dominance, curiosity, politeness, avoidance, or irritation drive the continuation."},
    {"act": "ACT 2 — PEOPLE BEING PEOPLE", "type": "buzzesque", "label": "BUZZESQUE INTERRUPTION", "instruction": "Add one weird environmental interruption if useful: laugh track, applause, buzzing fluorescent light, unexplained PA tone, distant canned gasp. Do not explain it. Do not make it the plot unless a resident fixates on it."},
    {"act": "ACT 2 — PEOPLE BEING PEOPLE", "type": "object", "label": "OBJECT / HABIT", "instruction": "A small object, routine, kept receipt, tool, mug, plant, chair, package, or repeated habit carries social meaning. Let it matter because a resident cares, not because the plot needs it."},
    {"act": "ACT 3 — AFTERTASTE", "type": "shift", "label": "SMALL SHIFT", "instruction": "One relationship changes slightly. Not a dramatic reversal. A new annoyance, attachment, suspicion, favor, debt, or inside joke forms."},
    {"act": "ACT 3 — AFTERTASTE", "type": "tag", "label": "TAG", "instruction": "Close on a tiny callback, unresolved annoyance, or recognizable pattern. The episode should feel like life continues tomorrow."},
]


def get_simfeld_beats(episode_number: int) -> list:
    return SIMFELD_BEATS_EP1 if episode_number == 1 else SIMFELD_BEATS_LATER


# ── The mushroom episode ─────────────────────────────────────────────────────
# Extended arc: offer → onset → peak → comedown → morning after. The substance
# is OFFERED to the room; the renderer reports who actually ingests via an
# "ingested" array. Nobody is dosed by authorial fiat — uptake must fall out of
# each resident's nature. Phases drive how the loop handles decay and modifiers.
SIMFELD_BEATS_TRIP = [
    {"act": "ACT 1 — AN OFFER", "type": "cold_open", "phase": "sober", "label": "THE BAG", "instruction": "A resident produces a bag of mushrooms — found, gifted, or bought, in keeping with who they are — and the bag becomes available to whoever is around. Do NOT decide who takes them. Show the offer and let residents react in character: curiosity, refusal, suspicion, indifference, documentation. Report who actually ingests in the 'ingested' array."},
    {"act": "ACT 1 — AN OFFER", "type": "building", "phase": "sober", "label": "THE HOLDOUTS", "instruction": "Show the residents who declined being themselves about declining. Refusal is character. Someone may ingest accidentally or change their mind — if so, add them to 'ingested'. Keep it grounded and low-stakes."},
    {"act": "ACT 2 — ONSET", "type": "conversation", "phase": "onset", "label": "SOMETHING IS HAPPENING", "instruction": "For anyone with ACTIVE_EFFECT, early onset: heightened openness, curiosity, a loosening. They act slightly unlike their normal selves. Sober residents notice or don't. No grand visuals — apartment-life onset."},
    {"act": "ACT 2 — PEAK", "type": "buzzesque", "phase": "peak", "label": "THE BUILDING LAUGHS", "instruction": "The unexplained environmental oddity (laugh track / applause / canned gasp) fires during the peak. To affected residents it lands enormously — profound or unbearable. To sober residents it means nothing. Maximize the gap between affected and unaffected reactions. Do not explain the sound."},
    {"act": "ACT 2 — PEAK", "type": "private", "phase": "peak", "label": "PEAK", "instruction": "An affected resident has a small, specific, in-character peak moment with an object, a plant, a mirror, a hallway. Valence is untethered from events. A sober resident may be reluctantly minding them."},
    {"act": "ACT 3 — COMEDOWN", "type": "shift", "phase": "comedown", "label": "COMING DOWN", "instruction": "Effects fade. The affected residents return toward themselves, a little altered, a little tender or rattled. A small relationship shift forms between those who went through it together."},
    {"act": "ACT 3 — COMEDOWN", "type": "tag", "phase": "comedown", "label": "THE MORNING AFTER", "instruction": "Next morning. Whoever tripped now shares a referent — an inside joke — that means nothing to anyone who wasn't there. Report it in the 'inside_joke' field as a short phrase. Someone sober (or just-returned) is permanently outside it. Life continues."},
]


# Episode 99 is reserved as the trip special; callers pass episode_number=99.
TRIP_EPISODE_NUMBER = 99


def get_simfeld_beats(episode_number: int) -> list:  # noqa: F811
    if episode_number == TRIP_EPISODE_NUMBER:
        return SIMFELD_BEATS_TRIP
    return SIMFELD_BEATS_EP1 if episode_number == 1 else SIMFELD_BEATS_LATER


def should_highlight_beat(result: dict, beat_type: str) -> bool:
    tension = int(result.get("tension_level", 0) or 0)
    explicit = bool(result.get("highlight", False))
    large_delta = max_relationship_delta_magnitude(result.get("relationship_deltas", [])) >= 0.14
    if beat_type in {"buzzesque", "tag"} and explicit:
        return True
    if tension >= 7 and (explicit or large_delta):
        return True
    return False


def build_system_prompt(cast: List[CastMember], premise: str) -> str:
    cast_block = "\n".join(m.profile_summary() for m in cast)
    return f"""You are producing ARW SIMFELD MODE: an unnarrated observational episode about ordinary NYC apartment life. This is not a sitcom imitation. Do not reference or emulate any real show or character. The residents do not know they are in a show. They only know their lives.

THE ENVIRONMENT:
{premise}

THE RESIDENTS:
{cast_block}

CRITICAL — NO CHARACTER EMULATION:
- Do not write anyone as a known sitcom character.
- Do not use archetype names as behavior instructions.
- Behavior must emerge from the HRM-style state/trait values, identity tags, prior relationship history, routines, objects, and current friction.
- The point is whether personality appears under low-stakes ordinary pressure.

THE TEST:
No season challenge. No artificial plot. No life-or-death stakes. The episode should reveal whether these residents become recognizable through repeated choices, habits, attachments, grudges, avoidance patterns, jokes, rituals, and small social debts.

BUZZ / CAMERA RULE:
Observation may include fixed building cameras and occasional BUZZ CAM, but BUZZ is not the cause of every weird thing. BUZZ NEVER SPEAKS. NEVER put Buzz in the dialogue array.

BUZZESQUE ENVIRONMENTAL ODDITY:
Rarely, the environment may produce a sitcom-like response such as a laugh track, applause, rimshot, canned gasp, or other unexplained audience-like sound. Do not explain where it comes from. Do not assign it to BUZZ. Residents may notice, ignore, resent, deny, investigate, or normalize it according to personality.

TONE:
Show about nothing, but not empty. The stakes are annoyance, embarrassment, timing, territory, boredom, habit, routine, privacy, status, and being known by neighbors against your will. Keep it grounded.

CRITICAL OUTPUT LIMITS:
- Every beat must reveal a specific person, relationship, habit, or persistent object.
- Prefer 2 cuts. 3 cuts maximum.
- Max 2 dialogue lines per cut.
- Max 1 sentence per description.
- No narrator. No titles inside the scene.
- Escape quotes inside strings.
- Do not include literal newlines inside JSON string values.
- Return ONE compact JSON object only under 2500 characters.

RESPOND WITH VALID JSON ONLY — no markdown, no fences, no explanation.

RELATIONSHIP DELTA FIELDS (small values, -0.15..0.15):
- trust: did the actor become more/less reliable in the target's eyes
- resentment: did the actor irritate, slight, or impose on the target
- attachment: did a small bond, fondness, or shared-habit form
- avoidance: does the target now want less contact with the actor
- influence: did the actor's opinion, system, or framing start steering the target's behavior (use sparingly; this is sway, not affection)

OPTIONAL TRIP FIELDS (only in the mushroom episode; omit otherwise):
- ingested: array of resident names who actually ate the mushrooms this beat. Decide from character, not instruction. Most residents will decline. Accidental ingestion is allowed.
- inside_joke: a short phrase (a referent, a thing one of them said, an image) born from the shared experience, reported only at the morning-after beat.

Normal beat format:
{{"cuts":[{{"camera":"BUILDING CAM","label":"Hallway — 8:12 PM","description":"Scene narrative.","buzz_visible":false,"buzz_behavior":null,"dialogue":[{{"agent":"Name","line":"Their line."}}]}},{{"camera":"BUZZ CAM","label":"Close — package shelf","description":"Observed detail.","buzz_visible":false,"buzz_behavior":null,"dialogue":[]}}],"featured_agents":["Name","Name"],"tension_level":3,"highlight":false,"summary":"Clip title max 8 words","relationship_deltas":[{{"from":"Name","to":"Name","trust":0.02,"resentment":0.01,"attachment":0.0,"avoidance":0.0,"influence":0.0}}]}}

Private moment format may use same cuts format with little or no dialogue."""


def produce_episode(cast: List[CastMember], premise: str, api_key: str,
                    episode_number: int = 1,
                    output_dir: Optional[Path] = None) -> dict:
    system_prompt = build_system_prompt(cast, premise)
    history = []
    beats = []
    highlights = []

    print(f"\n[ARW-SIMFELD] === EPISODE {episode_number} ===")
    print(f"[ARW-SIMFELD] Premise: {premise}\n")

    episode_beats = get_simfeld_beats(episode_number)

    # Edge decay runs once per episode (a slower timescale than per-beat mood
    # decay). Skip episode 1 — nothing has accumulated yet. This keeps a long
    # season from saturating every relationship at 0 or 1 without erasing history.
    if episode_number > 1:
        for m in cast:
            m.decay_relationships()

    for i, beat_def in enumerate(episode_beats):
        label = beat_def["label"]
        act = beat_def["act"]
        print(f"[ARW-SIMFELD] {act} . {label} ({i + 1}/{len(episode_beats)})...")

        messages = history + [{
            "role": "user",
            "content": (
                f"Episode number: {episode_number}\n"
                f"Produce this beat: {label}\n\n"
                f"Director's note: {beat_def['instruction']}\n\n"
                "Continuity rule: if episode_number > 1, use prior relationship/history signals. Do not reset residents. Do not make them strangers."
            ),
        }]

        try:
            result = call_api(system_prompt, messages, api_key)
            result = normalize_beat_result(result, beat_def["type"])
        except Exception as e:
            print(f"  [ARW-SIMFELD] Beat failed: {e}")
            result = {
                "cuts": [{"camera": "BUILDING CAM", "label": "—",
                          "description": f"[Production error: {e}]",
                          "buzz_visible": False, "buzz_behavior": None, "dialogue": []}],
                "featured_agents": [], "tension_level": 0,
                "highlight": False, "summary": f"{label} — error",
                "relationship_deltas": [],
            }

        apply_deltas(cast, result.get("relationship_deltas", []))

        phase = beat_def.get("phase")
        id_map = {m.name: m for m in cast}

        # Ingestion: whoever the renderer reports as eating the mushrooms gets
        # the modifier. Not assigned from outside — uptake came from the scene.
        for who in (result.get("ingested") or []):
            m = id_map.get(who)
            if m and not m.has_modifier("mushrooms"):
                m.apply_modifier("mushrooms", beats=4, intensity=0.9)
                print(f"  [ARW-SIMFELD] {who} ingested — trip begins.")

        # Advance any active trips one beat.
        if phase in ("onset", "peak", "comedown"):
            for m in cast:
                m.tick_modifiers()

        # Phase-aware homeostasis: during the peak, suspend baseline decay so
        # nobody snaps back mid-trip. Elsewhere (and for sober residents) decay
        # runs normally.
        for m in cast:
            if phase == "peak" and m.has_modifier("mushrooms"):
                continue
            m.decay_toward_baseline()

        # Mint the inside joke at comedown and give it only to those who tripped
        # together (and recently — anyone who still has, or just had, the trip).
        joke = result.get("inside_joke")
        if joke and phase == "comedown":
            trippers = [m for m in cast if m.has_modifier("mushrooms")
                        or any(j == joke for j in m.shared_jokes)]
            # if none currently flagged, fall back to featured agents of this beat
            if not trippers:
                trippers = [id_map[a] for a in result.get("featured_agents", []) if a in id_map]
            for m in trippers:
                m.add_shared_joke(joke)
            if trippers:
                print(f"  [ARW-SIMFELD] Inside joke minted for {[m.name for m in trippers]}: '{joke}'")

        beat = {"type": beat_def["type"], "label": label, "act": act, **result}
        beats.append(beat)

        if should_highlight_beat(result, beat_def["type"]):
            highlights.append(beat)

        history.append({"role": "user", "content": f"Beat {i + 1}: {label}"})
        history.append({"role": "assistant", "content": json.dumps(compact_history_result(result))})
        history = history[-6:]
        time.sleep(0.5)

    episode = {
        "mode": "simfeld",
        "episode": episode_number,
        "premise": premise,
        "beats": beats,
        "highlights": highlights,
        "highlight_count": len(highlights),
    }

    if output_dir:
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        ep_file = output_dir / f"episode_{episode_number:02d}_full.json"
        ep_file.write_text(json.dumps(episode, indent=2, default=str), encoding="utf-8")
        print(f"\n[ARW-SIMFELD] Episode written to {ep_file.name}")

    print(f"\n[ARW-SIMFELD] Episode {episode_number} complete.")
    print(f"[ARW-SIMFELD] {len(beats)} beats . {len(highlights)} highlight clips")
    return episode
