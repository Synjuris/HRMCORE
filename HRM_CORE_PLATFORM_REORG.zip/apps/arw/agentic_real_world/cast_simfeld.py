"""
cast_simfeld.py — compatibility wrapper.

The original real-world cast has been removed. Simfeld now uses the default
cast from cast.py.
"""

from typing import List
from cast import CastMember, build_season_1_cast


def build_simfeld_cast() -> List[CastMember]:
    return build_season_1_cast()
