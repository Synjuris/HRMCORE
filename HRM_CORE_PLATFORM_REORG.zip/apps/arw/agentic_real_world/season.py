"""
season.py — minimal utility functions retained for Simfeld.
"""

from typing import List


def print_relationship_matrix(cast: List):
    names = [m.name for m in cast]
    print("\n[SIMFELD] RELATIONSHIP MATRIX")
    print(f"{'':10s}", end="")
    for n in names:
        print(f"{n:>12s}", end="")
    print()
    for m in cast:
        print(f"{m.name:<10s}", end="")
        for other in cast:
            if other.id == m.id:
                print(f"{'—':>12s}", end="")
            else:
                r = m.relationships.get(other.id)
                if r and r["interactions"] > 0:
                    val = f"T{r['trust']:.1f}/R{r['resentment']:.1f}"
                else:
                    val = "."
                print(f"{val:>12s}", end="")
        print()
    print()
