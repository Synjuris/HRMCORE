"""
cast.py — Agentic Real World Season 1 cast definitions.

Seven agents with fixed, hardcoded HRM trait profiles.
These are NOT randomly generated. Their personalities are permanent.
They do NOT enter the general HRM population.

Each cast member is defined by:
  - AgentState:          their live psychological state (mutable per episode)
  - DevelopmentalTraits: their stable personality parameters (mostly fixed)
  - identity_tags:       consolidation stamps from their backstory
  - show_role:           their narrative archetype for the episode engine
  - color:               UI/display color for camera rendering
"""

from dataclasses import dataclass, field, asdict
from typing import List, Dict


# ── Cast member definition ────────────────────────────────────────────────────

@dataclass
class CastState:
    """Mutable per-episode psychological state. Mirrors AgentState fields."""
    energy: float = 0.70
    stress: float = 0.20
    curiosity: float = 0.50
    fear: float = 0.20
    cooperation: float = 0.50
    dominance: float = 0.50
    stability: float = 0.60
    social_openness: float = 0.50
    valence: float = 0.00
    plan_confidence: float = 0.50
    goal_satisfaction: float = 0.50
    status_security: float = 0.50


@dataclass
class CastTraits:
    """Stable personality parameters. Fixed at cast initialization."""
    trust_baseline: float = 0.50
    conflict_sensitivity: float = 0.50
    risk_tolerance: float = 0.50
    resilience: float = 0.50
    attachment_rate: float = 0.05
    avoidance_rate: float = 0.05
    role: str = "generalist"
    ideology_sensitivity: float = 0.50


@dataclass
class CastMember:
    id: str
    name: str
    show_role: str           # narrative archetype title
    color: str               # hex, for display
    emoji: str
    state: CastState
    traits: CastTraits
    identity_tags: List[str] = field(default_factory=list)
    # Relationship book: keyed by other cast member id -> RelationshipState dict
    relationships: Dict[str, dict] = field(default_factory=dict)
    # Homeostatic anchor: the core affective state the member decays back toward.
    # Captured once from the initial state so live state can drift and recover
    # instead of ratcheting in one direction forever.
    baseline: Dict[str, float] = field(default_factory=dict)
    # Active temporary modifiers (e.g. a psychedelic): each suspends normal
    # trait-gating and perturbs state for a bounded number of beats, then clears.
    modifiers: List[dict] = field(default_factory=list)
    # Shared referents minted by group experiences — the inside jokes that
    # survive into later episodes and mean nothing to whoever wasn't there.
    shared_jokes: List[str] = field(default_factory=list)

    def __post_init__(self):
        if not self.baseline:
            self.baseline = {
                "energy": self.state.energy,
                "stress": self.state.stress,
                "curiosity": self.state.curiosity,
                "fear": self.state.fear,
                "valence": self.state.valence,
                "social_openness": self.state.social_openness,
                "status_security": self.state.status_security,
                "goal_satisfaction": self.state.goal_satisfaction,
            }

    def relationship_with(self, other_id: str) -> dict:
        """Return relationship state with another cast member, initializing if absent."""
        if other_id not in self.relationships:
            self.relationships[other_id] = {
                "trust": 0.50,
                "resentment": 0.00,
                "attachment": 0.00,
                "influence": 0.00,
                "avoidance": 0.00,
                "interactions": 0,
                "allied": False,
            }
        return self.relationships[other_id]

    def apply_relationship_delta(self, other_id: str,
                                  trust_delta: float = 0.0,
                                  resentment_delta: float = 0.0,
                                  attachment_delta: float = 0.0,
                                  avoidance_delta: float = 0.0,
                                  influence_delta: float = 0.0):
        """Trait-modulated, state-coupled relationship mutation.

        The raw deltas reported by the renderer are gains; how much of each
        gain actually lands depends on this member's stable traits. The same
        event then bleeds into core affect (stress / valence / etc.), so a
        tense beat does not just change a number on an edge — it changes how
        this person walks into the next beat.
        """
        def clamp(x, lo=0.0, hi=1.0): return max(lo, min(hi, x))

        t = self.traits
        # While a psychedelic modifier is active, trait-gating loosens toward
        # 1.0 (neutral) — the member reacts unlike their normal self.
        g = self.gating_factor()
        def lerp_to_one(x): return 1.0 + (x - 1.0) * g
        # Trait gates: conflict-sensitive people absorb resentment faster;
        # resilient people absorb it slower. Attachment/avoidance scale by the
        # member's own attachment/avoidance rates. All gated by g.
        cs = lerp_to_one(0.5 + t.conflict_sensitivity)     # ->1.0 when tripping
        res_damp = lerp_to_one(1.0 - 0.5 * t.resilience)
        trust_gain = trust_delta * lerp_to_one(0.5 + t.trust_baseline) * res_damp
        resent_gain = resentment_delta * cs * res_damp
        attach_gain = attachment_delta * lerp_to_one(0.5 + 10.0 * t.attachment_rate)
        avoid_gain = avoidance_delta * lerp_to_one(0.5 + 10.0 * t.avoidance_rate)

        r = self.relationship_with(other_id)
        r["trust"]      = clamp(r["trust"]      + trust_gain)
        r["resentment"] = clamp(r["resentment"] + resent_gain)
        r["attachment"] = clamp(r["attachment"] + attach_gain)
        r["avoidance"]  = clamp(r["avoidance"]  + avoid_gain)
        r["influence"]  = clamp(r["influence"]  + influence_delta)
        r["interactions"] += 1
        r["allied"] = (r["trust"] >= 0.62 and
                       r["resentment"] <= 0.25 and
                       r["attachment"] >= 0.10)

        # ── State coupling: the edge event perturbs core affect ──────────────
        s = self.state
        # Conflict raises stress and pulls valence down; warmth does the reverse.
        s.stress  = clamp(s.stress  + resent_gain * 0.6 + avoid_gain * 0.3
                                    - trust_gain * 0.2)
        s.valence = clamp(s.valence + trust_gain * 0.4 + attach_gain * 0.5
                                    - resent_gain * 0.5, lo=-1.0, hi=1.0)
        s.fear    = clamp(s.fear    + avoid_gain * 0.4 + resent_gain * 0.2
                                    - trust_gain * 0.15)
        s.social_openness = clamp(s.social_openness + trust_gain * 0.3
                                                     - avoid_gain * 0.4)
        s.status_security = clamp(s.status_security + influence_delta * 0.3
                                                     - resent_gain * 0.2)

    def decay_toward_baseline(self, rate: float = 0.10):
        """Homeostasis: pull volatile core dims back toward the member's anchor.

        Resilient members recover faster. Without this the coupled state would
        ratchet and the cast would flatten into uniform extremes over a season.
        Relationship edges are NOT decayed — history persists; mood does not.
        """
        if not self.baseline:
            return
        s = self.state
        eff = rate * (0.6 + 0.8 * self.traits.resilience)  # resilience speeds recovery
        for dim, anchor in self.baseline.items():
            cur = getattr(s, dim, None)
            if cur is None:
                continue
            setattr(s, dim, cur + (anchor - cur) * eff)

    def decay_relationships(self, rate: float = 0.03):
        """Slow edge decay — prevents long-season saturation without erasing history.

        Much gentler than mood decay: relationships are supposed to persist.
        This only keeps a long run from pinning every edge at 0 or 1.

        Asymmetric anchors, because people forget differently:
          - trust drifts toward neutral acquaintance (0.50), not zero
          - resentment / avoidance / influence fade toward 0 (no contact, no grudge, no sway)
          - attachment decays at a fraction of the rate (bonds are stickier than slights)
        Only edges with real history decay. interactions / allied are untouched here.
        """
        for r in self.relationships.values():
            if r.get("interactions", 0) <= 0:
                continue
            r["trust"]      += (0.50 - r["trust"]) * rate
            r["resentment"] += (0.0  - r["resentment"]) * rate
            r["avoidance"]  += (0.0  - r["avoidance"]) * rate
            r["influence"]  += (0.0  - r["influence"]) * rate
            r["attachment"] += (0.0  - r["attachment"]) * (rate * 0.3)
            r["allied"] = (r["trust"] >= 0.62 and
                           r["resentment"] <= 0.25 and
                           r["attachment"] >= 0.10)

    # ── Temporary modifiers (psychedelics, etc.) ─────────────────────────────
    def apply_modifier(self, name: str, beats: int = 4,
                       intensity: float = 1.0):
        """Apply a timed perturbation. Onset is immediate but small; the loop's
        tick_modifiers ramps and clears it. A psychedelic spikes openness and
        curiosity, decouples valence from events, and (via gating_factor below)
        suspends the trait gates so the member acts unlike themselves.

        Nobody is assigned this from outside their nature — the engine offers a
        substance to the room and applies the modifier only to whoever the
        renderer reports actually ingested it.
        """
        self.modifiers.append({
            "name": name,
            "remaining": int(beats),
            "total": int(beats),
            "intensity": float(intensity),
        })
        s = self.state
        def clamp(x, lo=0.0, hi=1.0): return max(lo, min(hi, x))
        s.social_openness = clamp(s.social_openness + 0.15 * intensity)
        s.curiosity = clamp(s.curiosity + 0.15 * intensity)

    def has_modifier(self, name: str) -> bool:
        return any(m["name"] == name and m["remaining"] > 0 for m in self.modifiers)

    def gating_factor(self) -> float:
        """1.0 = normal trait-gating. Toward 0 = gates suspended (acts unlike
        self). Driven by the strongest active psychedelic-type modifier."""
        active = [m for m in self.modifiers if m["remaining"] > 0
                  and m["name"] in ("mushrooms", "psychedelic")]
        if not active:
            return 1.0
        peak = max(m["intensity"] * (m["remaining"] / max(1, m["total"])) for m in active)
        return max(0.15, 1.0 - 0.85 * peak)

    def tick_modifiers(self):
        """Advance modifiers one beat. While active, valence floats free of
        events (a small random-ish drift you can read as euphoria/dread). On
        expiry the modifier clears and normal baseline decay resumes elsewhere.
        Returns the list of names that just expired this tick.
        """
        expired = []
        def clamp(x, lo=0.0, hi=1.0): return max(lo, min(hi, x))
        for m in self.modifiers:
            if m["remaining"] <= 0:
                continue
            if m["name"] in ("mushrooms", "psychedelic"):
                # valence untethered from what's actually happening
                phase = m["remaining"] / max(1, m["total"])
                drift = (0.10 if phase > 0.5 else -0.06) * m["intensity"]
                self.state.valence = clamp(self.state.valence + drift, lo=-1.0, hi=1.0)
            m["remaining"] -= 1
            if m["remaining"] <= 0:
                expired.append(m["name"])
        self.modifiers = [m for m in self.modifiers if m["remaining"] > 0]
        return expired

    def add_shared_joke(self, joke: str):
        if joke and joke not in self.shared_jokes:
            self.shared_jokes.append(joke)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "show_role": self.show_role,
            "color": self.color,
            "emoji": self.emoji,
            "state": asdict(self.state),
            "traits": asdict(self.traits),
            "identity_tags": self.identity_tags,
            "relationships": self.relationships,
            "baseline": self.baseline,
            "modifiers": self.modifiers,
            "shared_jokes": self.shared_jokes,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "CastMember":
        return cls(
            id=d["id"],
            name=d["name"],
            show_role=d["show_role"],
            color=d["color"],
            emoji=d["emoji"],
            state=CastState(**d["state"]),
            traits=CastTraits(**d["traits"]),
            identity_tags=d.get("identity_tags", []),
            relationships=d.get("relationships", {}),
            baseline=d.get("baseline", {}),
            modifiers=d.get("modifiers", []),
            shared_jokes=d.get("shared_jokes", []),
        )

    def profile_summary(self) -> str:
        """Compact string fed to the episode engine system prompt."""
        tags = f", tags=[{','.join(self.identity_tags)}]" if self.identity_tags else ""
        rels = []
        for other_id, r in self.relationships.items():
            if r["interactions"] > 0:
                rels.append(
                    f"{other_id}(trust={r['trust']:.2f},resentment={r['resentment']:.2f},"
                    f"attachment={r['attachment']:.2f},allied={r['allied']})"
                )
        rel_str = f", relationships=[{'; '.join(rels)}]" if rels else ", relationships=[none yet — strangers]"
        mod_active = [m["name"] for m in self.modifiers if m["remaining"] > 0]
        mod_str = f", ACTIVE_EFFECT=[{','.join(mod_active)} — acting unlike normal self]" if mod_active else ""
        joke_str = f", inside_jokes=[{'; '.join(self.shared_jokes)}]" if self.shared_jokes else ""
        return (
            f"{self.name} ({self.show_role}): "
            f"dominance={self.state.dominance:.2f}, "
            f"cooperation={self.state.cooperation:.2f}, "
            f"trust_baseline={self.traits.trust_baseline:.2f}, "
            f"resilience={self.traits.resilience:.2f}, "
            f"curiosity={self.state.curiosity:.2f}, "
            f"risk_tolerance={self.traits.risk_tolerance:.2f}, "
            f"stress={self.state.stress:.2f}, "
            f"valence={self.state.valence:.2f}, "
            f"role={self.traits.role}"
            f"{tags}{rel_str}{mod_str}{joke_str}"
        )


# ── The Season 1 cast ─────────────────────────────────────────────────────────

def build_season_1_cast() -> List[CastMember]:
    """
    Construct the 7 fixed cast members with their hardcoded HRM profiles.
    Called once at season initialization. Returns fresh instances — no prior
    relationship history (they're strangers).
    """
    return [
        CastMember(
            id="marcus",
            name="Marcus",
            show_role="The Iron Architect",
            color="#00C9FF",
            emoji="🏛️",
            state=CastState(
                energy=0.88, stress=0.18, curiosity=0.42, fear=0.12,
                cooperation=0.38, dominance=0.82, stability=0.74,
                social_openness=0.28, valence=0.30, plan_confidence=0.79,
                goal_satisfaction=0.61, status_security=0.74,
            ),
            traits=CastTraits(
                trust_baseline=0.28, conflict_sensitivity=0.44,
                risk_tolerance=0.71, resilience=0.82,
                attachment_rate=0.02, avoidance_rate=0.06,
                role="protection", ideology_sensitivity=0.66,
            ),
            identity_tags=["hardened"],
        ),

        CastMember(
            id="zola",
            name="Zola",
            show_role="The Visionary Anarchist",
            color="#FF3CAC",
            emoji="🌀",
            state=CastState(
                energy=0.77, stress=0.31, curiosity=0.94, fear=0.09,
                cooperation=0.55, dominance=0.61, stability=0.44,
                social_openness=0.91, valence=0.52, plan_confidence=0.22,
                goal_satisfaction=0.44, status_security=0.41,
            ),
            traits=CastTraits(
                trust_baseline=0.62, conflict_sensitivity=0.28,
                risk_tolerance=0.88, resilience=0.58,
                attachment_rate=0.07, avoidance_rate=0.02,
                role="knowledge", ideology_sensitivity=0.44,
            ),
            identity_tags=["early-secure"],
        ),

        CastMember(
            id="eli",
            name="Eli",
            show_role="The Quiet Economist",
            color="#A8FF78",
            emoji="📊",
            state=CastState(
                energy=0.72, stress=0.14, curiosity=0.71, fear=0.18,
                cooperation=0.62, dominance=0.31, stability=0.66,
                social_openness=0.38, valence=0.28, plan_confidence=0.88,
                goal_satisfaction=0.55, status_security=0.58,
            ),
            traits=CastTraits(
                trust_baseline=0.51, conflict_sensitivity=0.38,
                risk_tolerance=0.44, resilience=0.66,
                attachment_rate=0.03, avoidance_rate=0.04,
                role="coordination", ideology_sensitivity=0.31,
            ),
            identity_tags=[],
        ),

        CastMember(
            id="priya",
            name="Priya",
            show_role="The Empathy Engine",
            color="#FFB347",
            emoji="🌊",
            state=CastState(
                energy=0.68, stress=0.22, curiosity=0.66, fear=0.14,
                cooperation=0.88, dominance=0.24, stability=0.58,
                social_openness=0.84, valence=0.61, plan_confidence=0.44,
                goal_satisfaction=0.58, status_security=0.48,
            ),
            traits=CastTraits(
                trust_baseline=0.74, conflict_sensitivity=0.62,
                risk_tolerance=0.31, resilience=0.54,
                attachment_rate=0.09, avoidance_rate=0.02,
                role="care", ideology_sensitivity=0.52,
            ),
            identity_tags=["early-secure"],
        ),

        CastMember(
            id="dominic",
            name="Dominic",
            show_role="The Silver-Tongued Opportunist",
            color="#F7971E",
            emoji="🎭",
            state=CastState(
                energy=0.81, stress=0.19, curiosity=0.58, fear=0.08,
                cooperation=0.61, dominance=0.74, stability=0.62,
                social_openness=0.78, valence=0.44, plan_confidence=0.66,
                goal_satisfaction=0.72, status_security=0.68,
            ),
            traits=CastTraits(
                trust_baseline=0.38, conflict_sensitivity=0.22,
                risk_tolerance=0.74, resilience=0.62,
                attachment_rate=0.04, avoidance_rate=0.03,
                role="diplomacy", ideology_sensitivity=0.28,
            ),
            identity_tags=[],
        ),

        CastMember(
            id="sable",
            name="Sable",
            show_role="The Philosophical Disruptor",
            color="#C084FC",
            emoji="🖤",
            state=CastState(
                energy=0.64, stress=0.28, curiosity=0.77, fear=0.24,
                cooperation=0.41, dominance=0.38, stability=0.44,
                social_openness=0.31, valence=-0.12, plan_confidence=0.58,
                goal_satisfaction=0.33, status_security=0.38,
            ),
            traits=CastTraits(
                trust_baseline=0.31, conflict_sensitivity=0.71,
                risk_tolerance=0.52, resilience=0.71,
                attachment_rate=0.02, avoidance_rate=0.08,
                role="knowledge", ideology_sensitivity=0.78,
            ),
            identity_tags=["early-wounded", "hypervigilant"],
        ),

        CastMember(
            id="theo",
            name="Theo",
            show_role="The Reckless Optimist",
            color="#FFC300",
            emoji="🚀",
            state=CastState(
                energy=0.94, stress=0.24, curiosity=0.88, fear=0.06,
                cooperation=0.72, dominance=0.58, stability=0.52,
                social_openness=0.88, valence=0.68, plan_confidence=0.31,
                goal_satisfaction=0.62, status_security=0.52,
            ),
            traits=CastTraits(
                trust_baseline=0.68, conflict_sensitivity=0.18,
                risk_tolerance=0.91, resilience=0.48,
                attachment_rate=0.08, avoidance_rate=0.01,
                role="generalist", ideology_sensitivity=0.22,
            ),
            identity_tags=[],
        ),
    ]
