# Simfeld ARW Clean Build

This folder has been stripped of the original Agentic Real World sealed-house cast and previous run data.

## What it is

A NYC apartment-life version of ARW designed to test whether personality emerges under low-stakes ordinary pressure.

There is no:
- sealed house
- revenue challenge
- survival premise
- original Marcus/Zola/Eli/Priya/Dominic/Sable/Theo cast
- previous episode output

## Cast

The cast lives in:

```text
agentic_real_world\cast.py
```

The residents are hidden trait bundles only. They are not told to emulate any sitcom character.

Current residents:
- Reed — observational, detached, verbally quick, accidental social hub
- Owen — anxious, status-sensitive, ruminating, self-protective
- Mara — independent, socially fluent, low tolerance for nonsense
- Gabe — high novelty, low inhibition, boundary-blind, odd side projects

## Run

From the folder containing `agentic_real_world`:

```bat
py agentic_real_world\run_episode.py --reset
py agentic_real_world\run_episode.py
```

## Output path

```text
agentic_real_world\seasons\season_01_simfeld\
```

Expected files after a run:

```text
cast_init.json
episode_01_full.json
episode_01_post.json
season_manifest.json
```

## API

Uses the Anthropic API key from either:

```text
ANTHROPIC_API_KEY
```

environment variable, or:

```text
.env.user
```

one folder above `agentic_real_world`.
