r"""
run_episode.py — Simfeld / apartment-life episode producer.

This cleaned build removes the original Agentic Real World sealed-house cast,
challenge premise, mirror mode, and run data.

Usage from the folder containing agentic_real_world:

    py agentic_real_world\run_episode.py --reset
    py agentic_real_world\run_episode.py
    py agentic_real_world\run_episode.py --summary

Outputs:
    agentic_real_world\seasons\season_01_simfeld\
"""

import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from cast import CastMember
from cast_simfeld import build_simfeld_cast
from season import print_relationship_matrix
from episode_simfeld import produce_episode as produce_simfeld_episode, SIMFELD_PREMISE


def resolve_api_key() -> str:
    """Find Anthropic API key from environment or common local key files.

    Accepted file locations, relative to this package root:
      .env.user
      .env
      anthropic_key.txt
      ANTHROPIC_API_KEY.txt
      agentic_real_world/.env.user
      agentic_real_world/.env
      agentic_real_world/anthropic_key.txt
      agentic_real_world/ANTHROPIC_API_KEY.txt

    Accepted file formats:
      ANTHROPIC_API_KEY=sk-ant-...
      sk-ant-...
    """
    key = os.environ.get("ANTHROPIC_API_KEY", "").strip().strip('"').strip("'")
    if key:
        return key

    here = Path(__file__).resolve().parent
    package_root = here.parent
    candidate_files = [
        package_root / ".env.user",
        package_root / ".env",
        package_root / "anthropic_key.txt",
        package_root / "ANTHROPIC_API_KEY.txt",
        here / ".env.user",
        here / ".env",
        here / "anthropic_key.txt",
        here / "ANTHROPIC_API_KEY.txt",
    ]

    for env_path in candidate_files:
        if not env_path.exists():
            continue
        try:
            for raw in env_path.read_text(encoding="utf-8").splitlines():
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                if line.startswith("ANTHROPIC_API_KEY="):
                    key = line.split("=", 1)[1].strip().strip('"').strip("'")
                elif line.startswith("sk-ant-"):
                    key = line.strip().strip('"').strip("'")
                else:
                    continue
                if key and "PASTE" not in key:
                    print(f"[SIMFELD] API key loaded from {env_path}")
                    return key
        except Exception as exc:
            print(f"[SIMFELD] Warning: could not read {env_path}: {exc}")

    print("[SIMFELD] ERROR: No ANTHROPIC_API_KEY found.")
    print("Put your key in ONE of these places:")
    for p in candidate_files:
        print(f"  - {p}")
    print("Format can be either:")
    print("  ANTHROPIC_API_KEY=sk-ant-...")
    print("or just:")
    print("  sk-ant-...")
    sys.exit(1)


def season_dir(season: int) -> Path:
    return Path(__file__).parent / "seasons" / f"season_{season:02d}_simfeld"


def init_season(season: int) -> list[CastMember]:
    d = season_dir(season)
    d.mkdir(parents=True, exist_ok=True)
    cast = build_simfeld_cast()
    (d / "cast_init.json").write_text(
        json.dumps([m.to_dict() for m in cast], indent=2),
        encoding="utf-8"
    )
    (d / "season_manifest.json").write_text(
        json.dumps({
            "season": season,
            "mode": "simfeld",
            "premise": SIMFELD_PREMISE,
            "note": "Original ARW sealed-house cast and run data removed. Residents are hidden trait bundles only.",
            "episodes": []
        }, indent=2),
        encoding="utf-8"
    )
    print(f"[SIMFELD] Initialized season_{season:02d}_simfeld with {len(cast)} residents.")
    return cast


def load_cast(season: int) -> list[CastMember]:
    d = season_dir(season)
    if not d.exists():
        return init_season(season)

    post_files = sorted(d.glob("episode_*_post.json"))
    source = post_files[-1] if post_files else d / "cast_init.json"

    if not source.exists():
        return init_season(season)

    data = json.loads(source.read_text(encoding="utf-8"))
    cast = [CastMember.from_dict(m) for m in data]
    print(f"[SIMFELD] Loaded cast from {source.name} — {len(cast)} residents.")
    return cast


def next_episode_number(season: int) -> int:
    d = season_dir(season)
    return len(list(d.glob("episode_*_post.json"))) + 1 if d.exists() else 1


def save_post_state(cast: list[CastMember], season: int, episode_num: int, highlight_count: int):
    d = season_dir(season)
    d.mkdir(parents=True, exist_ok=True)

    ep_path = d / f"episode_{episode_num:02d}_post.json"
    ep_path.write_text(json.dumps([m.to_dict() for m in cast], indent=2), encoding="utf-8")

    mp = d / "season_manifest.json"
    manifest = json.loads(mp.read_text(encoding="utf-8")) if mp.exists() else {
        "season": season, "mode": "simfeld", "premise": SIMFELD_PREMISE, "episodes": []
    }
    manifest["episodes"].append({
        "episode": episode_num,
        "highlight_clips": highlight_count,
        "cast_snapshot": ep_path.name,
    })
    mp.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"[SIMFELD] Episode {episode_num} state saved to {ep_path.name}.")


def main():
    parser = argparse.ArgumentParser(description="Simfeld — apartment-life episode producer")
    parser.add_argument("--reset", action="store_true", help="Wipe Simfeld run data and reinitialize cast.")
    parser.add_argument("--summary", action="store_true", help="Print relationship matrix and exit.")
    parser.add_argument("--season", type=int, default=1)
    args = parser.parse_args()

    d = season_dir(args.season)

    if args.reset:
        import shutil
        if d.exists():
            shutil.rmtree(d)
            print(f"[SIMFELD] Removed old {d.name}.")
        init_season(args.season)
        print("[SIMFELD] Run again without --reset to generate Episode 1.")
        return

    cast = load_cast(args.season)

    if args.summary:
        print_relationship_matrix(cast)
        return

    api_key = resolve_api_key()
    episode_num = next_episode_number(args.season)

    print(f"\n[SIMFELD] Season {args.season}, Episode {episode_num}")
    print("[SIMFELD] No revenue challenge. No sealed house. NYC apartment life only.")
    print(f"[SIMFELD] Prior relationship interactions: {sum(1 for m in cast for r in m.relationships.values() if r['interactions'] > 0)}")

    episode = produce_simfeld_episode(
        cast=cast,
        premise=SIMFELD_PREMISE,
        api_key=api_key,
        episode_number=episode_num,
        output_dir=d,
    )

    save_post_state(cast, args.season, episode_num, episode.get("highlight_count", 0))
    print_relationship_matrix(cast)
    print(f"[SIMFELD] Complete. JSON output: {d}")


if __name__ == "__main__":
    main()
