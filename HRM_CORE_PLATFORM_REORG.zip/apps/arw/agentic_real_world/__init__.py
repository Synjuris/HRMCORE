# agentic_real_world — HRM Season 1 production module
# Isolated cast world. Not injected into general population.
# Cast persists across episodes via season checkpoint.
