
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from hrm_core import HRMKernel, KernelConfig

k = HRMKernel(KernelConfig(population=300, seed=57))
k.inject_event({"label":"generic_pressure_event", "x":50, "y":50, "radius":25, "stress_delta":0.18, "trust_delta":-0.08})
k.tick(50)
out = ROOT / "outputs" / "hrm_studio_demo_state.json"
k.save_state(out)
print("HRM Studio demo complete")
print("State written:", out)
print("Metrics:", k.export_state()["metrics"])
