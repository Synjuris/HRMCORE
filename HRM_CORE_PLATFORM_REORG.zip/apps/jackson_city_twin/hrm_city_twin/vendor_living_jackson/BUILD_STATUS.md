# Living Jackson — Merged Build Status

## What changed in this package

- Merged the runnable prototype with Patch Pack 01.
- Added `data/`, `calibration/`, `api/`, `configs/`, `tests/`, and `docs/` to the main project tree.
- Mounted the calibration/run API router in `backend/app.py`.
- Replaced the dead `calibration.loop.run_once()` stub with a bridge into the current `LivingJacksonSim`.
- Added `backend/living_jackson/export.py` to emit calibration-shaped outputs from the current simulator.
- Added local launch scripts: `RUN_LOCAL.bat`, `RUN_LOCAL.sh`, and `run_living_jackson.py`.
- Removed compiled cache files from the clean package.

## Current truth

This is now an integrated runnable build. It is still not a validated Jackson civic model.

The calibration bridge creates deterministic placeholder tract/OD fixtures when live ACS, LODES, TIGER tract polygons, and OSM graph cache are not present. That makes the pipeline executable without pretending the results are policy-valid.

## Next hardening step

Replace placeholder geographic assignment in `backend/living_jackson/export.py` with true TIGER/Line tract polygons and point-in-polygon assignment. Then replace the local OD fixture with `data.lodes_ingest.load_od_matrix()` once LODES is cached.
