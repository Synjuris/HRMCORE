# Real Data Fetch Fix

This build patches `scripts/fetch_real_data.py` after the Windows launcher exposed a failure:

`json.decoder.JSONDecodeError: Expecting value`

That happened because the fetcher assumed Census API responses were always JSON. Census can return text/HTML/error responses when a year is unavailable, a URL is rejected, a firewall intercepts the request, or the endpoint is temporarily unavailable.

## What changed

- Census responses are now validated before JSON parsing.
- Failed URLs and response previews are written to `runs/calibration_launcher.log`.
- ACS year fallback was added: default starts at 2024 and tries older ACS 5-year releases down to 2018.
- LODES year fallback was added: default starts at 2023 and tries older LODES releases down to 2018.
- LODES failure no longer destroys the entire ACS calibration pull by default. It records the failure in `data/targets/provenance.json` and leaves OD calibration unavailable until LODES succeeds.
- No fake calibration data is generated.

## Run

Double-click:

`CALIBRATE_WITH_REAL_DATA.bat`

If it fails again, send:

`runs/calibration_launcher.log`
