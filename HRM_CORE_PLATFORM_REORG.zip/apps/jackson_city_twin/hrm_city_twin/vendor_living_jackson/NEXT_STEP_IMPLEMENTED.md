# Next Step Implemented — Calibration Realism Harness

This package is not just a second copy. The next required step has been implemented:

## Added

- `calibration/targets.py`
  - checks for observed target data files
  - validates required CSV columns
  - loads ACS/LODES/AADT/commute-band targets when present
  - computes calibration readiness/confidence

- `calibration/report.py`
  - generates a plain-English calibration report
  - writes `runs/<run_id>/CALIBRATION_REPORT.md`

- `data/targets/README.md`
  - exact filenames and columns needed to make the model actually calibrated

- API support
  - run summaries now include `readiness`
  - new endpoint: `/api/calibration/status`

- Metrics bridge upgraded
  - if real target files exist, metrics use them
  - if they do not, the report explicitly says the system is not calibrated

## What you do with it now

Run:

```bash
python -m calibration.report --baseline configs/baseline.yaml
```

That gives the thing you were missing: a hard verdict on whether the current simulation is usable for real policy/scenario interpretation.

Current expected verdict without real target CSVs:

> NOT CALIBRATED — executable prototype only

That is intentional. It prevents the system from pretending fake internal fixture data equals Jackson reality.
