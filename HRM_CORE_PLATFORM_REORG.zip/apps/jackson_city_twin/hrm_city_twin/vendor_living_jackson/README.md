# Living Jackson — first integrated prototype

A calibrated-simulation architecture scaffold and working prototype for a synthetic-population civic simulator of Jackson, Tennessee.

This prototype is **not predictive yet**. It is the first integrated build: real Jackson map tiles in the browser, synthetic residents, household/work/school routines, movement, scenario injection, metrics, replay, and resident inspection.

## Run

```bash
cd living_jackson
python -m venv .venv
# Windows: .venv\Scripts\activate
# Mac/Linux:
source .venv/bin/activate
pip install -r requirements.txt
uvicorn backend.app:app --reload --host 127.0.0.1 --port 8000
```

Open: http://127.0.0.1:8000


## Implemented next step: calibration realism harness

Run this before treating any scenario result as meaningful:

```bash
python -m calibration.report --baseline configs/baseline.yaml
```

It writes `runs/<run_id>/CALIBRATION_REPORT.md` and gives a hard verdict.
Without real observed CSVs in `data/targets/`, the expected verdict is:

> NOT CALIBRATED — executable prototype only

That is intentional. The system now distinguishes “the simulation runs” from “the simulation resembles Jackson.”

Required observed-data files are documented in `data/targets/README.md`.


## Real-data calibration

Use this before trusting scenario output:

```bash
python scripts/fetch_real_data.py
python -m calibration.report --baseline configs/baseline.yaml
```

Or run:

- Windows: `CALIBRATE_WITH_REAL_DATA.bat`
- Mac/Linux: `./CALIBRATE_WITH_REAL_DATA.sh`

This revision does **not** use placeholder calibration values. Missing real target files produce `nan` metrics and a NOT CALIBRATED verdict.

## API smoke test

```bash
python scripts/smoke_test.py
```

## What is real vs scaffolded

Real now:
- Jackson, TN map tiles through OpenStreetMap in the frontend.
- Jackson coordinate bounds and civic anchors.
- Full-population logical representation is supported by configuration, with viewport sampling for rendering.
- Append-only event log, SQLite run metadata, snapshots, replay, metrics.

Scaffolded now:
- Population synthesis uses seeded statistical distributions until ACS/LODES ingestion is wired.
- Routing uses a cached polyline corridor model unless `scripts/ingest_osm.py` is extended with OSMnx/OSRM/GraphHopper.
- Calibration targets are defined in docs but not fitted against observed data yet.

## Imported concepts from DAS

DAS is not coupled into Layer 1. The prototype only borrows architectural patterns:
- persistent agent state
- stress/trust scalar dynamics
- relationship/familiarity fields
- append-only event stream
- rolling metrics
- replay snapshots
