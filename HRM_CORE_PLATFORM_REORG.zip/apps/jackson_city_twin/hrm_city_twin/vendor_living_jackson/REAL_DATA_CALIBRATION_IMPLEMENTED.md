# Real-data calibration implemented

This revision removes the fake/placeholder calibration path.

## What changed

1. Added `scripts/fetch_real_data.py`.
   - Pulls ACS 5-year tract population for Madison County, TN.
   - Pulls ACS 5-year commute-time bands for Jackson city, TN.
   - Pulls Census LEHD/LODES Tennessee OD data and aggregates block OD to tract OD pairs where home or work is in Madison County.
   - Creates a TDOT AADT schema file but does not invent traffic counts.

2. Replaced placeholder scoring.
   - Missing ACS commute data now returns `nan`, not a made-up comparison.
   - Missing ACS tract population now returns `nan`.
   - Missing LODES OD flows now returns `nan`.
   - Missing TDOT AADT now returns `nan`.

3. Added one-command calibration launchers.
   - Windows: `CALIBRATE_WITH_REAL_DATA.bat`
   - Mac/Linux: `./CALIBRATE_WITH_REAL_DATA.sh`

## Use

```bash
python scripts/fetch_real_data.py
python -m calibration.report --baseline configs/baseline.yaml
```

## Important limitation

This is now honest real-data calibration infrastructure, but not final municipal boundary calibration.
Current target scope is:

- ACS tract population: Madison County, TN census tracts
- ACS commute bands: Jackson city, TN
- LODES OD: Tennessee LODES OD filtered to Madison County home/work tracts
- TDOT AADT: manual observed file required after mapping TDOT count stations to simulator `link_id`

The simulator should not claim calibrated scenario validity until the report reaches at least moderate confidence.
