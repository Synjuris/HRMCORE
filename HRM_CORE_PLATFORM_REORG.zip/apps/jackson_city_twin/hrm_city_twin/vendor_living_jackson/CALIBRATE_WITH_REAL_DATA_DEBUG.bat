@echo off
cd /d "%~dp0"
cmd /k CALIBRATE_WITH_REAL_DATA.bat
