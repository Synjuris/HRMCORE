"""
Determinism contract: identical manifest + seed -> identical event hash.

If this test fails, somewhere in the simulator pipeline an unseeded random
source has crept in (datetime.now, hash randomization, dict ordering on an
old Python, threadpool nondeterminism, etc.).
"""
from __future__ import annotations

import pytest

from calibration.loop import Manifest, run_once


def test_same_manifest_same_hash():
    m = Manifest(name="repro_test", seed=1234, ticks=500, params={})
    a = run_once(m)
    b = run_once(m)
    assert a["event_hash"] == b["event_hash"], (
        f"event hash drift: {a['event_hash']} != {b['event_hash']}"
    )


def test_different_seed_different_hash():
    a = run_once(Manifest("a", seed=1, ticks=500, params={}))
    b = run_once(Manifest("b", seed=2, ticks=500, params={}))
    assert a["event_hash"] != b["event_hash"]
