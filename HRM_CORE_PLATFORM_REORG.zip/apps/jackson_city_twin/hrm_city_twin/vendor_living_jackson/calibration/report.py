"""CLI report for checking whether Living Jackson is usable as a realism test."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from calibration.loop import Manifest, evaluate
from calibration.targets import target_statuses


def render(payload: dict) -> str:
    lines = []
    lines.append("# Living Jackson Calibration Report")
    lines.append("")
    lines.append(f"Run: `{payload['run_id']}`")
    lines.append(f"Manifest: `{payload['manifest']['name']}`")
    lines.append(f"Event hash: `{payload['event_hash']}`")
    lines.append("")
    readiness = payload.get("readiness", {})
    lines.append(f"## Verdict: {readiness.get('verdict', 'UNKNOWN')}")
    lines.append("")
    lines.append(f"Calibration confidence: **{readiness.get('calibration_confidence', 0):.3f}**")
    lines.append(f"Observed target coverage: **{readiness.get('observed_targets', 0)}/{readiness.get('total_targets', 0)}**")
    lines.append(f"Raw fit score: **{readiness.get('raw_fit_score', 0):.3f}**")
    lines.append("")
    lines.append("## Metrics")
    lines.append("")
    lines.append("| Metric | Value | Direction | Unit | Notes |")
    lines.append("|---|---:|---|---|---|")
    for m in payload["metrics"]:
        lines.append(f"| {m['name']} | {m['value']:.4f} | {m['direction']} | {m['unit']} | {m.get('notes','')} |")
    lines.append("")
    lines.append("## Observed target files")
    lines.append("")
    lines.append("| Target | Status | Rows | Path | Notes |")
    lines.append("|---|---|---:|---|---|")
    for t in readiness.get("target_status", target_statuses()):
        lines.append(f"| {t['name']} | {t['status']} | {t.get('rows',0)} | `{t['path']}` | {t.get('notes','')} |")
    lines.append("")
    lines.append("## Interpretation")
    lines.append("")
    lines.append("- If the verdict says NOT CALIBRATED, use the app for architecture/testing only, not policy claims.")
    lines.append("- Add real CSVs under `data/targets/` to unlock observed-data scoring.")
    lines.append("- A scenario result should not be treated as meaningful until confidence is at least moderate.")
    return "\n".join(lines)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--baseline", type=Path, default=Path("configs/baseline.yaml"))
    p.add_argument("--out", type=Path, default=None)
    args = p.parse_args()
    payload = evaluate(Manifest.load(args.baseline))
    text = render(payload)
    out = args.out or (Path("runs") / payload["run_id"] / "CALIBRATION_REPORT.md")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text, encoding="utf-8")
    print(text)
    print(f"\nWrote {out}")


if __name__ == "__main__":
    main()
