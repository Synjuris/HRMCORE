"""
Calibration harness.

Loads a baseline manifest (YAML), runs the simulator under each parameter
combination, and writes `runs/<run_id>/metrics.json` for the dashboard to read.

Determinism contract:
    Given identical manifest + seed, two runs MUST produce identical event hash.
    (See tests/test_reproducibility.py.)

Usage:
    python -m calibration.loop --baseline configs/baseline.yaml
    python -m calibration.loop --baseline configs/baseline.yaml --sweep stress_weight 0.1 0.2 0.3
"""
from __future__ import annotations

import argparse
import hashlib
import json
import time
from dataclasses import dataclass, field, asdict
from itertools import product
from pathlib import Path
from typing import Any

import yaml

RUNS_DIR = Path(__file__).resolve().parent.parent / "runs"


@dataclass
class Manifest:
    name: str
    seed: int
    ticks: int
    params: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def load(cls, path: Path) -> "Manifest":
        with path.open() as f:
            data = yaml.safe_load(f)
        return cls(**data)


def run_id(manifest: Manifest) -> str:
    """Deterministic id from manifest content + seed."""
    blob = json.dumps(asdict(manifest), sort_keys=True).encode()
    return hashlib.sha256(blob).hexdigest()[:12]


def run_once(manifest: Manifest) -> dict:
    """Run the current Living Jackson simulator through the calibration bridge."""
    from backend.living_jackson.export import run_for_calibration

    params = dict(manifest.params)
    pop_size = int(params.pop("pop_size", 5000))
    return run_for_calibration(
        seed=manifest.seed,
        ticks=manifest.ticks,
        pop_size=pop_size,
        **params,
    )


def evaluate(manifest: Manifest) -> dict:
    from calibration.metrics import compute_all
    from calibration.targets import target_statuses, readiness_report

    started = time.time()
    sim_out = run_once(manifest)
    elapsed = time.time() - started

    metrics = compute_all(
        sim_commute_minutes=sim_out["sim_commute_minutes"],
        sim_residents=sim_out["sim_residents"],
        acs_tract_pop=sim_out["acs_tract_pop"],
        sim_od=sim_out["sim_od"],
        lodes_od=sim_out["lodes_od"],
        sim_link_volumes=sim_out["sim_link_volumes"],
        commute_shares=sim_out.get("commute_shares"),
        commute_midpoints=sim_out.get("commute_midpoints"),
        aadt_observed=sim_out.get("aadt_observed"),
    )
    readiness = readiness_report(metrics, target_statuses())

    rid = run_id(manifest)
    out_dir = RUNS_DIR / rid
    out_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        "run_id": rid,
        "manifest": asdict(manifest),
        "event_hash": sim_out["event_hash"],
        "elapsed_seconds": elapsed,
        "metrics": metrics,
        "readiness": readiness,
    }
    (out_dir / "metrics.json").write_text(json.dumps(payload, indent=2))
    return payload


def sweep(baseline: Manifest, param: str, values: list[Any]) -> list[dict]:
    out = []
    for v in values:
        m = Manifest(
            name=f"{baseline.name}__{param}={v}",
            seed=baseline.seed,
            ticks=baseline.ticks,
            params={**baseline.params, param: v},
        )
        out.append(evaluate(m))
    return out


def grid_sweep(baseline: Manifest, grid: dict[str, list[Any]]) -> list[dict]:
    keys = list(grid.keys())
    out = []
    for combo in product(*[grid[k] for k in keys]):
        params = {**baseline.params, **dict(zip(keys, combo))}
        name = baseline.name + "__" + "_".join(f"{k}={v}" for k, v in zip(keys, combo))
        out.append(evaluate(Manifest(name, baseline.seed, baseline.ticks, params)))
    return out


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--baseline", type=Path, required=True)
    p.add_argument("--sweep", nargs="+", metavar=("PARAM", "VALUES"),
                   help="e.g. --sweep stress_weight 0.1 0.2 0.3")
    args = p.parse_args()
    baseline = Manifest.load(args.baseline)

    if args.sweep:
        param, *vals = args.sweep
        results = sweep(baseline, param, [yaml.safe_load(v) for v in vals])
    else:
        results = [evaluate(baseline)]

    for r in results:
        ks = next((m for m in r["metrics"] if m["name"] == "commute_time_ks"), None)
        print(f"  {r['run_id']}  ks={ks['value']:.3f}  "
              f"{r['elapsed_seconds']:.1f}s  {r['manifest']['name']}")
