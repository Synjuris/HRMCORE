"""Observed-target loading and calibration readiness scoring for Living Jackson.

This module is intentionally conservative: a metric backed by simulated data
compared against itself is marked as PLACEHOLDER and receives no calibration
credit. Only external target files in data/targets/ can move a metric into
OBSERVED status.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
TARGET_DIR = ROOT / "data" / "targets"

REQUIRED_TARGETS = {
    "acs_tract_population": {
        "path": TARGET_DIR / "acs_tract_population.csv",
        "columns": {"tract", "total_pop"},
        "description": "Census tract population targets for Jackson/Madison County.",
    },
    "lodes_od": {
        "path": TARGET_DIR / "lodes_od.csv",
        "columns": {"home_tract", "work_tract", "jobs"},
        "description": "LODES origin-destination worker flow matrix.",
    },
    "aadt": {
        "path": TARGET_DIR / "aadt_counts.csv",
        "columns": {"link_id", "observed_aadt"},
        "description": "Observed traffic counts for matched road links.",
    },
    "commute_bands": {
        "path": TARGET_DIR / "acs_commute_bands.csv",
        "columns": {"minutes_midpoint", "share"},
        "description": "ACS commute-time band midpoint/share distribution.",
    },
}

@dataclass
class TargetStatus:
    name: str
    status: str       # observed | missing | invalid
    path: str
    rows: int = 0
    columns: list[str] | None = None
    notes: str = ""

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _read_csv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, dtype={"tract": str, "home_tract": str, "work_tract": str, "link_id": str})


def target_statuses() -> list[dict[str, Any]]:
    out: list[TargetStatus] = []
    for name, spec in REQUIRED_TARGETS.items():
        path = spec["path"]
        if not path.exists():
            out.append(TargetStatus(name, "missing", str(path), notes=spec["description"]))
            continue
        try:
            df = _read_csv(path)
            missing = sorted(spec["columns"] - set(df.columns))
            if missing:
                out.append(TargetStatus(name, "invalid", str(path), len(df), list(df.columns), f"missing columns: {missing}"))
            elif len(df) == 0:
                out.append(TargetStatus(name, "invalid", str(path), 0, list(df.columns), "file has no rows"))
            else:
                out.append(TargetStatus(name, "observed", str(path), len(df), list(df.columns), "loaded"))
        except Exception as exc:
            out.append(TargetStatus(name, "invalid", str(path), notes=f"read error: {exc}"))
    return [x.as_dict() for x in out]


def load_observed_targets() -> dict[str, Any]:
    """Load any observed targets that exist. Missing targets are omitted."""
    loaded: dict[str, Any] = {}
    acs = REQUIRED_TARGETS["acs_tract_population"]["path"]
    if acs.exists():
        df = _read_csv(acs)
        if {"tract", "total_pop"}.issubset(df.columns):
            loaded["acs_tract_pop"] = df[["tract", "total_pop"]].copy()
    od = REQUIRED_TARGETS["lodes_od"]["path"]
    if od.exists():
        df = _read_csv(od)
        if {"home_tract", "work_tract", "jobs"}.issubset(df.columns):
            loaded["lodes_od"] = df[["home_tract", "work_tract", "jobs"]].copy()
    aadt = REQUIRED_TARGETS["aadt"]["path"]
    if aadt.exists():
        df = _read_csv(aadt)
        if {"link_id", "observed_aadt"}.issubset(df.columns):
            loaded["aadt_observed"] = dict(zip(df["link_id"].astype(str), df["observed_aadt"].astype(float)))
    commute = REQUIRED_TARGETS["commute_bands"]["path"]
    if commute.exists():
        df = _read_csv(commute)
        if {"minutes_midpoint", "share"}.issubset(df.columns):
            loaded["commute_midpoints"] = df["minutes_midpoint"].astype(float).to_numpy()
            loaded["commute_shares"] = df["share"].astype(float).to_numpy()
    return loaded


def readiness_report(metrics: list[dict[str, Any]], target_status: list[dict[str, Any]]) -> dict[str, Any]:
    observed_count = sum(1 for t in target_status if t["status"] == "observed")
    total_targets = len(target_status)
    metric_scores = []
    for m in metrics:
        v = m.get("value")
        direction = m.get("direction")
        name = m.get("name")
        score = 0.0
        if v == v:  # not NaN
            if direction == "lower_better":
                if name == "commute_time_ks": score = max(0.0, 1.0 - float(v))
                elif name == "tract_population_mape": score = max(0.0, 1.0 - float(v) / 100.0)
                elif name == "od_flow_mae": score = max(0.0, 1.0 - float(v) / 1000.0)
            elif direction == "higher_better":
                score = max(0.0, min(1.0, (float(v) + 1.0) / 2.0))
        metric_scores.append({"name": name, "score": round(score, 4)})
    raw_fit = sum(x["score"] for x in metric_scores) / max(1, len(metric_scores))
    target_coverage = observed_count / max(1, total_targets)
    # No matter how pretty the internal metrics look, missing observed targets cap confidence.
    calibration_confidence = raw_fit * target_coverage
    if observed_count == 0:
        verdict = "NOT CALIBRATED — executable prototype only"
    elif calibration_confidence < 0.45:
        verdict = "LOW CONFIDENCE — observed data partially wired"
    elif calibration_confidence < 0.75:
        verdict = "MODERATE CONFIDENCE — needs more target coverage / fit"
    else:
        verdict = "CALIBRATED ENOUGH FOR SCENARIO EXPERIMENTS"
    return {
        "verdict": verdict,
        "observed_targets": observed_count,
        "total_targets": total_targets,
        "target_coverage": round(target_coverage, 4),
        "raw_fit_score": round(raw_fit, 4),
        "calibration_confidence": round(calibration_confidence, 4),
        "metric_scores": metric_scores,
        "target_status": target_status,
    }
