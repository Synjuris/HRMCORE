"""
Goodness-of-fit metrics for a simulation run vs. observed Jackson, TN data.

All metrics return a dict with `value`, `target` (lower or higher is better),
and `unit`, so the dashboard can render them uniformly.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np
import pandas as pd
from scipy import stats


@dataclass
class Metric:
    name: str
    value: float
    direction: str   # "lower_better" | "higher_better"
    unit: str
    notes: str = ""

    def as_dict(self) -> dict:
        return {
            "name": self.name,
            "value": float(self.value),
            "direction": self.direction,
            "unit": self.unit,
            "notes": self.notes,
        }


# ---- Commute time -----------------------------------------------------------

def commute_time_ks(sim_commute_minutes: Iterable[float],
                    obs_shares: np.ndarray | None = None,
                    obs_midpoints: np.ndarray | None = None) -> Metric:
    """KS statistic between simulated commute distribution and observed ACS bands.

    This metric is real-data only. Missing observed ACS commute bands produce NaN
    instead of falling back to invented placeholder shares.
    """
    if obs_shares is None or obs_midpoints is None:
        return Metric("commute_time_ks", float("nan"), "lower_better", "ks_stat",
                      notes="missing observed ACS commute bands")
    sim = np.asarray(list(sim_commute_minutes), dtype=float)
    if sim.size == 0:
        return Metric("commute_time_ks", float("nan"), "lower_better", "ks_stat",
                      notes="no simulated commutes")
    # Build an empirical CDF from observed bands by sampling midpoints w/ weights
    rng = np.random.default_rng(0)
    obs_sample = rng.choice(obs_midpoints, size=10_000, p=obs_shares / obs_shares.sum())
    ks = stats.ks_2samp(sim, obs_sample).statistic
    return Metric("commute_time_ks", ks, "lower_better", "ks_stat",
                  notes="0 = identical distributions, 1 = disjoint")


# ---- Tract population -------------------------------------------------------

def tract_population_mape(sim_residents: pd.DataFrame,
                          acs_tract_pop: pd.DataFrame) -> Metric:
    """Mean absolute percent error of simulated tract population vs. ACS."""
    if acs_tract_pop is None or len(acs_tract_pop) == 0:
        return Metric("tract_population_mape", float("nan"), "lower_better", "%",
                      notes="missing observed ACS tract population")
    sim_counts = (sim_residents.groupby("tract").size()
                                .rename("sim_pop").reset_index())
    merged = acs_tract_pop.merge(sim_counts, on="tract", how="left").fillna(0)
    mape = float(((merged["sim_pop"] - merged["total_pop"]).abs() /
                  merged["total_pop"].replace(0, np.nan)).mean() * 100)
    return Metric("tract_population_mape", mape, "lower_better", "%")


# ---- OD flow ----------------------------------------------------------------

def od_flow_mae(sim_od: pd.DataFrame, lodes_od: pd.DataFrame) -> Metric:
    """Mean absolute error in worker counts per (home_tract, work_tract) pair.

    Both inputs: columns [home_tract, work_tract, jobs].
    """
    if lodes_od is None or len(lodes_od) == 0:
        return Metric("od_flow_mae", float("nan"), "lower_better", "workers/pair",
                      notes="missing observed LODES OD flows")
    merged = sim_od.merge(lodes_od, on=["home_tract", "work_tract"],
                          how="outer", suffixes=("_sim", "_obs")).fillna(0)
    mae = float((merged["jobs_sim"] - merged["jobs_obs"]).abs().mean())
    return Metric("od_flow_mae", mae, "lower_better", "workers/pair")


def od_flow_correlation(sim_od: pd.DataFrame, lodes_od: pd.DataFrame) -> Metric:
    if lodes_od is None or len(lodes_od) == 0:
        return Metric("od_flow_pearson", float("nan"), "higher_better", "r",
                      notes="missing observed LODES OD flows")
    merged = sim_od.merge(lodes_od, on=["home_tract", "work_tract"],
                          how="outer", suffixes=("_sim", "_obs")).fillna(0)
    if len(merged) < 3:
        return Metric("od_flow_pearson", float("nan"), "higher_better", "r")
    r = float(np.corrcoef(merged["jobs_sim"], merged["jobs_obs"])[0, 1])
    return Metric("od_flow_pearson", r, "higher_better", "r")


# ---- AADT ---------------------------------------------------------------

def aadt_correlation(sim_link_volumes: dict[str, float],
                     observed: dict[str, float] | None = None) -> Metric:
    if not observed:
        return Metric("aadt_pearson", float("nan"), "higher_better", "r",
                      notes="missing observed TDOT AADT counts")
    keys = [k for k in observed if k in sim_link_volumes]
    if len(keys) < 3:
        return Metric("aadt_pearson", float("nan"), "higher_better", "r",
                      notes=f"only {len(keys)} matched links")
    sim = np.array([sim_link_volumes[k] for k in keys])
    obs = np.array([observed[k] for k in keys])
    r = float(np.corrcoef(sim, obs)[0, 1])
    return Metric("aadt_pearson", r, "higher_better", "r",
                  notes=f"matched {len(keys)} links")


# ---- Aggregate --------------------------------------------------------------

def compute_all(sim_commute_minutes: Iterable[float],
                sim_residents: pd.DataFrame,
                acs_tract_pop: pd.DataFrame,
                sim_od: pd.DataFrame,
                lodes_od: pd.DataFrame,
                sim_link_volumes: dict[str, float],
                commute_shares: np.ndarray | None = None,
                commute_midpoints: np.ndarray | None = None,
                aadt_observed: dict[str, float] | None = None) -> list[dict]:
    commute_metric = commute_time_ks(sim_commute_minutes, commute_shares, commute_midpoints)
    metrics = [
        commute_metric,
        tract_population_mape(sim_residents, acs_tract_pop),
        od_flow_mae(sim_od, lodes_od),
        od_flow_correlation(sim_od, lodes_od),
        aadt_correlation(sim_link_volumes, aadt_observed),
    ]
    return [m.as_dict() for m in metrics]
