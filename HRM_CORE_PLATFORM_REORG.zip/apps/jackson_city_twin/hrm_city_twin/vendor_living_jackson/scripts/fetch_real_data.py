#!/usr/bin/env python3
"""Fetch public observed-data targets for Living Jackson calibration.

Default scope is Madison County, TN because tract-level ACS/LODES targets are
available there without local GIS clipping. Jackson city is mostly inside
Madison County; replace/clip these targets later if you add official city-boundary
tract allocation.

Outputs:
  data/targets/acs_tract_population.csv
  data/targets/acs_commute_bands.csv
  data/targets/lodes_od.csv
  data/targets/provenance.json

This fetcher never fabricates calibration data. If a public endpoint returns an
HTML/text error, unavailable year, firewall page, or any non-JSON response, it
prints the exact failing URL and tries older supported years before failing.
"""
from __future__ import annotations

import argparse
import csv
import gzip
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Iterable, TypeVar

ROOT = Path(__file__).resolve().parents[1]
TARGET_DIR = ROOT / "data" / "targets"
STATE = "47"         # Tennessee
COUNTY = "113"       # Madison County, TN
JACKSON_PLACE = "37640"  # Jackson city, TN Census place code

COMMUTE_VARS = [
    ("B08303_002E", 2.5, "less_than_5"),
    ("B08303_003E", 7.0, "5_to_9"),
    ("B08303_004E", 12.0, "10_to_14"),
    ("B08303_005E", 17.0, "15_to_19"),
    ("B08303_006E", 22.0, "20_to_24"),
    ("B08303_007E", 27.0, "25_to_29"),
    ("B08303_008E", 32.0, "30_to_34"),
    ("B08303_009E", 37.0, "35_to_39"),
    ("B08303_010E", 42.0, "40_to_44"),
    ("B08303_011E", 52.0, "45_to_59"),
    ("B08303_012E", 75.0, "60_to_89"),
    ("B08303_013E", 105.0, "90_plus"),
]



def load_dotenv(path: Path = ROOT / ".env") -> None:
    """Load key=value pairs from .env into os.environ if not already set."""
    if not path.exists():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))

class FetchError(RuntimeError):
    """User-readable public data fetch failure."""


@dataclass
class FetchAttempt:
    year: int
    ok: bool
    message: str


def _decode_body(raw: bytes) -> str:
    return raw.decode("utf-8", errors="replace")


def get_text(url: str, timeout: int = 60) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": "LivingJacksonCalibration/0.2"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return _decode_body(r.read())
    except urllib.error.HTTPError as e:
        body = _decode_body(e.read())[:1500]
        raise FetchError(f"HTTP {e.code} {e.reason}\nURL: {url}\nResponse preview:\n{body}") from e
    except urllib.error.URLError as e:
        raise FetchError(f"Network error: {e.reason}\nURL: {url}") from e


def get_json(url: str) -> list[list[str]]:
    text = get_text(url)
    try:
        payload = json.loads(text)
    except json.JSONDecodeError as e:
        preview = text[:1500].replace("\r", "")
        raise FetchError(
            "Expected JSON from Census API but received non-JSON text.\n"
            f"URL: {url}\n"
            f"JSON error: {e}\n"
            f"Response preview:\n{preview}"
        ) from e
    if not isinstance(payload, list) or not payload or not isinstance(payload[0], list):
        raise FetchError(f"Unexpected Census JSON shape.\nURL: {url}\nPayload preview: {str(payload)[:1000]}")
    return payload


def census_url(dataset_year: int, variables: Iterable[str], geography: str, api_key: str | None = None) -> str:
    qs = {"get": ",".join(variables)}
    if api_key:
        qs["key"] = api_key
    return f"https://api.census.gov/data/{dataset_year}/acs/acs5?{urllib.parse.urlencode(qs, safe=',:*')}&{geography}"


def rows_from_census(payload: list[list[str]]) -> list[dict[str, str]]:
    header = payload[0]
    return [dict(zip(header, row)) for row in payload[1:]]


def fetch_acs_tract_population(year: int, api_key: str | None) -> dict:
    url = census_url(year, ["NAME", "B01003_001E"], f"for=tract:*&in=state:{STATE}%20county:{COUNTY}", api_key)
    rows = rows_from_census(get_json(url))
    if not rows:
        raise FetchError(f"ACS tract population returned zero rows.\nURL: {url}")
    out = TARGET_DIR / "acs_tract_population.csv"
    with out.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["tract", "total_pop", "name", "source_year", "source_geography"])
        w.writeheader()
        for r in rows:
            tract = f"{r['state']}{r['county']}{r['tract']}"
            w.writerow({
                "tract": tract,
                "total_pop": int(float(r["B01003_001E"])),
                "name": r["NAME"],
                "source_year": year,
                "source_geography": "Madison County, TN census tracts",
            })
    return {"file": str(out.relative_to(ROOT)), "rows": len(rows), "url": url, "year_used": year}


def fetch_acs_commute_bands(year: int, api_key: str | None) -> dict:
    vars_ = ["NAME", "B08303_001E"] + [v for v, _, _ in COMMUTE_VARS]
    url = census_url(year, vars_, f"for=place:{JACKSON_PLACE}&in=state:{STATE}", api_key)
    rows = rows_from_census(get_json(url))
    if not rows:
        raise FetchError(f"ACS commute bands returned zero rows.\nURL: {url}")
    row = rows[0]
    total = max(1, int(float(row["B08303_001E"])))
    out = TARGET_DIR / "acs_commute_bands.csv"
    with out.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["minutes_midpoint", "share", "count", "band", "source_year", "source_geography"])
        w.writeheader()
        for var, midpoint, band in COMMUTE_VARS:
            count = max(0, int(float(row[var])))
            w.writerow({
                "minutes_midpoint": midpoint,
                "share": count / total,
                "count": count,
                "band": band,
                "source_year": year,
                "source_geography": row["NAME"],
            })
    return {"file": str(out.relative_to(ROOT)), "rows": len(COMMUTE_VARS), "url": url, "year_used": year}


def fetch_lodes_od(year: int) -> dict:
    url = f"https://lehd.ces.census.gov/data/lodes/LODES8/tn/od/tn_od_main_JT00_{year}.csv.gz"
    out = TARGET_DIR / "lodes_od.csv"
    grouped: dict[tuple[str, str], int] = {}
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "LivingJacksonCalibration/0.2"})
        with urllib.request.urlopen(req, timeout=180) as resp:
            with gzip.GzipFile(fileobj=resp) as gz:
                text = (line.decode("utf-8") for line in gz)
                reader = csv.DictReader(text)
                for r in reader:
                    h = r["h_geocode"][:11]
                    w = r["w_geocode"][:11]
                    if not (h.startswith(f"{STATE}{COUNTY}") or w.startswith(f"{STATE}{COUNTY}")):
                        continue
                    grouped[(h, w)] = grouped.get((h, w), 0) + int(r["S000"])
    except urllib.error.HTTPError as e:
        body = _decode_body(e.read())[:1500]
        raise FetchError(f"HTTP {e.code} {e.reason}\nURL: {url}\nResponse preview:\n{body}") from e
    except Exception as e:
        raise FetchError(f"LODES fetch/read failed: {e}\nURL: {url}") from e
    if not grouped:
        raise FetchError(f"LODES file downloaded but no Madison County OD rows were found.\nURL: {url}")
    with out.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["home_tract", "work_tract", "jobs", "source_year", "source_geography"])
        w.writeheader()
        for (h, wk), jobs in sorted(grouped.items()):
            w.writerow({"home_tract": h, "work_tract": wk, "jobs": jobs, "source_year": year, "source_geography": "LODES8 Tennessee OD main JT00"})
    return {"file": str(out.relative_to(ROOT)), "rows": len(grouped), "url": url, "year_used": year}


def write_aadt_template() -> dict:
    out = TARGET_DIR / "aadt_counts.csv"
    if not out.exists():
        with out.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=["link_id", "observed_aadt", "station_id", "route", "source_year", "source_url", "notes"])
            w.writeheader()
    return {"file": str(out.relative_to(ROOT)), "rows": 0, "note": "template only; populate from TDOT count-station export before using AADT scoring"}


T = TypeVar("T")


def try_years(label: str, years: list[int], fn: Callable[[int], T]) -> tuple[T, list[FetchAttempt]]:
    attempts: list[FetchAttempt] = []
    last_error = ""
    for year in years:
        print(f"Trying {label} year {year}...", flush=True)
        try:
            result = fn(year)
            attempts.append(FetchAttempt(year, True, "ok"))
            return result, attempts
        except FetchError as e:
            last_error = str(e)
            attempts.append(FetchAttempt(year, False, last_error[:1000]))
            print(f"  failed for {year}: {last_error.splitlines()[0]}", file=sys.stderr, flush=True)
    detail = "\n\n".join(f"{a.year}: {a.message}" for a in attempts)
    raise FetchError(f"All attempted {label} years failed: {years}\n\n{detail}\n\nLast full error:\n{last_error}")


def year_window(start: int, floor: int = 2018) -> list[int]:
    return list(range(start, floor - 1, -1))


def main() -> int:
    load_dotenv()
    p = argparse.ArgumentParser()
    p.add_argument("--acs-year", type=int, default=2024)
    p.add_argument("--lodes-year", type=int, default=2023)
    p.add_argument("--census-key", default=os.environ.get("CENSUS_API_KEY"))
    p.add_argument("--skip-lodes", action="store_true")
    p.add_argument("--strict-lodes", action="store_true", help="Fail the whole run if LODES is unavailable. Default writes ACS targets and records LODES failure in provenance.")
    args = p.parse_args()
    TARGET_DIR.mkdir(parents=True, exist_ok=True)

    provenance = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "scope_note": "ACS tract population is Madison County, TN; ACS commute bands are Jackson city, TN; LODES OD is Tennessee OD filtered to Madison County home/work tracts.",
        "sources": {},
        "fetch_attempts": {},
    }

    try:
        acs_years = year_window(args.acs_year, 2018)
        tract, attempts = try_years("ACS tract population", acs_years, lambda y: fetch_acs_tract_population(y, args.census_key))
        provenance["sources"]["acs_tract_population"] = tract
        provenance["fetch_attempts"]["acs_tract_population"] = [a.__dict__ for a in attempts]

        # Use the successful tract year first so ACS sources stay internally consistent.
        commute_years = [tract["year_used"]] + [y for y in acs_years if y != tract["year_used"]]
        commute, attempts = try_years("ACS commute bands", commute_years, lambda y: fetch_acs_commute_bands(y, args.census_key))
        provenance["sources"]["acs_commute_bands"] = commute
        provenance["fetch_attempts"]["acs_commute_bands"] = [a.__dict__ for a in attempts]
    except FetchError as e:
        print("\nERROR: ACS real-data fetch failed. No fake ACS targets were written.", file=sys.stderr)
        print(str(e), file=sys.stderr)
        return 2

    if args.skip_lodes:
        provenance["sources"]["lodes_od"] = {"skipped": True, "reason": "--skip-lodes was supplied"}
    else:
        try:
            lodes, attempts = try_years("LODES OD", year_window(args.lodes_year, 2018), fetch_lodes_od)
            provenance["sources"]["lodes_od"] = lodes
            provenance["fetch_attempts"]["lodes_od"] = [a.__dict__ for a in attempts]
        except FetchError as e:
            provenance["sources"]["lodes_od"] = {"available": False, "error": str(e)[:4000]}
            print("\nWARNING: LODES failed. ACS targets were fetched; OD calibration will remain unavailable until LODES succeeds.", file=sys.stderr)
            print(str(e), file=sys.stderr)
            if args.strict_lodes:
                return 3

    provenance["sources"]["aadt_counts"] = write_aadt_template()
    (TARGET_DIR / "provenance.json").write_text(json.dumps(provenance, indent=2), encoding="utf-8")
    print(json.dumps(provenance, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
