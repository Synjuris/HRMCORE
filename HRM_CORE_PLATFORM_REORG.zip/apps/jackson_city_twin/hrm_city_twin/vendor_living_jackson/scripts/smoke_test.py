from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from backend.living_jackson.sim import LivingJacksonSim

baseline=LivingJacksonSim(pop_size=1000, seed=7)
for _ in range(520): b=baseline.step()
print('baseline', b)
scenario=LivingJacksonSim(pop_size=1000, seed=7)
for _ in range(390): scenario.step()
scenario.inject(kind='road_closure', label='I-40 closure test', intensity=.8, duration=240)
for _ in range(130): s=scenario.step()
print('scenario', s)
assert s['avg_delay'] > b['avg_delay']
assert s['congestion_index'] >= b['congestion_index']
assert len(scenario.visible_residents(100)) > 0
assert len(scenario.replay()) > 0
print('OK')
