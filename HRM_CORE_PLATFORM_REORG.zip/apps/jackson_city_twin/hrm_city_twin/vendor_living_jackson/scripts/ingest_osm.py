"""
Optional next-step script for replacing fallback corridor routing with real OSM roads.
Requires: pip install osmnx geopandas shapely networkx

This is intentionally not required for the first prototype run because geospatial native
packages can be painful on Windows. The production path is:
1. download Jackson, TN drivable graph with OSMnx
2. persist nodes/edges to PostGIS or GeoPackage
3. precompute route cache for home-work/school OD pairs
4. swap backend.living_jackson.routing.route() to read cached polylines
"""
import osmnx as ox
PLACE='Jackson, Tennessee, USA'
G=ox.graph_from_place(PLACE, network_type='drive')
ox.save_graph_geopackage(G, filepath='data/jackson_osm_roads.gpkg')
print('saved data/jackson_osm_roads.gpkg')
