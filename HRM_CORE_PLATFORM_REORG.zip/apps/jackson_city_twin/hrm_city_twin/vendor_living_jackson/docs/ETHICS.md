# Living Jackson — Ethics & Privacy Boundaries

This document is normative. Any contributor adding a feature that touches the
agent layer (Layer 2/3) must read it.

## 1. What this simulator is

A calibrated, statistical model of aggregate behavior in Jackson, TN. It is
useful for asking *"if we changed bus route X, how would commute times shift
across tracts?"* — questions where the unit of interest is a **population**,
not an individual.

## 2. What this simulator is NOT

- A surveillance tool. No real resident is identifiable from any output.
- A predictor of individual behavior. The agents are draws from ACS/PUMS
  marginals; they do not correspond to real people.
- A policy oracle. Outputs are conditional on assumptions in the manifest;
  changing assumptions can flip conclusions.

## 3. Data we use

| Source | Type | Identifiability |
|---|---|---|
| OpenStreetMap (OSMnx) | Public infrastructure | None |
| LODES OD | Census, already disclosure-protected | None at tract level |
| ACS 5-year | Census, published marginals | None at tract level |
| PUMS | Census person-level, swapped/perturbed | Census disclosure rules |
| TDOT AADT | Public traffic counts | None |

We do **not** ingest: cell-phone mobility traces, license-plate readers,
utility billing data, school enrollment records, named individuals.

## 4. Layer 2 (stress, familiarity, intent) is optional

Layer 2 is the behavioral overlay. It is:
- Off by default in the baseline manifest.
- Required to be tied to a measurable proxy before being enabled in a
  scenario (e.g. "stress" must correlate with an observable like ER visits
  or 311 complaint volume at the tract level).
- Never used to make claims about a specific resident_id.

## 5. Publication discipline

When publishing a scenario result:
1. Publish the manifest hash and event hash alongside the chart.
2. Publish the goodness-of-fit metrics for the baseline used.
3. State which Layer 2 mechanisms were enabled.
4. State the largest assumption that, if changed, would flip the conclusion.

## 6. Red lines

- Do not export resident-level trajectories to anyone outside the research team.
- Do not allow the public dashboard to query by resident_id.
- Do not train downstream ML models on resident-level outputs that are then
  applied back to real people.
