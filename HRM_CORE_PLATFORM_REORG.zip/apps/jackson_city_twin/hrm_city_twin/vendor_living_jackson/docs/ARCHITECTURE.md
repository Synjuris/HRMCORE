# Living Jackson Architecture

## 1. Complete architecture plan

Living Jackson is split into three replaceable layers.

### Layer 1 — Spatial/Demographic Reality Engine
Purpose: deterministic civic substrate.

Responsibilities:
- ingest Jackson geography
- maintain road graph/routing graph
- synthesize households and residents from aggregate data
- assign schools/workplaces/amenities
- run daily schedules and mobility
- output baseline metrics

Layer 1 must not depend on DAS or narrative/social internals.

### Layer 2 — Behavioral/Social Layer
Purpose: modular agent/social behavior.

Responsibilities:
- resident memory
- household/social familiarity
- trust/stress/adaptation
- repeated interactions
- response to disruptions
- local social clustering

This layer may borrow DAS concepts, but is a plugin over the civic substrate.

### Layer 3 — Scenario/Policy Engine
Purpose: controlled interventions and counterfactual comparison.

Responsibilities:
- inject policies/events
- run baseline vs intervention
- replay runs
- report delta metrics
- preserve scenario manifests

## 2. System diagram

```text
                 ┌───────────────────────────────┐
                 │ React + MapLibre/Leaflet UI   │
                 │ map, heatmaps, replay, inspect│
                 └──────────────┬────────────────┘
                                │ REST / WebSocket
┌───────────────────────────────▼────────────────────────────────┐
│ FastAPI Simulation Server                                       │
│ ┌────────────────────┐ ┌───────────────────┐ ┌───────────────┐ │
│ │ Scenario Engine    │ │ Simulation Clock  │ │ Metrics       │ │
│ └─────────┬──────────┘ └─────────┬─────────┘ └──────┬────────┘ │
│           │                      │                  │          │
│ ┌─────────▼──────────┐ ┌─────────▼─────────┐ ┌──────▼────────┐ │
│ │ Behavioral Layer   │ │ Movement/Routing  │ │ Replay Store  │ │
│ │ stress/trust/mem   │ │ paths/trips/flows │ │ snapshots     │ │
│ └─────────┬──────────┘ └─────────┬─────────┘ └──────┬────────┘ │
│           │                      │                  │          │
│ ┌─────────▼──────────────────────▼──────────────────▼────────┐ │
│ │ Layer 1 Reality Engine: population, places, schedules, GIS  │ │
│ └─────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
                                │
                   ┌────────────▼─────────────┐
                   │ SQLite / JSONL / PostGIS │
                   └──────────────────────────┘
```

## 3. Data pipeline

Prototype path:
1. Use Jackson coordinate bounds and known civic anchors.
2. Display real OpenStreetMap tiles in the browser.
3. Generate seeded households/residents.
4. Assign destinations and daily schedules.
5. Simulate trips and scenario effects.
6. Persist snapshots and events.

Production path:
1. OSM extract → road graph, POIs, land use, schools, hospitals, churches, parks.
2. Census/ACS → tract/block-group demographic constraints.
3. LEHD/LODES → home-work origin-destination constraints.
4. School zone/open data → school assignment constraints.
5. GTFS/transit if available → transit travel-time layer.
6. Calibration store → target distributions and fitted parameters.

## 4. Population synthesis design

Synthetic residents are generated from aggregate constraints only. No real person is recreated.

Core entities:
- Household: location, tract, income band, members.
- Resident: age, home, assigned school/work/errand destination, mode, schedule.
- Place: work, school, hospital, park, shopping, church, civic facility.

Production method:
- IPF / simulated annealing / constraint sampling against ACS tract tables.
- LODES OD matching for commute destination assignment.
- Household composition constraints by age, household size, income band.
- School-age assignment by school catchment and capacity.

## 5. Routing/movement system

Prototype:
- cached corridor polylines between home and destination.
- trip progress by minute.
- mode-dependent speed.
- disruption-dependent delay.

Production:
- OSMnx or OSRM/GraphHopper road graph.
- precomputed home-destination route cache.
- time-dependent travel cost.
- road closures modify edge weights or edge availability.
- transit graph, walk graph, and car graph separated.

## 6. Calibration methodology

Calibration must happen before any serious policy claim.

Targets:
- population distribution by tract/block group
- commute departure/arrival windows
- LODES home-work flows
- school attendance counts
- traffic concentration on major corridors
- commercial activity timing
- baseline stress/delay proxies

Method:
1. Define baseline metrics.
2. Run seeded ensembles.
3. Compare aggregate distributions to target datasets.
4. Fit schedule, mode, destination, and routing parameters.
5. Lock a calibrated baseline manifest.
6. Compare interventions only against that manifest.

## 7. Policy engine design

Scenario event shape:
- id
- kind
- label
- start tick
- end tick
- intensity
- geometry
- params

Supported classes:
- road_closure
- fuel_spike
- school_closure
- festival
- hospital_overload
- zoning_change
- store_opening/closure
- policing_resource_shift
- storm/disaster
- bus_route_change

Each event mutates costs/availability/routines, not raw outcomes.

## 8. Behavioral layer design

Resident behavioral state:
- stress
- trust
- routine adaptation
- relationships/familiarity
- movement history

Rules:
- disruptions increase stress through delay or blocked access.
- repeated co-location increases familiarity.
- stress can spread lightly through local groups.
- adaptation can reduce future stress after repeated exposure.

Layer 2 must remain optional and replaceable.

## 9. Replay system

Runs persist:
- run metadata
- scenario events
- periodic snapshots
- metric timeline

Replay reads snapshots and sampled resident states. Full production replay should combine:
- deterministic seed
- scenario manifest
- event stream
- periodic checkpoints

## 10. Performance strategy

- Do not render all 70k residents as DOM nodes.
- Use WebGL point layers or server-side sampled residents.
- Aggregate to heatmaps when zoomed out.
- Use route caching for repeated OD pairs.
- Store append-only events, not giant memory logs.
- Save snapshots every N ticks.
- Use spatial indexing for resident/place lookup.
- Separate simulation clock from render frame rate.

## 11. Database schemas

Prototype SQLite:
- runs(id, seed, pop_size, started_at, status)
- snapshots(run_id, tick, payload)
- events(run_id, tick, event_type, payload)

Production additions:
- residents
- households
- places
- trips
- roads/nodes/edges
- route_cache
- scenario_manifests
- metric_timeseries
- calibration_targets
- calibration_runs

## 12. API design

Current:
- GET /api/city
- POST /api/run/new
- GET /api/state
- POST /api/step?n=10
- POST /api/inject
- GET /api/resident/{id}
- GET /api/replay
- WS /ws

Production additions:
- POST /api/scenario/compare
- GET /api/metrics/timeline
- GET /api/heatmap/{metric}
- POST /api/calibration/run
- GET /api/calibration/report

## 13. Frontend design

Current:
- Leaflet map with OSM tiles
- sampled resident markers
- scenario controls
- metrics panel
- resident inspection

Production:
- MapLibre GL
- deck.gl WebGL scatter/heatmap/flow layers
- replay scrubber
- baseline vs scenario split view
- click-to-inspect resident/household/place/road
- metric panels with confidence/validation warnings

## 14. Folder structure

```text
living_jackson/
  backend/
    app.py
    living_jackson/
      city.py
      models.py
      population.py
      routing.py
      sim.py
      storage.py
  frontend/
    index.html
  docs/
    ARCHITECTURE.md
  scripts/
    ingest_osm.py
    smoke_test.py
  data/
  runs/
```

## 15. Implementation roadmap

Phase 0: working integrated prototype. Done in this package.
Phase 1: real OSM road ingestion and cached routing.
Phase 2: ACS/LODES population synthesis.
Phase 3: baseline calibration harness.
Phase 4: scenario comparison engine.
Phase 5: WebGL frontend and heatmaps.
Phase 6: validation reports and uncertainty bands.
Phase 7: packaged desktop/local deployment.

## 16. Exact build sequence

1. Lock entity schema.
2. Build run/replay store.
3. Generate synthetic population.
4. Assign schedules and destinations.
5. Add movement loop.
6. Add scenario injection.
7. Add metrics.
8. Add resident inspection.
9. Add frontend map.
10. Add WebSocket streaming.
11. Add smoke test.
12. Replace fallback geography with OSM graph.
13. Replace seeded synthetic distribution with ACS/LODES synthesis.
14. Add calibration.
15. Add comparative run engine.

## 17. MVP milestones

MVP-0: this package: living map, synthetic residents, injection, metrics, replay.
MVP-1: OSM-routed road movement.
MVP-2: ACS/LODES calibrated population.
MVP-3: baseline calibration report.
MVP-4: baseline-vs-intervention comparison.
MVP-5: scalable WebGL visualization.

## 18. Critical risks/pitfalls

- Mistaking plausible animation for validated simulation.
- Claiming policy prediction without calibration.
- Recreating or implying real individuals.
- Rendering too many agents directly.
- Coupling behavior code into geographic substrate.
- Using opaque AI decisions where deterministic rules are required.
- Overfitting to weak target data.

## 19. Validation methodology

Every scenario result should report:
- baseline manifest id
- intervention manifest id
- target datasets used
- metrics compared
- ensemble size
- random seeds
- uncertainty bands
- known missing data
- confidence level

Validation gates:
- Gate 1: geography loaded
- Gate 2: population distribution matches targets
- Gate 3: OD/workflow matches LODES within tolerance
- Gate 4: baseline movement timings plausible
- Gate 5: scenario deltas directionally stable across seed ensemble

## 20. Working code

The working code is in this package. Start with `README.md` and `scripts/smoke_test.py`.
