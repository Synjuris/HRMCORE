@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

set LOG=runs\calibration_launcher.log
if not exist runs mkdir runs

echo ============================================================
echo Living Jackson - Real Data Calibration Launcher
echo Folder: %CD%
echo Log: %LOG%
echo ============================================================
echo.

echo [%date% %time%] Starting calibration launcher > "%LOG%"

REM Find Python. Windows often has py.exe even when python.exe is not on PATH.
set PYTHON_CMD=
where py >nul 2>nul
if %errorlevel%==0 set PYTHON_CMD=py -3
if not defined PYTHON_CMD (
  where python >nul 2>nul
  if !errorlevel!==0 set PYTHON_CMD=python
)

if not defined PYTHON_CMD (
  echo ERROR: Python was not found.
  echo.
  echo Install Python from https://www.python.org/downloads/windows/
  echo During install, check: Add python.exe to PATH
  echo.
  echo ERROR: Python not found. >> "%LOG%"
  pause
  exit /b 1
)

echo Using Python command: %PYTHON_CMD%
echo Using Python command: %PYTHON_CMD% >> "%LOG%"
%PYTHON_CMD% --version >> "%LOG%" 2>&1
%PYTHON_CMD% --version

echo.
echo Installing required Python packages for calibration/reporting...
echo Installing required Python packages... >> "%LOG%"
%PYTHON_CMD% -m pip install --upgrade pip >> "%LOG%" 2>&1
%PYTHON_CMD% -m pip install pandas numpy scipy pyyaml requests >> "%LOG%" 2>&1
if errorlevel 1 (
  echo.
  echo ERROR: Package install failed. See %LOG%
  type "%LOG%"
  pause
  exit /b 2
)

echo.
echo Fetching real public data targets...
echo Fetching real public data targets... >> "%LOG%"
%PYTHON_CMD% scripts\fetch_real_data.py >> "%LOG%" 2>&1
if errorlevel 1 (
  echo.
  echo ERROR: Real-data fetch failed. See %LOG%
  echo.
  type "%LOG%"
  echo.
  echo Common causes: no internet, Census/LODES server unavailable, corporate/firewall block.
  pause
  exit /b 3
)

echo.
echo Running calibration report...
echo Running calibration report... >> "%LOG%"
%PYTHON_CMD% -m calibration.report --baseline configs\baseline.yaml >> "%LOG%" 2>&1
if errorlevel 1 (
  echo.
  echo ERROR: Calibration report failed. See %LOG%
  echo.
  type "%LOG%"
  pause
  exit /b 4
)

echo.
echo ============================================================
echo DONE. Calibration completed.
echo The report path is printed near the bottom of this log:
echo %LOG%
echo ============================================================
echo.
type "%LOG%"
echo.
pause
