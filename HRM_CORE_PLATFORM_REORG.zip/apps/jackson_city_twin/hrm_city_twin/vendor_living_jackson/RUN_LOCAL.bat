@echo off
cd /d "%~dp0"
echo Installing requirements...
py -3 -m pip install -r requirements.txt
if errorlevel 1 pause & exit /b 1
echo.
echo Starting Living Jackson on this computer and local Wi-Fi...
echo Open on this computer: http://127.0.0.1:8000
echo Open on your phone: use this computer's IPv4 address, for example http://192.168.1.25:8000
echo.
py -3 run_living_jackson.py
pause
