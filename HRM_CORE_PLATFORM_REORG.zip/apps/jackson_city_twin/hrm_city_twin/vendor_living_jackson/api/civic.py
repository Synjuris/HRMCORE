"""api/civic.py — REST endpoints for civic data ingestion.

Endpoints:
  POST /api/civic/fetch          Pull fresh civic news (Claude web search or RSS fallback)
  GET  /api/civic/events         List cached civic events
  POST /api/civic/inject-all     Inject all cached events (above confidence threshold) into active sim
  POST /api/civic/inject/{id}    Inject a single cached event by source_id
  DELETE /api/civic/events       Clear civic event cache
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

# Lazy import sim — app.py sets the SIM global; we reference it at call time
import backend.app as _app_module

from backend.living_jackson.civic_ingest import (
    CivicEvent,
    fetch_civic_news,
    fetch_civic_news_rss,
    load_civic_events,
    save_civic_events,
    CIVIC_CACHE,
)

router = APIRouter(prefix="/api/civic", tags=["civic"])

ROOT = Path(__file__).resolve().parents[1]


def _get_api_key() -> Optional[str]:
    # Load from .env if not already in environment
    env_path = ROOT / ".env"
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            line = line.strip()
            if line.startswith("ANTHROPIC_API_KEY=") and "=" in line:
                val = line.split("=", 1)[1].strip().strip('"').strip("'")
                if val:
                    return val
    return os.environ.get("ANTHROPIC_API_KEY")


class FetchRequest(BaseModel):
    use_rss_fallback: bool = False
    min_confidence: float = 0.30
    queries: Optional[list[str]] = None


class InjectAllRequest(BaseModel):
    min_confidence: float = 0.40


@router.post("/fetch")
def civic_fetch(req: FetchRequest):
    """Pull real civic news and cache it. Uses Claude web search if API key present, else RSS."""
    api_key = _get_api_key()

    if req.use_rss_fallback or not api_key:
        events = fetch_civic_news_rss()
        source = "rss"
    else:
        events = fetch_civic_news(api_key, queries=req.queries)
        source = "claude_web_search"

    # Filter by confidence
    events = [e for e in events if e.confidence >= req.min_confidence]

    cache_path = save_civic_events(events)
    return {
        "ok": True,
        "source": source,
        "new_events": len(events),
        "cache_path": str(cache_path),
        "events": [_event_summary(e) for e in events],
    }


@router.get("/events")
def civic_events(min_confidence: float = 0.0):
    """List all cached civic events."""
    events = load_civic_events(min_confidence)
    return {
        "count": len(events),
        "events": [_event_summary(e) for e in events],
    }


@router.post("/inject-all")
def civic_inject_all(req: InjectAllRequest):
    """Inject all cached civic events above confidence threshold into active sim."""
    sim = _app_module.SIM
    events = load_civic_events(req.min_confidence)
    injected = []
    for ev in events:
        params = ev.to_inject_params()
        scenario = sim.inject(**params)
        injected.append({
            "civic_headline": ev.headline,
            "civic_type": ev.civic_type,
            "sim_event_id": scenario.id,
            "sim_kind": scenario.kind,
            "intensity": scenario.intensity,
        })
    return {"ok": True, "injected": len(injected), "events": injected}


@router.post("/inject/{source_id}")
def civic_inject_one(source_id: str):
    """Inject a single cached civic event by source_id."""
    events = load_civic_events()
    match = next((e for e in events if e.source_id == source_id), None)
    if not match:
        raise HTTPException(status_code=404, detail=f"No event with source_id={source_id}")
    sim = _app_module.SIM
    params = match.to_inject_params()
    scenario = sim.inject(**params)
    return {
        "ok": True,
        "civic_headline": match.headline,
        "sim_event_id": scenario.id,
        "sim_kind": scenario.kind,
        "intensity": scenario.intensity,
    }


@router.delete("/events")
def civic_clear():
    """Clear the civic event cache."""
    if CIVIC_CACHE.exists():
        CIVIC_CACHE.unlink()
    return {"ok": True, "message": "Civic event cache cleared."}


def _event_summary(e: CivicEvent) -> dict:
    return {
        "source_id": e.source_id,
        "headline": e.headline,
        "civic_type": e.civic_type,
        "sim_kind": e.sim_kind,
        "intensity": e.intensity,
        "duration_ticks": e.duration_ticks,
        "confidence": e.confidence,
        "source_url": e.source_url,
        "published_at": e.published_at,
        "summary": e.summary[:200],
    }
