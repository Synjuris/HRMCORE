"""
FastAPI router exposing run + metric data to the Lovable calibration dashboard.

Mount in your existing app:
    from api.runs import router as runs_router
    app.include_router(runs_router)

CORS (development): allow the Lovable preview URL.
    from fastapi.middleware.cors import CORSMiddleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],          # tighten for production
        allow_methods=["GET", "POST"],
        allow_headers=["*"],
    )
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

RUNS_DIR = Path(__file__).resolve().parent.parent / "runs"
BASELINE_POINTER = RUNS_DIR / "BASELINE"  # plain text file: run_id

router = APIRouter(prefix="/api", tags=["runs"])


class MetricDTO(BaseModel):
    name: str
    value: float
    direction: str
    unit: str
    notes: str = ""


class RunSummaryDTO(BaseModel):
    run_id: str
    name: str
    seed: int
    ticks: int
    event_hash: str
    elapsed_seconds: float
    metrics: list[MetricDTO]
    readiness: dict = {}


class LaunchRequest(BaseModel):
    manifest_yaml: str


def _load_run(run_id: str) -> dict:
    path = RUNS_DIR / run_id / "metrics.json"
    if not path.exists():
        raise HTTPException(404, f"run {run_id} not found")
    return json.loads(path.read_text())


@router.get("/runs", response_model=list[RunSummaryDTO])
def list_runs(limit: int = Query(50, le=500)) -> list[RunSummaryDTO]:
    if not RUNS_DIR.exists():
        return []
    items = []
    for run_dir in sorted(RUNS_DIR.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
        if not run_dir.is_dir():
            continue
        m = run_dir / "metrics.json"
        if not m.exists():
            continue
        data = json.loads(m.read_text())
        items.append(RunSummaryDTO(
            run_id=data["run_id"],
            name=data["manifest"]["name"],
            seed=data["manifest"]["seed"],
            ticks=data["manifest"]["ticks"],
            event_hash=data["event_hash"],
            elapsed_seconds=data["elapsed_seconds"],
            metrics=[MetricDTO(**m) for m in data["metrics"]],
            readiness=data.get("readiness", {}),
        ))
        if len(items) >= limit:
            break
    return items


@router.get("/runs/{run_id}", response_model=RunSummaryDTO)
def get_run(run_id: str) -> RunSummaryDTO:
    data = _load_run(run_id)
    return RunSummaryDTO(
        run_id=data["run_id"],
        name=data["manifest"]["name"],
        seed=data["manifest"]["seed"],
        ticks=data["manifest"]["ticks"],
        event_hash=data["event_hash"],
        elapsed_seconds=data["elapsed_seconds"],
        metrics=[MetricDTO(**m) for m in data["metrics"]],
        readiness=data.get("readiness", {}),
    )


@router.get("/runs/{run_id}/metrics", response_model=list[MetricDTO])
def get_run_metrics(run_id: str) -> list[MetricDTO]:
    data = _load_run(run_id)
    return [MetricDTO(**m) for m in data["metrics"]]


@router.get("/baseline", response_model=Optional[RunSummaryDTO])
def get_baseline() -> Optional[RunSummaryDTO]:
    if not BASELINE_POINTER.exists():
        return None
    return get_run(BASELINE_POINTER.read_text().strip())


@router.post("/runs", response_model=RunSummaryDTO)
def launch_run(req: LaunchRequest) -> RunSummaryDTO:
    """Synchronous launch — fine for short runs, swap for background task later."""
    import tempfile
    import yaml
    from calibration.loop import Manifest, evaluate

    with tempfile.NamedTemporaryFile("w", suffix=".yaml", delete=False) as f:
        f.write(req.manifest_yaml)
        path = Path(f.name)
    manifest = Manifest(**yaml.safe_load(path.read_text()))
    payload = evaluate(manifest)
    return RunSummaryDTO(
        run_id=payload["run_id"],
        name=payload["manifest"]["name"],
        seed=payload["manifest"]["seed"],
        ticks=payload["manifest"]["ticks"],
        event_hash=payload["event_hash"],
        elapsed_seconds=payload["elapsed_seconds"],
        metrics=[MetricDTO(**m) for m in payload["metrics"]],
        readiness=payload.get("readiness", {}),
    )


@router.get("/runs/{run_id}/ticks")
def get_ticks(run_id: str, from_tick: int = 0, to_tick: int = 1000):
    """Stub: return packed (resident_id, x, y) records for the renderer.

    Real implementation should stream a binary Float32 buffer:
        layout per resident per tick: [id:uint32, x:float32, y:float32]
    """
    raise HTTPException(501, "ticks streaming not yet wired — see Phase 3")


@router.get("/calibration/status")
def calibration_status():
    from calibration.targets import target_statuses
    return {"targets": target_statuses()}
