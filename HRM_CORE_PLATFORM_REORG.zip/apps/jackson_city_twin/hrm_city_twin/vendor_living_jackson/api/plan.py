"""api/plan.py — One Jackson Civic Master Plan scenario runner.

Endpoints:
  GET  /api/plan/info              Full scenario metadata + event list
  GET  /api/plan/phases            Phase summaries only
  POST /api/plan/inject/phase/{n}  Inject all events in phase N (1, 2, or 3)
  POST /api/plan/inject/event/{i}  Inject single event by global index
  POST /api/plan/inject/all        Inject every event across all phases
  GET  /api/plan/active            Events currently active in the sim
"""
from __future__ import annotations

import json
from pathlib import Path
from fastapi import APIRouter, HTTPException

import backend.app as _app_module

router = APIRouter(prefix="/api/plan", tags=["plan"])

SCENARIO_PATH = Path(__file__).resolve().parents[1] / "data" / "one_jackson_scenario.json"
_SCENARIO: dict | None = None


def _load() -> dict:
    global _SCENARIO
    if _SCENARIO is None:
        _SCENARIO = json.loads(SCENARIO_PATH.read_text())
    return _SCENARIO


def _all_events() -> list[dict]:
    """Flat list of all events across all phases, with phase metadata attached."""
    out = []
    for phase in _load()["phases"]:
        for ev in phase["events"]:
            out.append({**ev, "_phase": phase["phase"], "_phase_label": phase["label"]})
    return out


def _inject(ev: dict) -> dict:
    sim = _app_module.SIM
    scenario = sim.inject(
        kind=ev["kind"],
        label=ev["label"],
        intensity=ev["intensity"],
        duration=ev["duration"],
        params=ev.get("params", {}),
    )
    return {
        "sim_event_id": scenario.id,
        "kind": scenario.kind,
        "label": scenario.label,
        "intensity": scenario.intensity,
        "duration": ev["duration"],
        "phase": ev.get("_phase"),
        "chapter": ev.get("params", {}).get("chapter", ""),
    }


@router.get("/info")
def plan_info():
    s = _load()
    return {
        "name": s["name"],
        "source": s["source"],
        "description": s["description"],
        "total_events": sum(len(p["events"]) for p in s["phases"]),
        "phases": [
            {
                "phase": p["phase"],
                "label": p["label"],
                "description": p["description"],
                "event_count": len(p["events"]),
                "events": [
                    {
                        "index": i,
                        "kind": e["kind"],
                        "label": e["label"],
                        "intensity": e["intensity"],
                        "duration": e["duration"],
                        "chapter": e.get("params", {}).get("chapter", ""),
                        "action": e.get("params", {}).get("action", ""),
                        "sim_rationale": e.get("params", {}).get("sim_rationale", ""),
                    }
                    for i, e in enumerate(p["events"])
                ],
            }
            for p in s["phases"]
        ],
    }


@router.get("/phases")
def plan_phases():
    return [
        {
            "phase": p["phase"],
            "label": p["label"],
            "description": p["description"],
            "event_count": len(p["events"]),
        }
        for p in _load()["phases"]
    ]


@router.post("/inject/phase/{n}")
def inject_phase(n: int):
    phases = _load()["phases"]
    match = next((p for p in phases if p["phase"] == n), None)
    if not match:
        raise HTTPException(status_code=404, detail=f"Phase {n} not found")
    results = []
    for ev in match["events"]:
        results.append(_inject({**ev, "_phase": n}))
    return {
        "ok": True,
        "phase": n,
        "label": match["label"],
        "injected": len(results),
        "events": results,
    }


@router.post("/inject/event/{idx}")
def inject_event(idx: int):
    events = _all_events()
    if idx < 0 or idx >= len(events):
        raise HTTPException(status_code=404, detail=f"Event index {idx} out of range (0–{len(events)-1})")
    result = _inject(events[idx])
    return {"ok": True, **result}


@router.post("/inject/all")
def inject_all():
    results = []
    for ev in _all_events():
        results.append(_inject(ev))
    return {
        "ok": True,
        "injected": len(results),
        "events": results,
    }


@router.get("/active")
def active_events():
    sim = _app_module.SIM
    plan_events = [e for e in sim.active_events() if e.label.startswith("[PLAN")]
    return {
        "tick": sim.tick,
        "active_plan_events": len(plan_events),
        "events": [
            {
                "id": e.id,
                "label": e.label,
                "kind": e.kind,
                "intensity": e.intensity,
                "start_tick": e.start_tick,
                "end_tick": e.end_tick,
                "chapter": e.params.get("chapter", ""),
                "sim_rationale": e.params.get("sim_rationale", ""),
            }
            for e in plan_events
        ],
    }
