"""Living Jackson calibration API.

Adds browser/mobile-callable endpoints for:
- checking observed target status
- fetching real public calibration data
- running the calibration report

These endpoints are synchronous on purpose for this prototype. For production,
move fetch/report jobs into a background queue.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from calibration.targets import target_statuses

ROOT = Path(__file__).resolve().parent.parent
RUNS_DIR = ROOT / "runs"
ENV_PATH = ROOT / ".env"

router = APIRouter(prefix="/api/calibration", tags=["calibration"])


class CommandResult(BaseModel):
    ok: bool
    returncode: int
    command: list[str]
    stdout: str = ""
    stderr: str = ""


def _load_dotenv(path: Path = ENV_PATH) -> dict[str, str]:
    """Tiny .env reader to avoid adding another dependency."""
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def _redact(text: str, secrets: list[str]) -> str:
    out = text or ""
    for secret in secrets:
        if secret:
            out = out.replace(secret, "[REDACTED]")
    return out


def _run(cmd: list[str], timeout: int = 900) -> CommandResult:
    env = os.environ.copy()
    dotenv = _load_dotenv()
    env.update(dotenv)
    secret_values = [dotenv.get("CENSUS_API_KEY", ""), env.get("CENSUS_API_KEY", "")]
    proc = subprocess.run(
        cmd,
        cwd=ROOT,
        env=env,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    return CommandResult(
        ok=proc.returncode == 0,
        returncode=proc.returncode,
        command=cmd,
        stdout=_redact(proc.stdout, secret_values),
        stderr=_redact(proc.stderr, secret_values),
    )


@router.get("/status")
def status() -> dict[str, Any]:
    statuses = target_statuses()
    observed = sum(1 for t in statuses if t["status"] == "observed")
    return {
        "ok": True,
        "env_present": ENV_PATH.exists(),
        "census_key_present": bool(_load_dotenv().get("CENSUS_API_KEY") or os.environ.get("CENSUS_API_KEY")),
        "observed_targets": observed,
        "total_targets": len(statuses),
        "targets": statuses,
    }


@router.post("/fetch-real-data", response_model=CommandResult)
def fetch_real_data(skip_lodes: bool = False) -> CommandResult:
    cmd = [sys.executable, "scripts/fetch_real_data.py"]
    if skip_lodes:
        cmd.append("--skip-lodes")
    result = _run(cmd, timeout=1800)
    if not result.ok:
        # Return the command result instead of throwing away the useful log.
        return result
    return result


@router.post("/run-report", response_model=CommandResult)
def run_report() -> CommandResult:
    return _run([sys.executable, "-m", "calibration.report", "--baseline", "configs/baseline.yaml"], timeout=1800)


@router.get("/latest-report")
def latest_report() -> dict[str, Any]:
    reports = sorted(RUNS_DIR.glob("*/CALIBRATION_REPORT.md"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not reports:
        raise HTTPException(404, "No calibration report found yet. Run /api/calibration/run-report first.")
    path = reports[0]
    return {
        "run_id": path.parent.name,
        "path": str(path.relative_to(ROOT)),
        "markdown": path.read_text(encoding="utf-8"),
    }
