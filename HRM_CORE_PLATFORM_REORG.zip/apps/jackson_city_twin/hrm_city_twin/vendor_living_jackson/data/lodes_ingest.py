"""
LODES7 OD ingest for Madison County, TN (FIPS 47113).

LEHD Origin-Destination Employment Statistics give us home-block -> work-block
commute counts. We filter to Madison County and aggregate to the tract level
for use as a calibration target.

CLI:
    python -m data.lodes_ingest                 # latest available year, JT00
    python -m data.lodes_ingest --year 2021     # specific year
    python -m data.lodes_ingest --jobtype JT01  # primary jobs only

Output:
    cache/lodes/madison_tn_od_<year>_<jobtype>.parquet
        columns: home_tract, work_tract, jobs

Public API:
    load_od_matrix(year=None, jobtype="JT00") -> pandas.DataFrame
"""
from __future__ import annotations

import argparse
import gzip
import io
from pathlib import Path
from typing import Optional

import pandas as pd
import requests

CACHE_DIR = Path(__file__).resolve().parent.parent / "cache" / "lodes"
COUNTY_FIPS = "47113"            # Madison County, TN
STATE = "tn"
LATEST_YEAR_DEFAULT = 2021       # update when LEHD publishes a newer year
LODES_BASE = "https://lehd.ces.census.gov/data/lodes/LODES8"
# Note: LODES8 (released 2023+) is the current series. Old "LODES7" name kept
# in the docstring for continuity; the URL below is the live one.


def _od_url(year: int, jobtype: str) -> str:
    # main = intra-state commutes; aux = cross-state inbound
    return f"{LODES_BASE}/{STATE}/od/{STATE}_od_main_{jobtype}_{year}.csv.gz"


def _download(url: str) -> pd.DataFrame:
    r = requests.get(url, timeout=120)
    r.raise_for_status()
    with gzip.open(io.BytesIO(r.content), "rt") as f:
        return pd.read_csv(f, dtype={"w_geocode": str, "h_geocode": str})


def build_od(year: int = LATEST_YEAR_DEFAULT, jobtype: str = "JT00") -> pd.DataFrame:
    """Download state OD file, filter to Madison County, aggregate to tracts."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    out = CACHE_DIR / f"madison_tn_od_{year}_{jobtype}.parquet"
    if out.exists():
        return pd.read_parquet(out)

    df = _download(_od_url(year, jobtype))

    # Block GEOIDs are 15 chars: STATE(2) + COUNTY(3) + TRACT(6) + BLOCK(4)
    # County prefix is first 5 chars; tract prefix is first 11.
    df = df[(df["h_geocode"].str.startswith(COUNTY_FIPS)) |
            (df["w_geocode"].str.startswith(COUNTY_FIPS))].copy()
    df["home_tract"] = df["h_geocode"].str[:11]
    df["work_tract"] = df["w_geocode"].str[:11]
    od = (df.groupby(["home_tract", "work_tract"], as_index=False)["S000"]
            .sum()
            .rename(columns={"S000": "jobs"}))
    od.to_parquet(out, index=False)
    return od


def load_od_matrix(year: Optional[int] = None, jobtype: str = "JT00") -> pd.DataFrame:
    year = year or LATEST_YEAR_DEFAULT
    out = CACHE_DIR / f"madison_tn_od_{year}_{jobtype}.parquet"
    if not out.exists():
        return build_od(year, jobtype)
    return pd.read_parquet(out)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--year", type=int, default=LATEST_YEAR_DEFAULT)
    p.add_argument("--jobtype", default="JT00", choices=["JT00", "JT01", "JT02", "JT03"])
    args = p.parse_args()
    od = build_od(args.year, args.jobtype)
    intra = od[od["home_tract"].str.startswith(COUNTY_FIPS) &
               od["work_tract"].str.startswith(COUNTY_FIPS)]
    print(f"Madison County OD pairs: {len(od):,}")
    print(f"  intra-county pairs:    {len(intra):,}")
    print(f"  total jobs flow:       {int(od['jobs'].sum()):,}")
    print(f"  saved to: cache/lodes/madison_tn_od_{args.year}_{args.jobtype}.parquet")
