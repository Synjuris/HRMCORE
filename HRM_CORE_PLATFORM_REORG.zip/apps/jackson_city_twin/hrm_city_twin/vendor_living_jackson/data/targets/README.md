# Real observed target data

Calibration only earns confidence from real observed CSVs in this directory.
The simulator must not silently compare itself to itself.

## Fetch Census/LODES targets

```bash
python scripts/fetch_real_data.py
python -m calibration.report --baseline configs/baseline.yaml
```

The fetcher creates:

| File | Source | Required columns |
|---|---|---|
| `acs_tract_population.csv` | Census ACS 5-year B01003, Madison County TN tracts | `tract,total_pop` |
| `acs_commute_bands.csv` | Census ACS 5-year B08303, Jackson city TN | `minutes_midpoint,share` |
| `lodes_od.csv` | Census LEHD LODES8 TN OD main, filtered/aggregated to Madison County tract home/work flows | `home_tract,work_tract,jobs` |
| `aadt_counts.csv` | TDOT count-station export/manual mapping to simulator `link_id` | `link_id,observed_aadt` |

## Scope warning

This is a real-data calibration harness, but it is not yet a perfect municipal-boundary model:

- tract population is Madison County, TN, because tract-level Census API data is directly available;
- commute bands are Jackson city, TN place-level data;
- LODES OD is block-level Tennessee data aggregated to tract pairs where home or work is in Madison County;
- AADT is intentionally not invented. Populate `aadt_counts.csv` from TDOT data after you map count stations to simulator links.

Until city-boundary clipping and TDOT station mapping are implemented, treat results as **county/city hybrid calibration**, not final Jackson municipal calibration.
