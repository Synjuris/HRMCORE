"""
OSMnx-backed road network for Jackson, TN.

Replaces synthetic grid roads with the real OpenStreetMap network for
Madison County, TN. Caches GraphML + pickle to disk so subsequent runs
are offline.

CLI:
    python -m data.osmnx_graph            # build & cache
    python -m data.osmnx_graph --rebuild  # force re-download

Public API:
    load_graph() -> networkx.MultiDiGraph
    nearest_node(G, lat, lon) -> int
    shortest_path_time(G, src_node, dst_node) -> float  # minutes
    shortest_path_nodes(G, src_node, dst_node) -> list[int]
"""
from __future__ import annotations

import argparse
import pickle
from pathlib import Path
from typing import Optional

import networkx as nx

CACHE_DIR = Path(__file__).resolve().parent.parent / "cache" / "osmnx"
GRAPH_PKL = CACHE_DIR / "jackson_tn_drive.pkl"
GRAPH_GML = CACHE_DIR / "jackson_tn_drive.graphml"

# Madison County, TN — bounding box (north, south, east, west)
# Source: TIGER/Line 2023, FIPS 47113. Slight pad for boundary residents.
MADISON_BBOX = (35.79, 35.42, -88.55, -89.12)
PLACE_QUERY = "Madison County, Tennessee, USA"

# Free-flow travel-time assumption when OSM lacks maxspeed (mph)
DEFAULT_SPEED_MPH = 35.0


def _osmnx():
    import osmnx as ox  # imported lazily so the rest of the app doesn't pay the cost
    ox.settings.use_cache = True
    ox.settings.log_console = False
    return ox


def build_graph(rebuild: bool = False) -> nx.MultiDiGraph:
    """Download (or load cached) drivable road graph for Madison County, TN."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)

    if GRAPH_PKL.exists() and not rebuild:
        with GRAPH_PKL.open("rb") as f:
            return pickle.load(f)

    ox = _osmnx()
    try:
        G = ox.graph_from_place(PLACE_QUERY, network_type="drive", simplify=True)
    except Exception:
        # Fallback: bbox query is more tolerant of OSM Nominatim hiccups
        north, south, east, west = MADISON_BBOX
        G = ox.graph_from_bbox(north, south, east, west, network_type="drive", simplify=True)

    # Annotate edges with travel time in minutes for routing
    G = ox.add_edge_speeds(G, fallback=DEFAULT_SPEED_MPH)
    G = ox.add_edge_travel_times(G)

    # Convert seconds -> minutes (downstream code assumes minutes)
    for _, _, data in G.edges(data=True):
        if "travel_time" in data:
            data["travel_time_min"] = data["travel_time"] / 60.0

    with GRAPH_PKL.open("wb") as f:
        pickle.dump(G, f)
    ox.save_graphml(G, GRAPH_GML)
    return G


def load_graph() -> nx.MultiDiGraph:
    """Load cached graph, building it on first call."""
    if not GRAPH_PKL.exists():
        return build_graph()
    with GRAPH_PKL.open("rb") as f:
        return pickle.load(f)


def nearest_node(G: nx.MultiDiGraph, lat: float, lon: float) -> int:
    ox = _osmnx()
    return int(ox.distance.nearest_nodes(G, X=lon, Y=lat))


def shortest_path_nodes(G: nx.MultiDiGraph, src: int, dst: int) -> Optional[list[int]]:
    try:
        return nx.shortest_path(G, src, dst, weight="travel_time_min")
    except nx.NetworkXNoPath:
        return None


def shortest_path_time(G: nx.MultiDiGraph, src: int, dst: int) -> Optional[float]:
    """Minutes along the fastest path. None if unreachable."""
    try:
        return float(nx.shortest_path_length(G, src, dst, weight="travel_time_min"))
    except nx.NetworkXNoPath:
        return None


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--rebuild", action="store_true")
    args = p.parse_args()
    G = build_graph(rebuild=args.rebuild)
    print(f"Graph cached: {GRAPH_PKL}")
    print(f"  nodes: {G.number_of_nodes():,}")
    print(f"  edges: {G.number_of_edges():,}")
