"""
Synthesize a Madison County, TN resident population via Iterative Proportional
Fitting against ACS marginals.

Inputs:
    - PUMS person + household records for TN PUMAs covering Madison County
      (PUMA 4702400 in the 2020 vintage; verify for your ACS year).
    - ACS 5-year tract-level marginals for: total population, age bands,
      household income bands, household size.

Output:
    cache/synthpop/madison_tn_residents_<year>.parquet
        columns: resident_id, tract, age, sex, hh_income_band, hh_size, race,
                 worker_status, weight

CLI:
    python -m data.acs_pums_ipf --year 2022 --census-api-key <KEY>

NOTE: This module ships with the IPF skeleton and a small synthetic fixture so
tests run without a Census API key. Wire `_download_pums` and
`_download_acs_marginals` to live endpoints (or a local PUMS CSV) before
relying on the output for calibration.

Public API:
    load_residents(year=2022) -> pandas.DataFrame
    synthesize(year=2022, seed=42) -> pandas.DataFrame
"""
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

CACHE_DIR = Path(__file__).resolve().parent.parent / "cache" / "synthpop"
COUNTY_FIPS = "47113"
STATE_FIPS = "47"
TARGET_PUMAS = ["4702400"]  # West TN; verify against current Census vintage.

AGE_BANDS = [(0, 17), (18, 34), (35, 54), (55, 74), (75, 120)]
INCOME_BANDS = ["<25k", "25-50k", "50-75k", "75-100k", "100-150k", "150k+"]
HH_SIZE_BANDS = [1, 2, 3, 4, 5]  # 5 = 5+


# ----- IPF core --------------------------------------------------------------

def ipf(seed_table: np.ndarray,
        row_targets: np.ndarray,
        col_targets: np.ndarray,
        max_iter: int = 200,
        tol: float = 1e-4) -> np.ndarray:
    """Two-way IPF. Returns a fitted table with the given marginals.

    For >2 dims, apply IPF axis-by-axis in a loop (extend as needed).
    """
    T = seed_table.astype(float) + 1e-9
    for _ in range(max_iter):
        row_sums = T.sum(axis=1, keepdims=True)
        T *= (row_targets[:, None] / row_sums)
        col_sums = T.sum(axis=0, keepdims=True)
        T *= (col_targets[None, :] / col_sums)
        if (np.abs(T.sum(axis=1) - row_targets).max() < tol and
            np.abs(T.sum(axis=0) - col_targets).max() < tol):
            break
    return T


# ----- Data loaders (stubs — wire to live endpoints) -------------------------

def _download_pums(year: int, api_key: Optional[str]) -> pd.DataFrame:
    """TODO: Replace stub with real PUMS pull.

    Recommended: Census ACS PUMS API
      https://api.census.gov/data/{year}/acs/acs5/pums
    Or download flat CSVs from
      https://www2.census.gov/programs-surveys/acs/data/pums/{year}/5-Year/

    For now we emit a tiny synthetic frame so the IPF wiring is exercised
    end-to-end in tests.
    """
    rng = np.random.default_rng(0)
    n = 5_000
    return pd.DataFrame({
        "PUMA": rng.choice(TARGET_PUMAS, n),
        "AGEP": rng.integers(0, 95, n),
        "SEX": rng.choice([1, 2], n),
        "HINCP": rng.choice([15_000, 35_000, 60_000, 85_000, 120_000, 175_000], n),
        "NP": rng.integers(1, 7, n),
        "RAC1P": rng.choice([1, 2, 3, 6, 8, 9], n),
        "ESR": rng.choice([1, 2, 3, 6], n),  # employment status
        "PWGTP": rng.integers(5, 250, n),    # person weight
    })


def _download_acs_marginals(year: int, api_key: Optional[str]) -> pd.DataFrame:
    """TODO: Replace stub with real ACS 5-yr tract pulls.

    Tables of interest:
      B01001 (sex by age) -> age bands
      B19001 (HH income)   -> income bands
      B11016 (HH size)     -> household size
      B01003 (total pop)
    Endpoint: https://api.census.gov/data/{year}/acs/acs5

    Stub: deterministic synthetic tract marginals across 25 fake tracts.
    """
    rng = np.random.default_rng(1)
    tracts = [f"{COUNTY_FIPS}{i:06d}" for i in range(1, 26)]
    rows = []
    for t in tracts:
        pop = int(rng.integers(1_500, 5_500))
        age = rng.dirichlet(np.ones(len(AGE_BANDS))) * pop
        rows.append({"tract": t, "total_pop": pop,
                     **{f"age_{a}_{b}": int(c) for (a, b), c in zip(AGE_BANDS, age)}})
    return pd.DataFrame(rows)


# ----- Synthesis -------------------------------------------------------------

def _income_band(hincp: float) -> str:
    if hincp < 25_000: return "<25k"
    if hincp < 50_000: return "25-50k"
    if hincp < 75_000: return "50-75k"
    if hincp < 100_000: return "75-100k"
    if hincp < 150_000: return "100-150k"
    return "150k+"


def _age_band_idx(age: int) -> int:
    for i, (lo, hi) in enumerate(AGE_BANDS):
        if lo <= age <= hi:
            return i
    return len(AGE_BANDS) - 1


def synthesize(year: int = 2022,
               api_key: Optional[str] = None,
               seed: int = 42) -> pd.DataFrame:
    """Return a synthetic resident table fitted to ACS tract marginals."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)

    pums = _download_pums(year, api_key)
    marg = _download_acs_marginals(year, api_key)

    pums["age_band_idx"] = pums["AGEP"].map(_age_band_idx)

    residents = []
    rid = 0
    for _, row in marg.iterrows():
        tract = row["tract"]
        target_pop = int(row["total_pop"])
        age_targets = np.array(
            [row[f"age_{lo}_{hi}"] for lo, hi in AGE_BANDS], dtype=float
        )
        # Seed table: PUMS weights by (age_band, sex)
        seed_tab = (pums.groupby(["age_band_idx", "SEX"])["PWGTP"]
                        .sum().unstack(fill_value=0.0).values)
        sex_targets = np.array([target_pop * 0.49, target_pop * 0.51])
        fitted = ipf(seed_tab, age_targets, sex_targets)
        fitted_int = np.round(fitted).astype(int)

        for a_idx, (lo, hi) in enumerate(AGE_BANDS):
            for s_idx, sex in enumerate([1, 2]):
                n = int(fitted_int[a_idx, s_idx])
                if n <= 0:
                    continue
                # Sample concrete PUMS persons matching this cell
                pool = pums[(pums["age_band_idx"] == a_idx) & (pums["SEX"] == sex)]
                if len(pool) == 0:
                    continue
                picks = pool.sample(n=n, replace=True, weights="PWGTP",
                                    random_state=int(rng.integers(0, 2**31 - 1)))
                for _, p in picks.iterrows():
                    residents.append({
                        "resident_id": rid,
                        "tract": tract,
                        "age": int(p["AGEP"]),
                        "sex": int(p["SEX"]),
                        "hh_income_band": _income_band(float(p["HINCP"])),
                        "hh_size": int(min(p["NP"], 5)),
                        "race": int(p["RAC1P"]),
                        "worker_status": int(p["ESR"]),
                        "weight": 1.0,
                    })
                    rid += 1

    df = pd.DataFrame(residents)
    out = CACHE_DIR / f"madison_tn_residents_{year}.parquet"
    df.to_parquet(out, index=False)
    return df


def load_residents(year: int = 2022) -> pd.DataFrame:
    out = CACHE_DIR / f"madison_tn_residents_{year}.parquet"
    if not out.exists():
        return synthesize(year=year)
    return pd.read_parquet(out)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--year", type=int, default=2022)
    p.add_argument("--census-api-key", default=None)
    p.add_argument("--seed", type=int, default=42)
    args = p.parse_args()
    df = synthesize(args.year, args.census_api_key, args.seed)
    print(f"Synthesized {len(df):,} residents across {df['tract'].nunique()} tracts.")
    print(df.head())
