from __future__ import annotations

import os
import uvicorn
from backend.app import app

if __name__ == "__main__":
    # 0.0.0.0 lets another device on the same Wi-Fi, like your phone,
    # open the app using your laptop's local IP address.
    host = os.environ.get("LIVING_JACKSON_HOST", "0.0.0.0")
    port = int(os.environ.get("LIVING_JACKSON_PORT", "8000"))
    uvicorn.run(app, host=host, port=port)
