# Living Jackson Calibration Report

Run: `87474cd25811`
Manifest: `jackson_tn_baseline_v1`
Event hash: `ad9b81a307185eccfe6a7b3151fbbf8e71f2da2b756000db674204383757193f`

## Verdict: NOT CALIBRATED — executable prototype only

Calibration confidence: **0.000**
Observed target coverage: **0/4**
Raw fit score: **0.800**

## Metrics

| Metric | Value | Direction | Unit | Notes |
|---|---:|---|---|---|
| commute_time_ks | 0.9479 | lower_better | ks_stat | 0 = identical distributions, 1 = disjoint |
| tract_population_mape | 0.0000 | lower_better | % |  |
| od_flow_mae | 0.0000 | lower_better | workers/pair |  |
| od_flow_pearson | 1.0000 | higher_better | r |  |
| aadt_pearson | 0.8938 | higher_better | r | matched 3 links |

## Observed target files

| Target | Status | Rows | Path | Notes |
|---|---|---:|---|---|
| acs_tract_population | missing | 0 | `/mnt/data/lj_work/living_jackson_merged_build/data/targets/acs_tract_population.csv` | Census tract population targets for Jackson/Madison County. |
| lodes_od | missing | 0 | `/mnt/data/lj_work/living_jackson_merged_build/data/targets/lodes_od.csv` | LODES origin-destination worker flow matrix. |
| aadt | missing | 0 | `/mnt/data/lj_work/living_jackson_merged_build/data/targets/aadt_counts.csv` | Observed traffic counts for matched road links. |
| commute_bands | missing | 0 | `/mnt/data/lj_work/living_jackson_merged_build/data/targets/acs_commute_bands.csv` | ACS commute-time band midpoint/share distribution. |

## Interpretation

- If the verdict says NOT CALIBRATED, use the app for architecture/testing only, not policy claims.
- Add real CSVs under `data/targets/` to unlock observed-data scoring.
- A scenario result should not be treated as meaningful until confidence is at least moderate.