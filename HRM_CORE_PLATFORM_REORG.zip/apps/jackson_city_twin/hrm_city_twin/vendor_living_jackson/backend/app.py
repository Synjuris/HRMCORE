from __future__ import annotations
from fastapi import FastAPI, WebSocket
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from pathlib import Path
import asyncio
from .living_jackson.sim import LivingJacksonSim
from .living_jackson.city import JACKSON_BOUNDS, ALL_PLACES
from api.runs import router as runs_router
from api.calibration_api import router as calibration_router
from api.civic import router as civic_router
from api.plan import router as plan_router

ROOT=Path(__file__).resolve().parents[1]
app=FastAPI(title="Living Jackson Prototype")
app.mount("/static", StaticFiles(directory=ROOT/"frontend"), name="static")
app.include_router(runs_router)
app.include_router(calibration_router)
app.include_router(civic_router)
app.include_router(plan_router)
SIM=LivingJacksonSim(pop_size=5000, seed=42)

class NewRun(BaseModel):
    pop_size:int=5000; seed:int=42
class InjectReq(BaseModel):
    kind:str="road_closure"; label:str="Major disruption"; intensity:float=0.7; duration:int=180

@app.get("/")
def index(): return FileResponse(ROOT/"frontend"/"index.html")
@app.post("/api/run/new")
def new_run(req:NewRun):
    global SIM; SIM=LivingJacksonSim(req.pop_size, req.seed); return {"run_id":SIM.run_id,"pop_size":len(SIM.residents)}
@app.get("/api/city")
def city(): return {"bounds":JACKSON_BOUNDS,"places":[p.__dict__ for p in ALL_PLACES]}
@app.get("/api/state")
def state(): return {"run_id":SIM.run_id,"tick":SIM.tick,"metrics":SIM.metrics.__dict__,"residents":SIM.visible_residents(1200),"events":[e.__dict__ for e in SIM.events]}
@app.post("/api/step")
def step(n:int=1): return SIM.step(n)
@app.post("/api/inject")
def inject(req:InjectReq): return SIM.inject(req.kind, req.label, req.intensity, req.duration).__dict__
@app.get("/api/resident/{rid}")
def resident(rid:str): return SIM.inspect(rid)
@app.get("/api/replay")
def replay(): return {"run_id":SIM.run_id,"snapshots":SIM.replay()}

@app.websocket("/ws")
async def ws(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            SIM.step(1)
            await websocket.send_json({"tick":SIM.tick,"metrics":SIM.metrics.__dict__,"residents":SIM.visible_residents(900),"events":[e.__dict__ for e in SIM.events]})
            await asyncio.sleep(0.08)
    except Exception:
        await websocket.close()
