from __future__ import annotations
import sqlite3, json, time
from pathlib import Path

class Store:
    def __init__(self, path="runs/living_jackson.sqlite"):
        self.path=Path(path); self.path.parent.mkdir(parents=True, exist_ok=True); self.init()
    def conn(self): return sqlite3.connect(self.path)
    def init(self):
        with self.conn() as c:
            c.executescript('''
            create table if not exists runs(id text primary key, seed int, pop_size int, started_at real, status text);
            create table if not exists snapshots(run_id text, tick int, payload text, primary key(run_id,tick));
            create table if not exists events(run_id text, tick int, event_type text, payload text);
            create index if not exists idx_events_run_tick on events(run_id,tick);
            ''')
    def create_run(self, run_id, seed, pop_size):
        with self.conn() as c: c.execute("insert or replace into runs values(?,?,?,?,?)",(run_id,seed,pop_size,time.time(),"running"))
    def save_snapshot(self, run_id,tick,payload):
        with self.conn() as c: c.execute("insert or replace into snapshots values(?,?,?)",(run_id,tick,json.dumps(payload)))
    def event(self, run_id,tick,event_type,payload):
        with self.conn() as c: c.execute("insert into events values(?,?,?,?)",(run_id,tick,event_type,json.dumps(payload)))
    def snapshots(self, run_id):
        with self.conn() as c:
            return [{"tick":r[0],"payload":json.loads(r[1])} for r in c.execute("select tick,payload from snapshots where run_id=? order by tick",(run_id,))]
