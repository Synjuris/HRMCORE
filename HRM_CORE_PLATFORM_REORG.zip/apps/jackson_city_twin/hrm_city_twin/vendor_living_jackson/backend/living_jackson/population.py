from __future__ import annotations
import random, math
from typing import List, Tuple
from .models import Household, Resident, uid
from .city import NEIGHBORHOOD_CENTERS, WORKPLACES, SCHOOLS, AMENITIES

FIRST = ["Alex","Jordan","Taylor","Morgan","Casey","Riley","Jamie","Avery","Drew","Skyler","Quinn","Reese"]
LAST = ["Carter","Harris","Miller","Johnson","Brown","Davis","Wilson","Moore","Taylor","Anderson"]

def clamp(v, lo, hi): return max(lo, min(hi, v))

def jitter(lat: float, lon: float, scale=0.018) -> Tuple[float,float]:
    return (lat + random.gauss(0, scale), lon + random.gauss(0, scale))

def weighted_choice(items):
    total = sum(x[-1] for x in items); r = random.random() * total; s = 0
    for item in items:
        s += item[-1]
        if r <= s: return item
    return items[-1]

def nearest_place(coord, places):
    return min(places, key=lambda p: (p.coord[0]-coord[0])**2 + (p.coord[1]-coord[1])**2)

def synthesize_population(pop_size=5000, seed=42):
    random.seed(seed)
    households: List[Household] = []
    residents: List[Resident] = []
    income_bands = ["low", "lower_middle", "middle", "upper_middle"]
    while len(residents) < pop_size:
        nname, lat, lon, _w = weighted_choice(NEIGHBORHOOD_CENTERS)
        hcoord = jitter(lat, lon)
        hh_size = random.choices([1,2,3,4,5], weights=[28,34,16,14,8])[0]
        hh = Household(uid("hh"), hcoord, nname, random.choices(income_bands, [30,32,28,10])[0])
        households.append(hh)
        for _ in range(hh_size):
            if len(residents) >= pop_size: break
            age = int(clamp(random.gauss(39, 23), 1, 90))
            if age < 18:
                dest = nearest_place(hcoord, SCHOOLS)
                kind = "school"
                depart, ret = random.randint(420,470), random.randint(890,980)
            elif age < 65:
                dest = random.choices(WORKPLACES, weights=[p.capacity for p in WORKPLACES])[0]
                kind = "work"
                depart, ret = random.randint(390,540), random.randint(960,1110)
            else:
                dest = random.choice(AMENITIES)
                kind = "errand"
                depart, ret = random.randint(540,720), random.randint(760,900)
            mode = random.choices(["car","walk","transit"], weights=[82,8,10])[0]
            r = Resident(
                id=uid("res"), name=f"{random.choice(FIRST)} {random.choice(LAST)}", age=age,
                household_id=hh.id, home=hcoord, destination_id=dest.id,
                destination_kind=kind, destination=dest.coord, mode=mode,
                schedule={"depart": depart, "return": ret}, current_pos=hcoord,
            )
            residents.append(r); hh.members.append(r.id)
    return households, residents
