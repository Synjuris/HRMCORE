from __future__ import annotations
from .models import Place, uid

# Jackson, Tennessee approximate bbox and civic anchors.
JACKSON_BOUNDS = {
    "north": 35.735,
    "south": 35.545,
    "east": -88.720,
    "west": -88.920,
    "center": (35.6145, -88.8139),
}

NEIGHBORHOOD_CENTERS = [
    ("Downtown", 35.6145, -88.8139, 0.12),
    ("North Jackson", 35.6800, -88.8350, 0.18),
    ("East Jackson", 35.6200, -88.7550, 0.14),
    ("South Jackson", 35.5700, -88.8150, 0.16),
    ("West Jackson", 35.6200, -88.8850, 0.16),
    ("Midtown", 35.6370, -88.8180, 0.14),
    ("Bemis", 35.5880, -88.8220, 0.10),
]

WORKPLACES = [
    Place(uid("pl"), "Downtown Commercial Core", "work", (35.6145, -88.8139), 9000),
    Place(uid("pl"), "North Jackson Retail Corridor", "work", (35.6710, -88.8520), 8000),
    Place(uid("pl"), "Jackson-Madison Medical District", "work", (35.6360, -88.8310), 6000),
    Place(uid("pl"), "Industrial / Logistics West", "work", (35.6160, -88.8950), 7000),
    Place(uid("pl"), "East Jackson Services", "work", (35.6110, -88.7600), 4000),
]

SCHOOLS = [
    Place(uid("pl"), "North Parkway School Cluster", "school", (35.6580, -88.8270), 2500),
    Place(uid("pl"), "South Jackson School Cluster", "school", (35.5755, -88.8125), 2500),
    Place(uid("pl"), "East Jackson School Cluster", "school", (35.6100, -88.7580), 2500),
    Place(uid("pl"), "West Jackson School Cluster", "school", (35.6200, -88.8840), 2500),
]

AMENITIES = [
    Place(uid("pl"), "Old Hickory Mall Area", "shopping", (35.6708, -88.8538), 6000),
    Place(uid("pl"), "Downtown Jackson", "shopping", (35.6145, -88.8139), 4000),
    Place(uid("pl"), "Jackson General Hospital", "hospital", (35.6360, -88.8310), 2000),
    Place(uid("pl"), "Cypress Grove Park", "park", (35.6636, -88.8130), 1500),
    Place(uid("pl"), "Union University Area", "education", (35.6762, -88.8581), 4000),
]

ALL_PLACES = WORKPLACES + SCHOOLS + AMENITIES
