from __future__ import annotations
import random, time
from dataclasses import asdict
from typing import Dict, List, Optional
from .models import Resident, ScenarioEvent, Metrics, uid
from .population import synthesize_population
from .routing import route, point_on_route
from .storage import Store

class LivingJacksonSim:
    def __init__(self, pop_size=5000, seed=42, run_id: Optional[str]=None):
        self.seed=seed; random.seed(seed); self.run_id=run_id or uid("run")
        self.households, self.residents = synthesize_population(pop_size, seed)
        self.resident_index: Dict[str, Resident] = {r.id:r for r in self.residents}
        self.tick=0; self.events: List[ScenarioEvent]=[]; self.metrics=Metrics()
        self.trip_progress: Dict[str,float] = {r.id:0.0 for r in self.residents}
        self.returning: Dict[str,bool] = {r.id:False for r in self.residents}
        self.store=Store(); self.store.create_run(self.run_id, seed, pop_size)
        self.save_snapshot()

    def active_events(self):
        return [e for e in self.events if e.start_tick <= self.tick and (e.end_tick is None or self.tick <= e.end_tick)]

    def inject(self, kind="road_closure", label="Scenario event", intensity=0.5, duration=180, params=None):
        ev=ScenarioEvent(uid("evt"), kind, label, self.tick, self.tick+duration if duration else None, max(0,min(1,intensity)), params=params or {})
        self.events.append(ev); self.store.event(self.run_id,self.tick,"scenario_injected",asdict(ev)); return ev

    def disruption_factor(self, r: Resident) -> float:
        f=0.0
        for ev in self.active_events():
            if ev.kind == "road_closure":
                # stronger for car commuters going through downtown/north corridors
                f=max(f, ev.intensity * (1.0 if r.mode=="car" else 0.45))
            elif ev.kind == "fuel_spike":
                f=max(f, ev.intensity * (0.8 if r.mode=="car" else 0.1))
            elif ev.kind == "school_closure" and r.destination_kind=="school":
                f=max(f, ev.intensity)
            elif ev.kind == "festival":
                f=max(f, ev.intensity*0.35)
        return max(0,min(0.95,f))

    def step_resident(self, r: Resident):
        minute=self.tick % 1440
        target = r.destination
        returning = self.returning[r.id]
        if r.destination_kind == "school" and any(e.kind=="school_closure" for e in self.active_events()):
            r.status="home_school_closed"; r.current_pos=r.home; r.stress=min(1,r.stress+0.002); return 0.0
        if minute < r.schedule["depart"]:
            r.status="home"; r.current_pos=r.home; self.trip_progress[r.id]=0; self.returning[r.id]=False; r.stress=max(0.02,r.stress-0.001); return 0
        if r.schedule["depart"] <= minute < r.schedule["return"] and not returning:
            target=r.destination; start=r.home; r.status="commuting_out"
        elif minute >= r.schedule["return"]:
            target=r.home; start=r.destination; r.status="commuting_home"; self.returning[r.id]=True
        else:
            r.status = "at_school" if r.destination_kind=="school" else ("at_work" if r.destination_kind=="work" else "shopping")
            r.current_pos=r.destination; r.stress=max(0.02,r.stress-0.0005); return 0
        disrupt=self.disruption_factor(r); speed = {"car":0.018,"transit":0.012,"walk":0.006}.get(r.mode,0.012) * (1-disrupt)
        pts=route(round(start[0],5),round(start[1],5),round(target[0],5),round(target[1],5))
        p=self.trip_progress[r.id]+speed
        self.trip_progress[r.id]=min(1,p)
        r.current_pos=point_on_route(pts, self.trip_progress[r.id])
        if disrupt>0.35: r.stress=min(1.0, r.stress + 0.003 + disrupt*0.004)
        else: r.stress=max(0.02, r.stress-0.0002)
        if self.trip_progress[r.id]>=1:
            r.status = "home" if target==r.home else ("at_school" if r.destination_kind=="school" else "at_work")
            if target==r.home: self.trip_progress[r.id]=0
        if self.tick % 15 == 0: r.movement_history.append(r.current_pos); r.movement_history=r.movement_history[-96:]
        return disrupt

    def social_tick(self):
        # light modular Layer 2: residents in same rounded cell become more familiar; stress spreads slightly.
        if self.tick % 20: return
        buckets={}
        for r in self.residents[::max(1,len(self.residents)//2000)]:
            key=(round(r.current_pos[0],3), round(r.current_pos[1],3)); buckets.setdefault(key,[]).append(r)
        for group in buckets.values():
            if len(group)<2: continue
            for a,b in zip(group, group[1:]):
                rel=a.relationships.setdefault(b.id, __import__('backend.living_jackson.models', fromlist=['RelationshipState']).RelationshipState())
                rel.interactions+=1; rel.familiarity=min(1,rel.familiarity+0.02); rel.trust=min(1, rel.trust+0.003)
                avg=(a.stress+b.stress)/2; a.stress=a.stress*0.98+avg*0.02; b.stress=b.stress*0.98+avg*0.02

    def step(self, n=1):
        for _ in range(n):
            delay_sum=0.0
            counts={"moving":0,"at_work":0,"at_school":0,"at_home":0,"shopping":0}
            for r in self.residents:
                d=self.step_resident(r); delay_sum+=d
                if r.status.startswith("commuting"): counts["moving"]+=1
                elif r.status=="at_work": counts["at_work"]+=1
                elif r.status=="at_school": counts["at_school"]+=1
                elif r.status.startswith("home"): counts["at_home"]+=1
                elif r.status=="shopping": counts["shopping"]+=1
            self.social_tick()
            avg_stress=sum(r.stress for r in self.residents)/len(self.residents)
            avg_delay=delay_sum/len(self.residents)
            self.metrics=Metrics(self.tick, avg_stress, avg_delay, counts["moving"], counts["at_work"], counts["at_school"], counts["at_home"], counts["shopping"], min(1,counts["moving"]/max(1,len(self.residents))*2.2 + avg_delay), len(self.active_events()))
            if self.tick % 10 == 0: self.save_snapshot()
            self.tick+=1
        return asdict(self.metrics)

    def visible_residents(self, limit=1000):
        stride=max(1, len(self.residents)//limit)
        return [{"id":r.id,"name":r.name,"lat":r.current_pos[0],"lon":r.current_pos[1],"status":r.status,"stress":round(r.stress,3),"mode":r.mode} for r in self.residents[::stride]][:limit]

    def inspect(self, rid):
        r=self.resident_index[rid]; return r.public_dict()

    def save_snapshot(self):
        payload={"run_id":self.run_id,"tick":self.tick,"metrics":asdict(self.metrics),"sample":self.visible_residents(500)}
        self.store.save_snapshot(self.run_id,self.tick,payload)

    def replay(self): return self.store.snapshots(self.run_id)
