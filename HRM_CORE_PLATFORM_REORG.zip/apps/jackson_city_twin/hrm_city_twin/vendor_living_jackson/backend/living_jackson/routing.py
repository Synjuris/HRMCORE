from __future__ import annotations
from functools import lru_cache
from typing import Tuple, List
Coord = Tuple[float,float]
DOWNTOWN=(35.6145,-88.8139)
NORTH=(35.675,-88.845); SOUTH=(35.570,-88.815); EAST=(35.615,-88.755); WEST=(35.620,-88.890)

def lerp(a,b,t): return a+(b-a)*t

def dist(a:Coord,b:Coord)->float: return ((a[0]-b[0])**2+(a[1]-b[1])**2)**0.5

@lru_cache(maxsize=200000)
def route(a_lat:float,a_lon:float,b_lat:float,b_lon:float)->tuple[Coord,...]:
    a=(a_lat,a_lon); b=(b_lat,b_lon)
    # corridor route: home -> nearest arterial -> downtown-ish transfer -> destination arterial -> destination
    anchors=[NORTH,SOUTH,EAST,WEST,DOWNTOWN]
    aa=min(anchors, key=lambda x:dist(a,x)); bb=min(anchors, key=lambda x:dist(b,x))
    pts=[a, aa]
    if aa != bb: pts.append(DOWNTOWN); pts.append(bb)
    pts.append(b)
    dense=[]
    for p,q in zip(pts, pts[1:]):
        steps=max(3,int(dist(p,q)/0.004))
        for i in range(steps): dense.append((lerp(p[0],q[0],i/steps), lerp(p[1],q[1],i/steps)))
    dense.append(b)
    return tuple(dense)

def point_on_route(points:List[Coord]|tuple[Coord,...], progress:float)->Coord:
    if not points: return (0,0)
    idx=min(len(points)-1, max(0, int(progress*(len(points)-1))))
    return points[idx]
