from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Tuple
import uuid

Coord = Tuple[float, float]  # lat, lon


def uid(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:10]}"


@dataclass
class Household:
    id: str
    coord: Coord
    tract: str
    income_band: str
    members: List[str] = field(default_factory=list)


@dataclass
class Place:
    id: str
    name: str
    kind: str
    coord: Coord
    capacity: int = 100


@dataclass
class RelationshipState:
    trust: float = 0.50
    familiarity: float = 0.00
    avoidance: float = 0.00
    interactions: int = 0


@dataclass
class Resident:
    id: str
    name: str
    age: int
    household_id: str
    home: Coord
    destination_id: str
    destination_kind: str
    destination: Coord
    mode: str
    schedule: Dict[str, int]
    current_pos: Coord
    status: str = "home"
    stress: float = 0.10
    trust: float = 0.50
    routine_adaptation: float = 0.00
    movement_history: List[Coord] = field(default_factory=list)
    relationships: Dict[str, RelationshipState] = field(default_factory=dict)

    def public_dict(self) -> dict:
        d = asdict(self)
        # keep inspection readable
        d["relationships"] = {k: asdict(v) for k, v in list(self.relationships.items())[:12]}
        return d


@dataclass
class ScenarioEvent:
    id: str
    kind: str
    label: str
    start_tick: int
    end_tick: Optional[int]
    intensity: float
    geometry: Optional[dict] = None
    params: Dict[str, float | str | int] = field(default_factory=dict)


@dataclass
class Metrics:
    tick: int = 0
    avg_stress: float = 0.0
    avg_delay: float = 0.0
    moving: int = 0
    at_work: int = 0
    at_school: int = 0
    at_home: int = 0
    shopping: int = 0
    congestion_index: float = 0.0
    active_events: int = 0
