"""civic_ingest.py — Real-world civic data ingestion for Living Jackson.

Pulls news, city council decisions, tax changes, elections, and other
civic events from public sources, classifies them, and converts them into
ScenarioEvent parameters that the sim can absorb.

Sources consumed:
  - Jackson Sun / local news via web search (Claude API tool-use)
  - Jackson City Council meeting records (city website scrape)
  - Tennessee state legislature RSS
  - Madison County election commission

Event taxonomy → sim mapping:
  tax_hike         → fuel_spike (purchasing-power reduction, car/commute stress)
  road_project     → road_closure (construction disruption, rerouting)
  school_policy    → school_closure (attendance policy changes)
  election         → festival (civic participation bump, commute variation)
  infrastructure   → road_closure (utility work, bridge inspection, etc.)
  public_health    → school_closure (disease, weather emergency)
  economic_news    → fuel_spike (job announcements, plant closures affect commute)
  festival_event   → festival (fairs, parades, sporting events)
"""
from __future__ import annotations

import json
import os
import re
import time
import urllib.request
import urllib.parse
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

ROOT = Path(__file__).resolve().parents[2]

# ── Event taxonomy ────────────────────────────────────────────────────────────

EVENT_MAP = {
    "tax_hike":        {"kind": "fuel_spike",      "base_intensity": 0.45, "base_duration": 2880},
    "road_project":    {"kind": "road_closure",     "base_intensity": 0.55, "base_duration": 720},
    "school_policy":   {"kind": "school_closure",   "base_intensity": 0.70, "base_duration": 480},
    "election":        {"kind": "festival",         "base_intensity": 0.30, "base_duration": 180},
    "infrastructure":  {"kind": "road_closure",     "base_intensity": 0.40, "base_duration": 360},
    "public_health":   {"kind": "school_closure",   "base_intensity": 0.80, "base_duration": 1440},
    "economic_news":   {"kind": "fuel_spike",       "base_intensity": 0.35, "base_duration": 1440},
    "festival_event":  {"kind": "festival",         "base_intensity": 0.50, "base_duration": 240},
}

CIVIC_KEYWORDS = {
    "tax_hike":       ["property tax", "tax increase", "millage", "tax hike", "budget increase", "fee increase", "sales tax"],
    "road_project":   ["road closure", "construction", "bridge", "lane closure", "road work", "paving", "highway", "interstate"],
    "school_policy":  ["school closure", "snow day", "district", "JMCSS", "school board", "attendance", "early dismissal"],
    "election":       ["election", "ballot", "candidate", "vote", "primary", "runoff", "city council race", "mayor"],
    "infrastructure": ["water main", "sewer", "utility", "power outage", "gas line", "sidewalk", "signal light"],
    "public_health":  ["health alert", "outbreak", "quarantine", "shelter in place", "emergency declaration", "tornado warning"],
    "economic_news":  ["plant closure", "layoffs", "hiring", "new employer", "economic development", "job announcement"],
    "festival_event": ["festival", "parade", "fair", "concert", "race", "marathon", "street closure for event", "world's longest"],
}


@dataclass
class CivicEvent:
    """A classified real-world civic event ready for sim injection."""
    source_id: str
    headline: str
    summary: str
    civic_type: str
    sim_kind: str
    intensity: float
    duration_ticks: int
    confidence: float          # 0-1 classification confidence
    source_url: str = ""
    published_at: str = ""
    fetched_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    raw_text: str = ""

    def to_inject_params(self) -> dict:
        """Returns kwargs ready for SIM.inject()."""
        return {
            "kind": self.sim_kind,
            "label": f"[CIVIC] {self.headline[:60]}",
            "intensity": self.intensity,
            "duration": self.duration_ticks,
            "params": {
                "civic_type": self.civic_type,
                "source_url": self.source_url,
                "confidence": self.confidence,
                "headline": self.headline,
            },
        }


# ── Classification ────────────────────────────────────────────────────────────

def classify_text(text: str) -> tuple[str, float]:
    """Keyword-based classifier. Returns (civic_type, confidence)."""
    text_lower = text.lower()
    scores: dict[str, int] = {}
    for civic_type, keywords in CIVIC_KEYWORDS.items():
        hit = sum(1 for kw in keywords if kw in text_lower)
        if hit:
            scores[civic_type] = hit
    if not scores:
        return "economic_news", 0.20   # fallback with low confidence
    best = max(scores, key=lambda k: scores[k])
    total_hits = sum(scores.values())
    confidence = min(0.95, scores[best] / max(1, total_hits) + 0.15 * scores[best])
    return best, round(confidence, 3)


def intensity_from_text(text: str, base: float) -> float:
    """Nudge intensity up/down based on severity language in headline/summary."""
    text_lower = text.lower()
    if any(w in text_lower for w in ["major", "emergency", "shut down", "complete", "all lanes", "indefinitely"]):
        base = min(0.95, base + 0.20)
    elif any(w in text_lower for w in ["minor", "temporary", "brief", "partial", "small"]):
        base = max(0.10, base - 0.15)
    return round(base, 3)


# ── News fetch (Claude API + web_search) ─────────────────────────────────────

CLAUDE_API_URL = "https://api.anthropic.com/v1/messages"
JACKSON_QUERIES = [
    "Jackson Tennessee city council news 2025",
    "Jackson TN road closure construction 2025",
    "Jackson Tennessee school district news",
    "Jackson TN property tax increase 2025",
    "Madison County Tennessee election news",
    "Jackson Tennessee festival event 2025",
    "Jackson TN economic development news",
]


def _claude_web_search(query: str, api_key: str) -> list[dict]:
    """Call Claude with web_search tool, parse out results."""
    payload = {
        "model": "claude-sonnet-4-20250514",
        "max_tokens": 1500,
        "tools": [{"type": "web_search_20250305", "name": "web_search"}],
        "messages": [{
            "role": "user",
            "content": (
                f"Search for: {query}\n\n"
                "Return a JSON array of news items found. Each item: "
                "{\"headline\": str, \"summary\": str (2-3 sentences), \"url\": str, \"published_date\": str}. "
                "Only include items relevant to Jackson, Tennessee civic life. "
                "Return ONLY the JSON array, no markdown, no preamble."
            )
        }]
    }
    req = urllib.request.Request(
        CLAUDE_API_URL,
        data=json.dumps(payload).encode(),
        headers={
            "Content-Type": "application/json",
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "anthropic-beta": "interleaved-thinking-2025-05-14",
        },
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read())
    except Exception as e:
        return [{"error": str(e), "query": query}]

    # Extract text blocks from response
    full_text = ""
    for block in data.get("content", []):
        if block.get("type") == "text":
            full_text += block.get("text", "")

    # Parse JSON from response
    try:
        # Strip markdown fences if present
        clean = re.sub(r"```json|```", "", full_text).strip()
        items = json.loads(clean)
        if isinstance(items, list):
            return items
    except (json.JSONDecodeError, ValueError):
        pass
    return []


def fetch_civic_news(api_key: str, queries: Optional[list[str]] = None, max_per_query: int = 5) -> list[CivicEvent]:
    """Pull civic news from web and classify into CivicEvents."""
    queries = queries or JACKSON_QUERIES
    events: list[CivicEvent] = []
    seen_headlines: set[str] = set()

    for i, query in enumerate(queries):
        raw_items = _claude_web_search(query, api_key)
        for item in raw_items[:max_per_query]:
            if "error" in item:
                continue
            headline = item.get("headline", "")
            if not headline or headline in seen_headlines:
                continue
            seen_headlines.add(headline)

            combined = f"{headline} {item.get('summary', '')}"
            civic_type, confidence = classify_text(combined)
            mapping = EVENT_MAP[civic_type]
            intensity = intensity_from_text(combined, mapping["base_intensity"])

            events.append(CivicEvent(
                source_id=f"web_{i}_{len(events)}",
                headline=headline,
                summary=item.get("summary", ""),
                civic_type=civic_type,
                sim_kind=mapping["kind"],
                intensity=intensity,
                duration_ticks=mapping["base_duration"],
                confidence=confidence,
                source_url=item.get("url", ""),
                published_at=item.get("published_date", ""),
                raw_text=combined,
            ))
        time.sleep(0.5)  # rate limit courtesy

    return events


# ── RSS / direct scrape fallback (no API key needed) ─────────────────────────

RSS_FEEDS = [
    # Jackson Sun RSS
    "https://www.jacksonsun.com/rss/",
    # TN state news
    "https://www.tn.gov/news.rss",
]


def _fetch_rss(url: str) -> list[dict]:
    """Minimal RSS parser — no lxml dependency."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "LivingJacksonCivic/1.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            xml = resp.read().decode("utf-8", errors="replace")
    except Exception:
        return []

    items = []
    for block in re.findall(r"<item>(.*?)</item>", xml, re.DOTALL):
        def extract(tag: str) -> str:
            m = re.search(rf"<{tag}[^>]*><!\[CDATA\[(.*?)\]\]></{tag}>", block, re.DOTALL)
            if m:
                return m.group(1).strip()
            m = re.search(rf"<{tag}[^>]*>(.*?)</{tag}>", block, re.DOTALL)
            return m.group(1).strip() if m else ""

        headline = extract("title")
        summary = re.sub(r"<[^>]+>", "", extract("description"))[:300]
        url_item = extract("link") or extract("guid")
        pub = extract("pubDate")
        if headline:
            items.append({"headline": headline, "summary": summary, "url": url_item, "published_date": pub})
    return items


def fetch_civic_news_rss(filter_jackson: bool = True) -> list[CivicEvent]:
    """Fallback: pull RSS feeds without API key, filter for Jackson TN relevance."""
    jackson_terms = ["jackson", "madison county", "jmcss", "jackson sun", "tn-82", "old hickory"]
    events: list[CivicEvent] = []
    seen: set[str] = set()

    for feed_url in RSS_FEEDS:
        for item in _fetch_rss(feed_url):
            headline = item.get("headline", "")
            if not headline or headline in seen:
                continue
            combined = f"{headline} {item.get('summary', '')}".lower()
            if filter_jackson and not any(t in combined for t in jackson_terms):
                continue
            seen.add(headline)

            civic_type, confidence = classify_text(combined)
            mapping = EVENT_MAP[civic_type]
            intensity = intensity_from_text(combined, mapping["base_intensity"])
            events.append(CivicEvent(
                source_id=f"rss_{len(events)}",
                headline=headline,
                summary=item.get("summary", ""),
                civic_type=civic_type,
                sim_kind=mapping["kind"],
                intensity=intensity,
                duration_ticks=mapping["base_duration"],
                confidence=confidence,
                source_url=item.get("url", ""),
                published_at=item.get("published_date", ""),
            ))
    return events


# ── Persistence ───────────────────────────────────────────────────────────────

CIVIC_CACHE = ROOT / "data" / "civic_events.json"


def save_civic_events(events: list[CivicEvent]) -> Path:
    CIVIC_CACHE.parent.mkdir(parents=True, exist_ok=True)
    existing: list[dict] = []
    if CIVIC_CACHE.exists():
        try:
            existing = json.loads(CIVIC_CACHE.read_text())
        except Exception:
            existing = []
    seen_ids = {e["source_id"] for e in existing}
    new_items = [asdict(e) for e in events if e.source_id not in seen_ids]
    existing.extend(new_items)
    CIVIC_CACHE.write_text(json.dumps(existing, indent=2))
    return CIVIC_CACHE


def load_civic_events(min_confidence: float = 0.0) -> list[CivicEvent]:
    if not CIVIC_CACHE.exists():
        return []
    raw = json.loads(CIVIC_CACHE.read_text())
    out = []
    for d in raw:
        try:
            ev = CivicEvent(**d)
            if ev.confidence >= min_confidence:
                out.append(ev)
        except (TypeError, KeyError):
            continue
    return out
