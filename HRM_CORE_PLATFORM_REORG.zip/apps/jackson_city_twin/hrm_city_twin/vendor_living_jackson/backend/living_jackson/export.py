from __future__ import annotations

import hashlib
import json
from dataclasses import asdict
from typing import Any

import pandas as pd

from .sim import LivingJacksonSim
from .city import JACKSON_BOUNDS
from calibration.targets import load_observed_targets


def _coord_to_synth_tract(lat: float, lon: float) -> str:
    """Stable placeholder tract bucket until real ACS tract polygons are wired.

    This does NOT claim true Census tract geography. It creates repeatable
    Madison-like tract IDs so the calibration pipeline can run end-to-end and
    later be swapped for TIGER/Line tract point-in-polygon assignment.
    """
    south, north = JACKSON_BOUNDS["south"], JACKSON_BOUNDS["north"]
    west, east = JACKSON_BOUNDS["west"], JACKSON_BOUNDS["east"]
    row = max(0, min(4, int(((lat - south) / max(1e-9, north - south)) * 5)))
    col = max(0, min(4, int(((lon - west) / max(1e-9, east - west)) * 5)))
    return f"47113{(row * 5 + col + 1):06d}"


def run_for_calibration(seed: int, ticks: int, pop_size: int = 5000, **params: Any) -> dict:
    """Run the current prototype and emit the fields expected by calibration.metrics.

    This is a bridge, not final scientific calibration. Outputs are deterministic
    and shaped like the real pipeline; the geographic targets remain placeholders
    until ACS/LODES/OSM ingestion is populated with verified public data.
    """
    sim = LivingJacksonSim(pop_size=pop_size, seed=seed)
    commute_minutes: list[float] = []

    for _ in range(int(ticks)):
        before = {r.id: r.status for r in sim.residents}
        sim.step(1)
        for r in sim.residents:
            if before[r.id].startswith("commuting") and not r.status.startswith("commuting"):
                depart = r.schedule.get("depart", 0)
                ret = r.schedule.get("return", 0)
                minute = sim.tick % 1440
                # approximate observed trip duration from schedule window when exact
                # route timing is unavailable in the prototype state.
                if minute >= ret:
                    commute_minutes.append(max(1.0, float(minute - ret + 1)))
                else:
                    commute_minutes.append(max(1.0, float(minute - depart + 1)))

    hh_tract = {h.id: h.tract if str(h.tract).startswith("47113") else _coord_to_synth_tract(*h.coord) for h in sim.households}
    rows=[]
    od_rows=[]
    for r in sim.residents:
        home_tract = hh_tract.get(r.household_id, _coord_to_synth_tract(*r.home))
        work_tract = _coord_to_synth_tract(*r.destination)
        rows.append({
            "resident_id": r.id,
            "tract": home_tract,
            "age": r.age,
            "worker_status": 1 if r.destination_kind == "work" else 0,
            "mode": r.mode,
            "stress": r.stress,
        })
        if r.destination_kind == "work":
            od_rows.append({"home_tract": home_tract, "work_tract": work_tract, "jobs": 1})

    sim_residents = pd.DataFrame(rows)
    observed_targets = load_observed_targets()
    acs_tract_pop = observed_targets.get("acs_tract_pop")
    if acs_tract_pop is None:
        acs_tract_pop = pd.DataFrame(columns=["tract", "total_pop"])
    sim_od = pd.DataFrame(od_rows)
    if len(sim_od):
        sim_od = sim_od.groupby(["home_tract","work_tract"], as_index=False)["jobs"].sum()
    else:
        sim_od = pd.DataFrame(columns=["home_tract","work_tract","jobs"])
    lodes_od = observed_targets.get("lodes_od")
    if lodes_od is None:
        lodes_od = pd.DataFrame(columns=["home_tract", "work_tract", "jobs"])
    sim_link_volumes = {
        "us45_north_jackson": float(sim.metrics.moving),
        "i40_exit_82_wb": float(sim.metrics.congestion_index * 1000),
        "us412_madison_co": float(sim.metrics.avg_delay * 10000),
    }

    event_stream = [asdict(e) for e in sim.events]
    event_stream.append({"tick": sim.tick, "metrics": asdict(sim.metrics), "seed": seed, "pop_size": pop_size})
    event_hash = hashlib.sha256(json.dumps(event_stream, sort_keys=True).encode()).hexdigest()

    if not commute_minutes:
        # fallback proxy: scheduled worker trips, minutes. Keeps KS metric defined.
        commute_minutes = [max(5.0, min(90.0, (r.schedule["return"] - r.schedule["depart"]) / 16.0)) for r in sim.residents if r.destination_kind == "work"]

    return {
        "event_hash": event_hash,
        "sim_commute_minutes": commute_minutes,
        "sim_residents": sim_residents,
        "acs_tract_pop": acs_tract_pop,
        "sim_od": sim_od,
        "lodes_od": lodes_od,
        "sim_link_volumes": sim_link_volumes,
        "aadt_observed": observed_targets.get("aadt_observed"),
        "commute_shares": observed_targets.get("commute_shares"),
        "commute_midpoints": observed_targets.get("commute_midpoints"),
    }
