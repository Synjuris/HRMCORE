#!/usr/bin/env bash
set -euo pipefail
python scripts/fetch_real_data.py
python -m calibration.report --baseline configs/baseline.yaml
