from __future__ import annotations
import math
from collections import defaultdict
from typing import Dict, Iterable, List, Tuple
from .models import Resident, RouteEdge

# Haversine distance in km.  Used as a dependency-free fallback when OSMNX data
# is unavailable.  OSM integration can be layered later without changing outputs.
def distance_km(a: Tuple[float,float], b: Tuple[float,float]) -> float:
    lat1, lon1 = map(math.radians, a)
    lat2, lon2 = map(math.radians, b)
    dlat, dlon = lat2-lat1, lon2-lon1
    h = math.sin(dlat/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2
    return 6371.0 * 2 * math.asin(math.sqrt(h))

def speed_kmh(mode: str) -> float:
    return {"car": 38.0, "transit": 22.0, "walk": 4.8}.get(mode, 30.0)

def build_routes(residents: Iterable[Resident]) -> List[RouteEdge]:
    buckets: Dict[tuple, RouteEdge] = {}
    for r in residents:
        d = distance_km(r.home, r.destination)
        minutes = (d / speed_kmh(r.mode)) * 60.0
        key = (r.neighborhood, r.destination_id, r.mode)
        if key not in buckets:
            buckets[key] = RouteEdge(r.neighborhood, r.destination_id, r.mode, round(d,3), round(minutes,2), 0)
        buckets[key].load += 1
    return sorted(buckets.values(), key=lambda e: (-e.load, e.origin_id, e.destination_id))

def commute_pressure_by_tick(residents: Iterable[Resident], tick: int) -> float:
    active = 0
    total = 0
    for r in residents:
        total += 1
        if abs(tick - r.schedule.get("depart", -9999)) <= 30 or abs(tick - r.schedule.get("return", -9999)) <= 30:
            active += 1
    return 0.0 if total == 0 else active / total
