from __future__ import annotations
from .models import Place

JACKSON_BOUNDS = {
    "north": 35.735,
    "south": 35.545,
    "east": -88.720,
    "west": -88.920,
    "center": (35.6145, -88.8139),
}

# Approximate anchors. These are seed geometry, not claimed parcel-level truth.
NEIGHBORHOOD_CENTERS = [
    ("Downtown", 35.6145, -88.8139, 0.12),
    ("North Jackson", 35.6800, -88.8350, 0.18),
    ("East Jackson", 35.6200, -88.7550, 0.14),
    ("South Jackson", 35.5700, -88.8150, 0.16),
    ("West Jackson", 35.6200, -88.8850, 0.16),
    ("Midtown", 35.6370, -88.8180, 0.14),
    ("Bemis", 35.5880, -88.8220, 0.10),
]

def pl(pid, name, kind, lat, lon, capacity, **tags):
    return Place(pid, name, kind, (lat, lon), capacity, tags)

WORKPLACES = [
    pl("work_downtown", "Downtown Commercial Core", "work", 35.6145, -88.8139, 9000, sector="commercial"),
    pl("work_north_retail", "North Jackson Retail Corridor", "work", 35.6710, -88.8520, 8000, sector="retail"),
    pl("work_medical", "Jackson-Madison Medical District", "work", 35.6360, -88.8310, 6000, sector="healthcare"),
    pl("work_west_industrial", "Industrial / Logistics West", "work", 35.6160, -88.8950, 7000, sector="industrial_logistics"),
    pl("work_east_services", "East Jackson Services", "work", 35.6110, -88.7600, 4000, sector="services"),
]

SCHOOLS = [
    pl("school_north", "North Parkway School Cluster", "school", 35.6580, -88.8270, 2500),
    pl("school_south", "South Jackson School Cluster", "school", 35.5755, -88.8125, 2500),
    pl("school_east", "East Jackson School Cluster", "school", 35.6100, -88.7580, 2500),
    pl("school_west", "West Jackson School Cluster", "school", 35.6200, -88.8840, 2500),
]

AMENITIES = [
    pl("amenity_mall", "Old Hickory Mall Area", "shopping", 35.6708, -88.8538, 6000),
    pl("amenity_downtown", "Downtown Jackson", "shopping", 35.6145, -88.8139, 4000),
    pl("amenity_hospital", "Jackson General Hospital", "hospital", 35.6360, -88.8310, 2000),
    pl("amenity_cypress", "Cypress Grove Park", "park", 35.6636, -88.8130, 1500),
    pl("amenity_union", "Union University Area", "education", 35.6762, -88.8581, 4000),
]

CIVIC_PLACES = [
    pl("civic_city_hall", "Jackson City Hall", "civic", 35.6140, -88.8130, 300),
    pl("civic_police", "Jackson Police / Public Safety Anchor", "civic", 35.6130, -88.8150, 500),
    pl("civic_transit", "Transit / Mobility Anchor", "civic", 35.6155, -88.8095, 500),
]

ALL_PLACES = WORKPLACES + SCHOOLS + AMENITIES + CIVIC_PLACES
