"""HRM City Twin layer.

This package adds a real-data-oriented city digital twin layer to HRM without
replacing the core HRM/DAS simulation engine.  It produces HRM-compatible
profiles, scenario files, population frames, commute schedules, and calibration
reports.
"""
from .models import Household, Place, Resident, RouteEdge, CityTwinSnapshot
from .jackson_tn import build_jackson_twin, run_jackson_city_twin
