from __future__ import annotations
from collections import Counter
from typing import Any, Dict, Iterable
from .models import Resident, RouteEdge

def pct(n, d):
    return 0.0 if d == 0 else round(100.0*n/d, 2)

def summarize_population(residents: Iterable[Resident]) -> Dict[str, Any]:
    rs = list(residents)
    n = len(rs)
    ages = Counter("under_18" if r.age < 18 else "working_age" if r.age < 65 else "senior" for r in rs)
    modes = Counter(r.mode for r in rs)
    dests = Counter(r.destination_kind for r in rs)
    incomes = Counter(r.income_band for r in rs)
    neighborhoods = Counter(r.neighborhood for r in rs)
    return {
        "population": n,
        "age_structure_pct": {k: pct(v,n) for k,v in ages.items()},
        "mode_share_pct": {k: pct(v,n) for k,v in modes.items()},
        "daily_destination_pct": {k: pct(v,n) for k,v in dests.items()},
        "income_band_pct": {k: pct(v,n) for k,v in incomes.items()},
        "neighborhood_share_pct": {k: pct(v,n) for k,v in neighborhoods.items()},
        "mean_stress": round(sum(r.stress for r in rs)/n,4) if n else 0.0,
        "mean_institutional_trust": round(sum(r.institutional_trust for r in rs)/n,4) if n else 0.0,
        "mean_uncertainty": round(sum(r.uncertainty for r in rs)/n,4) if n else 0.0,
    }

def summarize_routes(routes: Iterable[RouteEdge]) -> Dict[str, Any]:
    rt = list(routes)
    total_load = sum(r.load for r in rt)
    top = sorted(rt, key=lambda r: r.load, reverse=True)[:12]
    return {
        "route_count": len(rt),
        "total_assigned_commuters": total_load,
        "top_routes": [r.__dict__ for r in top],
        "mean_route_minutes_weighted": round(sum(r.minutes_typical*r.load for r in rt)/total_load,2) if total_load else 0.0,
    }

def build_calibration_report(residents, routes) -> Dict[str, Any]:
    return {
        "source_status": "synthetic_city_twin_seed; real-data adapters included when external datasets are available",
        "population_summary": summarize_population(residents),
        "routing_summary": summarize_routes(routes),
        "limitations": [
            "Current bundled run is dependency-free and uses anchor geometry, not parcel-level addresses.",
            "Census/LODES/OSM ingestion scripts are integrated as data adapters, but external downloads require internet and optional dependencies.",
            "Outputs are calibrated seed layers for HRM, not claims of exact individual people or exact household locations.",
        ],
    }
