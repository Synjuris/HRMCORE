from __future__ import annotations
import math, random, uuid
from typing import Iterable, List, Sequence, Tuple
from .models import Household, Resident, Place
from .jackson_static import NEIGHBORHOOD_CENTERS, WORKPLACES, SCHOOLS, AMENITIES

FIRST = ["Alex","Jordan","Taylor","Morgan","Casey","Riley","Jamie","Avery","Drew","Skyler","Quinn","Reese","Cameron","Parker","Hayden","Rowan"]
LAST = ["Carter","Harris","Miller","Johnson","Brown","Davis","Wilson","Moore","Taylor","Anderson","Walker","Hall","Allen","Young"]

def uid(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:10]}"

def clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))

def jitter(rng: random.Random, lat: float, lon: float, scale=0.018) -> Tuple[float,float]:
    return (lat + rng.gauss(0, scale), lon + rng.gauss(0, scale))

def weighted_choice(rng: random.Random, items: Sequence[tuple]):
    total = sum(x[-1] for x in items)
    r = rng.random() * total
    s = 0.0
    for item in items:
        s += item[-1]
        if r <= s:
            return item
    return items[-1]

def nearest_place(coord, places: Iterable[Place]) -> Place:
    return min(places, key=lambda p: (p.coord[0]-coord[0])**2 + (p.coord[1]-coord[1])**2)

def trait_profile(rng: random.Random, age: int, income_band: str) -> dict:
    economic_pressure = {"low":0.74,"lower_middle":0.55,"middle":0.36,"upper_middle":0.22}.get(income_band,0.45)
    institutional_baseline = {"low":0.42,"lower_middle":0.48,"middle":0.54,"upper_middle":0.58}.get(income_band,0.50)
    return {
        "economic_pressure": round(clamp(rng.gauss(economic_pressure, 0.08), 0, 1), 4),
        "mobility_dependence": round(clamp(rng.gauss(0.70 if age >= 18 else 0.45, 0.12), 0, 1), 4),
        "institutional_trust_baseline": round(clamp(rng.gauss(institutional_baseline, 0.12), 0, 1), 4),
        "routine_rigidity": round(clamp(rng.gauss(0.50, 0.18), 0, 1), 4),
    }

def synthesize_population(pop_size: int = 5000, seed: int = 42):
    rng = random.Random(seed)
    households: List[Household] = []
    residents: List[Resident] = []
    income_bands = ["low", "lower_middle", "middle", "upper_middle"]
    income_weights = [30, 32, 28, 10]
    while len(residents) < pop_size:
        nname, lat, lon, _w = weighted_choice(rng, NEIGHBORHOOD_CENTERS)
        hcoord = jitter(rng, lat, lon)
        hh_size = rng.choices([1,2,3,4,5], weights=[28,34,16,14,8])[0]
        income = rng.choices(income_bands, weights=income_weights)[0]
        hh = Household(uid("hh"), hcoord, nname, nname, income)
        households.append(hh)
        for _ in range(hh_size):
            if len(residents) >= pop_size:
                break
            age = int(clamp(rng.gauss(39, 23), 1, 90))
            if age < 18:
                dest = nearest_place(hcoord, SCHOOLS)
                kind = "school"
                depart, ret = rng.randint(420,470), rng.randint(890,980)
            elif age < 65:
                dest = rng.choices(WORKPLACES, weights=[p.capacity for p in WORKPLACES])[0]
                kind = "work"
                depart, ret = rng.randint(390,540), rng.randint(960,1110)
            else:
                dest = rng.choice(AMENITIES)
                kind = "errand"
                depart, ret = rng.randint(540,720), rng.randint(760,900)
            mode = rng.choices(["car","walk","transit"], weights=[82,8,10])[0]
            traits = trait_profile(rng, age, income)
            inst = traits["institutional_trust_baseline"]
            stress = clamp(0.08 + traits["economic_pressure"] * 0.18 + rng.gauss(0,0.03), 0, 1)
            r = Resident(
                id=uid("res"),
                name=f"{rng.choice(FIRST)} {rng.choice(LAST)}",
                age=age,
                household_id=hh.id,
                home=hcoord,
                neighborhood=nname,
                income_band=income,
                destination_id=dest.id,
                destination_kind=kind,
                destination=dest.coord,
                mode=mode,
                schedule={"depart": depart, "return": ret},
                current_pos=hcoord,
                stress=round(stress,4),
                trust=round(inst,4),
                institutional_trust=round(inst,4),
                uncertainty=round(clamp(0.20 + traits["economic_pressure"]*0.15 + rng.gauss(0,0.04),0,1),4),
                traits=traits,
            )
            residents.append(r)
            hh.members.append(r.id)
    return households, residents
