from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple

Coord = Tuple[float, float]  # lat, lon

@dataclass
class Household:
    id: str
    coord: Coord
    tract: str
    neighborhood: str
    income_band: str
    members: List[str] = field(default_factory=list)

@dataclass
class Place:
    id: str
    name: str
    kind: str
    coord: Coord
    capacity: int = 100
    tags: Dict[str, Any] = field(default_factory=dict)

@dataclass
class RouteEdge:
    origin_id: str
    destination_id: str
    mode: str
    distance_km: float
    minutes_typical: float
    load: int = 0

@dataclass
class Resident:
    id: str
    name: str
    age: int
    household_id: str
    home: Coord
    neighborhood: str
    income_band: str
    destination_id: str
    destination_kind: str
    destination: Coord
    mode: str
    schedule: Dict[str, int]
    current_pos: Coord
    status: str = "home"
    stress: float = 0.10
    trust: float = 0.50
    uncertainty: float = 0.20
    institutional_trust: float = 0.50
    route_delay: float = 0.0
    routine_adaptation: float = 0.0
    traits: Dict[str, float] = field(default_factory=dict)

    def as_hrm_agent_seed(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "age": self.age,
            "home": list(self.home),
            "neighborhood": self.neighborhood,
            "income_band": self.income_band,
            "destination_kind": self.destination_kind,
            "destination": list(self.destination),
            "mode": self.mode,
            "schedule": self.schedule,
            "state": {
                "stress": round(self.stress, 4),
                "trust": round(self.trust, 4),
                "uncertainty": round(self.uncertainty, 4),
                "institutional_trust": round(self.institutional_trust, 4),
            },
            "traits": self.traits,
        }

@dataclass
class CityTwinSnapshot:
    city: str
    seed: int
    synthetic_population_size: int
    households: List[Household]
    residents: List[Resident]
    places: List[Place]
    routes: List[RouteEdge]
    calibration: Dict[str, Any] = field(default_factory=dict)

    def to_public_dict(self, max_residents: Optional[int] = None) -> Dict[str, Any]:
        residents = self.residents if max_residents is None else self.residents[:max_residents]
        return {
            "city": self.city,
            "seed": self.seed,
            "synthetic_population_size": self.synthetic_population_size,
            "households": [asdict(h) for h in self.households],
            "residents": [asdict(r) for r in residents],
            "places": [asdict(p) for p in self.places],
            "routes": [asdict(r) for r in self.routes],
            "calibration": self.calibration,
        }
