from __future__ import annotations
import argparse
from pathlib import Path
from .models import CityTwinSnapshot
from .jackson_static import ALL_PLACES
from .synthesis import synthesize_population
from .routing import build_routes
from .calibration import build_calibration_report
from .hrm_bridge import export_hrm_city_twin

def build_jackson_twin(pop_size: int = 5000, seed: int = 42) -> CityTwinSnapshot:
    households, residents = synthesize_population(pop_size=pop_size, seed=seed)
    routes = build_routes(residents)
    calibration = build_calibration_report(residents, routes)
    return CityTwinSnapshot(
        city="Jackson, Tennessee",
        seed=seed,
        synthetic_population_size=pop_size,
        households=households,
        residents=residents,
        places=list(ALL_PLACES),
        routes=routes,
        calibration=calibration,
    )

def run_jackson_city_twin(pop_size: int = 5000, seed: int = 42, root: Path | None = None):
    root = root or Path.cwd()
    snapshot = build_jackson_twin(pop_size=pop_size, seed=seed)
    return export_hrm_city_twin(snapshot, root=root)

def main():
    parser = argparse.ArgumentParser(description="Build the HRM Jackson TN city-twin data layer.")
    parser.add_argument("--pop", type=int, default=5000, help="Synthetic resident count. Use 1000 for smoke tests; 5000+ for richer runs.")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--root", default=".", help="HRM root directory")
    args = parser.parse_args()
    written = run_jackson_city_twin(pop_size=args.pop, seed=args.seed, root=Path(args.root).resolve())
    print("HRM Jackson city twin generated.")
    for k, v in written.items():
        print(f"  {k}: {v}")

if __name__ == "__main__":
    main()
