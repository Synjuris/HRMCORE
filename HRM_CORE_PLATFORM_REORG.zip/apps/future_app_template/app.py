
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from hrm_core import HRMKernel, KernelConfig

def main():
    kernel = HRMKernel(KernelConfig(population=100, seed=1))
    kernel.tick(5)
    print(kernel.export_state()["metrics"])

if __name__ == "__main__":
    main()
