"""HRM Core Platform: generic simulation engine used by apps.

Apps should import hrm_core instead of editing the engine directly.
"""
from .kernel import HRMKernel, KernelConfig
from .state import AgentState, WorldState
