
# HRM Core API Contract

Apps do not edit HRM internals. Apps call this contract:

```python
from hrm_core import HRMKernel, KernelConfig
kernel = HRMKernel(KernelConfig(population=500, seed=42))
kernel.inject_event({"label":"shock", "x":50, "y":50, "radius":20, "stress_delta":0.15})
kernel.tick(10)
state = kernel.export_state()
```

Required stable methods:
- `create_world()`
- `inject_event(event_dict)`
- `tick(steps=1)`
- `export_state()`
- `save_state(path)`

Rule: Jackson, Simfeld, ARW, maps, dashboards, and future products live in `/apps`.
The engine lives in `/hrm_core`.
