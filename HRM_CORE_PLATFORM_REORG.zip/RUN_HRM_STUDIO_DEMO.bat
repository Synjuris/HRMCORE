@echo off
cd /d "%~dp0"
py apps\hrm_studio\run_core_demo.py
pause
