@echo off
cd /d "%~dp0"
py apps\simfeld\agentic_real_world\run_episode.py --simfeld
pause
