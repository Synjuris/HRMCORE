@echo off
cd /d "%~dp0"
py apps\arw\agentic_real_world\run_episode.py
pause
