@echo off
cd /d "%~dp0"
py apps\jackson_city_twin\hrm_city_twin\vendor_living_jackson\run_living_jackson.py
pause
